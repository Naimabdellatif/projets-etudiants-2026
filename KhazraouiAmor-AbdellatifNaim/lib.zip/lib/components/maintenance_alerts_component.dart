// ignore_for_file: deprecated_member_use

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:carhabti/services/piece_maintenance_service.dart';

class MaintenanceAlertsComponent extends StatefulWidget {
  final String immatriculation;
  
  const MaintenanceAlertsComponent({
    super.key,
    required this.immatriculation,
  });

  @override
  State<MaintenanceAlertsComponent> createState() => _MaintenanceAlertsComponentState();
}

class _MaintenanceAlertsComponentState extends State<MaintenanceAlertsComponent> with SingleTickerProviderStateMixin {
  final PieceMaintenanceService _maintenanceService = PieceMaintenanceService();
  Map<String, MaintenanceAlert> _alerts = {};
  bool _isLoading = true;
  late AnimationController _animationController;
  
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    
    // Initialiser le service et charger les alertes
    _initializeService();
  }
  
  Future<void> _initializeService() async {
    try {
      // Initialiser le service de notifications
      await _maintenanceService.initialize();
      
      // Déclencher la vérification des dates de maintenance
      await _maintenanceService.checkMaintenanceDates(widget.immatriculation);
      
      // Charger les alertes
      await _loadAlerts();
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors de l\'initialisation du service: $e');
      }
      setState(() => _isLoading = false);
    }
  }
  
  Future<void> _loadAlerts() async {
    try {
      setState(() => _isLoading = true);
      
      // Vérifie d'abord si le véhicule existe
      final immatriculation = widget.immatriculation;
      if (kDebugMode) {
        print('🔍 Chargement des alertes pour le véhicule: $immatriculation');
      }

      // Attendre que les dates de maintenance soient synchronisées avec les prédictions
      await _maintenanceService.checkMaintenanceDates(immatriculation);
      
      // Récupérer les alertes de maintenance après synchronisation
      final alerts = await _maintenanceService.getMaintenanceAlerts(immatriculation);
      
      if (kDebugMode) {
        print('📊 ${alerts.length} alertes trouvées pour $immatriculation');
      }
      
      setState(() {
        _alerts = alerts;
        _isLoading = false;
      });
      
      // Démarrer l'animation une fois les données chargées
      _animationController.forward();
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors du chargement des alertes: $e');
      }
      setState(() => _isLoading = false);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _buildLoadingWidget();
    }
    
    if (_alerts.isEmpty) {
      return _buildNoAlertsWidget();
    }
    
    return _buildAlertsWidget();
  }
  
  Widget _buildLoadingWidget() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
      child: Container(
        padding: EdgeInsets.all(16.w),
        width: double.infinity,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Vérification des alertes de maintenance...',
              style: GoogleFonts.poppins(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 16.h),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildNoAlertsWidget() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
      child: Container(
        padding: EdgeInsets.all(16.w),
        width: double.infinity,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 48.sp),
            SizedBox(height: 8.h),
            Text(
              'Aucune alerte de maintenance',
              style: GoogleFonts.poppins(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8.h),
            Text(
              'Votre véhicule est en parfait état !',
              style: GoogleFonts.poppins(
                fontSize: 14.sp,
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 8.h),
            ElevatedButton.icon(
              icon: Icon(Icons.refresh),
              label: Text('Rafraîchir'),
              onPressed: _loadAlerts,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildAlertsWidget() {
    // Trier les alertes par priorité (critique en premier)
    final sortedAlerts = _alerts.values.toList()
      ..sort((a, b) => a.priority.index.compareTo(b.priority.index));
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
      child: Container(
        padding: EdgeInsets.all(16.w),
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Alertes de maintenance',
                  style: GoogleFonts.poppins(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.refresh),
                  onPressed: _loadAlerts,
                  tooltip: 'Rafraîchir les alertes',
                ),
              ],
            ),
            SizedBox(height: 12.h),
            // Liste des alertes
            ...sortedAlerts.map((alert) => _buildAlertItem(alert)),
            // Légende
            SizedBox(height: 16.h),
            _buildLegend(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildAlertItem(MaintenanceAlert alert) {
    final Animation<double> animation = CurvedAnimation(
      parent: _animationController,
      curve: Interval(
        0.1 * _alerts.values.toList().indexOf(alert),
        0.9,
        curve: Curves.easeOut,
      ),
    );
    
    return FadeTransition(
      opacity: animation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0.5, 0),
          end: Offset.zero,
        ).animate(animation),
        child: Padding(
          padding: EdgeInsets.only(bottom: 12.h),
          child: Container(
            decoration: BoxDecoration(
              color: alert.color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10.r),
              border: Border.all(color: alert.color, width: 1),
            ),
            padding: EdgeInsets.all(12.w),
            child: Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: alert.color.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  padding: EdgeInsets.all(8.w),
                  child: Icon(alert.icon, color: alert.color),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        alert.componentName,
                        style: GoogleFonts.poppins(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        alert.message,
                        style: GoogleFonts.poppins(
                          fontSize: 14.sp,
                          color: Colors.grey[800],
                        ),
                      ),
                      Text(
                        'Date prévue: ${alert.formattedDate}',
                        style: GoogleFonts.poppins(
                          fontSize: 12.sp,
                          color: Colors.grey[600],
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),
                _buildPriorityIndicator(alert.priority),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  Widget _buildPriorityIndicator(NotificationPriority priority) {
    IconData icon;
    Color color;
    String tooltip;
    
    switch (priority) {
      case NotificationPriority.critical:
        icon = Icons.error;
        color = Colors.red;
        tooltip = 'Critique';
        break;
      case NotificationPriority.warning:
        icon = Icons.warning;
        color = Colors.orange;
        tooltip = 'Attention';
        break;
      case NotificationPriority.info:
        icon = Icons.info;
        color = Colors.blue;
        tooltip = 'Information';
        break;
      case NotificationPriority.normal:
        icon = Icons.check_circle;
        color = Colors.green;
        tooltip = 'Normal';
        break;
      default:
        icon = Icons.help;
        color = Colors.grey;
        tooltip = 'Inconnu';
    }
    
    return Tooltip(
      message: tooltip,
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        padding: EdgeInsets.all(8.w),
        child: Icon(icon, color: color, size: 24.sp),
      ),
    );
  }
  
  Widget _buildLegend() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Légende:',
          style: GoogleFonts.poppins(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 8.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildLegendItem(
              icon: Icons.error,
              color: Colors.red,
              label: 'Critique',
            ),
            _buildLegendItem(
              icon: Icons.warning,
              color: Colors.orange,
              label: 'Attention',
            ),
            _buildLegendItem(
              icon: Icons.info,
              color: Colors.blue,
              label: 'Information',
            ),
            _buildLegendItem(
              icon: Icons.check_circle,
              color: Colors.green,
              label: 'Normal',
            ),
          ],
        ),
      ],
    );
  }
  
  Widget _buildLegendItem({
    required IconData icon,
    required Color color,
    required String label,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: color, size: 16.sp),
        SizedBox(width: 4.w),
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 12.sp,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}

class MaintenanceCalendarComponent extends StatefulWidget {
  final String immatriculation;
  
  const MaintenanceCalendarComponent({
    super.key,
    required this.immatriculation,
  });

  @override
  State<MaintenanceCalendarComponent> createState() => _MaintenanceCalendarComponentState();
}

class _MaintenanceCalendarComponentState extends State<MaintenanceCalendarComponent> {
  final PieceMaintenanceService _maintenanceService = PieceMaintenanceService();
  Map<String, MaintenanceAlert> _alerts = {};
  bool _isLoading = true;
  
  @override
  void initState() {
    super.initState();
    _loadAlerts();
  }
  
  Future<void> _loadAlerts() async {
    try {
      setState(() => _isLoading = true);
      
      // Récupérer les alertes de maintenance
      final alerts = await _maintenanceService.getMaintenanceAlerts(widget.immatriculation);
      
      setState(() {
        _alerts = alerts;
        _isLoading = false;
      });
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors du chargement des alertes: $e');
      }
      setState(() => _isLoading = false);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
        child: Container(
          padding: EdgeInsets.all(16.w),
          width: double.infinity,
          height: 200.h,
          child: Center(
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.r)),
      child: Container(
        padding: EdgeInsets.all(16.w),
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Calendrier de maintenance',
              style: GoogleFonts.poppins(
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 16.h),
            _buildCalendar(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildCalendar() {
    if (_alerts.isEmpty) {
      return Center(
        child: Column(
          children: [
            Icon(Icons.calendar_today, size: 48.sp, color: Colors.grey),
            SizedBox(height: 8.h),
            Text(
              'Aucune date de maintenance programmée',
              style: GoogleFonts.poppins(
                fontSize: 14.sp,
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
    
    // Trier les alertes par date (la plus proche en premier)
    final sortedAlerts = _alerts.values.toList()
      ..sort((a, b) => a.maintenanceDate.compareTo(b.maintenanceDate));
    
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: sortedAlerts.length,
      itemBuilder: (context, index) {
        final alert = sortedAlerts[index];
        return _buildTimelineItem(alert, index == sortedAlerts.length - 1);
      },
    );
  }
  
  Widget _buildTimelineItem(MaintenanceAlert alert, bool isLast) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 20.w,
              height: 20.w,
              decoration: BoxDecoration(
                color: alert.color,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.check,
                color: Colors.white,
                size: 12.sp,
              ),
            ),
            if (!isLast)
              Container(
                width: 2.w,
                height: 50.h,
                color: Colors.grey[300],
              ),
          ],
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                alert.formattedDate,
                style: GoogleFonts.poppins(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                'Changement de ${alert.componentName}',
                style: GoogleFonts.poppins(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                alert.message,
                style: GoogleFonts.poppins(
                  fontSize: 12.sp,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 8.h),
            ],
          ),
        ),
      ],
    );
  }
}

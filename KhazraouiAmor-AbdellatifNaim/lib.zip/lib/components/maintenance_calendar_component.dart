import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/piece_maintenance_service.dart';

/// Composant affichant un calendrier des dates de maintenance
class MaintenanceCalendarComponent extends StatefulWidget {
  final String immatriculation;

  const MaintenanceCalendarComponent({
    super.key, 
    required this.immatriculation,
  });

  @override
  State<MaintenanceCalendarComponent> createState() => _MaintenanceCalendarComponentState();
}

class _MaintenanceCalendarComponentState extends State<MaintenanceCalendarComponent> {
  final _maintenanceService = PieceMaintenanceService();
  bool _isLoading = true;
  List<MaintenanceEvent> _maintenanceEvents = [];

  @override
  void initState() {
    super.initState();
    _loadMaintenanceDates();
  }

  Future<void> _loadMaintenanceDates() async {
    setState(() => _isLoading = true);
    try {
      // Récupérer les dates de maintenance
      final maintenanceDates = await _maintenanceService.getMaintenanceDates(widget.immatriculation);
      
      // Convertir les dates en événements de maintenance
      List<MaintenanceEvent> events = [];
      
      // Composants à vérifier
      final components = {
        'changement_batterie': 'Batterie',
        'changement_vidange': 'Vidange',
        'changement_freins': 'Freins',
        'changement_pneus': 'Pneus',
        'changement_amortisseurs': 'Amortisseurs',
        'changement_courroie': 'Courroie',
        'changement_embrayage': 'Embrayage',
      };
      
      // Pour chaque composant, créer un événement de maintenance
      for (final entry in components.entries) {
        final String dbField = entry.key;
        final String componentName = entry.value;
        
        if (maintenanceDates[dbField] != null) {
          final DateTime date = DateTime.parse(maintenanceDates[dbField]);
          
          events.add(
            MaintenanceEvent(
              title: componentName,
              date: date,
            ),
          );
        }
      }
      
      setState(() {
        _maintenanceEvents = events;
        _isLoading = false;
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors du chargement des dates de maintenance: $e');
      }
      setState(() => _isLoading = false);
    }
  }

  /// Récupère tous les événements de maintenance triés par date
  List<MaintenanceEvent> _getAllEvents() {
    // Trier les événements par date (les plus proches en premier)
    _maintenanceEvents.sort((a, b) => a.date.compareTo(b.date));
    return _maintenanceEvents;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: _isLoading 
          ? const Center(child: CircularProgressIndicator())
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // En-tête du calendrier simplifié
                Text(
                  'Calendrier de maintenance',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16.0),
                
                // Liste des prochaines maintenances
                Text(
                  'Prochaines maintenances',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8.0),
                ..._getAllEvents().map((event) => _buildEventItem(event)),
                if (_getAllEvents().isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Aucune maintenance planifiée prochainement'),
                  ),
              ],
            ),
      ),
    );
  }

  Widget _buildEventItem(MaintenanceEvent event) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: const BoxDecoration(
              color: Colors.blue,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8.0),
          Expanded(
            child: Text(
              '${event.title} - ${DateFormat('dd/MM/yyyy').format(event.date)}',
              style: const TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}

/// Classe représentant un événement de maintenance
class MaintenanceEvent {
  final String title;
  final DateTime date;

  MaintenanceEvent({
    required this.title,
    required this.date,
  });
}

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:Carhabti/interfaces/ClientDashboard.dart';
import 'package:Carhabti/interfaces/DefintionApp.dart';
import 'package:Carhabti/magasin_model/Carhabti_theme.dart';
import 'package:Carhabti/interfaces/GetStarted.dart';
import 'package:Carhabti/notif.dart';
import 'package:Carhabti/pieces_form/amortisseurs_form.dart';
import 'package:Carhabti/pieces_form/batterie_form.dart';
import 'package:Carhabti/pieces_form/courroie_form.dart';
import 'package:Carhabti/pieces_form/embrayage_form.dart';
import 'package:Carhabti/pieces_form/pneus_form.dart';
import 'package:Carhabti/interfaces/show.dart';
import 'package:Carhabti/services/maintenance_notification_service.dart';
import 'package:Carhabti/services/notification_manager.dart';
import 'package:Carhabti/services/contextual_notification_service.dart';
import 'package:Carhabti/supabase_connexion.dart';
import 'package:Carhabti/pieces_form/vidange_form.dart';
import 'package:Carhabti/magasin_model/ProfileScreen.dart';
import 'package:Carhabti/interfaces/settings.dart';
import 'package:Carhabti/notif_details.dart';
import 'package:Carhabti/assistant financier/financial_dashboard.dart';
import 'package:Carhabti/assistant financier/add_expense_screen.dart';
import 'package:Carhabti/assistant financier/expense_list_screen.dart';
import 'package:Carhabti/assistant financier/financial_settings_screen.dart';
import 'package:Carhabti/ai_assistant/ui/chat_screen.dart';
import 'package:Carhabti/ai_assistant/ui/model_management_screen.dart';
import 'package:Carhabti/ai_assistant/ui/assistant_dashboard.dart';
import 'package:Carhabti/garages_pro/screens/notif_garage_screen.dart';
import 'pieces_form/freins_form.dart';
import 'pieces_form/vehicule_form.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:intl/date_symbol_data_local.dart';

/// Fonction pour récupérer la dernière immatriculation active de l'utilisateur
Future<String?> _getLastActiveImmatriculation() async {
  try {
    const storage = FlutterSecureStorage();
    final immatriculation =
        await storage.read(key: 'last_active_immatriculation');

    // Si une immatriculation est stockée et non vide, la retourner
    if (immatriculation != null && immatriculation.isNotEmpty) {
      return immatriculation;
    }

    // Sinon, essayer d'en récupérer une depuis Supabase
    try {
      // Utiliser la connexion Supabase existante depuis supabase_connexion.dart
      final user = supabase.auth.currentUser;

      if (user != null) {
        final vehiculesData = await supabase
            .from('voiture')
            .select('immatriculation')
            .eq('user_id', user.id)
            .limit(1);

        if (vehiculesData.isNotEmpty) {
          // Vérifiez que l'immatriculation existe et n'est pas nulle
          final immatData = vehiculesData[0]['immatriculation'];
          if (immatData != null) {
            final firstVehicleImmat = immatData.toString();
            // Enregistrer pour utilisation future seulement si non vide
            if (firstVehicleImmat.isNotEmpty) {
              await storage.write(
                  key: 'last_active_immatriculation', value: firstVehicleImmat);
              return firstVehicleImmat;
            }
          }
        }
      }
    } catch (e) {
      debugPrint(
          'Erreur lors de la récupération des véhicules depuis Supabase: $e');
    }
    return null;
  } catch (e) {
    debugPrint(
        'Erreur lors de la récupération de l\'immatriculation active: $e');
    return null;
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Charger les variables d'environnement (clé API Gemini, etc.)
  try {
    await dotenv.load(fileName: 'assets/.env');
    if (kDebugMode) print('[ENV] Fichier .env chargé avec succès');
  } catch (e) {
    if (kDebugMode) print('[ENV] Impossible de charger .env: $e');
  }

  await initSupabase();
  // Properly initialize the FlutterSecureStorage with await
  await const FlutterSecureStorage().read(key: 'test_init');

  // Initialize path_provider explicitly to avoid MissingPluginException
  try {
    await getApplicationDocumentsDirectory();
    if (kDebugMode) {
      print('Path provider initialized successfully');
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error initializing path_provider: $e');
    }
  }

  // Initialiser les données de timezone pour les notifications planifiées
  tz.initializeTimeZones();

  // Initialiser les données de locale pour le français
  await initializeDateFormatting('fr_FR', null);

  // Initialiser Firebase avec gestion d'erreur
  try {
    // Initialiser Firebase avec des options explicites pour éviter de charger depuis les ressources
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyDqkPIB-QOTAJ8Qv0rnbBrETuYgvjUCzEs",
        appId: "1:795881380850:android:6c99bc14b2df31ac00e5e3",
        messagingSenderId: "795881380850",
        projectId: "karhabti-54edc",
      ),
    );

    // Initialiser le nouveau gestionnaire de notifications
    final notificationManager = NotificationManager();
    await notificationManager.initialize();

    // Déprécié : Ancien service, maintenu pour la compatibilité temporaire
    // À supprimer dans une future mise à jour
    final maintenanceNotificationService = MaintenanceNotificationService();
    await maintenanceNotificationService.initialize();

    // Initialiser notre nouveau service de notifications contextuelles
    final contextualNotificationService = ContextualNotificationService();
    await contextualNotificationService.initialize();

    // Variable globale pour stocker la dernière immatriculation active
    // (sera utilisée au démarrage de l'app pour vérifier les notifications)
    String? lastActiveImmatriculation = await _getLastActiveImmatriculation();

    // Vérifier les notifications traditionnelles
    notificationManager.checkMaintenanceNeeds().then((count) {
      if (count > 0) {
        if (kDebugMode) {
          print('$count notifications générales créées au démarrage');
        }
      }
    });

    // Déclencher les notifications contextuelles si une immatriculation est disponible
    if (lastActiveImmatriculation != null) {
      contextualNotificationService
          .checkMaintenanceForActiveVehicle(
        immatriculation: lastActiveImmatriculation,
      )
          .then((count) {
        if (count > 0) {
          if (kDebugMode) {
            print(
                '$count notifications contextuelles créées pour $lastActiveImmatriculation');
          }
        }
      });
    }

    // Configurer Firebase Cloud Messaging pour les notifications push
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
  } catch (e) {
    if (kDebugMode) {
      print('Erreur lors de l\'initialisation de Firebase: $e');
    }
    // Continuer l'exécution même si Firebase n'est pas disponible
  }

  runApp(const AutoCareApp());
}

// Gestionnaire de messages en arrière-plan pour Firebase Cloud Messaging
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  if (kDebugMode) {
    print('Handling a background message: ${message.messageId}');
  }
}

class AutoCareApp extends StatelessWidget {
  const AutoCareApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Wrap MaterialApp with ScreenUtilInit to initialize flutter_screenutil
    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Carhabti - Assistant Automobile',
          // Configuration des localisations pour le français
          localizationsDelegates: [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          // Langues supportées
          supportedLocales: [
            const Locale('fr', 'FR'), // Français
            const Locale('en', 'US'), // Anglais
          ],
          // Locale par défaut
          locale: const Locale('fr', 'FR'),
          theme: KTheme.themeData,
          initialRoute: '/',
          routes: {
            '/': (context) => VehiculeAssistantDashboard(),
            '/Commencer': (context) => const Getstarted(),
            '/VehiculeInfoForm': (context) => const VehiculeInfoForm(),
            '/show': (context) {
              // Récupérer les arguments passés lors de la navigation
              final args = ModalRoute.of(context)!.settings.arguments
                  as Map<String, dynamic>;
              return ShowScreen(
                predictions: args['predictions'] as Map<String, double>,
                immatriculation: args['immatriculation'] as String,
              );
            },
            '/pneus': (context) {
              // Récupérer l'immatriculation passée via les arguments
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return PneusForm(
                immatriculation: immatriculation,
                initialData: {},
              );
            },
            '/vidange': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return VidangeForm(
                immatriculation: immatriculation,
              );
            },
            '/batterie': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return BatterieForm(immatriculation: immatriculation);
            },
            '/courroie': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return CourroieForm(immatriculation: immatriculation);
            },
            '/amortisseurs': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return AmortisseursForm(immatriculation: immatriculation);
            },
            '/embrayage': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return EmbrayageForm(immatriculation: immatriculation);
            },
            '/freins': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return FreinsForm(immatriculation: immatriculation);
            },
            '/dashboard': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return ClientDashboard(immatriculation: immatriculation);
            },
            '/settings': (context) => const SettingsScreen(),
            '/profile': (context) => const ProfileScreen(),
            '/notifications': (context) => const NotificationPage(),
            '/notification_details': (context) {
              final notification = ModalRoute.of(context)!.settings.arguments
                  as Map<String, dynamic>;
              return NotificationDetailsScreen(notification: notification);
            },

            // Routes pour l'assistant financier
            '/financialAssistant/dashboard': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return FinancialDashboard(immatriculation: immatriculation);
            },
            '/financialAssistant/addExpense': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return AddExpenseScreen(immatriculation: immatriculation);
            },
            '/financialAssistant/expenseList': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return ExpenseListScreen(immatriculation: immatriculation);
            },
            '/financialAssistant/settings': (context) {
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return FinancialSettingsScreen(
                immatriculation: immatriculation,
                onBudgetUpdated: (double newBudget) {},
              );
            },
            '/financialAssistant/expenseDetail': (context) {
              final args = ModalRoute.of(context)!.settings.arguments
                  as Map<String, dynamic>;
              return AddExpenseScreen(
                immatriculation: args['immatriculation'] as String,
                expense: args['expense'],
              );
            },
            // Routes pour l'assistant mécanique IA
            '/mechanicAssistant/chat': (context) {
              // Simplement retourner l'écran, les arguments seront gérés dans le State
              return const MechanicChatScreen();
            },
            '/mechanicAssistant/modelManagement': (context) {
              return ModelManagementScreen();
            },
            '/mechanicAssistant/dashboard': (context) {
              // Ici, on récupère toujours l'argument pour le passer au Dashboard
              final immatriculation =
                  ModalRoute.of(context)!.settings.arguments as String;
              return MechanicAssistantDashboard(
                  immatriculation: immatriculation);
            },
            '/garages/appointments': (context) => const MyAppointmentsScreen(),
          },
        );
      },
    );
  }
}

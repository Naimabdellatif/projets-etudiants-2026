// ignore_for_file: unused_field, unused_element, unused_local_variable, curly_braces_in_flow_control_structures

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PredictionCalculator {
  // SECTION: RÉFÉRENCES DE DURÉE DE VIE OPTIMALE DES PIÈCES
  // Ces valeurs servent de point central pour les algorithmes prédictifs
  // Basées sur des sources réelles et fiables des constructeurs automobiles

  // Durée de vie optimale des pièces en conditions normales (conduite et usage normaux)
  static const Map<String, Map<String, dynamic>> _referenceDureeVieOptimale = {
    'freins': {
      'km_min': 90000.0, // Valeur minimale: 90 000 km
      'km_max': 100000.0, // Valeur maximale: 100 000 km
      'km_intensif': 50000.0, // Usage intensif/louage: 50 000 km
      'km_intensif_max': 60000.0, // Usage intensif max: 60 000 km
      'km_median': 95000.0, // Valeur médiane pour calculs
      'km_intensif_median': 55000.0, // Valeur médiane usage intensif
      'ans': null, // Pas de référence en années pour les freins
    },
    'pneus': {
      'km_min': 60000.0, // Valeur minimale: 60 000 km
      'km_max': 80000.0, // Valeur maximale: 80 000 km
      'km_median': 70000.0, // Valeur médiane pour calculs
      'ans_min': 3, // Durée minimale: 3 ans
      'ans_max': 5, // Durée maximale: 4 ans
      'ans_median': 3.5, // Valeur médiane pour calculs
    },
    'batterie': {
      'ans_essence': 2, // Véhicules à essence: 2 ans max
      'ans_diesel': 1, // Véhicules diesel: 1 an max
    },
    'embrayage': {
      'km_min': 150000.0, // Valeur minimale: 150 000 km
      'km_max': 180000.0, // Valeur maximale: 180 000 km
      'km_median': 165000.0, // Valeur médiane pour calculs
      'ans': null, // Pas de référence en années pour l'embrayage
    },
    'amortisseurs': {
      'km_min': 65000.0, // Valeur minimale: 65 000 km
      'km_max': 80000.0, // Valeur maximale: 80 000 km
      'km_median': 72500.0, // Valeur médiane pour calculs
      'ans_min': 3, // Durée minimale: 3 ans
      'ans_max': 6, // Durée maximale: 4 ans
      'ans_median': 3.5, // Valeur médiane pour calculs
      'ans_intensif': 1, // 1 an pour usage intensif/louage
    },
    'courroie': {
      'km_max': 80000.0, // Valeur maximale: 80 000 km
      'km_intensif': 50000.0, // Usage intensif/louage: 50 000 km
      'ans': null, // Pas de référence en années pour la courroie
    },
  };

  // SECTION: FACTEURS D'USURE AMÉLIORÉS BASÉS SUR DES DONNÉES RÉELLES

  // Facteurs de route - impact sur l'usure des pièces
  static const _roadFactorsExpert = {
    'Autoroute': 0.75, // Usure plus faible due à une vitesse constante
    'Entre les pays': 0.78, // Similaire à l'autoroute
    'Campagne': 0.95, // Routes à vitesse modérée
    'Entre-région': 0.92, // Routes nationales/régionales
    'Asphelte': 0.90, // Surface standard
    'Beton': 0.93, // Surface plus dure
    'Urbain': 1.45, // Trafic dense, arrêts/démarrages fréquents
    'Centre-ville': 1.55, // Encore plus d'arrêts/démarrages
    'Montagne': 1.35, // Impact sur les freins et transmissions
    'Gravier': 1.70, // Surface non-pavée
    'Terre': 1.75, // Impact sur la suspension et le chassis
    'Piste': 1.80, // Impact maximal
    'default': 1.0, // Valeur standard
  };

  static const _dailyKmFactorsExpert = {
    // Severity multiplier based on daily kilometers
    'long': 0.85, // > 50 km
    'medium': 1.0, // 25-50 km
    'short': 1.3, // 10-25 km
    'very_short': 1.6, // < 10 km
  };

  static const _temperatureFactorsBatteryExpert = {
    // Degradation multiplier based on ambient temperature
    "> 35C°": 1.8,
    "< 0C°": 1.4,
    "0C°-20C°": 1.15,
    "20C°-35C°": 1.0,
    "default": 1.0,
  };

  static const _locationFactorsBatteryExpert = {
    // Degradation multiplier based on driving location
    'Centre-ville': 1.6,
    'Urbain': 1.6,
    'Désert': 1.3,
    'Campagne': 1.1,
    'Entre-région': 1.0,
    'Autoroute': 1.0,
    'Entre les pays': 1.0,
    'default': 1.1,
  };

  static const _timeConduiteFactorsBatteryExpert = {
    // Degradation multiplier based on driving time
    'Nocturne': 1.3,
    'Journalière': 1.0,
    'default': 1.0,
  };

  static const _dailyKmFactorsBatteryExpert = {
    // Degradation multiplier based on daily kilometers
    'very_short': 1.7, // < 15 km
    'short': 1.2, // 15-30 km
    'medium_long': 1.0, // > 30 km
  };

  static const _weatherFactorsBatteryExpert = {
    // Minor degradation multiplier based on general weather
    'Aride': 1.05,
    'Chaude': 1.05,
    'Humide': 1.05,
    'Pluies': 1.05,
    'Froid': 1.05,
    'default': 1.0,
  };

  static const _roadFactors = {
    'Autoroute': 0.8,
    'Urbain': 1.0,
    'Terre': 2.5,
    'Asphelte': 1.1,
    'Fourage': 1.8,
    'Beton': 1.3,
    'Gravier': 1.7,
    'Piste': 2.5,
    "Montagne": 2.0,
  };

  static const _engineTypeFactors = {
    'Essence': 1.0,
    'Diesel': 1.2,
    'Electrique': 0.8,
    'Hybride': 1.1,
  };

  // Suppression de _manufacturerCurves qui n'est pas utilisé dans le code

  static const _usageFactors = {
    'Quotidienne': 0.8,
    'Charges lourdes': 1.8,
    'Transport de livraison': 1.8,
    'Voyage': 1.0,
    'Louage': 1.5,
    'Taxi': 1.1,
    'Autre': 1.3,
    'default': 1.1,
  };

  static const _drivingStyleFactors = {
    'Calme': 1.0,
    'Normal': 1.3,
    'Sportif': 1.8,
  };

  static const _weatherFactors = {
    'Sub-Humide': 1.1,
    'Semi-Aride': 1.2,
    'Aride': 1.3,
    'Froid': 1.2,
    'Tempéré': 1.0,
    'Humide': 1.1,
    'Chaude': 1.3,
    'Pluies': 1.1,
  };

  static const _timeConduiteFactors = {'Journalière': 1.0, 'Nocturne': 1.1};

  static const _temperatureFactors = {
    "0C°-20C°": 0.8,
    "20C°-40C°": 1.1,
    "> 40C°": 1.5,
  };

  // --- Base Intervals (Values based on industry standards) ---
  static const double _baseKmIntervalPetrol = 8000.0;
  static const double _baseKmIntervalDiesel = 11000.0;
// 1 year
// Average lifespan
  static const int _baseTimeIntervalDaysOilExpert =
      137; // Strict Cap: ~4.5 months

  // Region: Instance Variables and Initialization
  // --------------------------------------------------------------------------
  final String immatriculation;
  final SupabaseClient supabase;
  final Map<String, dynamic> rawFacteurData;

  PredictionCalculator(
      {required this.immatriculation,
      required this.rawFacteurData,
      required Map<String, dynamic> rawData})
      : supabase = Supabase.instance.client;

  // Region: Utilitaires
  // --------------------------------------------------------------------------

  // Méthode utilitaire pour parser les doubles depuis différents formats
  static double _parseDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is num) return value.toDouble();
    final numericString = value.toString().replaceAll(RegExp(r'[^0-9.]'), '');
    return double.tryParse(numericString) ?? 0.0;
  }

  // Méthode pour analyser l'utilisation des routes
  static Map<String, double> _parseRoadUsage(dynamic input) {
    if (input is Map<String, dynamic>) {
      return input.map((k, v) => MapEntry(k, _parseDouble(v)));
    } else if (input is String) {
      final types = input
          .split(',')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();
      if (types.isEmpty) return {'Autoroute': 1.0};
      final factorPerType = 1.0 / types.length; // Répartition égale
      return {for (var type in types) type: factorPerType};
    }
    return {'Autoroute': 1.0}; // Valeur par défaut
  }

  // Calcul du facteur composite de route
  double _calculateCompositeRoadFactor(Map<String, double> roadUsage) {
    if (roadUsage.isEmpty) return 1.0;
    double totalFactor = 0.0;
    double totalWeight = 0.0;

    roadUsage.forEach((key, value) {
      totalFactor += (_roadFactors[key] ?? 1.0) * value;
      totalWeight += value;
    });

    return (totalWeight > 0) ? totalFactor / totalWeight : 1.0;
  }

  // Calcul de la sévérité de conduite
  double _calculateDrivingSeverity(String drivingStyle, String engineType) {
    return (_drivingStyleFactors[drivingStyle] ?? 1.15) *
        (_engineTypeFactors[engineType] ?? 1.0);
  }

  // Parsing de température
  double _parseTemperature(String tempRange) {
    switch (tempRange) {
      case "< 0C°":
        return -5.0;
      case "0C°-20C°":
        return 10.0;
      case "20C°-35C°":
        return 27.5;
      case "> 35C°":
        return 40.0;
      default:
        final numericPattern = RegExp(r'(\d+)');
        final matches = numericPattern.allMatches(tempRange);
        if (matches.isNotEmpty) {
          try {
            return double.parse(matches.first.group(0)!);
          } catch (_) {
            return 25.0;
          }
        }
        return 25.0;
    }
  }

  // Récupération de la plage de température
  String _getTempRange(String temp) {
    final value = _parseTemperature(temp);
    if (value < 0) return "< 0C°";
    if (value >= 0 && value < 20) return "0C°-20C°";
    if (value >= 20 && value <= 35) return "20C°-35C°";
    return "> 35C°";
  }

  // Calcul du nombre de jours depuis l'installation
  int _calculateDaysSinceInstallation(String? date) {
    try {
      return date != null
          ? DateTime.now().difference(DateTime.parse(date)).inDays
          : 30;
    } catch (_) {
      return 30;
    }
  }

  // Validation des dates
  DateTime _validateDate(dynamic date, [int defaultSubtractDays = 365]) {
    if (date == null) {
      return DateTime.now().subtract(Duration(days: defaultSubtractDays));
    }
    try {
      return DateTime.parse(date.toString());
    } catch (e) {
      debugPrint("Error parsing date: $date, defaulting. Error: $e");
      return DateTime.now().subtract(Duration(days: defaultSubtractDays));
    }
  }

  // Nouvelle méthode pour calculer l'âge du véhicule automatiquement
  Future<int> _calculateVehicleAge() async {
    try {
      // Récupérer l'année de fabrication de la table voiture en utilisant l'immatriculation
      final voitureData = await supabase
          .from('voiture')
          .select('annee')
          .eq('immatriculation', immatriculation)
          .maybeSingle();

      if (voitureData == null || voitureData['annee'] == null) {
        debugPrint(
            "Impossible de récupérer l'année du véhicule, utilisation de la valeur par défaut (5 ans)");
        return 5; // Valeur par défaut si l'année n'est pas trouvée
      }

      final int annee = voitureData['annee'];
      final int currentYear = DateTime.now().year;
      final int age = currentYear - annee;

      debugPrint(
          "Âge calculé du véhicule: $age ans (année de fabrication: $annee)");
      return age > 0
          ? age
          : 1; // Au moins 1 an pour éviter des calculs incorrects
    } catch (e) {
      debugPrint("Erreur lors du calcul de l'âge du véhicule: $e");
      return 5; // Valeur par défaut en cas d'erreur
    }
  }

  // Récupération des facteurs du véhicule
  Future<Map<String, dynamic>> _fetchVehicleFactors() async {
    if (rawFacteurData.isEmpty) {
      throw Exception("Aucune donnée facteur disponible");
    }

    // Combinaison des clés requises pour toutes les vérifications
    const requiredKeysCombined = {
      'total_km',
      'date_installation_pneus',
      'daily_km',
      'date_dernier_vidange',
      'type_de_moteur',
      'condition_de_utilisation',
      'type_de_route',
    };

    // Vérification des clés
    final missingKeys = requiredKeysCombined
        .where((key) => !rawFacteurData.containsKey(key))
        .toList();

    if (missingKeys.isNotEmpty) {
      throw Exception(
          "Données incomplètes pour le calcul expert. Clés manquantes : ${missingKeys.join(', ')}");
    }

    // Récupérer les données avec l'âge du véhicule calculé automatiquement
    Map<String, dynamic> data = Map.from(rawFacteurData);
    final vehicleAge = await _calculateVehicleAge();

    // Remplacer age_de_vehicule s'il existait déjà ou l'ajouter
    data['age_de_vehicule'] = vehicleAge;

    return data;
  }

  // Sauvegarde des prédictions
  Future<void> savePredictions(Map<String, double> predictions) async {
    try {
      await supabase.from('predictions').upsert({
        'fk_immatriculation': immatriculation,
        ...predictions,
        'updated_at': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      debugPrint("Erreur lors de la sauvegarde : $e");
      rethrow;
    }
  }

  // Modifier calculateAllPredictions pour sauvegarder après calcul
  Future<Map<String, double>> calculateAllPredictions() async {
    try {
      final data = await _fetchVehicleFactors();

      // Afficher l'âge du véhicule dans les logs pour vérification
      debugPrint(
          "Calcul des prédictions avec âge du véhicule: ${data['age_de_vehicule']} ans");

      final results = {
        'tire_wear': _calculateTireWear(data),
        'brake_wear': _calculateBrakeWear(data),
      };

      // Si les méthodes manquantes sont définies, les utiliser également
      // Sinon, utiliser des valeurs par défaut
      try {
        results['battery_health'] = _calculateBatteryHealth(data);
      } catch (e) {
        results['battery_health'] = 50.0;
      }
      try {
        results['clutch_wear'] = _calculateClutchWear(data);
      } catch (e) {
        results['clutch_wear'] = 30.0;
      }
      try {
        results['ShockAbsorber_Wear'] = _calculateShockAbsorberWear(data);
      } catch (e) {
        results['ShockAbsorber_Wear'] = 40.0;
      }
      try {
        results['oil_change'] = _calculateOilChange(data);
      } catch (e) {
        results['oil_change'] = 45.0;
      }
      try {
        results['belt_risk'] = _calculateBeltRisk(data);
      } catch (e) {
        results['belt_risk'] = 35.0;
      }

      // Assurez-vous que toutes les valeurs sont des doubles valides
      results.forEach((key, value) {
        results[key] = ((value.isNaN)) ? 0.0 : value;
      });

      // Sauvegarde des prédictions
      await savePredictions(results);
      return results;
    } catch (e, stack) {
      debugPrint("Erreur dans calculateAllPredictions: $e\n$stack");
      // Valeurs par défaut en cas d'erreur
      return {
        'tire_wear': 50.0,
        'oil_change': 45.0,
        'belt_risk': 35.0,
        'battery_health': 50.0,
        'brake_wear': 40.0,
        'clutch_wear': 30.0,
        'ShockAbsorber_Wear': 40.0,
      };
    }
  }

  double _calculateBrakeWear(Map<String, dynamic> data) {
    try {
      debugPrint("Début du calcul optimisé de l'usure des freins");

      // 1. Extraction et validation des données
      final installationDateStr = data['date_installation_frein'] as String?;
      if (installationDateStr == null) {
        return 50.0; // Usure moyenne si date inconnue
      }

      final installationDate = DateTime.parse(installationDateStr);
      final now = DateTime.now();
      final ageInDays = now.difference(installationDate).inDays;

      final dailyKm = _parseDouble(data['daily_km'] ?? 30.0);
      final location = data['localisation'] as String? ??
          data['place_de_conduite'] as String? ??
          'Centre-ville';
      final drivingStyle = data['style_de_conduite'] as String? ?? 'Normal';
      final vehicleWeight = _parseDouble(
          data['poids_vehicule'] ?? data['vehicle_weight'] ?? 1500.0);
      final roadType = data['type_de_route'] as String? ?? 'Urbain';
      final usageType =
          data['condition_de_utilisation'] as String? ?? 'Quotidienne';

      // Vérifier si c'est un usage intensif/louage
      final isIntensiveUse = usageType == 'Louage' ||
          usageType == 'Transport de charges lourdes' ||
          usageType == 'Usage intensif';

      // 2. Récupération des valeurs de référence optimales
      // Utilisation des valeurs médianes pour une meilleure précision
      final refKm = isIntensiveUse
          ? _referenceDureeVieOptimale['freins']!['km_intensif_median']
              as double
          : _referenceDureeVieOptimale['freins']!['km_median'] as double;

      // 3. Calcul des facteurs de sévérité
      // Facteur de localisation (impact du trafic et des arrêts fréquents)
      // Impact augmenté pour le style de conduite (40%)
      double locationFactor;
      switch (location) {
        case 'Centre-ville':
          locationFactor = 1.75; // Augmenté
          break;
        case 'Urbain':
          locationFactor = 1.55; // Augmenté
          break;
        case 'Entre-région':
          locationFactor = 0.80; // Légèrement ajusté
          break;
        case 'Autoroute':
          locationFactor = 0.70; // Légèrement ajusté
          break;
        default:
          locationFactor = 1.0;
      }
      // Facteur de style de conduite (impact majeur sur les freins - 40%)
      double drivingStyleFactor;
      switch (drivingStyle) {
        case 'Sportif':
          drivingStyleFactor = 2.0; // Augmenté pour plus d'impact
          break;
        case 'Calme':
          drivingStyleFactor = 0.7; // Conduite douce préserve les freins
          break;
        case 'Normal':
          drivingStyleFactor = 1.1;
          break;
        default:
          drivingStyleFactor = 1.2;
      }

      // Facteur de type de route (30% d'impact)
      double roadFactor;
      if (roadType.contains('Montagne')) {
        roadFactor = 1.85; // Freinage fréquent en descente - augmenté
      } else if (roadType.contains('Urbain') ||
          roadType.contains('Centre-ville')) {
        roadFactor = 1.65; // Arrêts fréquents - augmenté
      } else if (roadType.contains('Autoroute')) {
        roadFactor = 0.60; // Peu de freinage - diminué
      } else {
        roadFactor = 1.0;
      }

      // Facteur de poids (20% d'impact)
      final weightFactor = min(1.6, max(0.85, vehicleWeight / 1500.0));

      // 4. Conversion entre kilométrage et temps
      // Durée de vie en kilomètres ajustée selon les facteurs de sévérité
      final totalSeverityFactor =
          (drivingStyleFactor * 0.4 + // Style de conduite: 40%
              roadFactor * 0.3 + // Type de route: 30%
              weightFactor * 0.2 + // Poids du véhicule: 20%
              locationFactor * 0.1 // Localisation: 10%
          );

      // Durée de vie ajustée en kilomètres
      final adjustedLifeKm = refKm / totalSeverityFactor;

      // 5. Kilométrage estimé depuis l'installation
      final estimatedKm = ageInDays * dailyKm;

      // 6. Calcul de l'usure basé sur le kilométrage (plus précis que le temps)
      // Utilisation d'un modèle non-linéaire amélioré avec seuils adaptés
      final kmRatio = estimatedKm / adjustedLifeKm;

      double wearPercentage;
      if (kmRatio < 0.55) {
        // Première phase: usure linéaire lente
        wearPercentage = kmRatio * 70.0; // Progression plus lente au début
      } else if (kmRatio < 0.85) {
        // Deuxième phase: usure modérément accélérée
        wearPercentage = 38.5 + ((kmRatio - 0.55) / 0.3) * 36.5;
      } else {
        // Phase finale: usure très rapide (courbe exponentielle)
        final excessWear = kmRatio - 0.85;
        wearPercentage = 75.0 + excessWear * (125.0 + excessWear * 50.0);
      }

      // 7. Ajustement final et validation
      final clampedWearPercentage = wearPercentage.clamp(0.0, 100.0);

      debugPrint(
          "Calcul optimisé usure freins: $clampedWearPercentage% (Km estimés: $estimatedKm, Durée ajustée: $adjustedLifeKm km)");
      return clampedWearPercentage;
    } catch (e, stacktrace) {
      debugPrint("Erreur dans calcul usure freins: $e");
      debugPrint("Stack trace: $stacktrace");
      return 45.0; // Valeur moyenne en cas d'erreur
    }
  }

  double _calculateTireWear(Map<String, dynamic> data) {
    try {
      debugPrint("Début du calcul avancé de l'usure des pneus");

      // 1. Extraction et validation des données d'entrée
      final marque = data['marque_pneus'] as String? ?? '1e choix';
      final dailyKm = _parseDouble(data['daily_km']) ?? 50.0;
      final vehicleWeight =
          _parseDouble(data['vehicle_weight'] ?? data['poids_vehicule']) ??
              1500.0;
      final roadUsage = _parseRoadUsage(data['type_de_route'] as dynamic);
      final engineType = data['type_de_moteur'] as String? ?? 'Essence';
      final temperature = data['temperature'] as String? ?? '20C°-35C°';
      final drivingStyle = data['style_de_conduite'] as String? ?? 'Normal';
      final usageType =
          data['condition_de_utilisation'] as String? ?? 'Quotidienne';
      final weather = data['meteo'] as String? ?? 'Tempéré';

      debugPrint(
          "Données d'entrée récupérées: marque=$marque, dailyKm=$dailyKm, style=$drivingStyle, moteur=$engineType, usage=$usageType");

      // 2. Calcul des durées de vie de référence basées sur la qualité des pneus
      // Durée de vie ajustée pour un pourcentage d'usure plus réaliste
      Map<String, Map<String, dynamic>> tireLifespans = {
        'Original': {'km': 90000.0, 'years': 5.0}, // Haut de gamme - ajusté
        '1e choix': {'km': 85000.0, 'years': 4.5}, // Moyenne gamme - ajusté
        '2e choix': {'km': 75000.0, 'years': 4.0}, // Entrée de gamme - ajusté
      };

      // Récupérer les références de durée de vie selon la marque
      final tireLifespan = tireLifespans[marque] ?? tireLifespans['1e choix']!;
      final maxKm = tireLifespan['km'] as double;
      final maxYears = tireLifespan['years'] as double;

      debugPrint("Durée de vie de référence: $maxKm km sur $maxYears ans");

      // 3. Calcul des facteurs de modification
      // a) Facteur composite de route - moyenne pondérée des types de routes
      final compositeRoadFactor = _calculateCompositeRoadFactor(roadUsage);

      // b) Facteur de style de conduite
      final drivingFactor = _drivingStyleFactors[drivingStyle] ?? 1.3;

      // c) Impact météorologique - température et conditions climatiques (réduit)
      final tempValue = _parseTemperature(temperature);
      final weatherImpact = (_weatherFactors[weather] ?? 1.0) *
          (tempValue > 35
              ? 1.2
              : tempValue > 20
                  ? 1.0
                  : tempValue < 0
                      ? 1.15
                      : 0.9);

      // d) Impact du poids et type d'utilisation
      final loadFactor =
          (vehicleWeight / 1500) * (_usageFactors[usageType] ?? 1.1);

      // e) Catégorie de kilométrage quotidien
      String dailyKmCategory;
      if (dailyKm > 100) {
        dailyKmCategory = 'très_long';
      } else if (dailyKm > 50)
        dailyKmCategory = 'long';
      else if (dailyKm > 25)
        dailyKmCategory = 'medium';
      else if (dailyKm > 10)
        dailyKmCategory = 'short';
      else
        dailyKmCategory = 'very_short';

      final dailyDistanceFactor = _dailyKmFactorsExpert[dailyKmCategory] ?? 1.0;

      // 4. Âge des pneus et kilométrage estimé
      final ageDays = _calculateDaysSinceInstallation(
          data['date_installation_pneus'] as String?);
      if (ageDays < 7) return 0.0; // Installation très récente

      final ageYears = ageDays / 365.0;
      final estimatedTotalKm = dailyKm * ageDays;

      debugPrint(
          "Âge des pneus: $ageYears ans ($ageDays jours), km estimés: $estimatedTotalKm");

      // 5. Calcul du taux d'usure combiné
      // Combinaison du pourcentage d'usure par rapport au temps et au kilométrage
      final kmWearRatio = estimatedTotalKm /
          (maxKm /
              (compositeRoadFactor *
                  drivingFactor *
                  weatherImpact *
                  loadFactor *
                  dailyDistanceFactor));

      final timeWearRatio = ageYears / maxYears;

      // Le taux d'usure est déterminé par le facteur le plus avancé
      // avec une pondération de 65% pour le kilométrage et 35% pour le temps
      // Facteur d'atténuation ajusté selon la qualité des pneus
      double attenuationFactor;
      if (marque == 'Original' || marque == '1e choix') {
        attenuationFactor =
            1.2; // Augmentation pour les pneus de qualité (1.2 au lieu de 0.85)
      } else {
        attenuationFactor = 0.9; // Légèrement augmenté pour les autres qualités
      }
      double wearRatio =
          ((kmWearRatio * 0.65) + (timeWearRatio * 0.35)) * attenuationFactor;

      // 6. Modèle d'usure non-linéaire - coefficients ajustés selon la qualité des pneus
      // Les pneus s'usent plus rapidement vers la fin de leur cycle de vie
      double wearPercentage;

      // Coefficients d'usure différents selon la qualité des pneus
      if (marque == 'Original' || marque == '1e choix') {
        // Pour les pneus de qualité originale ou 1e choix - usure initiale augmentée
        if (wearRatio < 0.3) {
          // Phase initiale - usure augmentée pour atteindre 25-30%
          wearPercentage = wearRatio * 100.0; // Augmenté de 75 à 100
        } else if (wearRatio < 0.7) {
          // Phase intermédiaire - usure normale
          wearPercentage = 30.0 + ((wearRatio - 0.3) * 85.0);
        } else {
          // Phase finale - usure accélérée
          wearPercentage = 64.0 + ((wearRatio - 0.7) * 100.0);
        }
      } else {
        // Pour les pneus de qualité inférieure - valeurs originales légèrement ajustées
        if (wearRatio < 0.3) {
          wearPercentage = wearRatio * 80.0; // Légèrement augmenté de 75 à 80
        } else if (wearRatio < 0.7) {
          wearPercentage = 24.0 + ((wearRatio - 0.3) * 85.0);
        } else {
          wearPercentage = 58.0 + ((wearRatio - 0.7) * 100.0);
        }
      }

      // 7. Ajustement final et validation
      final clampedWearPercentage = wearPercentage.clamp(0.0, 100.0);

      // 8. Calcul de la vie résiduelle estimée (en km et en temps)
      final remainingPercentage = 100.0 - clampedWearPercentage;
      final remainingKm = (maxKm * remainingPercentage / 100.0).round();
      final remainingDays =
          ((maxYears * 365.0 * remainingPercentage / 100.0)).round();

      debugPrint("Calcul de l'usure des pneus: $clampedWearPercentage%");
      debugPrint(
          "Durée de vie restante estimée: $remainingKm km ou $remainingDays jours");

      return clampedWearPercentage;
    } catch (e, stack) {
      debugPrint("Erreur calcul avancé usure pneus: $e\n$stack");
      return 50.0; // Valeur moyenne en cas d'erreur
    }
  }

  // Calcul avancé de l'état de la batterie avec modélisation non-linéaire
  // Durée de vie optimale: 1.5 à 2 ans
  double _calculateBatteryHealth(Map<String, dynamic> data) {
    try {
      debugPrint("Début du calcul optimisé de la santé de la batterie");

      // 1. Extraction et validation des données
      final installationDateStr = data['date_installation_batterie'] as String?;
      final installationDate = installationDateStr != null
          ? DateTime.parse(installationDateStr)
          : DateTime.now().subtract(const Duration(days: 365));

      // Type de moteur - essentiel pour la durée de vie de référence
      final engineType = data['type_de_moteur'] as String? ?? 'Essence';
      final isDiesel = engineType.toLowerCase().contains('diesel');

      // Autres données importantes
      final usageType =
          data['condition_de_utilisation'] as String? ?? 'Quotidienne';
      final drivingLocation = data['place_de_conduite'] as String? ??
          data['localisation'] as String? ??
          'Entre-région';
      final temperatureValue = data['temperature'];
      final drivingStyle = data['style_de_conduite'] as String? ?? 'Normal';
      final dailyKm = _parseDouble(data['daily_km'] ?? 30.0);
      final vehicleAgeYears = _parseDouble(data['age_de_vehicule'] ?? 5.0);

      // Vérifier si c'est un usage intensif/louage
      final isIntensiveUse = usageType == 'Louage' ||
          usageType == 'Transport de charges lourdes' ||
          usageType == 'Usage intensif';

      // 2. Calcul de l'âge de la batterie
      final now = DateTime.now();
      final batteryAgeDays = max(0, now.difference(installationDate).inDays);
      final batteryAgeYears = batteryAgeDays / 365.0;

      debugPrint(
          "Âge de la batterie: $batteryAgeYears ans ($batteryAgeDays jours)");

      // 3. Récupération des valeurs de référence optimales
      // Durée de vie différente selon le type de moteur
      final refMaxYears = isDiesel
          ? _referenceDureeVieOptimale['batterie']!['ans_diesel'] as int
          : _referenceDureeVieOptimale['batterie']!['ans_essence'] as int;

      // 4. Déterminer la qualité de la batterie (influence la durée de vie)
      final String batteryQuality =
          data['qualite_batterie'] as String? ?? 'Standard';

      // Facteur de qualité qui influence la durée de vie
      double qualityFactor;
      switch (batteryQuality) {
        case 'Premium':
          qualityFactor = 1.15; // Batterie haut de gamme +15%
          break;
        case 'Economy':
          qualityFactor = 0.85; // Batterie économique -15%
          break;
        default: // 'Standard'
          qualityFactor = 1.2;
      }

      // Durée de vie de référence en années, ajustée selon la qualité
      final baseLifeYears = refMaxYears * qualityFactor;

      debugPrint(
          "Durée de vie de référence: $baseLifeYears ans (type: $engineType, qualité: $batteryQuality)");

      // 5. Calcul des facteurs de dégradation individuels
      // a) Température - impact sur les réactions chimiques (25%)
      double tempFactor;
      double temp = _parseDouble(temperatureValue ?? 25.0);
      if (temp > 35) {
        tempFactor = 1.35; // Chaleur extrême - forte dégradation
      } else if (temp < 0) {
        tempFactor = 1.25; // Froid extrême - dégradation importante
      } else if (temp < 20) {
        tempFactor = 1.1; // Froid modéré - légère dégradation
      } else {
        tempFactor = 1.0; // Température optimale
      }

      // b) Localisation - impact sur les cycles thermiques et vibrations (20%)
      double locationFactor;
      switch (drivingLocation) {
        case 'Centre-ville':
        case 'Urbain':
          locationFactor = 1.3; // Arrêts/démarrages fréquents
          break;
        case 'Désert':
          locationFactor = 1.15; // Conditions extrêmes
          break;
        case 'Campagne':
          locationFactor = 1.1; // Vibrations, chemins inégaux
          break;
        case 'Autoroute':
        case 'Entre-région':
          locationFactor = 0.95; // Usage régulier, optimal
          break;
        default:
          locationFactor = 1.05;
      }

      // c) Style de conduite - impact sur les cycles de charge/décharge (15%)
      double drivingStyleFactor;
      switch (drivingStyle) {
        case 'Sportif':
          drivingStyleFactor = 1.2; // Décharges rapides
          break;
        case 'Calme':
          drivingStyleFactor = 0.9; // Utilisation douce
          break;
        default:
          drivingStyleFactor = 1.05;
      }

      // d) Condition d'utilisation - impact sur la charge (20%)
      double usageFactor;
      switch (usageType) {
        case 'Transport de charges lourdes':
          usageFactor = 1.25; // Demande électrique élevée
          break;
        case 'Louage':
          usageFactor = 1.3; // Usage intensif
          break;
        case 'Voyage':
          usageFactor = 1.1; // Utilisation prolongée
          break;
        default:
          usageFactor = 1.0;
      }

      // e) Kilométrage quotidien - impact sur les cycles de charge (10%)
      double dailyKmFactor;
      if (dailyKm < 15) {
        dailyKmFactor = 1.25; // Trajets courts - charges incomplètes
      } else if (dailyKm < 30) {
        dailyKmFactor = 1.1; // Trajets moyens
      } else {
        dailyKmFactor = 0.95; // Longs trajets - charges complètes
      }

      // f) Âge du véhicule - impact sur le système électrique (10%)
      final ageVehicleFactor = min(1.3, 1.0 + (vehicleAgeYears / 20.0));

      // g) Type de moteur - impact supplémentaire pour diesel
      final engineTypeFactor = isDiesel ? 1.2 : 1.0;

      // 6. Calcul du multiplicateur de dégradation combiné avec pondération optimisée
      final degradationMultiplier = (tempFactor * 0.25 + // Température: 25%
              locationFactor * 0.20 + // Localisation: 20%
              drivingStyleFactor * 0.15 + // Style de conduite: 15%
              usageFactor * 0.20 + // Type d'utilisation: 20%
              dailyKmFactor * 0.01 + // Kilométrage quotidien: 10%
              ageVehicleFactor * 0.01 // Âge du véhicule: 10%
          ) *
          engineTypeFactor; // Facteur supplémentaire pour diesel

      // Limitation du multiplicateur dans une plage réaliste
      final effectiveMultiplier = max(0.95, min(1.8, degradationMultiplier));

      debugPrint(
          "Multiplicateur de dégradation optimisé: $effectiveMultiplier");

      // 7. Modèle de dégradation non-linéaire optimisé
      // Calcul du ratio de durée de vie écoulée, ajusté par le multiplicateur
      final lifeRatio = (batteryAgeYears / baseLifeYears) * effectiveMultiplier;

      // Modèle exponentiel par phases pour la dégradation de la batterie
      double degradationPercentage;

      if (lifeRatio < 0.5) {
        // Première phase: dégradation lente et linéaire
        degradationPercentage =
            lifeRatio * 35.0; // Max 17.5% à 50% de la durée de vie
      } else if (lifeRatio < 0.85) {
        // Deuxième phase: dégradation modérée, accélération
        degradationPercentage =
            17.5 + ((lifeRatio - 0.5) / 0.35) * 42.5; // 17.5% à 60%
      } else if (lifeRatio < 1.1) {
        // Troisième phase: dégradation rapide
        degradationPercentage =
            60.0 + ((lifeRatio - 0.85) / 0.25) * 25.0; // 60% à 85%
      } else {
        // Phase finale: dégradation très rapide (exponentielle)
        final excessLife = lifeRatio - 1.1;
        degradationPercentage = 85.0 + (excessLife * 75.0); // >85% jusqu'à 100%
      }

      // 8. Convertir la dégradation en santé de la batterie et appliquer des ajustements
      double batteryHealth = 100.0 - degradationPercentage;

      // Ajustement basé sur le type de moteur: dégradation plus rapide pour les diesels en fin de vie
      if (isDiesel && batteryHealth < 40.0) {
        batteryHealth = batteryHealth *
            0.85; // 15% de dégradation supplémentaire pour les diesels en fin de vie
      }

      // Ajustement pour l'usage intensif
      if (isIntensiveUse && batteryHealth < 60.0) {
        batteryHealth = batteryHealth *
            0.9; // 10% de dégradation supplémentaire pour usage intensif
      }

      // 9. Validation finale et limitation des valeurs
      final clampedBatteryHealth = batteryHealth.clamp(0.0, 100.0);

      debugPrint(
          "Calcul optimisé santé batterie: $clampedBatteryHealth% (Type: $engineType, Âge: $batteryAgeYears ans, Durée de vie estimée: $baseLifeYears ans)");
      return 100.0 -
          clampedBatteryHealth; // Inversion: retourne le pourcentage d'usure
    } catch (e, stacktrace) {
      debugPrint("Erreur dans calcul santé batterie: $e");
      debugPrint("Stack trace: $stacktrace");
      return 45.0; // Valeur moyenne en cas d'erreur
    }
  }

  // Calcul avancé de l'usure de l'embrayage avec modélisation exponentielle
  double _calculateClutchWear(Map<String, dynamic> data) {
    try {
      debugPrint("Début du calcul optimisé de l'usure de l'embrayage");

      // 1. Extraction et validation des données
      final installationDateStr =
          data['date_Installation_embrayage'] as String?;
      if (installationDateStr == null) return 40.0; // Valeur par défaut

      final installationDate = DateTime.parse(installationDateStr);
      final now = DateTime.now();
      final ageInDays = now.difference(installationDate).inDays;

      // Variables d'entrée essentielles
      final routeType = data['type_de_route'] as String? ?? 'Urbain';
      final hillDriving = routeType.contains('Montagne');
      final dailyKm = _parseDouble(data['daily_km'] ?? 30.0);
      final vehicleWeight = _parseDouble(
          data['poids_vehicule'] ?? data['vehicle_weight'] ?? 1500.0);
      final drivingStyle = data['style_de_conduite'] as String? ?? 'Normal';
      final usageCondition =
          data['condition_de_utilisation'] as String? ?? 'Quotidienne';

      // Vérifier si c'est un usage intensif/louage
      final isIntensiveUse = usageCondition == 'Louage' ||
          usageCondition == 'Transport de charges lourdes' ||
          usageCondition == 'Usage intensif';

      // 2. Récupération des valeurs de référence optimales
      // Utilisation de la valeur médiane pour une meilleure précision
      final refKm =
          _referenceDureeVieOptimale['embrayage']!['km_median'] as double;

      // 3. Calcul des facteurs de sévérité individuels
      // Style de conduite (impact critique sur l'embrayage - 40%)
      double drivingStyleFactor;
      switch (drivingStyle) {
        case 'Sportif':
          drivingStyleFactor =
              2.0; // Augmenté - Démarrages brusques, changements rapides
          break;
        case 'Calme':
          drivingStyleFactor = 0.7; // Utilisation douce - diminué
          break;
        case 'Normal':
          drivingStyleFactor = 1.1; // Style normal
          break;
        default:
          drivingStyleFactor = 1.2; // Style par défaut
      }

      // Facteur de trafic et type de route (30%)
      double trafficFactor;
      if (routeType.contains('Centre-ville') || routeType.contains('Urbain')) {
        trafficFactor = 1.75; // Arrêts/départs fréquents - augmenté
      } else if (hillDriving) {
        trafficFactor = 1.55; // Démarrages en côte - augmenté
      } else if (routeType.contains('Autoroute') ||
          routeType.contains('Entre-région')) {
        trafficFactor = 0.60; // Peu d'embrayages - diminué
      } else {
        trafficFactor = 1.0; // Routes mixtes
      }

      // Facteur de charge (poids et utilisation - 20%)
      double loadFactor;
      if (usageCondition == 'Transport de charges lourdes') {
        loadFactor = 1.85; // Fort impact sur l'embrayage - augmenté
      } else if (usageCondition == 'Louage') {
        loadFactor = 1.65; // Usage intensif - augmenté
      } else {
        loadFactor = max(0.85, min(1.6, vehicleWeight / 1500.0)); // Ajusté
      }

      // Facteur de kilométrage quotidien (trajets courts = plus d'embrayages - 10%)
      double distanceFactor;
      if (dailyKm < 10) {
        distanceFactor = 1.8; // Nombreux démarrages à froid - augmenté
      } else if (dailyKm < 25) {
        distanceFactor = 1.4; // Trajets courts urbains - augmenté
      } else if (dailyKm > 80) {
        distanceFactor = 0.7; // Longs trajets, peu d'embrayages - diminué
      } else {
        distanceFactor = 1.0; // Utilisation moyenne
      }

      // 4. Calcul du facteur de sévérité total avec pondération
      final totalSeverityFactor =
          (drivingStyleFactor * 0.7 + // Style de conduite: 40%
              trafficFactor * 0.4 + // Type de route: 30%
              loadFactor * 0.3 + // Charge et utilisation: 20%
              distanceFactor * 0.1 // Kilométrage quotidien: 10%
          );

      // 5. Calculer la durée de vie ajustée en kilomètres
      final adjustedLifeKm = refKm / totalSeverityFactor;

      // Conversion en jours selon le kilométrage quotidien
      final adjustedLifeDays = adjustedLifeKm / dailyKm;

      // 6. Kilométrage estimé depuis l'installation
      final estimatedKm = ageInDays * dailyKm;

      // 7. Calcul de l'usure basé sur le kilométrage (plus précis que le temps)
      // Utilisation d'un modèle non-linéaire amélioré avec seuils adaptés
      final kmRatio = estimatedKm / adjustedLifeKm;

      // 8. Modèle d'usure non-linéaire optimisé (pourcentage augmenté de 10% à 15%)
      // L'embrayage s'use de façon exponentielle en fin de vie
      double wearPercentage;

      if (kmRatio < 0.5) {
        // Première moitié: usure modérée, augmentée à 15%
        wearPercentage = kmRatio * 40.0; // Augmentation de l'usure initiale
      } else if (kmRatio < 0.8) {
        // 50-80%: usure accélérée
        wearPercentage = 20.0 + (kmRatio - 0.5) * 85.0; // Base augmentée à 20%
      } else {
        // >80%: usure très rapide avec modèle exponentiel
        final excessWear = kmRatio - 0.8;
        wearPercentage = 45.5 + excessWear * (200.0 + excessWear * 150.0);
      }

      // 9. Ajustement final et validation
      final clampedWearPercentage = wearPercentage.clamp(0.0, 100.0);

      debugPrint(
          "Calcul optimisé usure embrayage: $clampedWearPercentage% (Km estimés: $estimatedKm, Durée ajustée: $adjustedLifeKm km)");
      return clampedWearPercentage;
    } catch (e, stacktrace) {
      debugPrint("Erreur dans calcul usure embrayage: $e");
      debugPrint("Stack trace: $stacktrace");
      return 35.0; // Valeur moyenne en cas d'erreur
    }
  }

  // Calcul avancé de l'usure des amortisseurs avec modèle physique
  double _calculateShockAbsorberWear(Map<String, dynamic> data) {
    try {
      debugPrint("Début du calcul optimisé de l'usure des amortisseurs");

      // 1. Extraction et validation des données
      final installationDateStr =
          data['date_installation_amortisseur'] as String?;
      if (installationDateStr == null) return 30.0; // Valeur par défaut

      final installationDate = DateTime.parse(installationDateStr);
      final now = DateTime.now();
      final ageInDays = now.difference(installationDate).inDays;
      final ageInYears = ageInDays / 365.0;

      final dailyKm = _parseDouble(data['daily_km'] ?? 30.0);
      final roadType = data['type_de_route'] as String? ?? 'Urbain';
      final vehicleWeight = _parseDouble(
          data['poids_vehicule'] ?? data['vehicle_weight'] ?? 1500.0);
      final usageCondition =
          data['condition_de_utilisation'] as String? ?? 'Quotidienne';

      // Vérifier si c'est un usage intensif/louage
      final isIntensiveUse = usageCondition == 'Louage' ||
          usageCondition == 'Transport de charges lourdes' ||
          usageCondition == 'Usage intensif';

      // 2. Récupération des valeurs de référence optimales
      // Utilisation des valeurs médianes pour une meilleure précision
      final refKm =
          _referenceDureeVieOptimale['amortisseurs']!['km_median'] as double;
      final refAns =
          _referenceDureeVieOptimale['amortisseurs']!['ans_median'] as double;

      // Si usage intensif, durée de vie réduite à 1 an (coefficent d'usure x3.5)
      final intensiveUseFactor = isIntensiveUse ? 3.5 : 1.0;

      // 3. Calcul des facteurs de sévérité
      // Facteur de type de route (impact critique sur les suspensions - 50%)
      double roadFactor;
      if (roadType.contains('Terre') ||
          roadType.contains('Piste') ||
          roadType.contains('Gravier')) {
        roadFactor = 2.35; // Routes non pavées - augmenté
      } else if (roadType.contains('Montagne')) {
        roadFactor = 1.75; // Routes sinueuses, variations de charge - augmenté
      } else if (roadType.contains('Urbain')) {
        roadFactor = 1.45; // Nids-de-poule, ralentisseurs - augmenté
      } else if (roadType.contains('Autoroute')) {
        roadFactor = 0.70; // Surface régulière - diminué
      } else {
        roadFactor = 1.0; // Routes mixtes
      }

      // Facteur de charge et d'utilisation (30%)
      double loadFactor;
      switch (usageCondition) {
        case 'Transport de charges lourdes':
          loadFactor = 2.05; // Augmenté
          break;
        case 'Louage':
          loadFactor = 1.85; // Augmenté
          break;
        case 'Voyage':
          loadFactor = 1.15;
          break;
        default:
          loadFactor = max(0.9, min(1.5, vehicleWeight / 1500.0)); // Ajusté
      }

      // 4. Calcul du facteur de sévérité total avec pondération
      final totalSeverityFactor = (roadFactor * 0.4 + // Type de route: 50%
              loadFactor * 0.2 + // Charge: 30%
              intensiveUseFactor * 0.2 // Usage intensif/normal: 20%
          );

      // 5. Calculer la durée de vie ajustée en kilomètres et en temps
      final adjustedLifeKm = refKm / totalSeverityFactor;
      final adjustedLifeYears = refAns / totalSeverityFactor;

      // 6. Calcul de l'usure basée sur plusieurs facteurs
      // a) Usure temporelle (liée à l'âge)
      final temporalWearRatio = ageInYears / adjustedLifeYears;

      // b) Usure kilométrique (liée à la distance)
      final totalEstimatedKm = ageInDays * dailyKm;
      final distanceWearRatio = totalEstimatedKm / adjustedLifeKm;

      // 7. Modèle combiné avec pondération optimisée
      // Les amortisseurs s'usent plus par l'utilisation que par le temps
      final combinedWearRatio =
          distanceWearRatio * 0.75 + temporalWearRatio * 0.25;

      // 8. Modèle non-linéaire amélioré pour l'usure des amortisseurs
      // Les amortisseurs perdent en efficacité progressivement, puis rapidement
      // (pourcentage réduit de 20% à 30%)
      double wearPercentage;

      if (combinedWearRatio < 0.55) {
        // Phase initiale: perte d'efficacité progressive plus lente - réduite
        wearPercentage = combinedWearRatio * 20.0; // Réduit de 58.0 à 40.0
      } else if (combinedWearRatio < 0.85) {
        // Phase intermédiaire: détérioration accélérée - réduite
        wearPercentage =
            20.0 + (combinedWearRatio - 0.55) * 70.0; // Réduit de 31.9 à 22.0
      } else {
        // Phase finale: détérioration critique (courbe exponentielle) - réduite
        final excessWear = combinedWearRatio - 0.85;
        wearPercentage = 20 +
            excessWear * (110.0 + excessWear * 70.0); // Réduit de 64.3 à 47.5
      }

      // 9. Ajustement final et validation
      final clampedWearPercentage = wearPercentage.clamp(0.0, 100.0);

      debugPrint(
          "Calcul optimisé usure amortisseurs: $clampedWearPercentage% (Âge: $ageInYears ans, Km estimés: $totalEstimatedKm, Durée ajustée: $adjustedLifeKm km)");
      return clampedWearPercentage;
    } catch (e, stacktrace) {
      debugPrint("Erreur dans calcul usure amortisseurs: $e");
      debugPrint("Stack trace: $stacktrace");
      return 30.0; // Valeur moyenne en cas d'erreur
    }
  }

  // Calcul avancé de l'intervalle de vidange d'huile
  double _calculateOilChange(Map<String, dynamic> data) {
    try {
      // 1. Extraction et validation des données
      final dailyKm = _parseDouble(data['daily_km']) ?? 30.0;
      final lastOilChangeDate = _validateDate(data['date_dernier_vidange']);
      final engineType = data['type_de_moteur'] as String? ?? 'Essence';
      final usageCondition =
          data['condition_de_utilisation'] as String? ?? 'Quotidienne';
      final roadUsageInput = data['type_de_route'];
      final drivingStyle = data['style_de_conduite'] as String? ?? 'Normal';
      final temperature = data['temperature'] as String? ?? '20C°-35C°';
      final vehicleAgeYears = _parseDouble(data['age_de_vehicule'] ?? 3.0);

      // 2. Détermination des intervalles de base (km et temps)
      final baseKmInterval = (engineType == 'Diesel')
          ? _baseKmIntervalDiesel
          : _baseKmIntervalPetrol;
      final strictTimeCapDays = _baseTimeIntervalDaysOilExpert;

      // 3. Calcul du temps écoulé et de la distance estimée
      final now = DateTime.now();
      final daysSinceLast = max(0, now.difference(lastOilChangeDate).inDays);
      final kmSinceLast = daysSinceLast * dailyKm;

      // 4. Catégorisation du kilométrage quotidien
      String dailyKmCategory;
      if (dailyKm < 10) {
        dailyKmCategory = 'very_short';
      } else if (dailyKm < 25)
        dailyKmCategory = 'short';
      else if (dailyKm <= 50)
        dailyKmCategory = 'medium';
      else
        dailyKmCategory = 'long';

      // 5. Calcul des facteurs de sévérité individuels (avec la logique experte)
      final dailyKmFactor = _dailyKmFactorsExpert[dailyKmCategory] ?? 1.0;
      final usageFactor = _usageFactors[usageCondition] ?? 1.1;
      final roadUsageMap = _parseRoadUsage(roadUsageInput);
      final roadFactor = _calculateCompositeRoadFactor(roadUsageMap);
      final engineFactor = _engineTypeFactors[engineType] ?? 1.0;
      final drivingStyleFactor = _drivingStyleFactors[drivingStyle] ?? 1.15;

      // Facteur de température - important pour la dégradation de l'huile
      final tempRange = _getTempRange(temperature);
      double tempFactor;
      switch (tempRange) {
        case "< 0C°":
          tempFactor = 1.3;
          break; // Démarrages à froid fréquents
        case "0C°-20C°":
          tempFactor = 0.9;
          break; // Conditions idéales
        case "20C°-40C°":
          tempFactor = 1.1;
          break; // Chaleur modérée
        default:
          tempFactor = 1.4;
          break; // Chaleur élevée (>35°C)
      }

      // Facteur d'âge du véhicule - moteurs plus âgés consomment/contaminent plus l'huile
      final vehicleAgeFactor = min(1.5, 0.5 + (vehicleAgeYears - 3) * 0.05);

      // 6. Calcul du multiplicateur de sévérité combiné
      final severityMultiplier = dailyKmFactor *
          usageFactor *
          roadFactor *
          engineFactor *
          drivingStyleFactor *
          tempFactor *
          vehicleAgeFactor;

      // Limiter le multiplicateur pour éviter des valeurs extrêmes
      final effectiveMultiplier = max(0.65, min(2.75, severityMultiplier));

      // 7. Calcul des intervalles ajustés (km et temps)
      final adjustedKmInterval = baseKmInterval / effectiveMultiplier;

      // Intervalle de temps théorique basé sur la sévérité, mais la limite stricte reste
      final adjustedTimeIntervalDays = strictTimeCapDays /
          (effectiveMultiplier * 0.70); // Moins sensible au temps

      // 8. Modèle de dégradation non-linéaire de l'huile
      // L'huile se dégrade plus rapidement après un certain seuil
      double kmDegradationFactor;
      if (kmSinceLast < adjustedKmInterval * 0.5) {
        // Première moitié de l'intervalle - dégradation plus lente
        kmDegradationFactor = kmSinceLast / adjustedKmInterval;
      } else if (kmSinceLast < adjustedKmInterval * 0.8) {
        // 50-80% de l'intervalle - dégradation linéaire standard
        kmDegradationFactor = kmSinceLast / adjustedKmInterval;
      } else {
        // >80% de l'intervalle - dégradation accélérée
        final basePercentage = kmSinceLast / adjustedKmInterval;
        final accelerationFactor = 1.0 + ((basePercentage - 0.8) * 2.5);
        kmDegradationFactor = basePercentage * accelerationFactor;
      }

      // 9. Calcul des pourcentages de vie restante
      // Pourcentage basé sur le kilométrage (avec modèle non-linéaire)
      double remainingKmLifePercent = (1.0 - kmDegradationFactor) * 100.0;

      // Pourcentage basé sur le temps (ajusté par la sévérité)
      double remainingAdjTimeLifePercent =
          ((adjustedTimeIntervalDays - daysSinceLast) /
              adjustedTimeIntervalDays *
              100.0);

      // Pourcentage basé sur le temps (limite stricte)
      double remainingStrictTimeCapPercent =
          ((strictTimeCapDays - daysSinceLast) / strictTimeCapDays * 100.0);

      // 10. Détermination du pourcentage final de vie de l'huile
      // L'huile doit être changée dès que l'un des facteurs atteint sa limite
      final oilLifePercent = min(remainingKmLifePercent,
          min(remainingAdjTimeLifePercent, remainingStrictTimeCapPercent));
      final finalPercentage = oilLifePercent.clamp(0.0, 100.0);

      debugPrint(
          "Calcul avancé vidange: $finalPercentage% (Multiplicateur=$effectiveMultiplier)");
      return 100.0 -
          finalPercentage; // Inversion: retourne le pourcentage d'usure plutôt que la vie restante
    } catch (e, stacktrace) {
      debugPrint("Erreur dans calcul avancé vidange: $e");
      debugPrint("Stack trace: $stacktrace");
      return 50.0; // Valeur intermédiaire en cas d'erreur pour suggérer une vérification
    }
  }

  // Calcul avancé du risque de rupture de la courroie de distribution
  // Calcul avancé de l'état de la batterie avec modélisation non-linéaire
  // Durée de vie optimale: 1.5 à 2 ans

  // Calcul optimisé du risque de rupture de la courroie de distribution
  double _calculateBeltRisk(Map<String, dynamic> data) {
    try {
      debugPrint("Début du calcul optimisé du risque de la courroie");

      // 1. Extraction et validation des données
      final installationDateStr = data['date_installation_courroie'] as String?;
      if (installationDateStr == null) {
        return 75.0; // Risque élevé si date inconnue
      }

      final installationDate = DateTime.parse(installationDateStr);
      final now = DateTime.now();
      final ageInDays = now.difference(installationDate).inDays;
      final ageInYears = ageInDays / 365.0;

      final dailyKm = _parseDouble(data['daily_km'] ?? 30.0);

      final engineType = data['type_de_moteur'] as String? ?? 'Essence';
      final usageCondition =
          data['condition_de_utilisation'] as String? ?? 'Quotidienne';
      final drivingStyle = data['style_de_conduite'] as String? ?? 'Normal';
      final roadType = data['type_de_route'] as String? ?? 'Urbain';

      // Vérifier si c'est un usage intensif/louage
      final isIntensiveUse = usageCondition == 'Louage' ||
          usageCondition == 'Transport de charges lourdes' ||
          usageCondition == 'Usage intensif';

      // 2. Récupération des valeurs de référence optimales
      // Utilisation des valeurs de référence pour une meilleure précision
      final refKm = isIntensiveUse
          ? _referenceDureeVieOptimale['courroie']!['km_intensif'] as double
          : _referenceDureeVieOptimale['courroie']!['km_max'] as double;

      // 3. Calcul des facteurs de sévérité
      // a) Facteur d'utilisation intensif (charge, traction, usage) - 30%
      double usageFactor;
      switch (usageCondition) {
        case 'Transport de charges lourdes':
          usageFactor = 1.55; // Fort impact sur la courroie - augmenté
          break;
        case 'Louage':
          usageFactor = 1.45; // Usage intensif - augmenté
          break;
        case 'Voyage':
          usageFactor = 0.9; // Moins d'arrêts/départs - diminué
          break;
        default:
          usageFactor = 1.0; // Usage normal
      }

      // b) Facteur de style de conduite (impact sur les accélérations et tensions) - 25%
      double drivingStyleFactor;
      switch (drivingStyle) {
        case 'Sportif':
          drivingStyleFactor = 1.6; // Changements rapides de régime - augmenté
          break;
        case 'Calme':
          drivingStyleFactor = 0.8; // Conduite douce - diminué
          break;
        default:
          drivingStyleFactor = 1.1; // Style normal - légèrement ajusté
      }

      // c) Facteur de type de route (impact sur les sollicitations moteur) - 25%
      double roadFactor;
      if (roadType.contains('Montagne')) {
        roadFactor = 1.5; // Fortes sollicitations en montée/descente
      } else if (roadType.contains('Urbain') ||
          roadType.contains('Centre-ville')) {
        roadFactor = 1.4; // Trafic dense, arrêts/départs fréquents
      } else if (roadType.contains('Autoroute')) {
        roadFactor = 0.85; // Régime constant, moins de stress
      } else {
        roadFactor = 1.1; // Conditions mixtes
      }

      // d) Facteur moteur (diesel plus exigeant) - 20%
      final engineFactor =
          engineType.toLowerCase().contains('diesel') ? 1.3 : 1.0;

      // 4. Calcul du facteur de sévérité total avec pondération
      final totalSeverityFactor = (usageFactor * 0.25 + // Usage: 30%
              drivingStyleFactor * 0.4 + // Style de conduite: 25%
              roadFactor * 0.3 + // Type de route: 25%
              engineFactor * 0.2 // Type de moteur: 20%
          );

      // 5. Calculer la durée de vie ajustée en kilomètres
      final adjustedLifeKm = refKm / totalSeverityFactor;

      // 6. Kilométrage estimé depuis l'installation
      final estimatedKmSinceInstallation = ageInDays * dailyKm;

      // 7. Calcul du risque de rupture
      // Utilisation d'un modèle non-linéaire amélioré avec seuils adaptés
      // Le risque s'accélère après 75% de la durée de vie
      final kmRatio = estimatedKmSinceInstallation / adjustedLifeKm;

      double riskPercentage;
      if (kmRatio < 0.6) {
        // Première phase: risque faible à modéré
        riskPercentage = kmRatio * 45.0; // Max 27% à 60% de la durée de vie
      } else if (kmRatio < 0.75) {
        // Deuxième phase: risque modéré, augmentation linéaire
        riskPercentage = 27.0 + ((kmRatio - 0.6) / 0.15) * 18.0; // 27% à 45%
      } else if (kmRatio < 0.9) {
        // Troisième phase: risque important, augmentation rapide
        riskPercentage = 45.0 + ((kmRatio - 0.75) / 0.15) * 25.0; // 45% à 70%
      } else {
        // Phase finale: risque critique (courbe exponentielle)
        final excessWear = kmRatio - 0.9;
        riskPercentage = 70.0 +
            excessWear * (100.0 + excessWear * 200.0); // >70% jusqu'à 100%
      }

      // 8. Ajustements spécifiques
      // Pour les courroies très anciennes (>4 ans) indépendamment du km
      if (ageInYears > 4.5 && riskPercentage < 70.0) {
        riskPercentage = 70.0 +
            (ageInYears - 4.5) * 10.0; // +10% de risque par anée après 4.5 ans
      }

      // Risque majoré pour usage intensif proche de la fin de vie
      if (isIntensiveUse && kmRatio > 0.8) {
        riskPercentage +=
            10.0; // +10% de risque supplémentaire pour usage intensif
      }

      // 9. Validation finale
      final clampedRiskPercentage = riskPercentage.clamp(0.0, 100.0);

      debugPrint(
          "Calcul optimisé risque courroie: $clampedRiskPercentage% (Âge: $ageInYears ans, Km estimés: $estimatedKmSinceInstallation, Durée ajustée: $adjustedLifeKm km)");
      return clampedRiskPercentage;
    } catch (e, stacktrace) {
      debugPrint("Erreur dans calcul risque courroie: $e");
      debugPrint("Stack trace: $stacktrace");
      return 60.0; // Valeur moyenne en cas d'erreur pour suggérer vérification
    }
  }
}

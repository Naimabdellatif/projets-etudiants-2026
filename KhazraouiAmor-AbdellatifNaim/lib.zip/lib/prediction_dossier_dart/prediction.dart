import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/interfaces/ClientDashboard.dart';
import 'package:carhabti/interfaces/show.dart';
import 'predictionCalcul.dart';

class PredictionScreen extends StatefulWidget {
  final String immatriculation;

  const PredictionScreen({
    super.key,
    required this.immatriculation,
  });

  // Récupération de l'immatriculation via les arguments de navigation
  static Route<dynamic> route() {
    return MaterialPageRoute(
      builder: (context) {
        final args =
            ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
        return PredictionScreen(immatriculation: args['immatriculation']);
      },
    );
  }

  @override
  State<PredictionScreen> createState() => _PredictionScreenState();
}

class _PredictionScreenState extends State<PredictionScreen> {
  final supabase = Supabase.instance.client;
  Map<String, double> predictions = {};
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadPredictions();
  }


Map<String, dynamic> _rawFacteurData = {};

Future<void> _loadPredictions() async {
  setState(() {
    _isLoading = true;
    _errorMessage = null; // Réinitialiser l'erreur à chaque chargement
  });

  try {
    // Étape 1 : Récupération des données brutes
    final response = await supabase
        .from('facteur')
        .select()
        .eq('fk_immatriculation', widget.immatriculation)
        .maybeSingle();
    if (kDebugMode) {
      print('Données brutes récupérées: $response');
    }
    
    if (response == null) {
      throw Exception("Aucune donnée trouvée pour cette immatriculation");
    }
    
    _rawFacteurData = response;
    
    // Vérifier si les données techniques ont été saisies par l'utilisateur
    bool hasUserEnteredTechnicalData = _checkForUserEnteredData(_rawFacteurData);
    
    if (!hasUserEnteredTechnicalData) {
      throw Exception("Veuillez saisir les données techniques dans le formulaire des pièces avant d'afficher les prédictions");
    }
    debugPrint("Données facteur récupérées: $_rawFacteurData");

    // Étape 2 : Initialisation du calculateur
    final calculator = PredictionCalculator(
      immatriculation: widget.immatriculation,
      rawFacteurData: _rawFacteurData,
      rawData: _rawFacteurData,
    );

    // Étape 3 : Calcul des prédictions
    final results = await calculator.calculateAllPredictions();

    // Étape 4 : Mise à jour de l'état
    setState(() {
      predictions = results;
    });

  } catch (e, stack) {
    if (kDebugMode) {
      debugPrint("Erreur dans _loadPredictions: $e");
      debugPrint("Stack trace: $stack");
    }

    setState(() {
      _errorMessage = _extractErrorMessage(e);
    });
  } finally {
    setState(() => _isLoading = false);
  }
}

// Méthode pour vérifier si l'utilisateur a saisi des données techniques
bool _checkForUserEnteredData(Map<String, dynamic> data) {
  // Liste des champs techniques qui devraient être remplis par l'utilisateur
  final List<String> technicalFields = [
    'date_installation_pneus', 
    'date_derniere_vidange',
    'date_installation_batterie',
    'date_installation_freins',
    'date_installation_courroie',
    'date_installation_embrayage',
    'date_installation_amortisseur'
  ];
  
  // Vérifier si au moins un des champs techniques a été rempli
  bool hasAnyTechnicalData = technicalFields.any((field) {
    return data.containsKey(field) && data[field] != null && data[field].toString().isNotEmpty;
  });
  
  return hasAnyTechnicalData;
}

String _extractErrorMessage(dynamic error) {
  if (error is Exception) {
    final message = error.toString();
    return message.replaceFirst("Exception: ", "");
  }
  return "Erreur lors du calcul des prédictions";
}

  void _navigateToShowScreen() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => ShowScreen(
          predictions: predictions,
          immatriculation: widget.immatriculation,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Row(
          children: [
            CircleAvatar(
              radius: 15,
              backgroundColor: Colors.white,
              child: Icon(Icons.analytics, size: 18, color: Theme.of(context).primaryColor),
            ),
            SizedBox(width: 10),
            Text('Prédictions d\'usure', style: TextStyle(color: Colors.white)),
          ],
        ),
        backgroundColor: Theme.of(context).primaryColor,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadPredictions,
            tooltip: 'Actualiser les prédictions',
          ),
          IconButton(
            icon: const Icon(Icons.edit, color: Colors.white),
            onPressed: _navigateToShowScreen,
            tooltip: 'Compléter les informations',
          ),
        ],
      ),
      body: _buildPredictionBody(),
    );
  }

  Widget _buildPredictionBody() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 20),
            Text('Calcul des prédictions en cours...'),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 60, color: Colors.orange),
              const SizedBox(height: 20),
              Text(
                'Données insuffisantes pour les prédictions',
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                _errorMessage!,
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                icon: const Icon(Icons.edit),
                label: const Text('Compléter les informations'),
                onPressed: () => _navigateToShowScreen(),
              ),
            ],
          ),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildPredictionTile(
          title: 'Usure des pneus',
          value: predictions['tire_wear'] ?? 0.0,
          icon: Icons.directions_car,
          color: Colors.orange,
          maxValue: 100,
        ),
        _buildPredictionTile(
          title: 'Vidange nécessaire',
          value: predictions['oil_change'] ?? 0.0,
          icon: Icons.local_car_wash,
          color: Colors.blue,
          maxValue: 100,
        ),
        _buildPredictionTile(
          title: 'Santé batterie',
          value: predictions['battery_health'] ?? 0.0,
          icon: Icons.battery_charging_full,
          color: Colors.green,
          maxValue: 100,
        ),
        _buildPredictionTile(
          title: 'Usure des freins',
          value: predictions['brake_wear'] ?? 0.0,
          icon: Icons.stop_circle,
          color: Colors.red,
          maxValue: 100,
        ),
        _buildPredictionTile(
          title: 'Risque courroie',
          value: predictions['belt_risk'] ?? 0.0,
          icon: Icons.settings_input_antenna,
          color: Colors.purple,
          maxValue: 100,
        ),
        _buildPredictionTile(
          title: 'Usure embrayage',
          value: predictions['clutch_wear'] ?? 0.0,
          icon: Icons.engineering,
          color: Colors.brown,
          maxValue: 100,
        ),
        _buildPredictionTile(
          title: 'Usure des Amourtisseurs',
          value: predictions['ShockAbsorber_Wear'] ?? 0.0,
          icon: Icons.shield,
          color: Colors.brown,
          maxValue: 100,
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20.0, bottom: 40.0),
          child: ElevatedButton.icon(
            icon: const Icon(Icons.check_circle, size: 24),
            label: const Text('Espace client', style: TextStyle(fontSize: 18)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ClientDashboard(
                    immatriculation: widget.immatriculation,
                  ),
                ),
              );
            },
          ),
        )
      ],
    );
  }

  Widget _buildPredictionTile({
    required String title,
    required double value,
    required IconData icon,
    required Color color,
    required double maxValue,
  }) {
    final percentage = (value / maxValue * 100).clamp(0.0, 100.0);

    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, size: 40, color: color),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: percentage / 100,
                    backgroundColor: Colors.grey.shade200,
                    color: color,
                    minHeight: 12,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${percentage.toStringAsFixed(1)}% • ${_getStatusMessage(percentage)}',
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getStatusMessage(double percentage) {
    if (percentage < 30) return 'Excellent';
    if (percentage < 60) return 'Bon état';
    if (percentage < 80) return 'Usure modérée';
    if (percentage < 95) return 'Remplacement conseillé';
    return 'Danger ! Remplacement urgent';
  }
}

# predictionCalcul.py
import pandas as pd
from sklearn.linear_model import LinearRegression

# 1. Charger les données d'exemple (remplacez par vos données)
data = {
    'Kilométrage': [30000, 45000, 60000, 15000],
    'TypeRoute': ['Autoroute', 'Urbain', 'Mixte', 'Urbain'],
    'UsurePneus': [15, 25, 40, 10]
}
df = pd.DataFrame(data)

# 2. Convertir les catégories en nombres (ex: Urbain=1, Autoroute=0)
df['TypeRoute'] = df['TypeRoute'].map({'Autoroute':0, 'Urbain':1, 'Mixte':2})

# 3. Entraîner un modèle simple pour les pneus
X = df[['Kilométrage', 'TypeRoute']]
y = df['UsurePneus']

model_pneus = LinearRegression()
model_pneus.fit(X, y)

# 4. Fonction de prédiction
def predict_pneus(kilometrage, type_route):
    route_code = {'Autoroute':0, 'Urbain':1, 'Mixte':2}[type_route]
    prediction = model_pneus.predict([[kilometrage, route_code]])
    return round(prediction[0], 1)

# Testez le modèle
print(predict_pneus(50000, 'Urbain'))  # Doit retourner ~30%
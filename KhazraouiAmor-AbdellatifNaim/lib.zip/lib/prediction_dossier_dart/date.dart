import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Gère le calcul, le stockage et la mise à jour des dates de maintenance
/// basés sur les pourcentages d'usure des pièces du véhicule
class DateManager {
  static final _supabase = Supabase.instance.client;

  // Seuils de notification (jours) pour la configuration des alertes
  // Exportés en tant que constantes publiques pour être utilisés par le service de notifications
  static const int criticalThreshold =
      3; // Alerte rouge - Action immédiate requise
  static const int warningThreshold =
      7; // Alerte orange - Action requise bientôt
  static const int upcomingThreshold =
      14; // Alerte jaune - Planification à prévoir

  /// Insère ou met à jour les dates de maintenance pour un véhicule spécifique
  /// Prend une immatriculation et les dates de remplacement estimées pour chaque pièce
  static Future<bool> insertMaintenanceDates({
    required String immatriculation,
    DateTime? batterie,
    DateTime? amortisseurs,
    DateTime? embrayage,
    DateTime? freins,
    DateTime? courroie,
    DateTime? vidange,
    DateTime? pneus,
  }) async {
    try {
      // ÉTAPE 1: Vérifier si le véhicule existe
      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        if (kDebugMode) {
          print(
            '❌ Impossible d\'insérer des dates: véhicule $immatriculation inexistant');
        }
        return false;
      }

      // ÉTAPE 2: Vérifier si des dates existent déjà pour cette immatriculation
      final existingData = await _supabase
          .from('maintenance_dates')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      // ÉTAPE 3: Préparer l'objet de données pour les dates
      final datesData = {
        'changement_batterie': batterie?.toIso8601String(),
        'changement_amortisseurs': amortisseurs?.toIso8601String(),
        'changement_embrayage': embrayage?.toIso8601String(),
        'changement_freins': freins?.toIso8601String(),
        'changement_courroie': courroie?.toIso8601String(),
        'changement_vidange': vidange?.toIso8601String(),
        'changement_pneus': pneus?.toIso8601String(),
      };

      // Vérifier si au moins une date est fournie (validité des données)
      bool hasValidDate = datesData.values.any((value) => value != null);
      if (!hasValidDate) {
        if (kDebugMode) {
          print('⚠️ Aucune date valide fournie pour $immatriculation');
        }
        return false;
      }

      // ÉTAPE 4: Insérer ou mettre à jour selon le cas
      if (existingData != null) {
        // Mettre à jour l'enregistrement existant
        await _supabase
            .from('maintenance_dates')
            .update(datesData)
            .eq('fk_immatriculation', immatriculation);
        if (kDebugMode) {
          print("✅ Dates mises à jour avec succès pour $immatriculation!");
        }
      } else {
        // Créer un nouvel enregistrement
        datesData['fk_immatriculation'] = immatriculation;
        datesData['created_at'] = DateTime.now().toIso8601String();

        await _supabase.from('maintenance_dates').insert(datesData);
        if (kDebugMode) {
          print("✅ Dates insérées avec succès pour $immatriculation!");
        }
      }

      return true;
    } catch (e) {
      if (kDebugMode) {
        print('Erreur d\'enregistrement : $e');
      }
      return false;
    }
  }

  /// Vérifie si un véhicule existe avec l'immatriculation donnée
  static Future<bool> _vehicleExists(String immatriculation) async {
    try {
      final result = await _supabase
          .from('voiture')
          .select('immatriculation')
          .eq('immatriculation', immatriculation)
          .maybeSingle();

      return result != null;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la vérification du véhicule: $e');
      }
      return false;
    }
  }

  /// Vérifie si des prédictions d'usure existent pour un véhicule
  static Future<bool> predictionsExist(String immatriculation) async {
    try {
      final result = await _supabase
          .from('predictions')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      return result != null;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la vérification des prédictions: $e');
      }
      return false;
    }
  }


  // Méthodes de calcul
  static DateTime calculateNextDateBatterie({
    required DateTime baseDate,
    required double percentage,
    required int maxValue,
  }) {
    const maxLifeTimeDays = 720;
    final remainingPercentage = 1 - (percentage / 100);
    final remainingDays = maxLifeTimeDays * remainingPercentage;
    return baseDate.add(Duration(days: remainingDays.toInt()));
  }

  static DateTime calculateNextDateCourroie({
    required DateTime baseDate,
    required double percentage,
    required double maxValue,
  }) {
    const maxLifeTimeDays = 2190;
    final remainingPercentage = 1 - (percentage / 100);
    final remainingDays = maxLifeTimeDays * remainingPercentage;
    return baseDate.add(Duration(days: remainingDays.toInt()));
  }

  static DateTime calculateNextDatePneus({
    required DateTime baseDate,
    required double percentage,
    required double maxValue,
  }) {
    const maxLifeTimeDays = 1460;
    final remainingPercentage = 1 - (percentage / 100);
    final remainingDays = maxLifeTimeDays * remainingPercentage;
    return baseDate.add(Duration(days: remainingDays.toInt()));
  }

  static DateTime calculateNextDateFreins({
    required DateTime baseDate,
    required double percentage,
    required double maxValue,
  }) {
    const maxLifeTimeDays = 1100;
    final remainingPercentage = 1 - (percentage / 100);
    final remainingDays = maxLifeTimeDays * remainingPercentage;
    return baseDate.add(Duration(days: remainingDays.toInt()));
  }

  static DateTime calculateNextDateEmbrayage({
    required DateTime baseDate,
    required double percentage,
    required double maxValue,
  }) {
    const maxLifeTimeDays = 2738;
    final remainingPercentage = 1 - (percentage / 100);
    final remainingDays = maxLifeTimeDays * remainingPercentage;
    return baseDate.add(Duration(days: remainingDays.toInt()));
  }

  static DateTime calculateNextDateAmourtisseurs({
    required DateTime baseDate,
    required double percentage,
    required double maxValue,
  }) {
    const maxLifeTimeDays = 1825;
    final remainingPercentage = 1 - (percentage / 100);
    final remainingDays = maxLifeTimeDays * remainingPercentage;
    return baseDate.add(Duration(days: remainingDays.toInt()));
  }

  static DateTime calculateNextDateVidange({
    required DateTime baseDate,
    required dynamic percentage,
    required double maxValue,
  }) {
    // Conversion en double pour éviter les erreurs de type
    final double percentageValue =
        percentage is int ? percentage.toDouble() : (percentage as double);

    // Si l'usure est très élevée (> 90%), prévoir un remplacement dans les 7 jours
    if (percentageValue > 90) {
      return baseDate.add(const Duration(days: 2));
    }

    // Calcul du temps restant en fonction du pourcentage d'usure
    final remainingPercentage = 1 - (percentageValue / 100);
    // Durée de vie d'une vidange typique: environ 1 an ou 15000 km
    final remainingDays = 100 * remainingPercentage;

    if (kDebugMode) {
      print(
        "Vidange: $percentageValue% d'usure => remplacement dans ${remainingDays.toInt()} jours");
    }
    return baseDate.add(Duration(days: remainingDays.toInt()));
  }

  /// Met à jour les dates de maintenance en fonction des pourcentages d'usure pour une voiture spécifique
  /// Retourne true en cas de succès, false sinon
  static Future<bool> updateMaintenanceDatesFromPredictions(
      String immatriculation) async {
    try {
      if (kDebugMode) {
        print("⏳ Mise à jour des dates de maintenance pour $immatriculation...");
      }

      // ÉTAPE 1: Vérifier si le véhicule existe
      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        if (kDebugMode) {
          print(
            '❌ Impossible de mettre à jour les dates: véhicule $immatriculation inexistant');
        }
        return false;
      }

      // ÉTAPE 2: Récupérer les prédictions d'usure
      final predictions = await _supabase
          .from('predictions')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (predictions == null) {
        if (kDebugMode) {
          print("❌ Aucune prédiction d'usure trouvée pour $immatriculation");
          print(
              "ℹ️ Il est nécessaire de remplir les formulaires des pièces pour générer des prédictions");
        }
        return false;
      }

      // Vérifier que les prédictions contiennent des données valides
      bool hasValidPredictions = _containsValidPredictions(predictions);
      if (!hasValidPredictions) {
        if (kDebugMode) {
          print(
              "⚠️ Les prédictions pour $immatriculation sont incomplètes ou invalides");
        }
        return false;
      }

      final now = DateTime.now();

      // ÉTAPE 3: Calculer les dates en fonction des pourcentages d'usure
      final batterie = calculateNextDateBatterie(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'battery_health'),
          maxValue: 50000);

      final vidange = calculateNextDateVidange(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'oil_change'),
          maxValue: 10000);

      final freins = calculateNextDateFreins(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'brake_wear'),
          maxValue: 80000);

      final pneus = calculateNextDatePneus(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'tire_wear'),
          maxValue: 60000);

      final amortisseurs = calculateNextDateAmourtisseurs(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'ShockAbsorber_Wear'),
          maxValue: 120000);

      final courroie = calculateNextDateCourroie(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'belt_risk'),
          maxValue: 80000);

      final embrayage = calculateNextDateEmbrayage(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'clutch_wear'),
          maxValue: 150000);

      // ÉTAPE 4: Enregistrer les dates calculées dans la table maintenance_dates
      final success = await insertMaintenanceDates(
        immatriculation: immatriculation,
        batterie: batterie,
        vidange: vidange,
        freins: freins,
        pneus: pneus,
        amortisseurs: amortisseurs,
        courroie: courroie,
        embrayage: embrayage,
      );

      if (success) {
        if (kDebugMode) {
          print(
              "✅ Dates de maintenance mises à jour avec succès pour $immatriculation!");
        }
        return true;
      } else {
        if (kDebugMode) {
          print(
              "❌ Échec de l'enregistrement des dates de maintenance pour $immatriculation");
        }
        return false;
      }
    } catch (e) {
      if (kDebugMode) {
        print("❌ Erreur lors de la mise à jour des dates de maintenance: $e");
      }
      return false;
    }
  }

  /// Vérifie si les prédictions contiennent des données valides pour le calcul des dates
  static bool _containsValidPredictions(Map<String, dynamic> predictions) {
    // Liste des clés requises pour les prédictions
    final requiredKeys = [
      'battery_health',
      'oil_change',
      'brake_wear',
      'tire_wear',
      'ShockAbsorber_Wear',
      'belt_risk',
      'clutch_wear'
    ];

    // Vérifier que toutes les clés requises sont présentes et ont des valeurs valides
    for (final key in requiredKeys) {
      if (!predictions.containsKey(key) || predictions[key] == null) {
        return false;
      }
    }

    return true;
  }

  /// Extrait une valeur numérique sécurisée depuis les prédictions
  static double _getNumericValue(Map<String, dynamic> predictions, String key) {
    final value = predictions[key];

    if (value == null) {
      return 0.0;
    }

    if (value is int) {
      return value.toDouble();
    } else if (value is double) {
      return value;
    } else if (value is String) {
      return double.tryParse(value) ?? 0.0;
    }

    return 0.0;
  }

  /// Met à jour la date de maintenance pour une pièce spécifique suite à son remplacement
  /// À utiliser dans _buildMaintenanceTimeline lorsque l'utilisateur confirme un remplacement
  /// Retourne true en cas de succès
  static Future<bool> updateComponentMaintenanceDate({
    required String immatriculation,
    required String componentKey,
    DateTime? customNextDate,
  }) async {
    try {
      // Vérifier si le véhicule existe
      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        if (kDebugMode) {
          print(
              '❌ Impossible de mettre à jour la date: véhicule $immatriculation inexistant');
        }
        return false;
      }

      // Vérifier si le type de composant est valide
      final validComponents = [
        'changement_batterie',
        'changement_amortisseurs',
        'changement_embrayage',
        'changement_freins',
        'changement_courroie',
        'changement_vidange',
        'changement_pneus',
      ];

      if (!validComponents.contains(componentKey)) {
        if (kDebugMode) {
          print('❌ Type de composant $componentKey invalide');
        }
        return false;
      }

      // Récupérer l'enregistrement existant
      final existingData = await _supabase
          .from('maintenance_dates')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (existingData == null) {
        if (kDebugMode) {
          print('❌ Aucune date de maintenance trouvée pour $immatriculation');
        }
        return false;
      }

      // Calcul de la prochaine date de maintenance
      // Si une date personnalisée est fournie, l'utiliser
      // Sinon, calculer une nouvelle date en fonction du type de composant
      DateTime nextDate;
      if (customNextDate != null) {
        nextDate = customNextDate;
      } else {
        // Déterminer l'intervalle standard pour le composant (en jours)
        int interval;
        switch (componentKey) {
          case 'changement_batterie':
            interval = 365 * 2; // 3 ans
            break;
          case 'changement_vidange':
            interval = 100; // 1 an
            break;
          case 'changement_freins':
            interval = 365 * 3; // 2 ans
            break;
          case 'changement_pneus':
            interval = 365 * 4; // 2 ans
            break;
          case 'changement_amortisseurs':
            interval = 365 * 4; // 4 ans
            break;
          case 'changement_courroie':
            interval = 365 * 5; // 5 ans
            break;
          case 'changement_embrayage':
            interval = 365 * 6; // 4 ans
            break;
          default:
            interval = 365 * 2; // 2 ans par défaut
        }

        nextDate = DateTime.now().add(Duration(days: interval));
      }

      // Mise à jour de la date dans la base de données
      await _supabase
          .from('maintenance_dates')
          .update({componentKey: nextDate.toIso8601String()}).eq(
              'fk_immatriculation', immatriculation);

      if (kDebugMode) {
        print(
            '✅ Date de $componentKey mise à jour avec succès pour $immatriculation');
        print(
            'ℹ️ Prochaine maintenance prévue le ${nextDate.toString().substring(0, 10)}');
      }

      return true;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la mise à jour de la date de maintenance: $e');
      }
      return false;
    }
  }

  /// FONCTION PRINCIPALE: Vérifie si des dates de maintenance existent pour le véhicule sélectionné
  /// Si elles n'existent pas, calcule de nouvelles dates en fonction des prédictions d'usure
  /// À appeler lorsque l'utilisateur accède au dashboard client
  static Future<bool> verifyAndInitMaintenanceDates(
      String immatriculation) async {
    try {
      if (kDebugMode) {
        print('⏳ Vérification des dates de maintenance pour $immatriculation...');
      }

      // ÉTAPE 1: Vérifier si le véhicule existe
      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        if (kDebugMode) {
          print(
              '❌ Impossible de vérifier les dates: véhicule $immatriculation inexistant');
        }
        return false;
      }

      // ÉTAPE 2: Vérifier si des dates de maintenance existent déjà
      final existingDates = await _supabase
          .from('maintenance_dates')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (existingDates != null) {
        // Des dates existent déjà, rien à faire
        if (kDebugMode) {
          print('✅ Dates de maintenance existantes pour $immatriculation');
        }
        return true;
      }

      // ÉTAPE 3: Vérifier si des prédictions d'usure existent
      final predictionExists = await predictionsExist(immatriculation);

      if (predictionExists) {
        // Si des prédictions existent, calculer et enregistrer les dates de maintenance
        if (kDebugMode) {
          print('ℹ️ Calcul des dates de maintenance pour $immatriculation');
        }
        return await updateMaintenanceDatesFromPredictions(immatriculation);
      } else {
        // Si aucune prédiction n'existe, initialiser avec des dates par défaut
        if (kDebugMode) {
          print(
              'ℹ️ Initialisation des dates de maintenance par défaut pour $immatriculation');
        }
        return await _initializeDefaultMaintenanceDates(immatriculation);
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la vérification des dates de maintenance: $e');
      }
      return false;
    }
  }

  /// Initialise des dates de maintenance par défaut pour un véhicule sans prédictions
  static Future<bool> _initializeDefaultMaintenanceDates(
      String immatriculation) async {
    try {
      final now = DateTime.now();

      // Dates par défaut basées sur des intervalles standards
      final defaultBatteryDate =
          now.add(Duration(days: 365 * 3)); // 3 ans pour batterie
      final defaultVidangeDate =
          now.add(Duration(days: 365)); // 1 an pour vidange
      final defaultFreinsDate =
          now.add(Duration(days: 365 * 2)); // 2 ans pour freins
      final defaultPneusDate =
          now.add(Duration(days: 365 * 2)); // 2 ans pour pneus
      final defaultAmortisseursDate =
          now.add(Duration(days: 365 * 4)); // 4 ans pour amortisseurs
      final defaultCourroieDate =
          now.add(Duration(days: 365 * 5)); // 5 ans pour courroie
      final defaultEmbrayageDate =
          now.add(Duration(days: 365 * 4)); // 4 ans pour embrayage

      // Enregistrer les dates par défaut
      final success = await insertMaintenanceDates(
        immatriculation: immatriculation,
        batterie: defaultBatteryDate,
        vidange: defaultVidangeDate,
        freins: defaultFreinsDate,
        pneus: defaultPneusDate,
        amortisseurs: defaultAmortisseursDate,
        courroie: defaultCourroieDate,
        embrayage: defaultEmbrayageDate,
      );

      if (success) {
        if (kDebugMode) {
          print(
              '✅ Dates de maintenance par défaut initialisées pour $immatriculation');
        }
      } else {
        if (kDebugMode) {
          print(
              '❌ Échec de l\'initialisation des dates de maintenance par défaut');
        }
      }

      return success;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de l\'initialisation des dates par défaut: $e');
      }
      return false;
    }
  }

  /// Récupère toutes les dates de maintenance pour l'affichage de la timeline
  static Future<Map<String, DateTime?>> getFormattedMaintenanceDates(
      String immatriculation) async {
    try {
      // Vérifier si le véhicule existe
      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        if (kDebugMode) {
          print(
              '❌ Impossible de récupérer les dates: véhicule $immatriculation inexistant');
        }
        return {};
      }

      // Récupérer les dates de maintenance
      final maintenanceDates = await _supabase
          .from('maintenance_dates')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (maintenanceDates == null) {
        if (kDebugMode) {
          print('ℹ️ Aucune date de maintenance trouvée pour $immatriculation');
        }
        return {};
      }

      // Convertir les dates ISO en objets DateTime
      Map<String, DateTime?> formattedDates = {};

      // Liste des clés des composants à extraire
      final componentKeys = [
        'changement_batterie',
        'changement_amortisseurs',
        'changement_embrayage',
        'changement_freins',
        'changement_courroie',
        'changement_vidange',
        'changement_pneus',
      ];

      // Parser chaque date
      for (final key in componentKeys) {
        if (maintenanceDates[key] != null) {
          try {
            formattedDates[key] = DateTime.parse(maintenanceDates[key]);
          } catch (e) {
            formattedDates[key] = null;
          }
        } else {
          formattedDates[key] = null;
        }
      }

      return formattedDates;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la récupération des dates de maintenance: $e');
      }
      return {};
    }
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class VidangeForm extends StatefulWidget {
  final String immatriculation;
  const VidangeForm({super.key, required this.immatriculation});

  @override
  State<VidangeForm> createState() => _VidangeFormState();
}

class _VidangeFormState extends State<VidangeForm>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late String immatriculation;
  final _vilociteHuileController = TextEditingController();
  DateTime? _lastOilChangeDate;
  final List<String> _utilisation = [];
  bool _isSubmitting = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  @override
  void initState() {
    super.initState();
    immatriculation = widget.immatriculation;
    _loadExistingData();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
    _animationController.forward();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadExistingData());
  }

  @override
  void dispose() {
    _animationController.dispose();
    _vilociteHuileController.dispose();
    _lastOilChangeDate = null;
    _utilisation.clear();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color(0xFF4CAF50),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _lastOilChangeDate = picked);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is String) {
      immatriculation = args;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Erreur : Immatriculation non trouvée'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.pop(context);
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isSubmitting = true);
      final supabase = Supabase.instance.client;
      try {
        final vehiculeExiste = await supabase
            .from("voiture")
            .select()
            .eq('immatriculation', widget.immatriculation)
            .maybeSingle();
        if (vehiculeExiste == null) {
          throw "Véhicule non enregistré. Créez-le d'abord !";
        }

        // Créer un map avec seulement les données non nulles
        final Map<String, dynamic> dataToUpsert = {
          'fk_immatriculation': widget.immatriculation,
        };

        // Ajouter vilocité d'huile seulement si non vide
        if (_vilociteHuileController.text.isNotEmpty) {
          dataToUpsert['huile_power'] = _vilociteHuileController.text;
        }

        // Ajouter utilisation seulement si non vide
        if (_utilisation.isNotEmpty) {
          dataToUpsert['condition_de_utilisation'] = _utilisation.join(', ');
        }

        // Ajouter date seulement si non nulle
        if (_lastOilChangeDate != null) {
          dataToUpsert['date_dernier_vidange'] =
              _lastOilChangeDate!.toIso8601String();
        }

        await supabase
            .from('facteur')
            .upsert(dataToUpsert, onConflict: 'fk_immatriculation');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('✅ Données enregistrées avec succès !'),
              backgroundColor: Colors.green.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
          Navigator.pop(context);
          setState(() {
            _vilociteHuileController.clear();
            _utilisation.clear();
            _lastOilChangeDate = null;
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('❌ Erreur lors de l\'enregistrement !'),
              backgroundColor: Colors.red.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } finally {
        if (mounted) setState(() => _isSubmitting = false);
      }
    }
  }

  Future<void> _loadExistingData() async {
    try {
      // Réinitialiser les données pour éviter les doublons
      _utilisation.clear();

      final response = await Supabase.instance.client
          .from('facteur')
          .select()
          .eq('fk_immatriculation', widget.immatriculation)
          .maybeSingle();

      if (response != null && mounted) {
        setState(() {
          // Traiter les conditions d'utilisation sécuritairement
          if (response['condition_de_utilisation'] != null) {
            String utilisationStr =
                response['condition_de_utilisation'].toString();
            if (utilisationStr.isNotEmpty) {
              List<String> utilisationItems = utilisationStr.split(', ');
              for (String item in utilisationItems) {
                if (item.isNotEmpty) {
                  _utilisation.add(item);
                }
              }
            }
          }

          // Traiter la date sécuritairement
          if (response['date_dernier_vidange'] != null) {
            try {
              _lastOilChangeDate =
                  DateTime.parse(response['date_dernier_vidange'].toString());
            } catch (dateError) {
              if (kDebugMode) {
                print('Erreur de parsing de date: $dateError');
              }
              _lastOilChangeDate = null;
            }
          }

          // Traiter la vilocité d'huile sécuritairement
          if (response['huile_power'] != null) {
            _vilociteHuileController.text = response['huile_power'].toString();
          } else {
            _vilociteHuileController.text = '';
          }
          if (response['condition_de_utilisation'] != null) {
            _utilisation.clear();
            List<String> utilisationItems =
                response['condition_de_utilisation'].toString().split(', ');
            for (String item in utilisationItems) {
              if (item.isNotEmpty) {
                _utilisation.add(item);
              }
            }
          }
        });
      }
    } catch (e) {
      if (kDebugMode) {
        print('Erreur dans _loadExistingData: $e');
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('⚠️ Erreur de chargement: ${e.toString()}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '🛢️ Suivi Vidange',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurple,
        elevation: 0,
      ),
      body: AnimatedBuilder(
        animation: _animationController,
        builder: (context, child) {
          return FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Colors.deepPurple, Colors.deepPurpleAccent],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.deepPurple.withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.white,
                            child: SizedBox(
                              width: 80,
                              height: 80,
                              child: Image.asset(
                                'assets/vidange.png',
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            '🛢️🩸Suivi Vidange',
                            style: GoogleFonts.poppins(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Optimisez la durée de vie de votre moteur\net planifiez vos vidanges en toute sérénité.',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _buildDateField(),
                    const SizedBox(height: 32),
                    _buildVilociteHuileField(),
                    const SizedBox(height: 20),
                    _buildUsageSelection(),
                    const SizedBox(height: 20),
                    _buildSubmitButton(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildVilociteHuileField() {
    return TextFormField(
      controller: _vilociteHuileController,
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        labelText: 'vélocité  de l\'huile',
        prefixIcon: const Icon(Icons.local_gas_station, color: Colors.orange),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
      ),
      validator: (value) => value!.isEmpty ? 'Ce champ est obligatoire' : null,
    );
  }

  Widget _buildUsageSelection() {
    const utilisations = [
      'Quotidienne',
      'Voyage',
      'Autre',
      'Charges lourdes',
      'Transport de livraison',
      'Louage',
      'Taxi',
    ];
    final iconMap = {
      'Quotidienne': Icons.calendar_today,
      'Voyage': Icons.flight_takeoff,
      'Autre': Icons.build,
      'Charges lourdes': Icons.local_shipping,
      'Transport de livraison': Icons.local_shipping,
      'Louage': Icons.directions_bus,
      'Taxi': Icons.taxi_alert,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Icon(Icons.build_circle, color: Colors.deepOrange),
              SizedBox(width: 8),
              Text(
                '⚙️ Usage de vehicule',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF2E5D7E),
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: utilisations.map((utilisation) {
            final isSelected = _utilisation.contains(utilisation);
            final chipColor = Colors.deepOrange.shade300;
            return FilterChip(
              label: Text(
                utilisation,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: isSelected ? chipColor : Colors.grey.shade800,
                ),
              ),
              avatar: Icon(
                iconMap[utilisation],
                color: isSelected ? chipColor : Colors.grey,
                size: 20,
              ),
              selected: isSelected,
              onSelected: (selected) => setState(() {
                selected
                    ? _utilisation.add(utilisation)
                    : _utilisation.remove(utilisation);
              }),
              selectedColor: chipColor.withOpacity(0.15),
              backgroundColor: Colors.grey.shade100,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(
                  color: isSelected ? chipColor : Colors.grey.shade300,
                  width: 1.2,
                ),
              ),
              showCheckmark: false,
              elevation: isSelected ? 4 : 0,
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDateField() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: const Icon(Icons.date_range, color: Colors.blue),
        title: const Text('📆 Dernière vidange'),
        subtitle: Text(
          _lastOilChangeDate != null
              ? DateFormat('dd/MM/yyyy').format(_lastOilChangeDate!)
              : 'Sélectionnez une date',
        ),
        trailing: const Icon(Icons.arrow_drop_down),
        onTap: () => _selectDate(context),
      ),
    );
  }

  Widget _buildSubmitButton() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      child: ElevatedButton(
        onPressed: _isSubmitting ? null : _submitForm,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blueAccent,
          disabledBackgroundColor: Colors.grey.shade400,
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 6,
          shadowColor: Colors.blueAccent.withOpacity(0.3),
        ),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _isSubmitting
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: 12),
                    Text(
                      'Enregistrement en cours....',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.save, color: Colors.white),
                    SizedBox(width: 10),
                    Text(
                      'Sauvegarder',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

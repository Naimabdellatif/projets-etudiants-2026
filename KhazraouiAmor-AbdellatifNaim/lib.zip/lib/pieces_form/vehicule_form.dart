// ignore_for_file: unused_element, use_build_context_synchronously, deprecated_member_use

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/interfaces/show.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class VehiculeInfoForm extends StatefulWidget {
  final String? immatriculation;
  final Map<String, dynamic>? initialData;
  const VehiculeInfoForm({super.key, this.immatriculation, this.initialData});
  @override
  State<VehiculeInfoForm> createState() => _VehiculeInfoFormState();
}

class _VehiculeInfoFormState extends State<VehiculeInfoForm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _marqueController;
  final _immatriculationController = TextEditingController();
  final _modeleController = TextEditingController();
  final _anneeController = TextEditingController();
  String? _selectedMarque;
  String? _selectedMoteur;
  final _totalKmController = TextEditingController();
  final _dailyKmController = TextEditingController();
  //final _poids = TextEditingController();
  bool _isSubmitting = false;
  // Gestion du type de plaque
  String _selectedPlaqueType = 'TUN';
  String _hintText = '000-TUN-0000';
  Timer? _debounce;
  @override
  void initState() {
    super.initState();
    _marqueController = TextEditingController();
    // Forcer l’orientation portrait :
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    if (widget.initialData != null) {
      _loadInitialData();
    }
  }

  void _loadInitialData() {
    final data = widget.initialData!;
    _validateImmatriculation(data['immatriculation']);
    _immatriculationController.text = data['immatriculation'] ?? '';
    _modeleController.text = data['modele'] ?? '';
    _marqueController.text = data['marque'];
    _selectedMoteur = data['moteur'];
    _anneeController.text = data['annee']?.toString() ?? '';
  }

  @override
  void dispose() {
    _immatriculationController.dispose();
    _modeleController.dispose();
    _anneeController.dispose();
    super.dispose();
  }

  // Fonction pour mettre à jour le hintText en fonction du type de plaque
  void _updateHintText(String plaqueType) {
    setState(() {
      _selectedPlaqueType = plaqueType;
      _immatriculationController.clear(); // Clear the input field
      switch (plaqueType) {
        case 'TUN':
          _hintText = '000-TUN-0000';
          break;
        case 'RS':
          _hintText = 'RS-000000';
          break;
        case 'FR':
          _hintText = 'AA-000-AA';
          break;
      }
      _updateTextField(); // Mettre à jour le TextField après changement de type
    });
  }

  // Fonction pour formater la saisie en temps réel
  void _updateTextField() {
    final input = _immatriculationController.text;
    final formattedInput = _formatImmatriculation(input);
    _immatriculationController.value = TextEditingValue(
      text: formattedInput,
      selection: TextSelection.collapsed(offset: formattedInput.length),
    );
  }

  // Fonction pour formater la plaque d'immatriculation en fonction du type sélectionné
  String _formatImmatriculation(String input) {
    switch (_selectedPlaqueType) {
      case 'TUN':
        if (input.length >= 3 && input.length <= 7) {
          return '${input.substring(0, 3)}-TUN-${input.substring(3)}';
        }
        break;
      case 'FR':
        if (input.length >= 2 && input.length <= 7) {
          return '${input.substring(0, 2)}-${input.substring(2, 5)}-${input.substring(5)}';
        }
        break;
    }
    return input; // Retourne la saisie non formatée si elle ne correspond pas au format attendu
  }

  // Fonction pour valider la saisie en fonction du type de plaque
  bool _validateImmatriculation(String input) {
    final formattedInput = _formatImmatriculation(input);
    switch (_selectedPlaqueType) {
      case 'TUN':
        return RegExp(r'^\d{3}-TUN-\d{4}$').hasMatch(formattedInput);
      case 'RS':
        return RegExp(r'^RS-\d{6}$').hasMatch(formattedInput);
      case 'FR':
        return RegExp(r'^[A-Z]{2}-\d{3}-[A-Z]{2}$').hasMatch(formattedInput);
      default:
        return false;
    }
  }

  Future<void> _selectYear(BuildContext context) async {
    final DateTime now = DateTime.now();
    // Sélection directe de l'année avec YearPicker
    final DateTime? picked = await showDialog<DateTime>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Choisir l\'année'),
          content: SizedBox(
            width: 300,
            height: 300,
            child: YearPicker(
              firstDate: DateTime(1900),
              lastDate: now,
              initialDate: now,
              selectedDate: now,
              onChanged: (DateTime date) {
                Navigator.pop(context, date);
              },
            ),
          ),
        );
      },
    );
    if (picked != null) {
      setState(() {
        _anneeController.text = picked.year.toString();
      });
    }
  }

  Future<void> _submitForm() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw "Utilisateur non authentifié";

      // Préparation des données du véhicule
      final vehicleData = {
        'marque': _selectedMarque!,
        'modele': _modeleController.text,
        'moteur': _selectedMoteur!,
        'annee': int.parse(_anneeController.text),
        'total_km': int.parse(_totalKmController.text),
        'daily_km': int.parse(_dailyKmController.text),
        //'poids': int.parse(_poids.text),
      };

      // Préparation des données techniques
      final facteurData = {
        'fk_immatriculation': _immatriculationController.text,
        'total_km': int.parse(_totalKmController.text),
        'daily_km': int.parse(_dailyKmController.text),
        //'vehicle_weight': int.parse(_poids.text),
        'type_de_moteur': _selectedMoteur!,
      };

      // Vérification si c'est une mise à jour ou une nouvelle insertion
      if (widget.immatriculation != null) {
        // Mise à jour d'un véhicule existant
        await Supabase.instance.client
            .from('voiture')
            .update(vehicleData)
            .eq('immatriculation', widget.immatriculation!);

        // Mise à jour des données techniques
        await Supabase.instance.client
            .from('facteur')
            .upsert(facteurData, onConflict: 'fk_immatriculation');

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Véhicule mis à jour avec succès')),
        );
      } else {
        // Insertion d'un nouveau véhicule
        // Ajout de l'immatriculation aux données du véhicule
        vehicleData['immatriculation'] = _immatriculationController.text;

        // 1. Insérer le véhicule
        await Supabase.instance.client.from('voiture').insert(vehicleData);

        // 2. Lier à l'utilisateur
        await Supabase.instance.client.from('user_vehicles').insert({
          'user_id': user.id,
          'immatriculation': _immatriculationController.text,
        });

        // 3. Insérer les données techniques dans facteur
        await Supabase.instance.client
            .from('facteur')
            .upsert(facteurData, onConflict: 'fk_immatriculation');

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Véhicule ajouté avec succès')),
        );
      }

      // Navigation vers l'écran approprié
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ShowScreen(
            predictions: {},
            immatriculation: _immatriculationController.text,
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur: ${e.toString()}')),
      );
    } finally {
      setState(() => _isSubmitting = false);
    }
  }
  Future<void> _loadExistingData() async {
    try {
      final response = await Supabase.instance.client
          .from('facteur')
          .select()
          .eq('fk_immatriculation', widget.immatriculation as Object)
          .maybeSingle();

      if (response != null && mounted) {
        setState(() {
          _selectedMarque = response['marque']?.toString();
          _selectedMoteur = response['moteur']?.toString();
          _anneeController.text = response['annee']?.toString() ?? '';
          _totalKmController.text = response['total_km']?.toString() ?? '';
          _dailyKmController.text = response['daily_km']?.toString() ?? '';
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('⚠️ Erreur de chargement: ${e.toString()}')),
        );
      }
    }
  }
  @override
  Widget build(BuildContext context) {
    // Initialisation de ScreenUtil pour l'adaptation de la taille
    ScreenUtil.init(
      context,
      designSize: const Size(375, 812),
      minTextAdapt: true,
    );
    return Scaffold(
      appBar: AppBar(
        title: const Text('📋 Info Véhicule'),
        centerTitle: true,
        elevation: 4,
        backgroundColor: Colors.white,
        shadowColor: Colors.black12,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(12.w),
        child: Card(
          elevation: 8,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.r),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.w),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildHeader(),
                  SizedBox(height: 10.h),
                  const Divider(),
                  SizedBox(height: 10.h),
                  _buildImmatriculationField(),
                  SizedBox(height: 20.h),
                  _buildMarqueDropdown(),
                  SizedBox(height: 20.h),
                  _buildModeleField(),
                  SizedBox(height: 20.h),
                  _buildMoteurSelection(),
                  SizedBox(height: 20.h),
                  _buildAnneeField(),
                  SizedBox(height: 30.h),
                  _buildTotalKmField(),
                  const SizedBox(height: 20),
                  _buildDailyKmField(),
                  const SizedBox(height: 20),
                  //_buildPoidsehicule(),
                  //const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: SizedBox(
        width: 30.w,
        height: 60.w,
        child: FittedBox(
          child: FloatingActionButton(
            onPressed: _isSubmitting ? null : _submitForm,
            backgroundColor: Colors.green,
            child: _isSubmitting
                ? const CircularProgressIndicator(color: Colors.white)
                : const Icon(Icons.check),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        CircleAvatar(
          radius: 40,
          backgroundColor: Colors.white,
          child: SizedBox(
            width: 80, // Même taille que le diamètre du CircleAvatar
            height: 80,
            child: Lottie.asset(
              'assets/voiture_animation.json',
              fit: BoxFit.contain,
              animate: true,
              repeat: true,
              frameRate: FrameRate.max,
            ),
          ),
        ),
        SizedBox(height: 15.h),
        Text(
          '🚘 Nouveau Véhicule',
          style: TextStyle(
            fontSize: 18.sp,
            fontWeight: FontWeight.bold,
            color: Colors.blueGrey.shade900,
            letterSpacing: 1.1,
          ),
        ),
        SizedBox(height: 8.h),
        Text(
          'Complétez les informations de base de votre véhicule',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12.sp,
            color: Colors.grey.shade700,
            height: 1.4,
          ),
        ),
      ],
    );
  }

  Widget _buildImmatriculationField() {
    return Column(
      children: [
        // Sélecteur de type de plaque
        Row(
          children: [
            Text('Type de plaque :', style: TextStyle(fontSize: 13)),
            SizedBox(width: 8),
            IgnorePointer(
              ignoring: widget.immatriculation != null,
              child: Row(
                children: [
                  Row(
                    children: [
                      Radio(
                        value: 'TUN',
                        groupValue: _selectedPlaqueType,
                        onChanged: (value) {
                          _updateHintText(value as String);
                        },
                      ),
                      Text('TUN'),
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                        value: 'RS',
                        groupValue: _selectedPlaqueType,
                        onChanged: (value) {
                          _updateHintText(value as String);
                        },
                      ),
                      Text('RS'),
                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                        value: 'FR',
                        groupValue: _selectedPlaqueType,
                        onChanged: (value) {
                          _updateHintText(value as String);
                        },
                      ),
                      Text('FR'),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
        // Champ de texte pour l'immatriculation
        TextFormField(
          controller: _immatriculationController,
          style: TextStyle(fontSize: 14.sp),
          decoration: InputDecoration(
            labelText: ' Numéro d\'immatriculation',
            hintText: _hintText,
            prefixIcon: Icon(Icons.confirmation_number,
                color: Colors.blueAccent, size: 20.sp),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15.r),
              borderSide: const BorderSide(color: Colors.blueAccent, width: 1),
            ),
            filled: true,
            fillColor: Colors.white,
            contentPadding:
                EdgeInsets.symmetric(vertical: 14.h, horizontal: 16.w),
          ),
          validator: (value) {
            if (value!.isEmpty) {
              return 'Champ obligatoire';
            }
            if (!_validateImmatriculation(value)) {
              return 'Format d\'immatriculation invalide';
            }
            return null;
          },
          keyboardType: TextInputType.text,
          textCapitalization: TextCapitalization.characters,
          onChanged: (value) {
            // Debounce input changes
            if (_debounce?.isActive ?? false) _debounce!.cancel();
            _debounce = Timer(const Duration(milliseconds: 300), () {
              //FocusScope.of(context).unfocus();
              final input = _immatriculationController.text;
              // Formater la saisie
              final String() = _formatImmatriculation(input);
              // Convertir la saisie en majuscules
              final upperCaseValue = value.toUpperCase();
              _immatriculationController.value = TextEditingValue(
                text: upperCaseValue,
                selection: _immatriculationController.selection,
              );
              _updateTextField(); // Mettre à jour le TextField en temps réel
            });
          },
        ),
      ],
    );
  }

/*  Widget _buildPoidsehicule() {
    return TextFormField(
      controller: _poids,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: '🎰 poids',
        prefixIcon:
            const Icon(Icons.history, color: Color.fromARGB(255, 29, 35, 120)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
      ),
      validator: (value) =>
          value!.isEmpty ? 'Veuillez entrer le poids du véhicule' : null,
    );
  }
*/
  Widget _buildMarqueDropdown() {
    final List<String> marques = [
      'Audi',
      'BMW',
      'Citroen',
      'Fiat',
      'Ford',
      'Honda',
      'Hyundai',
      'Isuzu',
      'Jaguar',
      'Jeep',
      'Kia',
      'Mazda',
      'Mercedes',
      'Mitsubishi',
      'Mahindra',
      'Maruti',
      'Nissan',
      'Opel',
      'Peugeot',
      'Renault',
      'Seat',
      'Skoda',
      'Toyota',
      'TATA'
      'Volkswagen',
      'Volvo',
      'Autre'
    ];
    return Autocomplete<String>(
      optionsBuilder: (TextEditingValue textEditingValue) {
        if (textEditingValue.text.isEmpty) {
          return const Iterable<String>.empty();
        }
        return marques.where((option) =>
            option.toLowerCase().contains(textEditingValue.text.toLowerCase()));
      },
      onSelected: (String selection) {
        setState(() {
          _selectedMarque = selection; // Met à jour la marque sélectionnée
        });
      },
      fieldViewBuilder: (BuildContext context,
          TextEditingController fieldTextEditingController,
          FocusNode fieldFocusNode,
          VoidCallback onFieldSubmitted) {
        return TextFormField(
          controller: fieldTextEditingController,
          focusNode: fieldFocusNode,
          decoration: _customInputDecoration('🚗 Marque', Icons.search),
          validator: (value) {
            if (_selectedMarque == null || _selectedMarque!.isEmpty) {
              return 'Veuillez sélectionner une marque';
            }
            return null;
          },
          onChanged: (value) => setState(() {}),
        );
      },
      optionsViewBuilder: (BuildContext context,
          AutocompleteOnSelected<String> onSelected, Iterable<String> options) {
        return Align(
          alignment: Alignment.topLeft,
          child: Material(
            elevation: 4.0,
            child: Container(
              width: MediaQuery.of(context).size.width * 0.8,
              constraints: BoxConstraints(maxHeight: 200.h),
              child: ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: options.length,
                itemBuilder: (BuildContext context, int index) {
                  final option = options.elementAt(index);
                  return ListTile(
                    title: Text(
                      option,
                      style: TextStyle(fontSize: 14.sp),
                    ),
                    onTap: () {
                      onSelected(option);
                    },
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildModeleField() {
    return TextFormField(
      controller: _modeleController,
      style: TextStyle(fontSize: 14.sp),
      decoration: _customInputDecoration('📝 Modèle', Icons.model_training),
      validator: (value) => value!.isEmpty ? 'Champ obligatoire' : null,
    );
  }

  Widget _buildMoteurSelection() {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      elevation: 3,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '⚙️ Type de moteur',
              style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 10.h),
            Row(
              children: [
                Expanded(
                  child: RadioListTile<String>(
                    title: Text('Essence ⛽', style: TextStyle(fontSize: 13.sp)),
                    value: 'Essence',
                    groupValue: _selectedMoteur,
                    onChanged: (value) =>
                        setState(() => _selectedMoteur = value),
                    activeColor: Colors.green,
                  ),
                ),
                Expanded(
                  child: RadioListTile<String>(
                    title:
                        Text('Diesel 🛢️', style: TextStyle(fontSize: 14.sp)),
                    value: 'Diesel',
                    groupValue: _selectedMoteur,
                    onChanged: (value) =>
                        setState(() => _selectedMoteur = value),
                    activeColor: Colors.blue,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnneeField() {
    return TextFormField(
      controller: _anneeController,
      readOnly: true,
      style: TextStyle(fontSize: 14.sp),
      decoration: InputDecoration(
        labelText: '📅 Année de fabrication',
        labelStyle: TextStyle(fontSize: 14.sp),
        prefixIcon:
            Icon(Icons.calendar_today, color: Colors.redAccent, size: 20.sp),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.r),
        ),
        filled: true,
        fillColor: Colors.white,
        suffixIcon: IconButton(
          icon: const Icon(Icons.arrow_drop_down),
          onPressed: () => _selectYear(context),
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 14.h, horizontal: 16.w),
      ),
      validator: (value) => value!.isEmpty ? 'Sélectionnez une année' : null,
    );
  }

  Widget _buildTotalKmField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 6.0),
          child: Text(
            'Total de kilométrage (km)',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Color(0xFF2E5D7E),
            ),
          ),
        ),
        TextFormField(
          controller: _totalKmController,
          keyboardType: TextInputType.number,
          style: const TextStyle(fontSize: 15),
          decoration: InputDecoration(
            hintText: 'Ex : 120000',
            prefixIcon: const Icon(Icons.speed, color: Color(0xFF2E5D7E)),
            filled: true,
            fillColor: Colors.white,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF2E5D7E), width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
            ),
          ),
          validator: (value) => value == null || value.isEmpty
              ? 'Veuillez indiquer le kilométrage total du véhicule'
              : null,
        ),
      ],
    );
  }

  Widget _buildDailyKmField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 6.0),
          child: Text(
            'Kilométrage moyen quotidien',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Color(0xFF2E5D7E),
            ),
          ),
        ),
        TextFormField(
          controller: _dailyKmController,
          keyboardType: TextInputType.number,
          style: const TextStyle(fontSize: 15),
          decoration: InputDecoration(
            hintText: 'Ex : 60',
            prefixIcon: const Icon(Icons.av_timer, color: Color(0xFF2E5D7E)),
            suffixText: 'km',
            filled: true,
            fillColor: Colors.white,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF2E5D7E), width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
            ),
          ),
          validator: (value) => value == null || value.isEmpty
              ? 'Veuillez indiquer la distance moyenne parcourue par jour'
              : null,
        ),
      ],
    );
  }

  InputDecoration _customInputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(fontSize: 14.sp),
      prefixIcon: Icon(icon, color: Colors.blueAccent, size: 20.sp),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15.r),
        borderSide: const BorderSide(color: Colors.blueAccent, width: 1),
      ),
      filled: true,
      fillColor: Colors.white,
      contentPadding: EdgeInsets.symmetric(vertical: 14.h, horizontal: 16.w),
    );
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PneusForm extends StatefulWidget {
  final String immatriculation;
  final PostgrestMap initialData;
  const PneusForm(
      {super.key, required this.immatriculation, required this.initialData});

  @override
  State<PneusForm> createState() => _PneusFormState();
}

class _PneusFormState extends State<PneusForm>
    with SingleTickerProviderStateMixin {
  late String immatriculation;
  final _formKey = GlobalKey<FormState>();
  //final _kmTotalController = TextEditingController();
  DateTime? _installationDate;
  final List<String> _selectedRouteTypes = [];
  String? _selectedDrivingStyle;
  String? _selectedTireBrand;
  bool _isSubmitting = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _loadExistingData();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
    _animationController.forward();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadExistingData());
  }

  @override
  void dispose() {
    _animationController.dispose();
    //_kmTotalController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color(0xFF4CAF50),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _installationDate = picked);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is String) {
      immatriculation = args;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Erreur : Immatriculation non trouvée'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.pop(context);
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isSubmitting = true);
      final supabase = Supabase.instance.client;
      try {
        final vehiculeExiste = await supabase
            .from("voiture")
            .select()
            .eq('immatriculation', widget.immatriculation)
            .maybeSingle();
        if (vehiculeExiste == null) {
          throw "Véhicule non enregistré. Créez-le d'abord !";
        }
        
        // Préparer les données à sauvegarder avec sécurité null
        final Map<String, dynamic> dataToUpsert = {
          'fk_immatriculation': widget.immatriculation,
        };
        
        // Ajouter date seulement si non nulle
        if (_installationDate != null) {
          dataToUpsert['date_installation_pneus'] = _installationDate!.toIso8601String();
        }
        
        // Ajouter type de route seulement si non vide
        if (_selectedRouteTypes.isNotEmpty) {
          dataToUpsert['type_de_route'] = _selectedRouteTypes.join('//');
        }
        
        // Ajouter style de conduite seulement si non null
        if (_selectedDrivingStyle != null) {
          dataToUpsert['style_de_conduite'] = _selectedDrivingStyle;
        }
        
        // Ajouter marque de pneus seulement si non null
        if (_selectedTireBrand != null) {
          dataToUpsert['marque_pneus'] = _selectedTireBrand;
        }
        
        await supabase.from('facteur').upsert(dataToUpsert, onConflict: 'fk_immatriculation');
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('✅ Données enregistrées avec succès !'),
              backgroundColor: Colors.green.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
          Navigator.pop(context);
          setState(() {
            _installationDate = null;
            //_kmTotalController.clear();
            _selectedRouteTypes.clear();
            _selectedDrivingStyle = null;
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('❌ Erreur: ${e.toString()}'),
              backgroundColor: Colors.red.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() => _isSubmitting = false);
        }
      }
    }
  }

  Future<void> _loadExistingData() async {
    if (widget.initialData.isNotEmpty && mounted) {
      setState(() {
        //_kmTotalController.text = widget.initialData['total_km']?.toString() ?? '';
        _selectedDrivingStyle =
            widget.initialData['style_de_conduite']?.toString();
        _installationDate =
            widget.initialData['date_installation_pneus'] != null
                ? DateTime.parse(
                    widget.initialData['date_installation_pneus'].toString())
                : null;
        // Gérer le cas où type_de_route est null
        if (widget.initialData['type_de_route'] != null) {
          final routeTypes = widget.initialData['type_de_route'].toString();
          if (routeTypes.isNotEmpty) {
            _selectedRouteTypes.addAll(routeTypes.split('//').where((type) => type.isNotEmpty));
          }
        }
        _selectedTireBrand = widget.initialData['marque_pneus']?.toString();
      });
      return;
    }

    // Charger les données existantes pour l'immatriculation
    try {
      final response = await Supabase.instance.client
          .from('facteur')
          .select()
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();
      if (response != null && mounted) {
        setState(() {
          //_kmTotalController.text = response['total_km']?.toString() ?? '';
          _selectedDrivingStyle = response['style_de_conduite']?.toString();
          _installationDate = response['date_installation_pneus'] != null
              ? DateTime.parse(response['date_installation_pneus'].toString())
              : null;
          _selectedRouteTypes.clear();
          // Gérer le cas où type_de_route est null
          if (response['type_de_route'] != null) {
            final routeTypes = response['type_de_route'].toString();
            if (routeTypes.isNotEmpty) {
              _selectedRouteTypes.addAll(routeTypes.split('//').where((type) => type.isNotEmpty));
            }
          }
          _selectedTireBrand = response['marque_pneus']?.toString();
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('⚠️ Erreur de chargement: ${e.toString()}')),
        );
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '🔧 Suivi des Pneus',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color.fromARGB(255, 11, 192, 205),
        elevation: 0,
      ),
      body: AnimatedBuilder(
        animation: _animationController,
        builder: (context, child) {
          return FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color.fromARGB(255, 28, 188, 188), Colors.deepPurpleAccent],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: const Color.fromARGB(255, 8, 181, 216).withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.white,
                            child: SizedBox(
                              width:
                                  80, // Même taille que le diamètre du CircleAvatar
                              height: 80,
                              child: Image(
                                image: AssetImage('assets/pneusIcon.png'),
                                fit: BoxFit.contain,
                                
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Suivi des Pneus',
                            style: GoogleFonts.poppins(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Remplissez les détails pour une analyse optimale de vos pneus',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                                          const SizedBox(height: 24),
                      _buildDateField(),
                      const SizedBox(height: 20),
                      //_buildVehicleKmField(),
                      //const SizedBox(height: 20),
                      _buildTireBrandSelection(),
                      const SizedBox(height: 32),
                      _buildRouteTypeSelection(),
                      const SizedBox(height: 20),
                      _buildDrivingStyleSelection(),
                      const SizedBox(height: 32),
                      _buildSubmitButton(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDateField() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.green.shade300, Colors.green.shade100],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.green.withOpacity(0.2),
            blurRadius: 6,
            offset: const Offset(0, 3),
          )
        ],
      ),
      child: ListTile(
        leading: const Icon(Icons.calendar_today, color: Colors.white),
        title: const Text('📅 Date d\'installation',
            style: TextStyle(color: Colors.white)),
        subtitle: Text(
          _installationDate != null
              ? DateFormat('dd/MM/yyyy').format(_installationDate!)
              : 'Sélectionnez une date',
          style: const TextStyle(color: Colors.white70),
        ),
        trailing: const Icon(Icons.arrow_drop_down, color: Colors.white),
        onTap: () => _selectDate(context),
      ),
    );
  }

  /*Widget _buildVehicleKmField() {
    // Champ de saisie modernisé
    return TextFormField(
      controller: _kmTotalController,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: '📏 Kilométrage total (km)',
        labelStyle: TextStyle(
          color: Colors.orange.shade700,
          fontWeight: FontWeight.bold,
        ),
        prefixIcon: const Icon(Icons.speed_outlined, color: Colors.orange),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.orange.shade50,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      validator: (value) =>
          value!.isEmpty ? 'Veuillez entrer le Km total parcourir' : null,
    );
  }
*/
  Widget _buildTireBrandSelection() {
    final List<String> tireOptions = ['Original', '1er choix', '2e choix'];
    final Map<String, IconData> tireIcons = {
      'Original': Icons.star,
      '1er choix': Icons.star_half,
      '2e choix': Icons.star_border,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 12.0),
          child: Row(
            children: [
              Icon(Icons.local_fire_department, color: Colors.redAccent),
              SizedBox(width: 8),
              Text(
                '🏷 Marque des pneus',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        Column(
          children: tireOptions.map((option) {
            final bool isSelected = _selectedTireBrand == option;
            return GestureDetector(
              onTap: () => setState(() => _selectedTireBrand = option),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(vertical: 6),
                padding:
                    const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFFE3F2FD) : Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color:
                        isSelected ? Colors.blueAccent : Colors.grey.shade300,
                    width: isSelected ? 2 : 1,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: Colors.blueAccent.withOpacity(0.15),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          )
                        ]
                      : [],
                ),
                child: Row(
                  children: [
                    Icon(
                      tireIcons[option],
                      color: isSelected ? Colors.blueAccent : Colors.grey,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        option,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.normal,
                          color:
                              isSelected ? Colors.blueAccent : Colors.black87,
                        ),
                      ),
                    ),
                    if (isSelected)
                      const Icon(Icons.check_circle, color: Colors.blueAccent),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildRouteTypeSelection() {
    const routeTypes = [
      'Autoroute',
      'Urbain',
      'Terre',
      'Asphelte',
      'Fourage',
      'Beton',
      'Gravier',
      'Piste',
      'Montagne'
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12.0),
          child: Row(
            children: [
              Icon(Icons.alt_route, color: Colors.green.shade600),
              const SizedBox(width: 8),
              Text(
                '🚧 Type de route',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey.shade800,
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: routeTypes.map((type) {
            final isSelected = _selectedRouteTypes.contains(type);
            return ChoiceChip(
              label: Text(
                type,
                style: TextStyle(
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                ),
              ),
              selected: isSelected,
              selectedColor: Colors.green.shade100,
              backgroundColor: Colors.grey.shade200,
              labelStyle: TextStyle(
                color: isSelected ? Colors.green.shade800 : Colors.black87,
              ),
              avatar: Icon(
                isSelected ? Icons.check_circle : Icons.circle_outlined,
                size: 18,
                color: isSelected ? Colors.green : Colors.grey,
              ),
              onSelected: (selected) => setState(() {
                selected
                    ? _selectedRouteTypes.add(type)
                    : _selectedRouteTypes.remove(type);
              }),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              elevation: isSelected ? 4 : 0,
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDrivingStyleSelection() {
    final drivingStyles = {
      'Calme': Icons.directions_walk,
      'Normal': Icons.directions_car,
      'Sportif': Icons.speed,
    };
    final colors = {
      'Calme': Colors.lightBlue,
      'Normal': Colors.teal,
      'Sportif': Colors.deepPurple,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12.0),
          child: Row(
            children: [
              const Icon(Icons.sports_score, color: Colors.deepPurple),
              const SizedBox(width: 8),
              Text(
                '🏎 Style de conduite',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey.shade800,
                ),
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: drivingStyles.entries.map((entry) {
            final isSelected = _selectedDrivingStyle == entry.key;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isSelected
                    ? colors[entry.key]!.withOpacity(0.15)
                    : Colors.grey.shade100,
                border: Border.all(
                  color: isSelected ? colors[entry.key]! : Colors.grey.shade300,
                  width: isSelected ? 2 : 1,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: colors[entry.key]!.withOpacity(0.2),
                          blurRadius: 6,
                          offset: const Offset(0, 3),
                        )
                      ]
                    : [],
              ),
              child: InkWell(
                onTap: () => setState(() {
                  _selectedDrivingStyle = entry.key;
                }),
                child: Row(
                  children: [
                    Icon(entry.value,
                        color: isSelected
                            ? colors[entry.key]
                            : Colors.grey.shade600),
                    const SizedBox(width: 8),
                    Text(
                      entry.key,
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: isSelected
                            ? colors[entry.key]
                            : Colors.grey.shade700,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSubmitButton() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Colors.blueAccent, Colors.lightBlueAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.blueAccent.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: ElevatedButton.icon(
        icon: _isSubmitting
            ? const CircularProgressIndicator(color: Colors.white)
            : const Icon(Icons.save_alt, size: 24),
        label: Text(
          _isSubmitting ? 'Enregistrement...' : 'Enregistrer les données',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        onPressed: _isSubmitting ? null : _submitForm,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blueAccent,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 4,
          shadowColor: Colors.blue.shade100,
        ),
      ),
    );
  }
}

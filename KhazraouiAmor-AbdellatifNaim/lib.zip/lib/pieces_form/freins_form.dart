// ignore_for_file: unused_field, unused_local_variable, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:math' as math;

class AnimatedSection extends StatelessWidget {
  final Widget child;
  final Duration delay;
  final Duration duration;
  final Curve curve;
  final bool fadeIn;
  final bool slideIn;
  final bool scaleIn;

  const AnimatedSection({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 750),
    this.curve = Curves.easeOutCubic,
    this.fadeIn = true,
    this.slideIn = true,
    this.scaleIn = false,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Future.delayed(delay),
      builder: (context, _) => TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0.0, end: 1.0),
        duration: duration,
        curve: curve,
        key: key,
        builder: (context, value, child) {
          return Opacity(
            opacity: fadeIn ? value : 1.0,
            child: Transform.translate(
              offset: slideIn ? Offset(0, 20 * (1 - value)) : Offset.zero,
              child: Transform.scale(
                scale: scaleIn ? 0.95 + (0.05 * value) : 1.0,
                child: child,
              ),
            ),
          );
        },
        child: child,
      ),
    );
  }
}

class FreinsForm extends StatefulWidget {
  final String immatriculation;
  const FreinsForm({super.key, required this.immatriculation});
  @override
  State<FreinsForm> createState() => _FreinsFormState();
}

// Custom painter for curved background decoration
class CurvedBackgroundPainter extends CustomPainter {
  final Color color1;
  final Color color2;

  CurvedBackgroundPainter({required this.color1, required this.color2});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..shader = LinearGradient(
        colors: [color1, color2],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;

    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width, size.height * 0.7)
      ..quadraticBezierTo(
          size.width * 0.5, size.height * 1.2, 0, size.height * 0.7)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FreinsFormState extends State<FreinsForm>
    with SingleTickerProviderStateMixin {
  // Form state variables
  late String immatriculation;
  final _formKey = GlobalKey<FormState>();
  DateTime? _installationDate;
  final List<String> _selectedRouteTypes = [];
  String? _selectedDrivingStyle;
  String? _selectedTemperature;
  final List<String> _utilisation = [];
  String? _selectedQualitePiece;
  bool _isSubmitting = false;
  bool _isLoading = true;

  // Animation controllers
  late AnimationController _animationController;
  // Animations that will be used for transition effects
  late Animation<double> _fadeAnimation; // Used for main container fading in
  late Animation<double>
      _slideAnimation; // Used for animated feedback on form submission
  late Animation<double> _scaleAnimation; // Used for button scaling effects

  // Page controller for card swiping effect
  final PageController _pageController = PageController();

  // Colors
  final Color _primaryColor = const Color(0xFF3F51B5); // Indigo
  final Color _accentColor = const Color(0xFFFF5722); // Deep Orange
  final Color _secondaryColor = const Color(0xFF4CAF50); // Green
  final Color _cardColor = Colors.white;
  final Color _backgroundColor = const Color(0xFFF5F7FA);

  // Theme-related globals
  final BorderRadius _borderRadius = BorderRadius.circular(16.0);
  final double _elevation = 4.0;
  @override
  void initState() {
    super.initState();
    // Initialize immatriculation from widget
    immatriculation = widget.immatriculation;

    // Setup animations
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    // Create multiple animations with different curves and delays
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _slideAnimation = Tween<double>(begin: 50.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.1, 0.9, curve: Curves.easeOutCubic),
      ),
    );

    _scaleAnimation = Tween<double>(begin: 0.9, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.3, 1.0, curve: Curves.easeOut),
      ),
    );

    // Start animations and load data
    _animationController.forward();
    _isLoading = true;
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadExistingData());
  }

  @override
  void dispose() {
    _animationController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color(0xFF4CAF50),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _installationDate = picked);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // This method is no longer needed since we're getting immatriculation from widget
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isSubmitting = true);
      final supabase = Supabase.instance.client;
      // Apply haptic feedback
      HapticFeedback.mediumImpact();

      // Animate the form with scale effect before submitting
      _animationController.reverse().then((_) {
        _animationController.forward();
      });

      try {
        // Vérifier si le véhicule existe
        final vehiculeExiste = await supabase
            .from("voiture")
            .select()
            .eq('immatriculation', widget.immatriculation)
            .maybeSingle();
        if (vehiculeExiste == null) {
          throw "Véhicule non enregistré. Créez-le d'abord !";
        }
        await supabase.from('facteur').upsert({
          'fk_immatriculation': widget.immatriculation,
          'date_installation_frein': _installationDate?.toIso8601String(),
          'temperature': _selectedTemperature,
          //'daily_km': _dailyKmController.text,
          'type_de_route': _selectedRouteTypes.join('//'),
          'style_de_conduite': _selectedDrivingStyle,
          'condition_de_utilisation': _utilisation.join("//"),
          'qualite_de_la_piece_frein': _selectedQualitePiece,
        }, onConflict: 'fk_immatriculation');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('✅ Données enregistrées avec succès !'),
              backgroundColor: Colors.green.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
          Navigator.pop(context);
          setState(() {
            _installationDate = null;
            _selectedRouteTypes.clear();
            _selectedDrivingStyle = null;
            //_dailyKmController.clear();
            _selectedTemperature = null;
            _utilisation.clear();
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('❌ Erreur: ${e.toString()}'),
              backgroundColor: Colors.red.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() => _isSubmitting = false);
        }
      }
    }
  }

  Future<void> _loadExistingData() async {
    try {
      final supabase = Supabase.instance.client;
      final data = await supabase
          .from('facteur')
          .select()
          .eq('fk_immatriculation', widget.immatriculation)
          .maybeSingle();

      if (data != null) {
        setState(() {
          if (data['date_installation_frein'] != null) {
            _installationDate = DateTime.parse(data['date_installation_frein']);
          }
          if (data['temperature'] != null) {
            _selectedTemperature = data['temperature'];
          }
          if (data['qualite_de_la_piece_frein'] != null) {
            _selectedQualitePiece = data['qualite_de_la_piece_frein'];
          }
          if (data['type_de_route'] != null) {
            _selectedRouteTypes
                .addAll(data['type_de_route'].split('//').toList());
          }
          if (data['style_de_conduite'] != null) {
            _selectedDrivingStyle = data['style_de_conduite'];
          }
          if (data['condition_de_utilisation'] != null) {
            _utilisation
                .addAll(data['condition_de_utilisation'].split('//').toList());
          }
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('⚠️ Erreur de chargement: ${e.toString()}'),
            backgroundColor: Colors.red.shade700,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      // Set loading to false when data is loaded (or failed to load)
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text(
          '🛑 Suivi du Freinage',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Colors.white,
          ),
        ),
        backgroundColor: _primaryColor.withOpacity(0.85),
        elevation: 0,
        centerTitle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(16)),
        ),
        leading: BackButton(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline, color: Colors.white),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text(
                      'Suivez l\'état de vos freins pour une conduite sécurisée'),
                  backgroundColor: _primaryColor,
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              );
            },
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _backgroundColor,
              Color.lerp(
                  _backgroundColor, _primaryColor.withOpacity(0.1), 0.1)!,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: _isLoading
              ? Center(child: CircularProgressIndicator(color: _primaryColor))
              : AnimatedBuilder(
                  animation: _animationController,
                  builder: (context, _) {
                    return SingleChildScrollView(
                      controller: _pageController,
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20.0, vertical: 16.0),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            AnimatedSection(
                              delay: const Duration(milliseconds: 100),
                              child: _buildHeader(),
                            ),
                            const SizedBox(height: 24),
                            // Section Date d'installation
                            AnimatedSection(
                              delay: const Duration(milliseconds: 200),
                              child: Card(
                                elevation: _elevation,
                                color: _cardColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: _borderRadius),
                                margin: const EdgeInsets.symmetric(vertical: 8),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: _buildDateField(),
                                ),
                              ),
                            ),
                            // Section Température
                            AnimatedSection(
                              delay: const Duration(milliseconds: 300),
                              child: Card(
                                elevation: _elevation,
                                color: _cardColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: _borderRadius),
                                margin: const EdgeInsets.symmetric(vertical: 8),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: _buildSelectedTemperature(),
                                ),
                              ),
                            ),
                            // Section Route
                            AnimatedSection(
                              delay: const Duration(milliseconds: 400),
                              child: Card(
                                elevation: _elevation,
                                color: _cardColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: _borderRadius),
                                margin: const EdgeInsets.symmetric(vertical: 8),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: _buildRouteTypeSelection(),
                                ),
                              ),
                            ),

                            // Section Style de conduite
                            AnimatedSection(
                              delay: const Duration(milliseconds: 500),
                              child: Card(
                                elevation: _elevation,
                                color: _cardColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: _borderRadius),
                                margin: const EdgeInsets.symmetric(vertical: 8),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: _buildDrivingStyleSelection(),
                                ),
                              ),
                            ),

                            // Section Condition d'utilisation
                            AnimatedSection(
                              delay: const Duration(milliseconds: 600),
                              child: Card(
                                elevation: _elevation,
                                color: _cardColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: _borderRadius),
                                margin: const EdgeInsets.symmetric(vertical: 8),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: _buildUtilisationSelection(),
                                ),
                              ),
                            ),

                            const SizedBox(height: 32),
                            _buildQualitePiece(),
                            // Submit button with scale animation
                            AnimatedSection(
                              delay: const Duration(milliseconds: 700),
                              scaleIn: true,
                              child: _buildSubmitButton(),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        // Decorative top background arc
        Container(
          width: double.infinity,
          height: 60,
          margin: const EdgeInsets.only(bottom: 20),
          child: CustomPaint(
            painter: CurvedBackgroundPainter(
              color1: _primaryColor.withOpacity(0.1),
              color2: _accentColor.withOpacity(0.1),
            ),
          ),
        ),

        // Logo and brake icon
        Stack(
          alignment: Alignment.center,
          children: [
            // Animated background circle
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0.0, end: 1.0),
              duration: const Duration(seconds: 1),
              builder: (context, value, _) {
                return Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: SweepGradient(
                      startAngle: 0,
                      endAngle: math.pi * 2 * value,
                      colors: [
                        _primaryColor.withOpacity(0.5),
                        _accentColor.withOpacity(0.7),
                        _primaryColor.withOpacity(0.5),
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _accentColor.withOpacity(0.3),
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                );
              },
            ),

            // Icon
            CircleAvatar(
              radius: 40,
              backgroundColor: Colors.white,
              child: Image.asset("assets/frien.webp"),
            ),
          ],
        ),

        const SizedBox(height: 20),

        // Title with gradient effect
        ShaderMask(
          shaderCallback: (Rect bounds) {
            return LinearGradient(
              colors: [
                _primaryColor,
                _accentColor,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds);
          },
          child: Text(
            '🛑 Suivi des Freins',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color:
                  Colors.white, // This color will be replaced by the gradient
              letterSpacing: 0.5,
            ),
          ),
        ),

        const SizedBox(height: 10),

        // Subtitle with animation
        TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0.0, end: 1.0),
          duration: const Duration(milliseconds: 800),
          builder: (context, value, _) {
            return Opacity(
              opacity: value,
              child: Text(
                'Remplissez les détails pour une analyse optimale',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey.shade600,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            );
          },
        ),

        // Divider
        Container(
          margin: const EdgeInsets.only(top: 20, bottom: 10),
          width: 100,
          height: 3,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _primaryColor.withOpacity(0.2),
                _accentColor.withOpacity(0.8),
                _primaryColor.withOpacity(0.2),
              ],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ],
    );
  }

  Widget _buildDateField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section title
        Row(
          children: [
            Icon(Icons.event, color: _primaryColor),
            const SizedBox(width: 10),
            Text(
              '📅 Date d\'installation',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: _primaryColor.withOpacity(0.9),
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),

        const SizedBox(height: 15),

        // Date selection card
        InkWell(
          onTap: () => _selectDate(context),
          borderRadius: BorderRadius.circular(12),
          splashColor: _primaryColor.withOpacity(0.1),
          highlightColor: _accentColor.withOpacity(0.05),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _installationDate != null
                    ? _primaryColor.withOpacity(0.5)
                    : Colors.grey.shade300,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: _installationDate != null
                      ? _primaryColor.withOpacity(0.1)
                      : Colors.grey.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: _installationDate != null
                      ? _primaryColor.withOpacity(0.15)
                      : Colors.grey.shade100,
                  child: Icon(
                    Icons.calendar_month,
                    color: _installationDate != null
                        ? _primaryColor
                        : Colors.grey.shade500,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _installationDate != null
                            ? DateFormat('dd MMMM yyyy', 'fr_FR')
                                .format(_installationDate!)
                            : 'Choisir une date',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: _installationDate != null
                              ? FontWeight.w600
                              : FontWeight.normal,
                          color: _installationDate != null
                              ? Colors.black87
                              : Colors.grey.shade600,
                        ),
                      ),
                      if (_installationDate != null) ...[
                        const SizedBox(height: 4),
                        Text(
                          'Age: ${DateTime.now().difference(_installationDate!).inDays} jours',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: _installationDate != null
                      ? _primaryColor.withOpacity(0.7)
                      : Colors.grey.shade400,
                  size: 18,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSelectedTemperature() {
    final temperatureOptions = {
      '0C°-20C°': Icons.ac_unit,
      '20C°-40C°': Icons.wb_sunny,
      '> 40C°': Icons.local_fire_department,
    };
    final temperatureColors = {
      '0C°-20C°': Colors.blue.shade600,
      '20C°-40C°': Colors.orange.shade600,
      '> 40C°': Colors.red.shade600,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section title with icon
        Row(
          children: [
            Icon(Icons.thermostat, color: _primaryColor),
            const SizedBox(width: 10),
            Text(
              '🌡 Température moyenne',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: _primaryColor.withOpacity(0.9),
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),

        const SizedBox(height: 15),

        // Temperature options with improved visuals
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: temperatureOptions.entries.map((entry) {
            final isSelected = _selectedTemperature == entry.key;
            final activeColor = temperatureColors[entry.key]!;

            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0),
                child: InkWell(
                  onTap: () {
                    setState(() => _selectedTemperature = entry.key);
                    HapticFeedback.lightImpact();
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOutQuint,
                    height: 120,
                    padding:
                        const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? activeColor.withOpacity(0.15)
                          : Colors.grey.shade50,
                      border: Border.all(
                        color: isSelected ? activeColor : Colors.grey.shade300,
                        width: isSelected ? 2 : 1,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: activeColor.withOpacity(0.2),
                                blurRadius: 10,
                                spreadRadius: 1,
                              )
                            ]
                          : [],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Temperature icon with animation
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? activeColor.withOpacity(0.2)
                                : Colors.grey.shade100,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            entry.value,
                            size: 30,
                            color:
                                isSelected ? activeColor : Colors.grey.shade500,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          entry.key,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight:
                                isSelected ? FontWeight.bold : FontWeight.w500,
                            color:
                                isSelected ? activeColor : Colors.grey.shade700,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

/*
  Widget _buildDailyKmField() {
    return TextFormField(
      controller: _dailyKmController,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: '📊 Km moyen par jour',
        labelStyle: TextStyle(
          color: Colors.orange.shade700,
          fontWeight: FontWeight.bold,
        ),
        prefixIcon: const Icon(Icons.speed_outlined, color: Colors.orange),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.orange.shade50,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      validator: (value) =>
          value!.isEmpty ? 'Veuillez entrer le Km moyen par jour' : null,
    );
  }*/
  Widget _buildRouteTypeSelection() {
    const routeTypes = [
      'Autoroute',
      'Urbain',
      'Terre',
      'Asphelte',
      'Fourage',
      'Beton',
      'Gravier',
      'Piste',
      'Montagne'
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12.0),
          child: Row(
            children: [
              Icon(Icons.alt_route, color: Colors.green.shade600),
              const SizedBox(width: 8),
              Text(
                '🛣 Type de route',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey.shade800,
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: routeTypes.map((type) {
            final isSelected = _selectedRouteTypes.contains(type);
            return ChoiceChip(
              label: Text(
                type,
                style: TextStyle(
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                ),
              ),
              selected: isSelected,
              selectedColor: Colors.green.shade100,
              backgroundColor: Colors.grey.shade200,
              labelStyle: TextStyle(
                color: isSelected ? Colors.green.shade800 : Colors.black87,
              ),
              avatar: Icon(
                isSelected ? Icons.check_circle : Icons.circle_outlined,
                size: 18,
                color: isSelected ? Colors.green : Colors.grey,
              ),
              onSelected: (selected) => setState(() {
                selected
                    ? _selectedRouteTypes.add(type)
                    : _selectedRouteTypes.remove(type);
              }),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              elevation: isSelected ? 4 : 0,
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDrivingStyleSelection() {
    final drivingStyles = {
      'Calme': Icons.self_improvement,
      'Normal': Icons.directions_car,
      'Sportif': Icons.sports_motorsports,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.sports_score, color: Colors.purple),
            const SizedBox(width: 8),
            Text(
              '🏎 Style de conduite',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade700),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ToggleButtons(
          borderRadius: BorderRadius.circular(12),
          selectedColor: Colors.white,
          fillColor: Colors.purpleAccent,
          constraints: const BoxConstraints(minHeight: 48),
          onPressed: (index) => setState(() {
            _selectedDrivingStyle = drivingStyles.keys.elementAt(index);
          }),
          isSelected: drivingStyles.keys
              .map((e) => e == _selectedDrivingStyle)
              .toList(),
          children: drivingStyles.entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  Icon(entry.value, size: 20),
                  const SizedBox(width: 8),
                  Text(entry.key),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildUtilisationSelection() {
    const utilisations = [
      'Quotidienne',
      'Voyage',
      'Taxi',
      'Louage',
      'Charges lourdes',
      'Transport de livraison',
      'Autre',
    ];
    final iconMap = {
      'Quotidienne': Icons.calendar_today,
      'Voyage': Icons.flight_takeoff,
      'Autre': Icons.build,
      'Charges lourdes': Icons.local_shipping,
      'Transport de livraison': Icons.local_shipping,
      'Louage': Icons.directions_bus,
      'Taxi': Icons.taxi_alert,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Icon(Icons.build_circle, color: Colors.deepOrange),
              SizedBox(width: 8),
              Text(
                '⚙️ Usage de vehicule',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF2E5D7E),
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: utilisations.map((utilisation) {
            final isSelected = _utilisation.contains(utilisation);
            final chipColor = Colors.deepOrange.shade300;
            return FilterChip(
              label: Text(
                utilisation,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: isSelected ? chipColor : Colors.grey.shade800,
                ),
              ),
              avatar: Icon(
                iconMap[utilisation],
                color: isSelected ? chipColor : Colors.grey,
                size: 20,
              ),
              selected: isSelected,
              onSelected: (selected) => setState(() {
                selected
                    ? _utilisation.add(utilisation)
                    : _utilisation.remove(utilisation);
              }),
              selectedColor: chipColor.withOpacity(0.15),
              backgroundColor: Colors.grey.shade100,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(
                  color: isSelected ? chipColor : Colors.grey.shade300,
                  width: 1.2,
                ),
              ),
              showCheckmark: false,
              elevation: isSelected ? 4 : 0,
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildQualitePiece() {
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color secondaryColor = const Color(0xFF8E54E9);

    // Options pour l'âge du véhicule
    final List<Map<String, dynamic>> ageOptions = [
      {
        'title': 'Original',
        'value': 'neuf',
        'icon': Icons.auto_awesome,
        'color': Colors.green.shade600,
        'subtitle': 'Pièce d\'origine constructeur',
      },
      {
        'title': '1er Choix',
        'value': 'recent',
        'icon': Icons.thumb_up,
        'color': Colors.blue.shade600,
        'subtitle': 'Qualité premium équivalente',
      },
      {
        'title': '2em Choix',
        'value': 'ancien',
        'icon': Icons.history,
        'color': Colors.orange.shade600,
        'subtitle': 'Qualité standard',
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Row(
            children: [
              Icon(
                Icons.directions_car,
                size: 18,
                color: primaryColor.withOpacity(0.8),
              ),
              const SizedBox(width: 8),
              Text(
                'Qualité de la pièce',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade800,
                ),
              ),
              const Spacer(),
              Tooltip(
                message: 'Sélectionnez la qualité de la pièce',
                child: Icon(
                  Icons.help_outline,
                  size: 16,
                  color: Colors.grey.shade500,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 2),
        Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade300, width: 1),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Column(
              children: List.generate(
                ageOptions.length,
                (index) {
                  final option = ageOptions[index];
                  final bool isSelected =
                      _selectedQualitePiece == option['value'];

                  // Ajouter une ligne de séparation entre les options, sauf pour la dernière
                  final bool addDivider = index < ageOptions.length - 1;

                  return Column(
                    children: [
                      InkWell(
                        onTap: () {
                          setState(() {
                            _selectedQualitePiece = option['value'];
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16.0,
                            vertical: 12.0,
                          ),
                          child: Row(
                            children: [
                              // Radio button
                              Container(
                                width: 22,
                                height: 22,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: isSelected
                                        ? option['color']
                                        : Colors.grey.shade400,
                                    width: 2,
                                  ),
                                ),
                                child: Center(
                                  child: isSelected
                                      ? Container(
                                          width: 12,
                                          height: 12,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: option['color'],
                                          ),
                                        )
                                      : null,
                                ),
                              ),

                              const SizedBox(width: 12),

                              // Icône
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: option['color'].withOpacity(0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  option['icon'],
                                  color: option['color'],
                                  size: 22,
                                ),
                              ),

                              const SizedBox(width: 16),

                              // Texte
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      option['title'],
                                      style: GoogleFonts.poppins(
                                        fontSize: 15,
                                        fontWeight: isSelected
                                            ? FontWeight.w600
                                            : FontWeight.w500,
                                        color: isSelected
                                            ? option['color']
                                            : Colors.grey.shade800,
                                      ),
                                    ),
                                    Text(
                                      option['subtitle'],
                                      style: GoogleFonts.poppins(
                                        fontSize: 13,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // Indicateur animé de sélection
                              AnimatedOpacity(
                                opacity: isSelected ? 1.0 : 0.0,
                                duration: const Duration(milliseconds: 200),
                                child: Icon(
                                  Icons.check_circle,
                                  color: option['color'],
                                  size: 20,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      if (addDivider)
                        Divider(
                          height: 1,
                          thickness: 1,
                          color: Colors.grey.shade200,
                          indent: 16,
                          endIndent: 16,
                        ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
        // Message d'aide
        Padding(
          padding: const EdgeInsets.only(left: 4, top: 8),
          child: Text(
            'La qualité de la pièce peut influencer les recommandations d\'entretien',
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontStyle: FontStyle.italic,
              color: Colors.grey.shade600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSubmitButton() {
    return Container(
      width: double.infinity,
      height: 60,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          colors: _isSubmitting
              ? [Colors.grey.shade400, Colors.grey.shade500]
              : [_primaryColor, _accentColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: _isSubmitting
                ? Colors.grey.withOpacity(0.3)
                : _primaryColor.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 6),
            spreadRadius: -3,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          splashColor: Colors.white24,
          onTap: _isSubmitting
              ? null
              : () {
                  HapticFeedback.mediumImpact();
                  _submitForm();
                },
          child: AnimatedBuilder(
            animation: _scaleAnimation,
            builder: (context, child) => Transform.scale(
              scale: _isSubmitting ? 1.0 : _scaleAnimation.value,
              child: child,
            ),
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _isSubmitting
                      ? SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : const Icon(Icons.check_circle,
                          color: Colors.white, size: 26),
                  const SizedBox(width: 16),
                  Text(
                    _isSubmitting
                        ? 'Enregistrement...'
                        : 'Enregistrer les données ',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

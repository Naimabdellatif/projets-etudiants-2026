// ignore_for_file: unused_field, unused_element_parameter, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// ─────────────────────────────────────────────
// Palette : Morning Mist — bleus poudre, lavande pâle, menthe douce
// ─────────────────────────────────────────────
class _Colors {
  static const bg        = Color(0xFFF0F4FF);
  static const surface   = Color(0xFFFFFFFF);
  static const primary   = Color(0xFF6C8EBF);   // Bleu ardoise doux
  static const accent    = Color(0xFF8FB8AD);   // Menthe sauge
  static const lavender  = Color(0xFFB5A9D4);   // Lavande
  static const textMain  = Color(0xFF2D3A50);
  static const textSub   = Color(0xFF7A8BAA);
  static const chipSel   = Color(0xFFDDE9FF);
  static const danger    = Color(0xFFE57373);
}

// ─── Animated entrance widget ─────────────────
class _FadeSlide extends StatefulWidget {
  final Widget child;
  final Duration delay;
  const _FadeSlide({required this.child, this.delay = Duration.zero});
  @override
  State<_FadeSlide> createState() => _FadeSlideState();
}

class _FadeSlideState extends State<_FadeSlide>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _fade  = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween(begin: const Offset(0, .08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    Future.delayed(widget.delay, () { if (mounted) _c.forward(); });
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: _fade,
        child: SlideTransition(position: _slide, child: widget.child),
      );
}

// ─── Soft glass card ──────────────────────────
class _Card extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  const _Card({required this.child, this.padding});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: _Colors.surface,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [
            BoxShadow(color: Color(0x14000000), blurRadius: 20, offset: Offset(0, 6)),
          ],
        ),
        child: Padding(
          padding: padding ?? const EdgeInsets.all(20),
          child: child,
        ),
      );
}

// ─── Section header ───────────────────────────
class _SectionTitle extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _SectionTitle(this.icon, this.label, {this.color = _Colors.primary});
  @override
  Widget build(BuildContext context) => Row(children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: color.withOpacity(.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: color),
        ),
        const SizedBox(width: 10),
        Text(label,
            style: GoogleFonts.dmSans(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: _Colors.textMain)),
      ]);
}

// ═══════════════════════════════════════════════
//  MAIN FORM
// ═══════════════════════════════════════════════
class AmortisseursForm extends StatefulWidget {
  final String immatriculation;
  const AmortisseursForm({super.key, required this.immatriculation});
  @override
  State<AmortisseursForm> createState() => _AmortisseursFormState();
}

class _AmortisseursFormState extends State<AmortisseursForm>
    with SingleTickerProviderStateMixin {
  late String immatriculation;
  final _formKey  = GlobalKey<FormState>();
  final List<String> _conduitePlace  = [];
  final List<String> _utilisation    = [];
  final List<String> _routeTypes     = [];
  DateTime? _installDate;
  String?   _drivingStyle;
  String?   _qualitePiece;
  bool      _isSubmitting = false;
  bool      _isLoading    = true;

  late AnimationController _headerAnim;
  late Animation<double>   _headerScale;

  @override
  void initState() {
    super.initState();
    immatriculation = widget.immatriculation;
    _headerAnim  = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _headerScale = CurvedAnimation(parent: _headerAnim, curve: Curves.elasticOut);
    _headerAnim.forward();
    _loadData();
  }

  @override
  void dispose() { _headerAnim.dispose(); super.dispose(); }

  // ── Data ──────────────────────────────────────
  Future<void> _loadData() async {
    try {
      final d = await Supabase.instance.client
          .from('facteur').select().eq('fk_immatriculation', immatriculation).maybeSingle();
      if (d != null && mounted) {
        setState(() {
        _installDate  = d['date_installation_amortisseur'] != null
            ? DateTime.parse(d['date_installation_amortisseur'].toString()) : null;
        _drivingStyle = d['style_de_conduite']?.toString();
        if (d['type_de_route'] != null) {
          _routeTypes.addAll(d['type_de_route'].toString().split('//'));
        }
        if (d['condition_de_utilisation'] != null) {
          _utilisation.addAll(d['condition_de_utilisation'].toString().split('//'));
        }
        if (d['qualite_de_la_piece_amortisseur'] != null) {
          _qualitePiece = d['qualite_de_la_piece_amortisseur'].toString();
        }
        if (d['place_de_conduite'] != null) {
          _conduitePlace.addAll(d['place_de_conduite'].toString().split('//'));
        }
      });
      }
    } catch (_) {}
    finally { if (mounted) setState(() => _isLoading = false); }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSubmitting = true);
    try {
      final v = await Supabase.instance.client
          .from('voiture').select().eq('immatriculation', immatriculation).maybeSingle();
      if (v == null) throw 'Véhicule introuvable';
      await Supabase.instance.client.from('facteur').upsert({
        'fk_immatriculation': immatriculation,
        'date_installation_amortisseur': _installDate?.toIso8601String(),
        'style_de_conduite': _drivingStyle,
        'condition_de_utilisation': _utilisation.join('//'),
        'place_de_conduite': _conduitePlace.join('//'),
        'type_de_route': _routeTypes.join('//'),
        'qualite_de_la_piece_Amortisseur': _qualitePiece,
      }, onConflict: 'fk_immatriculation');
      if (mounted) {
        _showSnack('✅ Enregistré avec succès', Colors.green.shade400);
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) _showSnack('❌ Erreur : $e', _Colors.danger);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  void _showSnack(String msg, Color color) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(msg, style: GoogleFonts.dmSans(fontWeight: FontWeight.w500)),
          backgroundColor: color,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ));

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: _installDate ?? DateTime.now(),
      firstDate: DateTime(2000), lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(primary: _Colors.primary)),
        child: child!),
    );
    if (p != null) setState(() => _installDate = p);
  }

  // ── Build ─────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Colors.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: _Colors.primary))
          : _buildBody(),
    );
  }

  AppBar _buildAppBar() => AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _Colors.primary, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Amortisseurs',
            style: GoogleFonts.dmSans(
                color: _Colors.textMain, fontWeight: FontWeight.w700, fontSize: 18)),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: _Colors.primary.withOpacity(.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: IconButton(
              icon: const Icon(Icons.info_outline_rounded, color: _Colors.primary, size: 20),
              onPressed: () => _showSnack('Suivez l\'état de vos amortisseurs', _Colors.primary),
            ),
          ),
        ],
      );

  Widget _buildBody() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 100, 20, 40),
      child: Form(
        key: _formKey,
        child: Column(children: [
          _FadeSlide(delay: const Duration(milliseconds: 0),  child: _buildHero()),
          const SizedBox(height: 24),
          _FadeSlide(delay: const Duration(milliseconds: 80),  child: _buildDateCard()),
          _FadeSlide(delay: const Duration(milliseconds: 140), child: _buildConduiteCard()),
          _FadeSlide(delay: const Duration(milliseconds: 200), child: _buildRouteCard()),
          _FadeSlide(delay: const Duration(milliseconds: 260), child: _buildStyleCard()),
          _FadeSlide(delay: const Duration(milliseconds: 320), child: _buildUsageCard()),
          _FadeSlide(delay: const Duration(milliseconds: 380), child: _buildQualiteCard()),
          const SizedBox(height: 32),
          _FadeSlide(delay: const Duration(milliseconds: 440), child: _buildSubmitBtn()),
          const SizedBox(height: 40),
        ]),
      ),
    );
  }

  // ── Hero ─────────────────────────────────────
  Widget _buildHero() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF6C8EBF), Color(0xFF8FB8AD)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(color: _Colors.primary.withOpacity(.3), blurRadius: 24, offset: const Offset(0, 10)),
        ],
      ),
      child: Row(children: [
        ScaleTransition(
          scale: _headerScale,
          child: Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.25),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(Icons.car_repair_rounded, color: Colors.white, size: 36),
          ),
        ),
        const SizedBox(width: 18),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Suivi Amortisseurs',
              style: GoogleFonts.dmSans(
                  color: Colors.white, fontWeight: FontWeight.w700, fontSize: 20)),
          const SizedBox(height: 4),
          Text(widget.immatriculation,
              style: GoogleFonts.dmMono(
                  color: Colors.white.withOpacity(.85), fontSize: 13,
                  letterSpacing: 1.2)),
          const SizedBox(height: 6),
          Text('Analysez l\'état de vos amortisseurs',
              style: GoogleFonts.dmSans(
                  color: Colors.white.withOpacity(.8), fontSize: 13)),
        ])),
      ]),
    );
  }

  // ── Date card ─────────────────────────────────
  Widget _buildDateCard() => _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle(Icons.calendar_today_rounded, 'Date d\'installation'),
        const SizedBox(height: 14),
        GestureDetector(
          onTap: _pickDate,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: _installDate != null
                  ? _Colors.primary.withOpacity(.07)
                  : const Color(0xFFF5F7FF),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _installDate != null ? _Colors.primary : const Color(0xFFDDE3F0),
                width: 1.5),
            ),
            child: Row(children: [
              Icon(Icons.event_rounded,
                  color: _installDate != null ? _Colors.primary : _Colors.textSub, size: 22),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_installDate != null
                    ? DateFormat('dd MMMM yyyy', 'fr_FR').format(_installDate!)
                    : 'Sélectionner une date',
                    style: GoogleFonts.dmSans(
                        fontSize: 15,
                        fontWeight: _installDate != null ? FontWeight.w600 : FontWeight.w400,
                        color: _installDate != null ? _Colors.textMain : _Colors.textSub)),
                if (_installDate != null) ...[
                  const SizedBox(height: 2),
                  Text('Il y a ${DateTime.now().difference(_installDate!).inDays} jours',
                      style: GoogleFonts.dmSans(fontSize: 12, color: _Colors.textSub)),
                ],
              ])),
              Icon(Icons.chevron_right_rounded,
                  color: _installDate != null ? _Colors.primary : _Colors.textSub),
            ]),
          ),
        ),
      ]));

  // ── Chips helper ─────────────────────────────
  Widget _chipWrap(List<String> items, List<String> selected, Color accent) => Wrap(
        spacing: 8, runSpacing: 8,
        children: items.map((item) {
          final sel = selected.contains(item);
          return GestureDetector(
            onTap: () => setState(() => sel ? selected.remove(item) : selected.add(item)),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: sel ? accent.withOpacity(.15) : const Color(0xFFF3F6FF),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(
                    color: sel ? accent : const Color(0xFFDDE3F0), width: 1.5),
              ),
              child: Text(item,
                  style: GoogleFonts.dmSans(
                      fontSize: 13,
                      fontWeight: sel ? FontWeight.w600 : FontWeight.w400,
                      color: sel ? accent : _Colors.textSub)),
            ),
          );
        }).toList(),
      );

  // ── Conduite place card ───────────────────────
  Widget _buildConduiteCard() => _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle(Icons.location_on_rounded, 'Lieu de conduite', color: _Colors.accent),
        const SizedBox(height: 14),
        _chipWrap(['Centre-ville', 'Entre-région', 'Campagne', 'Désert', 'Entre les pays'],
            _conduitePlace, _Colors.accent),
      ]));

  // ── Route card ────────────────────────────────
  Widget _buildRouteCard() => _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle(Icons.alt_route_rounded, 'Type de route', color: Color(0xFF5B9BD5)),
        const SizedBox(height: 14),
        _chipWrap(['Autoroute', 'Urbain', 'Terre', 'Asphalte', 'Fourage', 'Béton', 'Gravier', 'Piste', 'Montagne'],
            _routeTypes, const Color(0xFF5B9BD5)),
      ]));

  // ── Driving style ─────────────────────────────
  Widget _buildStyleCard() {
    final styles = [
      {'label': 'Calme',   'icon': Icons.self_improvement_rounded,  'color': const Color(0xFF81C784)},
      {'label': 'Normal',  'icon': Icons.directions_car_rounded,     'color': _Colors.primary},
      {'label': 'Sportif', 'icon': Icons.speed_rounded,              'color': const Color(0xFFFF8A65)},
    ];
    return _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionTitle(Icons.sports_score_rounded, 'Style de conduite', color: Color(0xFF9575CD)),
      const SizedBox(height: 14),
      Row(children: styles.map((s) {
        final sel = _drivingStyle == s['label'];
        final col = s['color'] as Color;
        return Expanded(child: GestureDetector(
          onTap: () => setState(() => _drivingStyle = s['label'] as String),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: sel ? col.withOpacity(.12) : const Color(0xFFF5F7FF),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: sel ? col : const Color(0xFFDDE3F0), width: 1.5),
            ),
            child: Column(children: [
              Icon(s['icon'] as IconData, color: sel ? col : _Colors.textSub, size: 24),
              const SizedBox(height: 6),
              Text(s['label'] as String,
                  style: GoogleFonts.dmSans(
                      fontSize: 13,
                      fontWeight: sel ? FontWeight.w600 : FontWeight.w400,
                      color: sel ? col : _Colors.textSub)),
            ]),
          ),
        ));
      }).toList()),
    ]));
  }

  // ── Usage card ────────────────────────────────
  Widget _buildUsageCard() => _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle(Icons.build_circle_rounded, 'Usage du véhicule', color: Color(0xFFEF7C5A)),
        const SizedBox(height: 14),
        _chipWrap(['Quotidienne', 'Transport livraison', 'Voyage', 'Charges lourdes', 'Taxi', 'Louage', 'Autre'],
            _utilisation, const Color(0xFFEF7C5A)),
      ]));

  // ── Qualité pièce ─────────────────────────────
  Widget _buildQualiteCard() {
    final opts = [
      {'val': 'neuf',   'title': 'Original',   'sub': 'Pièce d\'origine constructeur', 'color': const Color(0xFF66BB6A), 'icon': Icons.auto_awesome_rounded},
      {'val': 'recent', 'title': '1er Choix',  'sub': 'Qualité premium équivalente',   'color': _Colors.primary,          'icon': Icons.thumb_up_alt_rounded},
      {'val': 'ancien', 'title': '2ème Choix', 'sub': 'Qualité standard',              'color': const Color(0xFFFFB74D),  'icon': Icons.history_rounded},
    ];
    return _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _SectionTitle(Icons.verified_rounded, 'Qualité de la pièce', color: _Colors.lavender),
      const SizedBox(height: 14),
      ...opts.map((o) {
        final sel = _qualitePiece == o['val'];
        final col = o['color'] as Color;
        return GestureDetector(
          onTap: () => setState(() => _qualitePiece = o['val'] as String),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: sel ? col.withOpacity(.08) : const Color(0xFFF8FAFF),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: sel ? col : const Color(0xFFE0E7F5), width: 1.5),
            ),
            child: Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(color: col.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
                child: Icon(o['icon'] as IconData, color: col, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(o['title'] as String,
                    style: GoogleFonts.dmSans(
                        fontWeight: sel ? FontWeight.w600 : FontWeight.w500,
                        color: sel ? col : _Colors.textMain, fontSize: 14)),
                Text(o['sub'] as String,
                    style: GoogleFonts.dmSans(fontSize: 12, color: _Colors.textSub)),
              ])),
              AnimatedOpacity(
                opacity: sel ? 1 : 0, duration: const Duration(milliseconds: 200),
                child: Icon(Icons.check_circle_rounded, color: col, size: 20),
              ),
            ]),
          ),
        );
      }),
    ]));
  }

  // ── Submit ────────────────────────────────────
  Widget _buildSubmitBtn() => GestureDetector(
        onTap: _isSubmitting ? null : _submit,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 58,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: _isSubmitting
                  ? [Colors.grey.shade300, Colors.grey.shade400]
                  : [_Colors.primary, const Color(0xFF8FB8AD)],
              begin: Alignment.centerLeft, end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: _isSubmitting ? [] : [
              BoxShadow(color: _Colors.primary.withOpacity(.35),
                  blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Center(child: _isSubmitting
              ? const SizedBox(width: 24, height: 24,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
              : Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.save_rounded, color: Colors.white, size: 22),
                  const SizedBox(width: 10),
                  Text('Enregistrer les données',
                      style: GoogleFonts.dmSans(
                          color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
                ])),
        ),
      );
}
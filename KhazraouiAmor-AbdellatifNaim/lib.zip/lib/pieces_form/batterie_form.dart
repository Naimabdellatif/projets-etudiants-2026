
// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_fonts/google_fonts.dart';

class BatterieForm extends StatefulWidget {
  const BatterieForm({super.key, required String immatriculation});

  @override
  State<BatterieForm> createState() => _BatterieFormState();
}

class _BatterieFormState extends State<BatterieForm>
    with SingleTickerProviderStateMixin {
  late String immatriculation;
  final _formKey = GlobalKey<FormState>();
  DateTime? _installationDate;
  final List<String> _utilisation = [];
  String? _selectedDrivingStyle;
  String? _selectedTemperature;
  String? _timeConduite;
  bool _isSubmitting = false;

  // Animation
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _loadExistingData();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
    _animationController.forward();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadExistingData());
  }

  @override
  void dispose() {
    _animationController.dispose();
    _selectedDrivingStyle = null;
    _selectedTemperature = null;
    _timeConduite = null;
    _utilisation.clear();
    _installationDate = null;
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color.fromARGB(255, 120, 75, 199),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _installationDate = picked);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is String) {
      immatriculation = args;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Erreur : Immatriculation non trouvée'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.pop(context);
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isSubmitting = true);
      final supabase = Supabase.instance.client;

      try {
        final vehiculeExiste = await supabase
            .from("voiture")
            .select()
            .eq('immatriculation', immatriculation)
            .maybeSingle();

        if (vehiculeExiste == null) {
          throw "Véhicule non enregistré. Créez-le d'abord !";
        }

        await supabase.from('facteur').upsert(
          {
            'fk_immatriculation': immatriculation,
            'date_installation_batterie': _installationDate?.toIso8601String(),
            'style_de_conduite': _selectedDrivingStyle,
            'temperature': _selectedTemperature,
            'time_conduite': _timeConduite,
            'condition_de_utilisation': _utilisation.join("//"),
          },
          onConflict: 'fk_immatriculation',
        );

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('✅ Données enregistrées avec succès !'),
              backgroundColor: Colors.green.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
          Navigator.pop(context); // Revenir à l'écran précédent
          setState(() {
            _installationDate = null;
            _selectedDrivingStyle = null;
            _utilisation.clear();
            _selectedTemperature = null;
            _timeConduite = null;
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text(
                  '❌ Erreur lors de l\'enregistrement des données !'),
              backgroundColor: Colors.red.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
        debugPrint('Erreur lors de la soumission du formulaire: $e');
      } finally {
        if (mounted) {
          setState(() => _isSubmitting = false);
        }
      }
    }
  }

  Future<void> _loadExistingData() async {
    try {
      final response = await Supabase.instance.client
          .from('facteur')
          .select()
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (response != null && mounted) {
        setState(() {
          _selectedDrivingStyle = response['style_de_conduite']?.toString();
          _utilisation.clear();
          _utilisation.addAll(
            (response['condition_de_utilisation'] as String?)?.split("//") ??
                [],
          );
          _selectedTemperature = response['temperature']?.toString();
          _timeConduite = response['time_conduite']?.toString();
          _installationDate = response['date_installation_batterie'] != null
              ? DateTime.parse(
                  response['date_installation_batterie'].toString())
              : null;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('⚠️ Erreur de chargement: ${e.toString()}')),
        );
      }
    }
  }

  // ignore: unused_element
  InputDecoration _buildInputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: GoogleFonts.poppins(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: Colors.grey.shade700,
      ),
      prefixIcon: Icon(icon, color: Colors.deepPurple),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      filled: true,
      fillColor: Colors.grey.shade50,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '🔋 Suivi de la Batterie',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurple,
        elevation: 0,
      ),
      body: AnimatedBuilder(
        animation: _animationController,
        builder: (context, child) {
          return FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Colors.deepPurple, Colors.deepPurpleAccent],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.deepPurple.withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.white,
                            child: SizedBox(
                              width:
                                  80, // Même taille que le diamètre du CircleAvatar
                              height: 80,
                              child: Lottie.asset(
                                'assets/batterie_animation.json',
                                fit: BoxFit.contain,
                                animate: true,
                                repeat: true,
                                frameRate: FrameRate.max,
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Suivi des Batteries',
                            style: GoogleFonts.poppins(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Analysez la performance de votre batterie',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    _buildDateField(),
                    const SizedBox(height: 20),
                    _buildTemperatureSelection(),
                    const SizedBox(height: 32),
                    _buildTimeConduiteSelection(),
                    const SizedBox(height: 25),
                    _buildDrivingStyleSelection(),
                    const SizedBox(height: 32),
                    _buildUtilisationSelection(),
                    const SizedBox(height: 32),
                    _buildSubmitButton(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDateField() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: const Icon(Icons.calendar_today, color: Colors.deepPurple),
        title: const Text('📅 Date d\'installation'),
        subtitle: Text(
          _installationDate != null
              ? DateFormat('dd/MM/yyyy').format(_installationDate!)
              : 'Sélectionnez une date',
          style: GoogleFonts.poppins(),
        ),
        trailing: const Icon(Icons.arrow_drop_down),
        onTap: () => _selectDate(context),
      ),
    );
  }

  Widget _buildTemperatureSelection() {
    final temperatureOptions = {
      '0C°-20C°': Icons.wb_sunny,
      '20C°-40C°': Icons.ac_unit,
      '> 40C°': Icons.local_fire_department,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text('🌡 Température moyenne',
              style: GoogleFonts.poppins(
                  fontSize: 10, fontWeight: FontWeight.w500)),
        ),
        ToggleButtons(
          borderRadius: BorderRadius.circular(12),
          selectedColor: Colors.white,
          fillColor: Colors.deepPurpleAccent,
          constraints: const BoxConstraints(minHeight: 48),
          onPressed: (index) => setState(() {
            _selectedTemperature = temperatureOptions.keys.elementAt(index);
          }),
          isSelected: temperatureOptions.keys
              .map((e) => e == _selectedTemperature)
              .toList(),
          children: temperatureOptions.entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Icon(entry.value, size: 15),
                  const SizedBox(width: 7),
                  Text(entry.key, style: GoogleFonts.poppins()),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildTimeConduiteSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 7.0),
          child: Text('🕒 Période de conduite',
              style: GoogleFonts.poppins(
                  fontSize: 16, fontWeight: FontWeight.w500)),
        ),
        Row(
          children: [
            Expanded(
              child: RadioListTile<String>(
                title: Text('Journalière 🌞', style: GoogleFonts.poppins()),
                value: 'Jour',
                groupValue: _timeConduite,
                onChanged: (value) => setState(() => _timeConduite = value),
              ),
            ),
            Expanded(
              child: RadioListTile<String>(
                title: Text('Nocturne 🌙', style: GoogleFonts.poppins()),
                value: 'Nuit',
                groupValue: _timeConduite,
                onChanged: (value) => setState(() => _timeConduite = value),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildUtilisationSelection() {
    const utilisations = [
      'Quotidienne',
      'Voyage',
      'Autre',
      'Charges lourdes',
      'Transport de livraison',
      'Louage',
      'Taxi',
    ];
    final iconMap = {
      'Quotidienne': Icons.calendar_today,
      'Voyage': Icons.flight_takeoff,
      'Autre': Icons.build,
      'Charges lourdes': Icons.local_shipping,
      'Transport de livraison': Icons.local_shipping,
      'Louage': Icons.directions_bus,
      'Taxi': Icons.taxi_alert,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Icon(Icons.build_circle, color: Colors.deepOrange),
              SizedBox(width: 8),
              Text(
                '⚙️ Usage de vehicule',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF2E5D7E),
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: utilisations.map((utilisation) {
            final isSelected = _utilisation.contains(utilisation);
            final chipColor = Colors.deepOrange.shade300;
            return FilterChip(
              label: Text(
                utilisation,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: isSelected ? chipColor : Colors.grey.shade800,
                ),
              ),
              avatar: Icon(
                iconMap[utilisation],
                color: isSelected ? chipColor : Colors.grey,
                size: 20,
              ),
              selected: isSelected,
              onSelected: (selected) => setState(() {
                selected
                    ? _utilisation.add(utilisation)
                    : _utilisation.remove(utilisation);
              }),
              selectedColor: chipColor.withOpacity(0.15),
              backgroundColor: Colors.grey.shade100,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(
                  color: isSelected ? chipColor : Colors.grey.shade300,
                  width: 1.2,
                ),
              ),
              showCheckmark: false,
              elevation: isSelected ? 4 : 0,
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDrivingStyleSelection() {
    final drivingStyles = {
      'Calme': Icons.directions_walk,
      'Normal': Icons.directions_car,
      'Sportif': Icons.speed,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.sports_score, color: Colors.purple),
            const SizedBox(width: 8),
            Text(
              '🏎 Style de conduite',
              style: GoogleFonts.poppins(
                  fontSize: 16, fontWeight: FontWeight.w500),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ToggleButtons(
          borderRadius: BorderRadius.circular(12),
          selectedColor: Colors.white,
          fillColor: Colors.purpleAccent,
          constraints: const BoxConstraints(minHeight: 48),
          onPressed: (index) => setState(() {
            _selectedDrivingStyle = drivingStyles.keys.elementAt(index);
          }),
          isSelected: drivingStyles.keys
              .map((e) => e == _selectedDrivingStyle)
              .toList(),
          children: drivingStyles.entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Icon(entry.value, size: 20),
                  const SizedBox(width: 8),
                  Text(entry.key, style: GoogleFonts.poppins()),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSubmitButton() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      child: ElevatedButton(
        onPressed: _isSubmitting ? null : _submitForm,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 126, 1, 160),
          disabledBackgroundColor: Colors.grey.shade400,
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 6,
          shadowColor: const Color.fromARGB(255, 65, 6, 245),
        ),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _isSubmitting
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: 12),
                    Text(
                      'Enregistrement en cours....',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Color.fromARGB(255, 182, 2, 242),
                      ),
                    ),
                  ],
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.save, color: Color.fromARGB(255, 243, 241, 244)),
                    SizedBox(width: 10),
                    Text(
                      'Enregistrer les données',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 230, 227, 231),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

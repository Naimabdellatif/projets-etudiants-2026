// ignore_for_file: unused_local_variable, unused_element, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CourroieForm extends StatefulWidget {
  final String immatriculation;
  const CourroieForm({super.key, required this.immatriculation});

  @override
  State<CourroieForm> createState() => _CourroieFormState();
}

class _CourroieFormState extends State<CourroieForm>
    with SingleTickerProviderStateMixin {
  late String immatriculation;
  final _formKey = GlobalKey<FormState>();
  String? _selectedQualitePiece;
  DateTime? _installationDate;
  final List<String> _selectedRouteTypes = [];
  String? _selectedDrivingStyle;
  //final _totalKmController = TextEditingController();
  String? _selectedTemperature;
  //final _dailyKmController = TextEditingController();
  //final _poids = TextEditingController();

  bool _isSubmitting = false;

  // Animation
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _loadExistingData();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
    _animationController.forward();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadExistingData());
  }

  @override
  void dispose() {
    _animationController.dispose();
    _selectedQualitePiece = null;
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color(0xFF4CAF50),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _installationDate = picked);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Récupérer l'immatriculation passée via les arguments de la route
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is String) {
      immatriculation = args;
    } else {
      // Gérer l'erreur si l'immatriculation n'est pas passée
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Erreur : Immatriculation non trouvée'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.pop(context); // Revenir à l'écran précédent
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isSubmitting = true);
      final supabase = Supabase.instance.client;

      try {
        // Vérifier si le véhicule existe
        final vehiculeExiste = await supabase
            .from("voiture")
            .select()
            .eq('immatriculation', widget.immatriculation)
            .maybeSingle();

        if (vehiculeExiste == null) {
          throw "Véhicule non enregistré. Créez-le d'abord !";
        }

        // UPSERT dans facteur
        await supabase.from('facteur').upsert({
          'fk_immatriculation': widget.immatriculation,
          'date_installation_courroie': _installationDate?.toIso8601String(),
          'temperature': _selectedTemperature,
          //'total_km': _totalKmController.text,
          //'daily_km': _dailyKmController.text,
          //'vehicle_weight': _poids.text,
          'qualite_piece_courroie': _selectedQualitePiece,
          'type_de_route': _selectedRouteTypes.join('//'),
          'style_de_conduite': _selectedDrivingStyle,
        }, onConflict: 'fk_immatriculation');

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('✅ Données enregistrées avec succès !'),
              backgroundColor: Colors.green.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
          Navigator.pop(context); // Revenir à l'écran précédent

          setState(() {
            _installationDate = null;
            _selectedQualitePiece = null;
            _selectedRouteTypes.clear();
            _selectedDrivingStyle = null;
            //_totalKmController.clear();
            //_dailyKmController.clear();
            _selectedTemperature = null;
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('❌ Erreur: ${e.toString()}'),
              backgroundColor: Colors.red.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() => _isSubmitting = false);
        }
      }
    }
  }

  Future<void> _loadExistingData() async {
    try {
      final response = await Supabase.instance.client
          .from('facteur')
          .select()
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (response != null && mounted) {
        setState(() {
          _selectedQualitePiece =
              response['qualite_piece_courroie']?.toString();
          _selectedDrivingStyle = response['style_de_conduite']?.toString();
          _selectedRouteTypes.clear();
          _selectedRouteTypes
              .addAll(response['type_de_route']?.toString().split('//') ?? []);
          _selectedTemperature = response['temperature']?.toString();
          //_totalKmController.text = response['total_km']?.toString() ?? '';
          //_dailyKmController.text = response['daily_km']?.toString() ?? '';
          _installationDate = response['date_installation_courroie'] != null
              ? DateTime.parse(
                  response['date_installation_courroie'].toString())
              : null;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('⚠️ Erreur de chargement: ${e.toString()}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Courroie et chaine de Distribution 🚗",
          style: GoogleFonts.poppins(fontWeight: FontWeight.w400),
        ),
        backgroundColor: Colors.brown.shade300,
        elevation: 0, // Supprimer l'ombre de l'AppBar
        centerTitle: true,
      ),
      body: AnimatedBuilder(
        animation: _animationController,
        builder: (context, child) {
          return FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                child: ListView(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(30.0),
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.brown.shade300,
                              const Color.fromARGB(255, 231, 115, 73)
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.brown.shade200,
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ]),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.brown.shade100,
                            child: const Icon(Icons.directions_car,
                                size: 40, color: Colors.brown),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Suivi le chaine et la courroie de votre véhicule',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Analysez la performance de votre chaine et la courroie',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    _buildDateField(),
                    const SizedBox(height: 20),
                    _buildSelectedTemperature(),
                    const SizedBox(height: 20),
                    _buildQualitePiece(),
                    const SizedBox(height: 20),
                    //_buildTotalKmField(),
                    //const SizedBox(height: 20),
                    //_buildDailyKmField(),
                    //const SizedBox(height: 20),
                    //_buildPoidsehicule(),
                    //const SizedBox(height: 20),
                    _buildRouteTypeSelection(),
                    const SizedBox(height: 20),
                    _buildDrivingStyleSelection(),
                    const SizedBox(height: 32),
                    _buildSubmitButton(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        CircleAvatar(
          radius: 40,
          backgroundColor: Colors.blue.shade100,
          child: Image(
            image: AssetImage('assets/courroie.png'),
            width: 70,
            height: 70,
          ),
        ),
        const SizedBox(height: 16),
        Text(
          '🔧 Suivi des Courroies de Distribution',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.blueGrey.shade800,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Remplissez les détails pour une analyse optimale',
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey.shade600,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildDateField() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: const Icon(Icons.calendar_today, color: Colors.blueAccent),
        title: const Text('📅 Date d\'installation'),
        subtitle: Text(
          _installationDate != null
              ? DateFormat('dd/MM/yyyy').format(_installationDate!)
              : 'Sélectionnez une date',
        ),
        trailing: const Icon(Icons.arrow_drop_down),
        onTap: () => _selectDate(context),
      ),
    );
  }

  Widget _buildQualitePiece() {
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color secondaryColor = const Color(0xFF8E54E9);

    // Options pour l'âge du véhicule
    final List<Map<String, dynamic>> ageOptions = [
      {
        'title': 'Original',
        'value': 'neuf',
        'icon': Icons.auto_awesome,
        'color': Colors.green.shade600,
        'subtitle': 'Pièce d\'origine constructeur',
      },
      {
        'title': '1er Choix',
        'value': 'recent',
        'icon': Icons.thumb_up,
        'color': Colors.blue.shade600,
        'subtitle': 'Qualité premium équivalente',
      },
      {
        'title': '2em Choix',
        'value': 'ancien',
        'icon': Icons.history,
        'color': Colors.orange.shade600,
        'subtitle': 'Qualité standard',
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Row(
            children: [
              Icon(
                Icons.directions_car,
                size: 18,
                color: primaryColor.withOpacity(0.8),
              ),
              const SizedBox(width: 8),
              Text(
                'Qualité de la pièce',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade800,
                ),
              ),
              const Spacer(),
              Tooltip(
                message: 'Sélectionnez la qualité de la pièce',
                child: Icon(
                  Icons.help_outline,
                  size: 16,
                  color: Colors.grey.shade500,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 2),
        Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade300, width: 1),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Column(
              children: List.generate(
                ageOptions.length,
                (index) {
                  final option = ageOptions[index];
                  final bool isSelected =
                      _selectedQualitePiece == option['value'];

                  // Ajouter une ligne de séparation entre les options, sauf pour la dernière
                  final bool addDivider = index < ageOptions.length - 1;

                  return Column(
                    children: [
                      InkWell(
                        onTap: () {
                          setState(() {
                            _selectedQualitePiece = option['value'];
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16.0,
                            vertical: 12.0,
                          ),
                          child: Row(
                            children: [
                              // Radio button
                              Container(
                                width: 22,
                                height: 22,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: isSelected
                                        ? option['color']
                                        : Colors.grey.shade400,
                                    width: 2,
                                  ),
                                ),
                                child: Center(
                                  child: isSelected
                                      ? Container(
                                          width: 12,
                                          height: 12,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: option['color'],
                                          ),
                                        )
                                      : null,
                                ),
                              ),

                              const SizedBox(width: 12),

                              // Icône
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: option['color'].withOpacity(0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  option['icon'],
                                  color: option['color'],
                                  size: 22,
                                ),
                              ),

                              const SizedBox(width: 16),

                              // Texte
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      option['title'],
                                      style: GoogleFonts.poppins(
                                        fontSize: 15,
                                        fontWeight: isSelected
                                            ? FontWeight.w600
                                            : FontWeight.w500,
                                        color: isSelected
                                            ? option['color']
                                            : Colors.grey.shade800,
                                      ),
                                    ),
                                    Text(
                                      option['subtitle'],
                                      style: GoogleFonts.poppins(
                                        fontSize: 13,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // Indicateur animé de sélection
                              AnimatedOpacity(
                                opacity: isSelected ? 1.0 : 0.0,
                                duration: const Duration(milliseconds: 200),
                                child: Icon(
                                  Icons.check_circle,
                                  color: option['color'],
                                  size: 20,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      if (addDivider)
                        Divider(
                          height: 1,
                          thickness: 1,
                          color: Colors.grey.shade200,
                          indent: 16,
                          endIndent: 16,
                        ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
        // Message d'aide
        Padding(
          padding: const EdgeInsets.only(left: 4, top: 8),
          child: Text(
            'La qualité de la pièce peut influencer les recommandations d\'entretien',
            style: GoogleFonts.poppins(
              fontSize: 12,
              fontStyle: FontStyle.italic,
              color: Colors.grey.shade600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRouteTypeSelection() {
    const routeTypes = [
      'Autoroute',
      'Urbain',
      'Terre',
      "Asphelte",
      "Fourage",
      "Beton",
      'Gravier',
      "Piste",
      'Montagne'
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Row(
            children: [
              const Icon(Icons.aod, color: Colors.green),
              const SizedBox(width: 8),
              Text(
                'Type de route',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade700,
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 8.0,
          children: routeTypes.map((type) {
            return FilterChip(
              label: Text(type),
              selected: _selectedRouteTypes.contains(type),
              onSelected: (selected) => setState(() {
                selected
                    ? _selectedRouteTypes.add(type)
                    : _selectedRouteTypes.remove(type);
              }),
              selectedColor: Colors.green.shade100,
              checkmarkColor: Colors.green,
              showCheckmark: true,
              avatar: Icon(_selectedRouteTypes.contains(type)
                  ? Icons.check_circle
                  : Icons.radio_button_unchecked),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDrivingStyleSelection() {
    final drivingStyles = {
      'Calme': Icons.directions_walk,
      'Normal': Icons.directions_car,
      'Sportif': Icons.speed,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Row(
            children: [
              const Icon(Icons.sports_score, color: Colors.purple),
              const SizedBox(width: 8),
              Text(
                '🏎 Style de conduite',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade700,
                ),
              ),
            ],
          ),
        ),
        ToggleButtons(
          borderRadius: BorderRadius.circular(12),
          selectedColor: Colors.white,
          fillColor: Colors.purpleAccent,
          constraints: const BoxConstraints(minHeight: 48),
          onPressed: (index) => setState(() {
            _selectedDrivingStyle = drivingStyles.keys.elementAt(index);
          }),
          isSelected: drivingStyles.keys
              .map((e) => e == _selectedDrivingStyle)
              .toList(),
          children: drivingStyles.entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Icon(entry.value, size: 20),
                  const SizedBox(width: 8),
                  Text(entry.key),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSelectedTemperature() {
    final temperatureOptions = {
      '0C°-20C°': Icons.ac_unit,
      '20C°-40C°': Icons.wb_sunny,
      '> 40C°': Icons.local_fire_department,
    };

    final temperatureColors = {
      '0C°-20C°': Colors.blue.shade400,
      '20C°-40C°': Colors.orange.shade400,
      '> 40C°': Colors.red.shade400,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 10.0),
          child: Text(
            '🌡 Température moyenne',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Color(0xFF2E5D7E),
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: temperatureOptions.entries.map((entry) {
            final isSelected = _selectedTemperature == entry.key;
            final bgColor = isSelected
                ? temperatureColors[entry.key]!.withOpacity(0.15)
                : Colors.grey.shade100;

            return Expanded(
              child: GestureDetector(
                onTap: () => setState(() {
                  _selectedTemperature = entry.key;
                }),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  padding:
                      const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                  decoration: BoxDecoration(
                    color: bgColor,
                    border: Border.all(
                      color: isSelected
                          ? temperatureColors[entry.key]!
                          : Colors.grey.shade300,
                      width: isSelected ? 2 : 1,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(entry.value,
                          color: isSelected
                              ? temperatureColors[entry.key]
                              : Colors.grey.shade600),
                      const SizedBox(width: 8),
                      Text(
                        entry.key,
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: isSelected
                              ? temperatureColors[entry.key]
                              : Colors.grey.shade800,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

/*
  Widget _buildTotalKmField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 6.0),
          child: Text(
            'Total de kilométrage (km)',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Color(0xFF2E5D7E),
            ),
          ),
        ),
        TextFormField(
          controller: _totalKmController,
          keyboardType: TextInputType.number,
          style: const TextStyle(fontSize: 15),
          decoration: InputDecoration(
            hintText: 'Ex : 120000',
            prefixIcon: const Icon(Icons.speed, color: Color(0xFF2E5D7E)),
            filled: true,
            fillColor: Colors.white,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF2E5D7E), width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
            ),
          ),
          validator: (value) => value == null || value.isEmpty
              ? 'Veuillez indiquer le kilométrage total du véhicule'
              : null,
        ),
      ],
    );
  }

  Widget _buildDailyKmField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 6.0),
          child: Text(
            'Kilométrage moyen quotidien',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Color(0xFF2E5D7E),
            ),
          ),
        ),
        TextFormField(
          controller: _dailyKmController,
          keyboardType: TextInputType.number,
          style: const TextStyle(fontSize: 15),
          decoration: InputDecoration(
            hintText: 'Ex : 60',
            prefixIcon: const Icon(Icons.av_timer, color: Color(0xFF2E5D7E)),
            suffixText: 'km',
            filled: true,
            fillColor: Colors.white,
            contentPadding:
                const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.grey.shade300, width: 1),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF2E5D7E), width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
            ),
          ),
          validator: (value) => value == null || value.isEmpty
              ? 'Veuillez indiquer la distance moyenne parcourue par jour'
              : null,
        ),
      ],
    );
  }

  Widget _buildPoidsehicule() {
    return TextFormField(
      controller: _poids,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: '🎰 poids',
        prefixIcon:
            const Icon(Icons.history, color: Color.fromARGB(255, 29, 35, 120)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
      ),
      validator: (value) =>
          value!.isEmpty ? 'Veuillez entrer le poids du véhicule' : null,
    );
  }
*/
  Widget _buildSubmitButton() {
    return ElevatedButton.icon(
      icon: _isSubmitting
          ? const CircularProgressIndicator(color: Colors.white)
          : const Icon(Icons.save_alt, size: 24),
      label: Text(
        _isSubmitting ? 'Enregistrement...' : 'Enregistrer les données',
        style: const TextStyle(fontSize: 16),
      ),
      onPressed: _isSubmitting ? null : _submitForm,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.blueAccent,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 4,
        shadowColor: Colors.blue.shade100,
      ),
    );
  }
}

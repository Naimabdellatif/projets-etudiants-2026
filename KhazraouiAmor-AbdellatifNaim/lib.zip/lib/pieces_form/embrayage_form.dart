// ignore_for_file: unused_element, unused_local_variable, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_fonts/google_fonts.dart';

class EmbrayageForm extends StatefulWidget {
  const EmbrayageForm({super.key, required String immatriculation});

  @override
  State<EmbrayageForm> createState() => _EmbrayageFormState();
}

class _EmbrayageFormState extends State<EmbrayageForm>
    with SingleTickerProviderStateMixin {
  late String immatriculation;
  final _formKey = GlobalKey<FormState>();
  //final _totalKmController = TextEditingController();
  final List<String> _selectConduitePlace = [];
  DateTime? _installationDate;
  String? _selectedQualitePiece;
  final List<String> _utilisation = [];
  String? _selectedDrivingStyle;
  final Set<String> _meteoSelector = {};
  bool _isSubmitting = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  final Color _primaryColor = const Color(0xFFFF5722); // Indigo
  final Color _accentColor =
      const Color.fromARGB(255, 34, 255, 52); // Deep Orange
  @override
  void initState() {
    super.initState();
    _loadExistingData();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadExistingData());
  }

  @override
  void dispose() {
    _animationController.dispose();
    _selectedQualitePiece = null;
    _selectConduitePlace.clear();
    _meteoSelector.clear();
    _utilisation.clear();
    _installationDate = null;
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: ThemeData.light().copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color.fromARGB(255, 164, 199, 75),
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _installationDate = picked);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is String) {
      immatriculation = args;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Erreur : Immatriculation non trouvée'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.pop(context);
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isSubmitting = true);
      final supabase = Supabase.instance.client;
      try {
        final vehiculeExiste = await supabase
            .from("voiture")
            .select()
            .eq('immatriculation', immatriculation)
            .maybeSingle();
        if (vehiculeExiste == null) {
          throw "Véhicule non enregistré. Créez-le d'abord !";
        }
        await supabase.from('facteur').upsert(
          {
            'fk_immatriculation': immatriculation,
            'date_Installation_embrayage': _installationDate?.toIso8601String(),
            'style_de_conduite': _selectedDrivingStyle,
            "meteo": _meteoSelector.join("//"),
            //"total_km": _totalKmController.text,
            'condition_de_utilisation': _utilisation.join("//"),
            "place_de_conduite": _selectConduitePlace.join("//"),
            "qualite_de_piece_embrayage": _selectedQualitePiece,
          },
          onConflict: 'fk_immatriculation',
        );
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('✅ Données enregistrées avec succès !'),
              backgroundColor: Colors.green.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
          Navigator.pop(context);
          setState(() {
            _installationDate = null;
            _selectedDrivingStyle = null;
            _utilisation.clear();
            _selectConduitePlace.clear();
            _meteoSelector.clear();
            _selectedQualitePiece = null;
          });
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text(
                  '❌ Erreur lors de l\'enregistrement des données !'),
              backgroundColor: Colors.red.shade700,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
        debugPrint('Erreur lors de la soumission du formulaire: $e');
      } finally {
        if (mounted) {
          setState(() => _isSubmitting = false);
        }
      }
    }
  }

  Future<void> _loadExistingData() async {
    try {
      final response = await Supabase.instance.client
          .from('facteur')
          .select()
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();
      if (response != null && mounted) {
        setState(() {
          _selectedDrivingStyle = response['style_de_conduite']?.toString();
          _installationDate = response['date_Installation_embrayage'] != null
              ? DateTime.parse(response['date_Installation_embrayage'])
              : null;
          _utilisation.addAll(
            response['condition_de_utilisation']?.toString().split("//") ?? [],
          );
          _selectConduitePlace.addAll(
            response['place_de_conduite']?.toString().split("//") ?? [],
          );
          _selectedQualitePiece =
              response['qualite_de_piece_embrayage']?.toString();
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('⚠️ Erreur de chargement: ${e.toString()}')),
        );
      }
    }
  }

  InputDecoration _buildInputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: GoogleFonts.poppins(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: Colors.grey.shade700,
      ),
      prefixIcon: Icon(icon, color: Colors.deepOrange),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      filled: true,
      fillColor: Colors.grey.shade50,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '🔧 Suivi d\'Embrayage',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepOrange,
        elevation: 0,
      ),
      body: AnimatedBuilder(
        animation: _animationController,
        builder: (context, child) {
          return FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Colors.deepOrange, Colors.deepOrangeAccent],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.deepOrange.withOpacity(0.3),
                            blurRadius: 10,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.white,
                            child: Icon(Icons.build,
                                size: 40, color: Colors.deepOrange),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Suivi d\'Embrayage',
                            style: GoogleFonts.poppins(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Optimisez la performance de votre embrayage',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    _buildDateField(),
                    const SizedBox(height: 20),
                    _buildQualitePiece(),
                    const SizedBox(height: 20),
                    _buildUtilisationSelection(),
                    const SizedBox(height: 32),
                    _buildDrivingStyleSelection(),
                    const SizedBox(height: 32),
                    _buildConduitePlaceSelection(),
                    const SizedBox(height: 32),
                    _buildMeteoSection(),
                    const SizedBox(height: 32),
                    _buildSubmitButton(),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
  
Widget _buildQualitePiece() {
  final Color primaryColor = Theme.of(context).primaryColor;
  final Color secondaryColor = const Color(0xFF8E54E9);
  
  // Options pour l'âge du véhicule
  final List<Map<String, dynamic>> ageOptions = [
    {
      'title': 'Original',
      'value': 'neuf',
      'icon': Icons.auto_awesome,
      'color': Colors.green.shade600,
      'subtitle': 'Pièce d\'origine constructeur',
    },
    {
      'title': '1er Choix',
      'value': 'recent',
      'icon': Icons.thumb_up,
      'color': Colors.blue.shade600,
      'subtitle': 'Qualité premium équivalente',
    },
    {
      'title': '2em Choix',
      'value': 'ancien',
      'icon': Icons.history,
      'color': Colors.orange.shade600,
      'subtitle': 'Qualité standard',
    },
  ];

  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 10),
        child: Row(
          children: [
            Icon(
              Icons.directions_car,
              size: 18,
              color: primaryColor.withOpacity(0.8),
            ),
            const SizedBox(width: 8),
            Text(
              'Qualité de la pièce',
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.grey.shade800,
              ),
            ),
            const Spacer(),
            Tooltip(
              message: 'Sélectionnez la qualité de la pièce',
              child: Icon(
                Icons.help_outline,
                size: 16,
                color: Colors.grey.shade500,
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 2),
      Container(
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade300, width: 1),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Column(
            children: List.generate(
              ageOptions.length,
              (index) {
                final option = ageOptions[index];
                final bool isSelected = _selectedQualitePiece == option['value'];
                
                // Ajouter une ligne de séparation entre les options, sauf pour la dernière
                final bool addDivider = index < ageOptions.length - 1;
                
                return Column(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {
                          _selectedQualitePiece = option['value'];
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16.0,
                          vertical: 12.0,
                        ),
                        child: Row(
                          children: [
                            // Radio button
                            Container(
                              width: 22,
                              height: 22,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: isSelected
                                      ? option['color']
                                      : Colors.grey.shade400,
                                  width: 2,
                                ),
                              ),
                              child: Center(
                                child: isSelected
                                    ? Container(
                                        width: 12,
                                        height: 12,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: option['color'],
                                        ),
                                      )
                                    : null,
                              ),
                            ),
                            
                            const SizedBox(width: 12),
                            
                            // Icône
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: option['color'].withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                option['icon'],
                                color: option['color'],
                                size: 22,
                              ),
                            ),
                            
                            const SizedBox(width: 16),
                            
                            // Texte
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    option['title'],
                                    style: GoogleFonts.poppins(
                                      fontSize: 15,
                                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                                      color: isSelected ? option['color'] : Colors.grey.shade800,
                                    ),
                                  ),
                                  Text(
                                    option['subtitle'],
                                    style: GoogleFonts.poppins(
                                      fontSize: 13,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            // Indicateur animé de sélection
                            AnimatedOpacity(
                              opacity: isSelected ? 1.0 : 0.0,
                              duration: const Duration(milliseconds: 200),
                              child: Icon(
                                Icons.check_circle,
                                color: option['color'],
                                size: 20,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (addDivider)
                      Divider(
                        height: 1,
                        thickness: 1,
                        color: Colors.grey.shade200,
                        indent: 16,
                        endIndent: 16,
                      ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
      // Message d'aide
      Padding(
        padding: const EdgeInsets.only(left: 4, top: 8),
        child: Text(
          'La qualité de la pièce peut influencer les recommandations d\'entretien',
          style: GoogleFonts.poppins(
            fontSize: 12,
            fontStyle: FontStyle.italic,
            color: Colors.grey.shade600,
          ),
        ),
      ),
    ],
  );
}

  Widget _buildDateField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section title
        Row(
          children: [
            Icon(Icons.event, color: _primaryColor),
            const SizedBox(width: 10),
            Text(
              '📅 Date d\'installation',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: _primaryColor.withOpacity(0.9),
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),

        const SizedBox(height: 15),

        // Date selection card
        InkWell(
          onTap: () => _selectDate(context),
          borderRadius: BorderRadius.circular(12),
          splashColor: _primaryColor.withOpacity(0.1),
          highlightColor: _accentColor.withOpacity(0.05),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _installationDate != null
                    ? _primaryColor.withOpacity(0.5)
                    : Colors.grey.shade300,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: _installationDate != null
                      ? _primaryColor.withOpacity(0.1)
                      : Colors.grey.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: _installationDate != null
                      ? _primaryColor.withOpacity(0.15)
                      : Colors.grey.shade100,
                  child: Icon(
                    Icons.calendar_month,
                    color: _installationDate != null
                        ? _primaryColor
                        : Colors.grey.shade500,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _installationDate != null
                            ? DateFormat('dd MMMM yyyy', 'fr_FR')
                                .format(_installationDate!)
                            : 'Choisir une date',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: _installationDate != null
                              ? FontWeight.w600
                              : FontWeight.normal,
                          color: _installationDate != null
                              ? Colors.black87
                              : Colors.grey.shade600,
                        ),
                      ),
                      if (_installationDate != null) ...[
                        const SizedBox(height: 4),
                        Text(
                          'Age: ${DateTime.now().difference(_installationDate!).inDays} jours',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: _installationDate != null
                      ? _primaryColor.withOpacity(0.7)
                      : Colors.grey.shade400,
                  size: 18,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildUtilisationSelection() {
    const utilisations = [
      'Quotidienne',
      'Charges lourdes',
      'Transport de livraison',
      'Voyage',
      
      'Louage',
      'Taxi',
      'Autre'
    ];
    final iconMap = {
      'Quotidienne': Icons.calendar_today,
      'Voyage': Icons.flight_takeoff,
      'Charges lourdes': Icons.local_shipping,
      'Transport de livraison': Icons.local_shipping,
      'Louage': Icons.directions_bus,
      'Taxi': Icons.local_taxi,
      'Autre': Icons.build,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Icon(Icons.build_circle, color: Colors.deepOrange),
              SizedBox(width: 8),
              Text(
                '⚙️ Usage de vehicule',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF2E5D7E),
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: utilisations.map((utilisation) {
            final isSelected = _utilisation.contains(utilisation);
            final chipColor = Colors.deepOrange.shade300;
            return FilterChip(
              label: Text(
                utilisation,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: isSelected ? chipColor : Colors.grey.shade800,
                ),
              ),
              avatar: Icon(
                iconMap[utilisation],
                color: isSelected ? chipColor : Colors.grey,
                size: 20,
              ),
              selected: isSelected,
              onSelected: (selected) => setState(() {
                selected
                    ? _utilisation.add(utilisation)
                    : _utilisation.remove(utilisation);
              }),
              selectedColor: chipColor.withOpacity(0.15),
              backgroundColor: Colors.grey.shade100,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(
                  color: isSelected ? chipColor : Colors.grey.shade300,
                  width: 1.2,
                ),
              ),
              showCheckmark: false,
              elevation: isSelected ? 4 : 0,
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildDrivingStyleSelection() {
    final drivingStyles = {
      'Calme': Icons.directions_walk,
      'Normal': Icons.directions_car,
      'Sportif': Icons.speed,
    };
    final colors = {
      'Calme': Colors.lightBlue,
      'Normal': Colors.teal,
      'Sportif': Colors.deepPurple,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12.0),
          child: Row(
            children: [
              const Icon(Icons.sports_score, color: Colors.deepPurple),
              const SizedBox(width: 8),
              Text(
                '🏎 Style de conduite',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey.shade800,
                ),
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: drivingStyles.entries.map((entry) {
            final isSelected = _selectedDrivingStyle == entry.key;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isSelected
                    ? colors[entry.key]!.withOpacity(0.15)
                    : Colors.grey.shade100,
                border: Border.all(
                  color: isSelected ? colors[entry.key]! : Colors.grey.shade300,
                  width: isSelected ? 2 : 1,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: colors[entry.key]!.withOpacity(0.2),
                          blurRadius: 6,
                          offset: const Offset(0, 3),
                        )
                      ]
                    : [],
              ),
              child: InkWell(
                onTap: () => setState(() {
                  _selectedDrivingStyle = entry.key;
                }),
                child: Row(
                  children: [
                    Icon(entry.value,
                        color: isSelected
                            ? colors[entry.key]
                            : Colors.grey.shade600),
                    const SizedBox(width: 8),
                    Text(
                      entry.key,
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: isSelected
                            ? colors[entry.key]
                            : Colors.grey.shade700,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildMeteoSection() {
    final Map<String, IconData> meteo = {
      "Sub-Humide": Icons.cloud,
      "Semi-Aride": Icons.wb_sunny,
      "Aride": Icons.ac_unit,
      "Froid": Icons.ac_unit,
      "Tempéré": Icons.wb_sunny,
      "Humide": Icons.grain,
      "Chaude": Icons.wb_sunny,
      "Pluies": Icons.beach_access,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Row(
            children: [
              const Icon(Icons.cloud, color: Colors.blue),
              const SizedBox(width: 8),
              Text('🌤 Conditions météorologiques',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  )),
            ],
          ),
        ),
        Wrap(
          spacing: 8.0,
          children: meteo.keys.map((type) {
            return FilterChip(
              label: Text(type),
              selected: _meteoSelector.contains(type),
              onSelected: (selected) => setState(() {
                if (selected) {
                  _meteoSelector.add(type);
                } else {
                  _meteoSelector.remove(type);
                }
              }),
              selectedColor: Colors.green.shade100,
              checkmarkColor: Colors.green,
              showCheckmark: true,
              avatar: Icon(
                meteo[type],
                color:
                    _meteoSelector.contains(type) ? Colors.green : Colors.grey,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildConduitePlaceSelection() {
    const conduitePlace = [
      'Centre-ville',
      'Entre-région',
      'Campagne',
      'Désert',
      'Entre les pays'
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Row(
            children: [
              const Icon(Icons.aod, color: Colors.green),
              const SizedBox(width: 8),
              Text(
                '🛣 Les places de conduite',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey.shade700,
                ),
              ),
            ],
          ),
        ),
        Wrap(
          spacing: 8.0,
          children: conduitePlace.map((type) {
            return FilterChip(
              label: Text(type, style: GoogleFonts.poppins()),
              selected: _selectConduitePlace.contains(type),
              onSelected: (selected) => setState(() {
                selected
                    ? _selectConduitePlace.add(type)
                    : _selectConduitePlace.remove(type);
              }),
              selectedColor: Colors.green.shade100,
              checkmarkColor: Colors.green,
              showCheckmark: true,
              avatar: Icon(
                _selectConduitePlace.contains(type)
                    ? Icons.check_circle
                    : Icons.radio_button_unchecked,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSubmitButton() {
    return ElevatedButton.icon(
      icon: _isSubmitting
          ? const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 2,
              ),
            )
          : const Icon(Icons.save_alt, size: 24),
      label: Text(
        _isSubmitting ? 'Enregistrement...' : 'Enregistrer les données',
        style: GoogleFonts.poppins(fontSize: 16),
      ),
      onPressed: _isSubmitting ? null : _submitForm,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.deepOrange,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 6,
        shadowColor: Colors.deepOrangeAccent,
      ),
    );
  }
}

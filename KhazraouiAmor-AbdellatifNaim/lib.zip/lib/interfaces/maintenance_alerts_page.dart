// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:carhabti/components/maintenance_alerts_component.dart';

class MaintenanceAlertsPage extends StatefulWidget {
  final String immatriculation;

  const MaintenanceAlertsPage({
    super.key,
    required this.immatriculation,
  });

  @override
  State<MaintenanceAlertsPage> createState() => _MaintenanceAlertsPageState();
}

class _MaintenanceAlertsPageState extends State<MaintenanceAlertsPage> {
  @override
  Widget build(BuildContext context) {
    // Utilisation de ScreenUtil pour la mise en page responsive
    ScreenUtil.init(context, designSize: const Size(375, 812));

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Row(
          children: [
            const CircleAvatar(
              radius: 15,
              backgroundColor: Colors.white,
              child: Icon(Icons.warning_amber, size: 18, color: Colors.orange),
            ),
            SizedBox(width: 10.w),
            Text(
              'Alertes de maintenance',
              style: GoogleFonts.poppins(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 15.sp,
              ),
            ),
          ],
        ),
        backgroundColor: Colors.purple,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 20, 126, 201),
                Color.fromARGB(255, 136, 59, 219)
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            tooltip: 'Rafraîchir les alertes',
            onPressed: () {
              // Afficher un message de rafraîchissement
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Rafraîchissement des alertes en cours...'),
                  duration: Duration(seconds: 1),
                ),
              );
              // Forcer une reconstruction de la page
              setState(() {});
            },
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // En-tête explicatif
              _buildInfoHeader(),
              SizedBox(height: 16.h),

              // Composant d'alertes de maintenance
              MaintenanceAlertsComponent(
                immatriculation: widget.immatriculation,
              ),

              SizedBox(height: 16.h),

              // Composant de calendrier des maintenances futures (si disponible)
              MaintenanceCalendarComponent(
                immatriculation: widget.immatriculation,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoHeader() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: Colors.blue.withOpacity(0.3), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline, color: Colors.blue, size: 24.sp),
              SizedBox(width: 8.w),
              Text(
                'À propos des alertes',
                style: GoogleFonts.poppins(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.blue,
                ),
              ),
            ],
          ),
          SizedBox(height: 8.h),
          Text(
            'Ces alertes sont calculées automatiquement en fonction de l\'usure prévue de vos pièces automobiles. Chaque alerte vous informe du délai restant avant le remplacement recommandé.',
            style: GoogleFonts.poppins(
              fontSize: 13.sp,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:carhabti/settingSection/about.dart';
import 'package:carhabti/settingSection/help_support.dart';
import 'package:carhabti/settingSection/language.dart';
import 'package:carhabti/settingSection/notifications.dart';
import 'package:carhabti/settingSection/security.dart';
import 'package:carhabti/magasin_model/ProfileScreen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.light;

  ThemeMode get themeMode => _themeMode;

  void toggleTheme(bool isDark) {
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _darkModeEnabled = false;

  void _toggleDarkMode(bool value) {
    setState(() {
      _darkModeEnabled = value;
    });
    // Dans SettingsScreen
    Switch(
      value: Provider.of<ThemeProvider>(context).themeMode == ThemeMode.dark,
      onChanged: (value) =>
          Provider.of<ThemeProvider>(context, listen: false).toggleTheme(value),
    );
    // Ajouter ici la logique pour changer le thème de l'application
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Paramètres',
          style: GoogleFonts.poppins(
            fontSize: 22,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('Compte'),
            _buildSettingItem(
              icon: Icons.person_outline,
              title: 'Profil',
              subtitle: 'Modifier vos informations personnelles',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ProfileScreen()),
                );
              },
            ),
            _buildSettingItem(
              icon: Icons.lock_outline,
              title: 'Sécurité',
              subtitle: 'Changer le mot de passe et la sécurité',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const SecurityScreen()),
                );
              },
            ),
            _buildSettingItem(
              icon: Icons.notifications_outlined,
              title: 'Notifications',
              subtitle: 'Gérer les notifications',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const NotificationsScreen()),
                );
              },
            ),
            const SizedBox(height: 20),
            _buildSectionHeader('Préférences'),
            _buildSettingItem(
              icon: Icons.language_outlined,
              title: 'Langue',
              subtitle: 'Changer la langue de l\'application',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const LanguageScreen()),
                );
              },
            ),
            _buildSettingItem(
              icon: Icons.dark_mode_outlined,
              title: 'Mode sombre',
              subtitle: 'Activer ou désactiver le mode sombre',
              trailing: Switch(
                value: _darkModeEnabled,
                onChanged: _toggleDarkMode,
              ),
            ),
            const SizedBox(height: 20),
            _buildSectionHeader('Support'),
            _buildSettingItem(
              icon: Icons.help_outline,
              title: 'Aide et support',
              subtitle: 'Obtenir de l\'aide',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const HelpSupportScreen()),
                );
              },
            ),
            _buildSettingItem(
              icon: Icons.info_outline,
              title: 'À propos',
              subtitle: 'En savoir plus sur l\'application',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AboutScreen()),
                );
              },
            ),
            const SizedBox(height: 20),
            _buildSectionHeader('Danger Zone'),
            _buildSettingItem(
              icon: Icons.delete_outline,
              title: 'Supprimer le compte',
              subtitle: 'Supprimer définitivement votre compte',
              onTap: () => _showDeleteConfirmationDialog(context),
              isDanger: true,
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Supprimer le compte'),
        content: const Text(
            'Êtes-vous sûr de vouloir supprimer définitivement votre compte ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Annuler'),
          ),
          TextButton(
            onPressed: () {
              // Ajouter la logique de suppression du compte
              Navigator.pop(context);
            },
            child: const Text(
              'Supprimer',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: Colors.black54,
        ),
      ),
    );
  }

  Widget _buildSettingItem({
    required IconData icon,
    required String title,
    required String subtitle,
    VoidCallback? onTap,
    Widget? trailing,
    bool isDanger = false,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: isDanger ? Colors.red : Colors.black54,
        ),
        title: Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: isDanger ? Colors.red : Colors.black87,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: GoogleFonts.poppins(
            fontSize: 14,
            color:
                isDanger ? Colors.red.withOpacity(0.7) : Colors.grey.shade600,
          ),
        ),
        trailing: trailing,
        onTap: onTap,
      ),
    );
  }
}

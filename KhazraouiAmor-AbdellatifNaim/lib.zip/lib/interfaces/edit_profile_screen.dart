// Fichier: interfaces/edit_profile_screen.dart
// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// ─── Palette CARHABTI (cohérente avec le reste de l'app) ─────────────────────
const _kPrimary   = Color(0xFF6FD3DE);
const _kBlue      = Color(0xFF42A5F5);
const _kCyan      = Color(0xFF26C6DA);
const _kBgLight   = Color(0xFFF4FAFB);
const _kTextDark  = Color(0xFF1A2E35);
const _kTextMid   = Color(0xFF607D8B);
const _kTextLight = Color(0xFFB0BEC5);
const _kError     = Color(0xFFEF5350);
const _kSuccess   = Color(0xFF43A047);
// ─────────────────────────────────────────────────────────────────────────────

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen>
    with SingleTickerProviderStateMixin {

  // ── Contrôleurs ────────────────────────────────────────────────────────────
  final _formKey              = GlobalKey<FormState>();
  final _nameController       = TextEditingController();
  final _emailController      = TextEditingController();
  final _phoneController      = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  // ── État local ─────────────────────────────────────────────────────────────
  String _clientType        = 'propriétaire';
  String _phoneNumber       = '';        // numéro complet avec indicatif
  String _initialPhone      = '';        // pour pré-remplir IntlPhoneField
  bool   _obscureNewPwd     = true;
  bool   _obscureConfirmPwd = true;
  bool   _isLoading         = true;      // chargement initial
  bool   _isSaving          = false;     // sauvegarde en cours
  bool   _changePassword    = false;     // section mdp dépliée
  String? _userId;

  late AnimationController _animCtrl;

  final List<String> _clientTypes = ['propriétaire', 'professionnel'];

  // ── Cycle de vie ───────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _loadCurrentUser();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  // ── Chargement des données existantes ──────────────────────────────────────
  Future<void> _loadCurrentUser() async {
    try {
      final authUser = Supabase.instance.client.auth.currentUser;
      if (authUser == null) {
        _showSnack('Session expirée, veuillez vous reconnecter.', isError: true);
        return;
      }
      _userId = authUser.id;

      // Récupérer les données dans la table client
      final clientData = await Supabase.instance.client
          .from('client')
          .select('nom_client, type_client, telephone')
          .eq('id', _userId!)
          .single();

      if (!mounted) return;
      setState(() {
        _nameController.text  = clientData['nom_client']  ?? '';
        _clientType           = clientData['type_client'] ?? 'propriétaire';
        _emailController.text = authUser.email            ?? '';

        // Téléphone : on sépare l'indicatif du numéro local pour IntlPhoneField
        final rawPhone = (clientData['telephone'] ?? '') as String;
        _phoneNumber   = rawPhone;
        // On extrait la partie locale (sans indicatif) pour l'affichage
        // IntlPhoneField gère l'indicatif séparément
        _initialPhone  = _extractLocalNumber(rawPhone);
        _phoneController.text = _initialPhone;

        _isLoading = false;
      });
      _animCtrl.forward();
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        _showSnack('Erreur lors du chargement : $e', isError: true);
      }
    }
  }

  /// Retire l'indicatif international (+216, +33, etc.) pour laisser le numéro local
  String _extractLocalNumber(String fullPhone) {
    if (fullPhone.startsWith('+')) {
      // Ex: "+21698765432" → on cherche la position après l'indicatif
      // Heuristique : indicatifs de 1 à 3 chiffres → on retire les 1-4 chars
      final match = RegExp(r'^\+\d{1,3}').firstMatch(fullPhone);
      if (match != null) {
        return fullPhone.substring(match.end).trim();
      }
    }
    return fullPhone;
  }

  // ── Sauvegarde ─────────────────────────────────────────────────────────────
  Future<void> _saveProfile() async {
    if (!_formKey.currentState!.validate()) return;
    if (_phoneNumber.isEmpty) {
      _showSnack('Veuillez entrer un numéro de téléphone valide', isError: true);
      return;
    }

    setState(() => _isSaving = true);

    try {
      final supabase = Supabase.instance.client;

      // ── 1. Mettre à jour la table `client` ─────────────────────────────────
      await supabase.from('client').update({
        'nom_client':  _nameController.text.trim(),
        'type_client': _clientType,
        'telephone':   _phoneNumber,
      }).eq('id', _userId!);

      // ── 2. Mettre à jour l'email Auth si modifié ───────────────────────────
      final currentEmail = supabase.auth.currentUser?.email ?? '';
      final newEmail = _emailController.text.trim();
      if (newEmail != currentEmail) {
        await supabase.auth.updateUser(UserAttributes(email: newEmail));
      }

      // ── 3. Mettre à jour le mot de passe Auth si demandé ───────────────────
      if (_changePassword && _newPasswordController.text.isNotEmpty) {
        await supabase.auth.updateUser(
          UserAttributes(password: _newPasswordController.text),
        );
      }

      if (!mounted) return;
      _showSnack('Profil mis à jour avec succès !', isError: false);

      // Retourner à la page précédente avec un signal de rafraîchissement
      await Future.delayed(const Duration(milliseconds: 800));
      if (mounted) Navigator.pop(context, true); // true = données modifiées
    } catch (e) {
      if (mounted) _showSnack('Erreur lors de la sauvegarde : $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _showSnack(String msg, {required bool isError}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle_outline,
            color: Colors.white,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(msg, style: GoogleFonts.poppins(
              fontSize: 14, fontWeight: FontWeight.w500,
            )),
          ),
        ]),
        backgroundColor: isError ? _kError : _kSuccess,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBgLight,
      body: Stack(
        children: [
          // Blobs décoratifs
          Positioned(top: -70, left: -50,
            child: Container(width: 220, height: 220,
              decoration: const BoxDecoration(
                shape: BoxShape.circle, color: Color(0x1A6FD3DE),
              ))),
          Positioned(top: 30, right: -30,
            child: Container(width: 130, height: 130,
              decoration: const BoxDecoration(
                shape: BoxShape.circle, color: Color(0x1226C6DA),
              ))),

          SafeArea(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: _kPrimary))
                : Column(children: [
                    _buildAppBar(),
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildAvatarSection(),
                              const SizedBox(height: 28),
                              _buildCard(children: [
                                _buildSectionLabel('Informations personnelles',
                                    Icons.person_outline_rounded),
                                const SizedBox(height: 16),
                                _buildField(
                                  controller:  _nameController,
                                  hint:        'Nom complet',
                                  icon:        Icons.badge_outlined,
                                  validator:   (v) => (v == null || v.trim().isEmpty)
                                      ? 'Veuillez entrer votre nom' : null,
                                ),
                                const SizedBox(height: 14),
                                _buildClientTypeDropdown(),
                              ]),
                              const SizedBox(height: 16),
                              _buildCard(children: [
                                _buildSectionLabel('Coordonnées',
                                    Icons.contact_phone_outlined),
                                const SizedBox(height: 16),
                                _buildField(
                                  controller:  _emailController,
                                  hint:        'Adresse e-mail',
                                  icon:        Icons.mail_outline_rounded,
                                  keyboard:    TextInputType.emailAddress,
                                  validator:   (v) {
                                    if (v == null || v.trim().isEmpty) {
                                      return 'Veuillez entrer votre e-mail';
                                    }
                                    if (!RegExp(r'^[\w\-.]+@([\w-]+\.)+[\w]{2,4}$')
                                        .hasMatch(v)) {
                                      return 'E-mail invalide';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 14),
                                _buildPhoneField(),
                              ]),
                              const SizedBox(height: 16),
                              _buildPasswordSection(),
                              const SizedBox(height: 28),
                              _buildSaveButton(),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ]),
          ),
        ],
      ),
    );
  }

  // ─── App Bar custom ───────────────────────────────────────────────────────
  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 20, 8),
      child: Row(children: [
        // Bouton retour
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 10,
            )],
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _kTextDark, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        const SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Modifier le profil',
            style: GoogleFonts.poppins(
              fontSize: 22, fontWeight: FontWeight.bold, color: _kTextDark,
            )),
          Text('Mettez à jour vos informations',
            style: GoogleFonts.poppins(fontSize: 12, color: _kTextMid)),
        ]),
      ]),
    );
  }

  // ─── Avatar / initiales ────────────────────────────────────────────────────
  Widget _buildAvatarSection() {
    final name = _nameController.text.trim();
    final initials = name.isNotEmpty
        ? name.split(' ').map((e) => e.isNotEmpty ? e[0] : '').take(2).join()
        : '?';

    return Center(
      child: Stack(alignment: Alignment.bottomRight, children: [
        Container(
          width: 88, height: 88,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [_kPrimary, _kCyan],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Center(
            child: Text(
              initials.toUpperCase(),
              style: GoogleFonts.poppins(
                fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white,
              ),
            ),
          ),
        ),
        Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            color: _kBlue,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 2),
          ),
          child: const Icon(Icons.edit, color: Colors.white, size: 14),
        ),
      ]),
    );
  }

  // ─── Carte blanche ─────────────────────────────────────────────────────────
  Widget _buildCard({required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.08),
            blurRadius: 20, offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }

  Widget _buildSectionLabel(String label, IconData icon) {
    return Row(children: [
      Container(
        width: 32, height: 32,
        decoration: BoxDecoration(
          color: _kPrimary.withOpacity(0.12),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: _kPrimary, size: 16),
      ),
      const SizedBox(width: 10),
      Text(label, style: GoogleFonts.poppins(
        fontSize: 15, fontWeight: FontWeight.w700, color: _kTextDark,
      )),
    ]);
  }

  // ─── Champ texte standard ─────────────────────────────────────────────────
  Widget _buildField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType keyboard = TextInputType.text,
    bool obscure = false,
    bool? obscureState,
    VoidCallback? onToggleObscure,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller:    controller,
      obscureText:   obscure && (obscureState ?? true),
      keyboardType:  keyboard,
      style: GoogleFonts.poppins(fontSize: 15, color: _kTextDark),
      decoration: InputDecoration(
        hintText:  hint,
        hintStyle: GoogleFonts.poppins(color: _kTextLight, fontSize: 14),
        prefixIcon: Padding(
          padding: const EdgeInsets.all(14),
          child: Icon(icon, color: _kPrimary.withOpacity(0.75), size: 20),
        ),
        suffixIcon: onToggleObscure != null
            ? IconButton(
                icon: Icon(
                  (obscureState ?? true)
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: _kTextLight, size: 20,
                ),
                onPressed: onToggleObscure,
              )
            : null,
        filled:    true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(vertical: 18),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.grey.withOpacity(0.2)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.grey.withOpacity(0.2)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _kPrimary, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _kError),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _kError, width: 1.5),
        ),
        errorStyle: GoogleFonts.poppins(color: _kError, fontSize: 12),
        isDense: true,
      ),
      validator: validator,
    );
  }

  // ─── Dropdown type client ─────────────────────────────────────────────────
  Widget _buildClientTypeDropdown() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            isExpanded: true,
            icon: const Icon(Icons.keyboard_arrow_down_rounded, color: _kPrimary),
            value: _clientType,
            items: _clientTypes.map((type) {
              return DropdownMenuItem<String>(
                value: type,
                child: Row(children: [
                  Icon(
                    type == 'propriétaire'
                        ? Icons.person_rounded
                        : Icons.business_rounded,
                    color: _kPrimary.withOpacity(0.75), size: 20,
                  ),
                  const SizedBox(width: 12),
                  Text(type, style: GoogleFonts.poppins(
                    color: _kTextDark, fontSize: 15,
                  )),
                ]),
              );
            }).toList(),
            onChanged: (v) { if (v != null) setState(() => _clientType = v); },
          ),
        ),
      ),
    );
  }

  // ─── Champ téléphone ─────────────────────────────────────────────────────
  Widget _buildPhoneField() {
    return IntlPhoneField(
      controller:          _phoneController,
      initialCountryCode:  'TN',
      initialValue:        _initialPhone,
      style: GoogleFonts.poppins(fontSize: 15, color: _kTextDark),
      decoration: InputDecoration(
        hintText:  'Numéro de téléphone',
        hintStyle: GoogleFonts.poppins(color: _kTextLight, fontSize: 14),
        filled:    true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.grey.withOpacity(0.2)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.grey.withOpacity(0.2)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _kPrimary, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _kError),
        ),
        isDense: true,
      ),
      dropdownTextStyle: GoogleFonts.poppins(fontSize: 15, color: _kTextDark),
      keyboardType: TextInputType.phone,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      disableLengthCheck: false,
      invalidNumberMessage: 'Numéro invalide',
      onChanged: (phone) => setState(() => _phoneNumber = phone.completeNumber),
    );
  }

  // ─── Section changement de mot de passe (dépliable) ──────────────────────
  Widget _buildPasswordSection() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.08),
            blurRadius: 20, offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(children: [
        // En-tête cliquable
        InkWell(
          onTap: () => setState(() => _changePassword = !_changePassword),
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  color: (_changePassword ? _kBlue : _kPrimary).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(Icons.lock_outline_rounded,
                    color: _changePassword ? _kBlue : _kPrimary, size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text('Modifier le mot de passe',
                  style: GoogleFonts.poppins(
                    fontSize: 15, fontWeight: FontWeight.w700, color: _kTextDark,
                  )),
              ),
              Icon(
                _changePassword
                    ? Icons.keyboard_arrow_up_rounded
                    : Icons.keyboard_arrow_down_rounded,
                color: _kTextMid,
              ),
            ]),
          ),
        ),

        // Corps dépliable
        AnimatedCrossFade(
          firstChild: const SizedBox.shrink(),
          secondChild: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(children: [
              Container(height: 1,
                margin: const EdgeInsets.only(bottom: 16),
                color: Colors.grey.withOpacity(0.1)),
              _buildField(
                controller:      _newPasswordController,
                hint:            'Nouveau mot de passe',
                icon:            Icons.lock_outline_rounded,
                obscure:         true,
                obscureState:    _obscureNewPwd,
                onToggleObscure: () => setState(() => _obscureNewPwd = !_obscureNewPwd),
                validator: (v) {
                  if (!_changePassword) return null;
                  if (v == null || v.isEmpty) {
                    return 'Veuillez entrer un nouveau mot de passe';
                  }
                  if (v.length < 6) {
                    return 'Au moins 6 caractères requis';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 14),
              _buildField(
                controller:      _confirmPasswordController,
                hint:            'Confirmer le mot de passe',
                icon:            Icons.lock_reset_outlined,
                obscure:         true,
                obscureState:    _obscureConfirmPwd,
                onToggleObscure: () => setState(() => _obscureConfirmPwd = !_obscureConfirmPwd),
                validator: (v) {
                  if (!_changePassword) return null;
                  if (v == null || v.isEmpty) {
                    return 'Veuillez confirmer le mot de passe';
                  }
                  if (v != _newPasswordController.text) {
                    return 'Les mots de passe ne correspondent pas';
                  }
                  return null;
                },
              ),
            ]),
          ),
          crossFadeState: _changePassword
              ? CrossFadeState.showSecond
              : CrossFadeState.showFirst,
          duration: const Duration(milliseconds: 280),
        ),
      ]),
    );
  }

  // ─── Bouton Enregistrer ───────────────────────────────────────────────────
  Widget _buildSaveButton() {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_kPrimary, _kCyan],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.35),
            blurRadius: 16, offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _isSaving ? null : _saveProfile,
          borderRadius: BorderRadius.circular(18),
          splashColor: Colors.white.withOpacity(0.15),
          child: Center(
            child: _isSaving
                ? const SizedBox(
                    width: 24, height: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2.5,
                    ))
                : Row(mainAxisSize: MainAxisSize.min, children: [
                    Text('Enregistrer les modifications',
                      style: GoogleFonts.poppins(
                        color: Colors.white, fontSize: 16,
                        fontWeight: FontWeight.bold, letterSpacing: 0.3,
                      )),
                    const SizedBox(width: 8),
                    const Icon(Icons.check_rounded, color: Colors.white, size: 20),
                  ]),
          ),
        ),
      ),
    );
  }
}
// Fichier: interfaces/GetStarted.dart
// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/auth/login.dart';
import 'package:carhabti/auth/Sign_Up.dart';
import 'package:carhabti/magasin_model/carhabti_theme.dart';

class Getstarted extends StatelessWidget {
  const Getstarted({super.key});

  @override
  Widget build(BuildContext context) {
    return const OnboardingScreen();
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  late AnimationController _bgController;
  late AnimationController _contentController;
  late Animation<double> _fadeContent;
  late Animation<Offset> _slideContent;

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat(reverse: true);

    _contentController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _fadeContent = CurvedAnimation(
      parent: _contentController,
      curve: const Interval(0.2, 1.0, curve: Curves.easeOut),
    );

    _slideContent = Tween<Offset>(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _contentController,
      curve: const Interval(0.2, 1.0, curve: Curves.easeOutCubic),
    ));

    _contentController.forward();
  }

  @override
  void dispose() {
    _bgController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Stack(
        children: [
          // ── Fond gradient navy → turquoise ──
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  KTheme.navy,
                  Color(0xFF122040),
                  KTheme.turquoiseDark,
                ],
                stops: [0.0, 0.5, 1.0],
              ),
            ),
          ),

          // ── Floating blobs animés ──
          AnimatedBuilder(
            animation: _bgController,
            builder: (context, _) {
              final t = _bgController.value;
              return Stack(
                children: [
                  Positioned(
                    top: -40 + (20 * t),
                    right: -60 + (15 * t),
                    child: _buildBlob(
                      size: size.width * 0.55,
                      color: KTheme.turquoise.withOpacity(0.08),
                    ),
                  ),
                  Positioned(
                    bottom: size.height * 0.25 + (10 * t),
                    left: -40 - (10 * t),
                    child: _buildBlob(
                      size: size.width * 0.4,
                      color: KTheme.cyan.withOpacity(0.06),
                    ),
                  ),
                  Positioned(
                    top: size.height * 0.35 - (15 * t),
                    right: -20 + (20 * t),
                    child: _buildBlob(
                      size: size.width * 0.25,
                      color: KTheme.yellow.withOpacity(0.05),
                    ),
                  ),
                ],
              );
            },
          ),

          // ── Contenu ──
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 24),

                  // Logo et nom
                  FadeTransition(
                    opacity: _fadeContent,
                    child: Row(
                      children: [
                        Text(
                          ' CARHABTI',
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: KTheme.yellow,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Image centrale
                  Expanded(
                    child: Center(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Glow derrière le logo
                          Container(
                            width: 220,
                            height: 220,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  KTheme.turquoise.withOpacity(0.15),
                                  KTheme.turquoise.withOpacity(0.0),
                                ],
                              ),
                            ),
                          ),
                          // Cercle vert pâle de fond avec Hero tag
                          Hero(
                            tag: 'background-circle',
                            child: Container(
                              width: 200,
                              height: 200,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    KTheme.cyan.withOpacity(0.22),
                                    KTheme.turquoise.withOpacity(0.16),
                                  ],
                                ),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color:
                                        KTheme.turquoise.withOpacity(0.2),
                                    blurRadius: 30,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          // Image du véhicule avec Hero tag
                          Hero(
                            tag: 'bike-image',
                            child: Image.asset(
                                'assets/LOGO_CARHABTI.png',
                              width: 280,
                              fit: BoxFit.contain,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Textes de bienvenue
                  FadeTransition(
                    opacity: _fadeContent,
                    child: SlideTransition(
                      position: _slideContent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Commençons",
                            style: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 38,
                              fontWeight: FontWeight.w800,
                              height: 1.1,
                              letterSpacing: -0.5,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            "Votre véhicule mérite le meilleur suivi.\nTout commence ici.",
                            style: GoogleFonts.poppins(
                              color: Colors.white.withOpacity(0.65),
                              fontSize: 15,
                              height: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 36),

                  // Bouton « Se connecter » — Jaune CTA
                  FadeTransition(
                    opacity: _fadeContent,
                    child: SlideTransition(
                      position: _slideContent,
                      child: KGradientButton(
                        label: 'Se connecter',
                        icon: Icons.login_rounded,
                        gradient: KTheme.accentGradient,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const LoginScreen()),
                          );
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Bouton « S'inscrire » — Glass style
                  FadeTransition(
                    opacity: _fadeContent,
                    child: SlideTransition(
                      position: _slideContent,
                      child: GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(
                            PageRouteBuilder(
                              pageBuilder:
                                  (context, animation, secondaryAnimation) =>
                                      const SignUp(),
                              transitionsBuilder: (context, animation,
                                  secondaryAnimation, child) {
                                return SlideTransition(
                                  position: Tween<Offset>(
                                    begin: const Offset(1.0, 0.0),
                                    end: Offset.zero,
                                  ).animate(CurvedAnimation(
                                    parent: animation,
                                    curve: Curves.easeInOutCubic,
                                  )),
                                  child: child,
                                );
                              },
                              transitionDuration:
                                  const Duration(milliseconds: 500),
                            ),
                          );
                        },
                        child: Container(
                          width: double.infinity,
                          height: 54,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius:
                                BorderRadius.circular(KTheme.radiusMD),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.25),
                              width: 1.5,
                            ),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.person_add_rounded,
                                    color: Colors.white, size: 20),
                                const SizedBox(width: 10),
                                Text(
                                  "S'inscrire",
                                  style: GoogleFonts.poppins(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 36),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBlob({required double size, required Color color}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
      ),
    );
  }
}

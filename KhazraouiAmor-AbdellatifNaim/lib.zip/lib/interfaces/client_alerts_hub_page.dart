// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/garages_pro/screens/notif_garage_screen.dart';
import 'package:carhabti/interfaces/maintenance_alerts_page.dart';
import 'package:carhabti/notif.dart';
import 'package:carhabti/assistant financier/notification_history_screen.dart';

/// Point d’entrée unique depuis la cloche du tableau de bord client :
/// rendez-vous garages, alertes entretien (véhicule actif), centre [NotificationPage].
class ClientAlertsHubPage extends StatelessWidget {
  final String? vehicleImmatriculation;

  const ClientAlertsHubPage({super.key, this.vehicleImmatriculation});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FB),
      appBar: AppBar(
        elevation: 0,
        title: Text(
          'Notifications & rendez-vous',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w700,
            fontSize: 17,
            color: Colors.white,
          ),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF0D5C8A),
                Color(0xFF127BBC),
                Color(0xFF1AA3D8),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        backgroundColor: const Color(0xFF127BBC),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
        children: [
          Text(
            'Accès rapide',
            style: GoogleFonts.poppins(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF8A94A6),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: const BorderSide(color: Color(0xFFEAEEF4)),
            ),
            child: Column(
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFFE8F0FE),
                    child: Icon(Icons.event_available_rounded,
                        color: const Color(0xFF1A73E8)),
                  ),
                  title: Text(
                    'Mes rendez-vous garages',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: const Color(0xFF1A2340),
                    ),
                  ),
                  subtitle: Text(
                    'Demandes en cours, confirmées ou annulées',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: const Color(0xFF8A94A6),
                    ),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: Color(0xFF8A94A6)),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const MyAppointmentsScreen(),
                      ),
                    );
                  },
                ),
                const Divider(height: 1),
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFFF3E5F5),
                    child: Icon(Icons.build_circle_rounded,
                        color: const Color(0xFF5E35B1)),
                  ),
                  title: Text(
                    'Alertes entretien',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: const Color(0xFF1A2340),
                    ),
                  ),
                  subtitle: Text(
                    vehicleImmatriculation != null
                        ? 'Véhicule : $vehicleImmatriculation'
                        : 'Sélectionnez un véhicule sur l’accueil du tableau de bord',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: const Color(0xFF8A94A6),
                    ),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: Color(0xFF8A94A6)),
                  enabled: vehicleImmatriculation != null,
                  onTap: vehicleImmatriculation == null
                      ? null
                      : () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => MaintenanceAlertsPage(
                                immatriculation: vehicleImmatriculation!,
                              ),
                            ),
                          );
                        },
                ),
                const Divider(height: 1),
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFFE0F7FA),
                    child: Icon(Icons.account_balance_wallet_rounded,
                        color: const Color(0xFF00ACC1)),
                  ),
                  title: Text(
                    'Alertes financières',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: const Color(0xFF1A2340),
                    ),
                  ),
                  subtitle: Text(
                    vehicleImmatriculation != null
                        ? 'Budget, dépenses récurrentes et anomalies'
                        : 'Sélectionnez un véhicule sur l\'accueil du tableau de bord',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: const Color(0xFF8A94A6),
                    ),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: Color(0xFF8A94A6)),
                  enabled: vehicleImmatriculation != null,
                  onTap: vehicleImmatriculation == null
                      ? null
                      : () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  FinanceNotificationHistoryScreen(
                                immatriculation: vehicleImmatriculation!,
                              ),
                            ),
                          );
                        },
                ),
                const Divider(height: 1),
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFFE8F5E9),
                    child: Icon(Icons.notifications_active_rounded,
                        color: const Color(0xFF43A047)),
                  ),
                  title: Text(
                    'Centre de notifications',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: const Color(0xFF1A2340),
                    ),
                  ),
                  subtitle: Text(
                    'Historique : entretien, rendez-vous, alertes diverses',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: const Color(0xFF8A94A6),
                    ),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: Color(0xFF8A94A6)),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const NotificationPage(),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFE8F0FE),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: const Color(0xFF1A73E8).withOpacity(0.2)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline_rounded,
                    color: Color(0xFF1A73E8), size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Lorsqu’un garage confirme ou refuse un rendez-vous, '
                    'une alerte est ajoutée ici et une notification s’affiche sur l’appareil '
                    '(si les notifications sont autorisées).',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      height: 1.45,
                      color: const Color(0xFF1A2340),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/chatbot/mechanic_chat_service.dart';
import 'package:carhabti/pieces_form/pneus_form.dart';
import 'package:carhabti/pieces_form/vidange_form.dart';
import 'package:carhabti/pieces_form/amortisseurs_form.dart';
import 'package:carhabti/pieces_form/courroie_form.dart';
import 'package:carhabti/pieces_form/freins_form.dart';
import 'package:carhabti/pieces_form/batterie_form.dart';
import 'package:carhabti/pieces_form/embrayage_form.dart';
import 'package:carhabti/interfaces/show.dart';
import 'package:carhabti/interfaces/edit_profile_screen.dart';

// ─── Palette de marque CARHABTI ──────────────────────────────────────────────
const _kPrimary   = Color(0xFF6FD3DE); // Turquoise
const _kBlue      = Color(0xFF42A5F5); // Bleu vif
const _kCyan      = Color(0xFF26C6DA); // Cyan
const _kYellow    = Color(0xFFFFD341); // Jaune accent
const _kBgLight   = Color(0xFFF4FAFB); // Fond global
const _kTextDark  = Color(0xFF1A2E35); // Titre
const _kTextMid   = Color(0xFF607D8B); // Secondaire
const _kTextLight = Color(0xFFB0BEC5); // Placeholder
const _kCard      = Colors.white;
// ─────────────────────────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════════
// Point d'entrée (wrapper MaterialApp conservé pour compatibilité)
// ═══════════════════════════════════════════════════════════════════════════════
class Profilecleint extends StatelessWidget {
  final String immatriculation;
  final PostgrestMap initialData;

  const Profilecleint({
    super.key,
    required this.immatriculation,
    required this.initialData,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Poppins',
        scaffoldBackgroundColor: _kBgLight,
        colorScheme: ColorScheme.fromSeed(seedColor: _kPrimary),
      ),
      home: _ProfilePage(immatriculation: immatriculation),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Page principale — StatefulWidget pour gérer l'état proprement
// ═══════════════════════════════════════════════════════════════════════════════
class _ProfilePage extends StatefulWidget {
  final String immatriculation;

  const _ProfilePage({required this.immatriculation});

  @override
  State<_ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<_ProfilePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  Map<String, dynamic>? _clientData;
  bool _chatExpanded = false;

  // ── Services / pièces ───────────────────────────────────────────────────────
  static const _services = [
    {'icon': Icons.tire_repair_outlined,       'label': 'Pneus',      'formType': 'Pneus',         'color': Color(0xFF42A5F5)},
    {'icon': Icons.oil_barrel_outlined,         'label': 'Vidange',    'formType': 'Vidange',       'color': Color(0xFF26C6DA)},
    {'icon': Icons.car_repair_outlined,         'label': 'Amortis.',   'formType': 'Amortisseurs',  'color': Color(0xFF6FD3DE)},
    {'icon': Icons.settings_outlined,           'label': 'Embrayage',  'formType': 'Embrayage',     'color': Color(0xFFFFB74D)},
    {'icon': Icons.build_circle_outlined,       'label': 'Courroie',   'formType': 'Courroie',      'color': Color(0xFF66BB6A)},
    {'icon': Icons.stop_circle_outlined,        'label': 'Freins',     'formType': 'Freins',        'color': Color(0xFFEF5350)},
    {'icon': Icons.battery_charging_full_outlined,'label': 'Batterie', 'formType': 'Batterie',      'color': Color(0xFFAB47BC)},
  ];

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
    MechanicChatService.initWithDefaultAccount();
    _loadClientInfo();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  // ── Données ────────────────────────────────────────────────────────────────
  Future<void> _loadClientInfo() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) return;
      final data = await Supabase.instance.client
          .from('client')
          .select('nom_client, type_client')
          .eq('id', user.id)
          .maybeSingle();
      if (mounted) setState(() => _clientData = data);
    } catch (e) {
      if (kDebugMode) debugPrint('Erreur client info: $e');
    }
  }


  // ── Navigation vers la modification du profil ──────────────────────────────
  Future<void> _navigateToEditProfile() async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const EditProfileScreen()),
    );
    if (result == true && mounted) {
      _loadClientInfo(); // rafraîchit nom et type dans le header
    }
  }
  Future<Map<String, dynamic>> _fetchPiecesData() async {
    if (widget.immatriculation.isEmpty) throw 'Immatriculation non valide';
    final data = await Supabase.instance.client
        .from('facteur')
        .select()
        .eq('fk_immatriculation', widget.immatriculation)
        .maybeSingle();
    return data ?? {};
  }

  Future<List<Map<String, dynamic>>> _fetchReminders() async {
    final supabase = Supabase.instance.client;
    if (supabase.auth.currentUser == null) return [];
    try {
      final now = DateTime.now();
      final twoWeeks = now.add(const Duration(days: 14));
      final vehicules = await supabase.from('voiture').select('immatriculation');
      if (vehicules.isEmpty) return [];

      final reminders = <Map<String, dynamic>>[];
      for (final v in List<Map<String, dynamic>>.from(vehicules)) {
        try {
          final rows = await supabase
              .from('pieces_vehicule')
              .select('*, voiture(immatriculation)')
              .eq('fk_immatriculation', v['immatriculation'])
              .or('prochaine_maintenance.lte.${twoWeeks.toIso8601String()},prochaine_maintenance.eq.${now.toIso8601String()}')
              .order('prochaine_maintenance');

          for (final item in List<Map<String, dynamic>>.from(rows)) {
            reminders.add({
              'piece_nom':         item['nom'] ?? 'Pièce',
              'date_remplacement': DateTime.parse(item['prochaine_maintenance']),
              'immatriculation':   item['voiture']?['immatriculation'] ?? v['immatriculation'],
            });
          }
        } catch (_) {}
      }
      return reminders;
    } catch (e) {
      if (kDebugMode) debugPrint('Erreur rappels: $e');
      return [];
    }
  }

  // ── Navigation vers formulaire pièce ───────────────────────────────────────
  //
  // Stratégie par formulaire :
  //   • PneusForm   → constructeur(immatriculation, initialData)  + args (double sécurité)
  //   • VidangeForm, AmortisseursForm, CourroieForm, FreinsForm
  //               → constructeur(immatriculation) ; chargent eux-mêmes depuis Supabase
  //   • BatterieForm, EmbrayageForm
  //               → PAS de champ final immatriculation dans leur constructeur ;
  //                 ils lisent UNIQUEMENT ModalRoute.settings.arguments
  //                 → on utilise MaterialPageRoute avec RouteSettings(arguments: immat)
  //
  Future<void> _navigateToForm(String formType) async {
    if (!mounted) return;
    final immat = widget.immatriculation;

    if (immat.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aucun véhicule sélectionné')),
      );
      return;
    }

    // Afficher un indicateur pendant la récupération des données Supabase
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: _kPrimary, strokeWidth: 2.5),
      ),
    );

    try {
      // Récupérer les données existantes de la table facteur pour ce véhicule
      final Map<String, dynamic> facteurData = await _fetchPiecesData();

      if (!mounted) return;
      Navigator.pop(context); // fermer le loader

      switch (formType) {
        // ── PneusForm : accepte initialData en constructeur ────────────────────
        case 'Pneus':
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat),
              builder: (_) => PneusForm(
                immatriculation: immat,
                initialData: facteurData, // pré-remplit les champs
              ),
            ),
          );
          break;

        // ── VidangeForm : charge ses données en interne depuis Supabase ────────
        case 'Vidange':
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat),
              builder: (_) => VidangeForm(immatriculation: immat),
            ),
          );
          break;

        // ── AmortisseursForm : charge ses données en interne ───────────────────
        case 'Amortisseurs':
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat),
              builder: (_) => AmortisseursForm(immatriculation: immat),
            ),
          );
          break;

        // ── CourroieForm : charge ses données en interne ───────────────────────
        case 'Courroie':
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat),
              builder: (_) => CourroieForm(immatriculation: immat),
            ),
          );
          break;

        // ── FreinsForm : charge ses données en interne ─────────────────────────
        case 'Freins':
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat),
              builder: (_) => FreinsForm(immatriculation: immat),
            ),
          );
          break;

        // ── BatterieForm : PAS de champ constructeur → arguments obligatoires ──
        case 'Batterie':
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat), // seul mécanisme valide
              builder: (_) => const BatterieForm(immatriculation: ''),
              // immatriculation:'' car le form ignore le paramètre constructeur
              // et lit exclusivement ModalRoute.settings.arguments
            ),
          );
          break;

        // ── EmbrayageForm : identique à BatterieForm ───────────────────────────
        case 'Embrayage':
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat),
              builder: (_) => const EmbrayageForm(immatriculation: ''),
            ),
          );
          break;

        // ── Fallback : Pneus avec les données existantes ───────────────────────
        default:
          await Navigator.push(
            context,
            MaterialPageRoute(
              settings: RouteSettings(arguments: immat),
              builder: (_) => PneusForm(
                immatriculation: immat,
                initialData: facteurData,
              ),
            ),
          );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // fermer le loader en cas d'erreur
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur lors de l\'ouverture du formulaire : $e'),
            backgroundColor: const Color(0xFFEF5350),
          ),
        );
      }
    }
  }

  // ── Navigation vers ShowScreen ──────────────────────────────────────────────
  Future<void> _navigateToShow() async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator(color: _kPrimary)),
    );
    try {
      final facteurData = await _fetchPiecesData();
      if (!mounted) return;
      Navigator.pop(context);
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ShowScreen(
            immatriculation: widget.immatriculation,
            predictions: {
              'tire_wear': 0.0, 'oil_change': 0.0, 'belt_risk': 0.0,
              'battery_health': 0.0, 'brake_wear': 0.0, 'clutch_wear': 0.0,
              'ShockAbsorber_Wear': 0.0,
            },
            facteurData: facteurData,
          ),
        ),
      );
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final clientName = _clientData?['nom_client'] ?? 'Client';
    final clientType = _clientData?['type_client'] ?? 'propriétaire';
    final isPro = clientType != 'propriétaire';

    return Scaffold(
      backgroundColor: _kBgLight,
      body: Stack(
        children: [
          // Blobs décoratifs en fond
          Positioned(
            top: -70, left: -50,
            child: Container(
              width: 220, height: 220,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0x1A6FD3DE),
              ),
            ),
          ),
          Positioned(
            top: 30, right: -30,
            child: Container(
              width: 120, height: 120,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0x1226C6DA),
              ),
            ),
          ),

          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                // ── App Bar custom ──────────────────────────────────────────
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: _buildHeader(clientName, clientType, isPro),
                  ),
                ),

                // ── Carte véhicule / immatriculation ───────────────────────
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: _buildVehicleCard(),
                  ),
                ),

                // ── Section pièces ─────────────────────────────────────────
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 28, 20, 0),
                    child: _buildSectionTitle('Suivi des pièces', Icons.build_outlined),
                  ),
                ),
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 110,
                    child: _buildServicesRow(),
                  ),
                ),

                // ── Bannière diagnostic ────────────────────────────────────
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 28, 20, 0),
                    child: _buildDiagnosticBanner(),
                  ),
                ),

                // ── Rappels d'entretien ────────────────────────────────────
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 28, 20, 0),
                    child: _buildSectionTitle('Rappels d\'entretien', Icons.notifications_outlined),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                    child: _buildRemindersSection(),
                  ),
                ),

                // ── Assistant mécanique (chatbot) ──────────────────────────
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 28, 20, 0),
                    child: _buildSectionTitle('Assistant mécanique', Icons.smart_toy_outlined),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
                    child: _buildChatCard(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── Header ────────────────────────────────────────────────────────────────
  Widget _buildHeader(String name, String type, bool isPro) {
    // Initiales à afficher dans l'avatar
    final initials = name.trim().isNotEmpty
        ? name.trim().split(' ').map((e) => e.isNotEmpty ? e[0] : '').take(2).join().toUpperCase()
        : '?';

    return FadeTransition(
      opacity: _animCtrl,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // ── Salutation + nom ─────────────────────────────────────────────
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Text('👋 ', style: TextStyle(fontSize: 18)),
                  Text('Bonjour,', style: GoogleFonts.poppins(
                      fontSize: 14, color: _kTextMid)),
                ]),
                const SizedBox(height: 4),
                Text(
                  name,
                  style: GoogleFonts.poppins(
                    fontSize: 26, fontWeight: FontWeight.bold, color: _kTextDark,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                // Badge type de compte
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: (isPro ? _kYellow : _kPrimary).withOpacity(0.13),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    isPro ? '🏢 Professionnel' : '🚗 Propriétaire',
                    style: GoogleFonts.poppins(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: isPro ? const Color(0xFFFF8F00) : _kPrimary,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 12),

          // ── Avatar cliquable → Modifier profil ───────────────────────────
          GestureDetector(
            onTap: _navigateToEditProfile,
            child: Tooltip(
              message: 'Modifier le profil',
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  // Cercle avatar avec initiales
                  Container(
                    width: 56, height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: isPro
                            ? [_kYellow, const Color(0xFFFFB74D)]
                            : [_kPrimary, _kCyan],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (isPro ? _kYellow : _kPrimary).withOpacity(0.35),
                          blurRadius: 12, offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        initials,
                        style: GoogleFonts.poppins(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  // Badge crayon en bas à droite
                  Positioned(
                    bottom: -2, right: -2,
                    child: Container(
                      width: 22, height: 22,
                      decoration: BoxDecoration(
                        color: _kBlue,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: _kBlue.withOpacity(0.30),
                            blurRadius: 6, offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.edit, color: Colors.white, size: 11),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Carte véhicule ────────────────────────────────────────────────────────
  Widget _buildVehicleCard() {
    return SlideTransition(
      position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
          .animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic)),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_kPrimary, _kCyan],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: _kPrimary.withOpacity(0.30),
              blurRadius: 20, offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.directions_car_rounded, color: Colors.white, size: 36),
            const SizedBox(width: 14),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Véhicule actif', style: GoogleFonts.poppins(
                  color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 2),
                Text(
                  widget.immatriculation.isNotEmpty
                      ? widget.immatriculation
                      : 'Non défini',
                  style: GoogleFonts.poppins(
                    color: Colors.white, fontSize: 20,
                    fontWeight: FontWeight.bold, letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const Spacer(),
            GestureDetector(
              onTap: _navigateToShow,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.22),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text('Diagnostic', style: GoogleFonts.poppins(
                  color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600,
                )),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Titre de section ──────────────────────────────────────────────────────
  Widget _buildSectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Container(
          width: 34, height: 34,
          decoration: BoxDecoration(
            color: _kPrimary.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: _kPrimary, size: 18),
        ),
        const SizedBox(width: 10),
        Text(title, style: GoogleFonts.poppins(
          fontSize: 18, fontWeight: FontWeight.w700, color: _kTextDark,
        )),
      ],
    );
  }

  // ─── Rangée des pièces / services ──────────────────────────────────────────
  Widget _buildServicesRow() {
    return ListView.separated(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
      itemCount: _services.length,
      separatorBuilder: (_, __) => const SizedBox(width: 12),
      itemBuilder: (context, i) {
        final s = _services[i];
        final color = s['color'] as Color;
        return GestureDetector(
          onTap: () {
            if (widget.immatriculation.isNotEmpty) {
              _navigateToForm(s['formType'] as String);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Aucun véhicule sélectionné')),
              );
            }
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: 82,
            decoration: BoxDecoration(
              color: _kCard,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.15),
                  blurRadius: 12, offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(s['icon'] as IconData, color: color, size: 22),
                ),
                const SizedBox(height: 8),
                Text(
                  s['label'] as String,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 11, fontWeight: FontWeight.w600, color: _kTextDark,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── Bannière diagnostic ───────────────────────────────────────────────────
  Widget _buildDiagnosticBanner() {
    return GestureDetector(
      onTap: _navigateToShow,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_kBlue.withOpacity(0.08), _kCyan.withOpacity(0.12)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _kPrimary.withOpacity(0.20), width: 1.2),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('🔧 Assistant Entretien', style: GoogleFonts.poppins(
                    fontSize: 17, fontWeight: FontWeight.w800, color: _kTextDark,
                  )),
                  const SizedBox(height: 8),
                  Text(
                    'Surveillez votre moteur, vos niveaux et planifiez vos entretiens.',
                    style: GoogleFonts.poppins(
                      fontSize: 13, color: _kTextMid, height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [_kPrimary, _kCyan]),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(color: _kPrimary.withOpacity(0.25),
                            blurRadius: 10, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('Voir le diagnostic', style: GoogleFonts.poppins(
                        color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600,
                      )),
                      const SizedBox(width: 6),
                      const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 16),
                    ]),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Image.network(
              'https://cdn-icons-png.flaticon.com/512/7431/7431317.png',
              height: 80, fit: BoxFit.contain,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.car_repair, size: 70, color: _kPrimary),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Rappels d'entretien ───────────────────────────────────────────────────
  Widget _buildRemindersSection() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _fetchReminders(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: CircularProgressIndicator(color: _kPrimary, strokeWidth: 2),
            ),
          );
        }
        final reminders = snapshot.data ?? [];
        if (reminders.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: _kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _kPrimary.withOpacity(0.15)),
            ),
            child: Row(children: [
              const Icon(Icons.check_circle_outline, color: _kPrimary, size: 24),
              const SizedBox(width: 12),
              Text('Aucun rappel d\'entretien pour le moment',
                  style: GoogleFonts.poppins(color: _kTextMid, fontSize: 13)),
            ]),
          );
        }
        return SizedBox(
          height: 110,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: reminders.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => _buildReminderCard(reminders[i]),
          ),
        );
      },
    );
  }

  Widget _buildReminderCard(Map<String, dynamic> r) {
    final date = r['date_remplacement'] as DateTime;
    final isLate = date.isBefore(DateTime.now());
    final accentColor = isLate ? const Color(0xFFEF5350) : _kPrimary;

    return Container(
      width: 220,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentColor.withOpacity(0.25), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: accentColor.withOpacity(0.08),
            blurRadius: 10, offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: accentColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(
                date.day.toString(),
                style: GoogleFonts.poppins(
                  color: accentColor, fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                _shortDay(date.weekday),
                style: GoogleFonts.poppins(color: accentColor, fontSize: 10),
              ),
            ]),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(r['piece_nom'] ?? 'Pièce', style: GoogleFonts.poppins(
                  color: _kTextDark, fontWeight: FontWeight.w600, fontSize: 13,
                ), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(r['immatriculation'] ?? '', style: GoogleFonts.poppins(
                  color: _kTextMid, fontSize: 11,
                )),
                const SizedBox(height: 4),
                Row(children: [
                  Icon(
                    isLate ? Icons.warning_amber_rounded : Icons.access_time_rounded,
                    size: 12, color: accentColor,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    isLate ? 'En retard' : DateFormat('HH:mm').format(date),
                    style: GoogleFonts.poppins(color: accentColor, fontSize: 11),
                  ),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _shortDay(int wd) {
    const days = ['', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
    return days[wd];
  }

  // ─── Chatbot mécanique ─────────────────────────────────────────────────────
  Widget _buildChatCard() {
    return Container(
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.10),
            blurRadius: 20, offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          // En-tête cliquable pour plier/déplier
          GestureDetector(
            onTap: () => setState(() => _chatExpanded = !_chatExpanded),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_kPrimary, _kCyan]),
                borderRadius: BorderRadius.vertical(
                  top: const Radius.circular(24),
                  bottom: Radius.circular(_chatExpanded ? 0 : 24),
                ),
              ),
              child: Row(children: [
                const Icon(Icons.smart_toy_rounded, color: Colors.white, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Text('Assistant Mécanique',
                    style: GoogleFonts.poppins(
                      color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold,
                    )),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.22),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(children: [
                    Container(
                      width: 6, height: 6,
                      decoration: const BoxDecoration(
                        color: Color(0xFF69F0AE), shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text('En ligne', style: GoogleFonts.poppins(
                      color: Colors.white, fontSize: 11,
                    )),
                  ]),
                ),
                const SizedBox(width: 10),
                Icon(
                  _chatExpanded ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded,
                  color: Colors.white,
                ),
              ]),
            ),
          ),

          // Corps du chat (collapsible)
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Text(
                  'Posez vos questions sur l\'entretien de votre véhicule.',
                  style: GoogleFonts.poppins(color: _kTextMid, fontSize: 13),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 280,
                  child: _ChatMessagesList(immatriculation: widget.immatriculation),
                ),
                const SizedBox(height: 8),
                _ChatInputField(immatriculation: widget.immatriculation),
              ]),
            ),
            crossFadeState: _chatExpanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 300),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Chat — modèle de message
// ═══════════════════════════════════════════════════════════════════════════════
class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({required this.text, required this.isUser, required this.timestamp});
}

// ═══════════════════════════════════════════════════════════════════════════════
// Liste des messages
// ═══════════════════════════════════════════════════════════════════════════════
class _ChatMessagesList extends StatefulWidget {
  final String immatriculation;

  const _ChatMessagesList({required this.immatriculation});

  @override
  _ChatMessagesListState createState() => _ChatMessagesListState();
}

class _ChatMessagesListState extends State<_ChatMessagesList> {
  final List<ChatMessage> _messages = [];

  void addMessage(String text, bool isUser) {
    setState(() {
      _messages.insert(0, ChatMessage(
        text: text, isUser: isUser, timestamp: DateTime.now(),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_messages.isEmpty) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.chat_bubble_outline_rounded, color: _kTextLight, size: 40),
          const SizedBox(height: 10),
          Text('Commencez la conversation…',
            style: GoogleFonts.poppins(color: _kTextLight, fontSize: 13)),
        ]),
      );
    }
    return ListView.builder(
      reverse: true,
      physics: const BouncingScrollPhysics(),
      itemCount: _messages.length,
      itemBuilder: (_, i) => _ChatBubble(message: _messages[i]),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Bulle de message
// ═══════════════════════════════════════════════════════════════════════════════
class _ChatBubble extends StatelessWidget {
  final ChatMessage message;

  const _ChatBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.72,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: message.isUser
              ? const LinearGradient(colors: [_kPrimary, _kCyan])
              : null,
          color: message.isUser ? null : const Color(0xFFF1F5F8),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(message.isUser ? 18 : 4),
            bottomRight: Radius.circular(message.isUser ? 4 : 18),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message.text, style: GoogleFonts.poppins(
              color: message.isUser ? Colors.white : _kTextDark,
              fontSize: 13,
            )),
            const SizedBox(height: 4),
            Text(
              DateFormat('HH:mm').format(message.timestamp),
              style: GoogleFonts.poppins(
                color: message.isUser ? Colors.white60 : _kTextLight,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Champ de saisie du chat
// ═══════════════════════════════════════════════════════════════════════════════
class _ChatInputField extends StatefulWidget {
  final String immatriculation;

  const _ChatInputField({required this.immatriculation});

  @override
  _ChatInputFieldState createState() => _ChatInputFieldState();
}

class _ChatInputFieldState extends State<_ChatInputField> {
  final _ctrl = TextEditingController();
  bool _isSending = false;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _handleSend() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    _ctrl.clear();

    final listState = context.findAncestorStateOfType<_ChatMessagesListState>();
    listState?.addMessage(text, true);
    setState(() => _isSending = true);

    try {
      final response = await MechanicChatService.getResponse(
        text, 'fr', widget.immatriculation,
      );
      listState?.addMessage(response, false);
    } catch (e) {
      listState?.addMessage('Désolé, je ne peux pas répondre pour le moment.', false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Erreur de connexion au chatbot')),
        );
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: _kBgLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kPrimary.withOpacity(0.25), width: 1.2),
      ),
      child: Row(children: [
        Expanded(
          child: TextField(
            controller: _ctrl,
            maxLines: 3,
            minLines: 1,
            style: GoogleFonts.poppins(fontSize: 14, color: _kTextDark),
            decoration: InputDecoration(
              hintText: 'Posez une question sur votre véhicule…',
              hintStyle: GoogleFonts.poppins(color: _kTextLight, fontSize: 13),
              border: InputBorder.none,
            ),
            onSubmitted: (_) => _handleSend(),
          ),
        ),
        const SizedBox(width: 6),
        GestureDetector(
          onTap: _isSending ? null : _handleSend,
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              gradient: _isSending ? null : const LinearGradient(
                colors: [_kPrimary, _kCyan],
              ),
              color: _isSending ? _kTextLight : null,
              borderRadius: BorderRadius.circular(12),
            ),
            child: _isSending
                ? const Padding(
                    padding: EdgeInsets.all(10),
                    child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white,
                    ),
                  )
                : const Icon(Icons.send_rounded, color: Colors.white, size: 18),
          ),
        ),
      ]),
    );
  }
}
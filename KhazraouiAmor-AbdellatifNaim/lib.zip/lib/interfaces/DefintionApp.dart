// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:carhabti/interfaces/GetStarted.dart';
import 'package:carhabti/notif.dart';
import 'package:carhabti/magasin_model/carhabti_theme.dart';

// ─── APP ROOT ────────────────────────────────────────────────────────────────

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CARHABTI',
      debugShowCheckedModeBanner: false,
      theme: KTheme.themeData,
      home: const VehiculeAssistantDashboard(),
      routes: {
        '/Commencer': (context) => const Getstarted(),
        '/notifications': (context) => const NotificationPage(),
      },
    );
  }
}

// ─── MAIN SCREEN ─────────────────────────────────────────────────────────────

class VehiculeAssistantDashboard extends StatefulWidget {
  const VehiculeAssistantDashboard({super.key});

  @override
  State<VehiculeAssistantDashboard> createState() =>
      _VehiculeAssistantDashboardState();
}

class _VehiculeAssistantDashboardState
    extends State<VehiculeAssistantDashboard>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _progressAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    _pulseAnimation = Tween<double>(begin: 0.97, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _progressAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.fastOutSlowIn),
    );
    _pulseController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              _buildSliverAppBar(context),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 20),
                      _buildStatsRow(),
                      const SizedBox(height: 20),
                      _buildHealthBanner(),
                      const SizedBox(height: 24),
                      KSectionHeader(
                        title: 'Avis des utilisateurs',
                        icon: Icons.rate_review_rounded,
                      ),
                      const SizedBox(height: 4),
                      _buildReviewsCarousel(),
                      const SizedBox(height: 24),
                      KSectionHeader(
                        title: 'Nos partenaires',
                        icon: Icons.handshake_rounded,
                      ),
                      const SizedBox(height: 4),
                      _buildSponsorsCarousel(),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
          // Fixed CTA button at bottom
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: _buildCTAButton(),
          ),
        ],
      ),
    );
  }

  // ─── SLIVER APP BAR ────────────────────────────────────────────────────────

  Widget _buildSliverAppBar(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 220,
      pinned: true,
      elevation: 0,
      backgroundColor: KTheme.navy,
      actions: [
        GestureDetector(
          onTap: () => Navigator.pushNamed(context, '/notifications'),
          child: Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.15)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.calendar_today_rounded,
                    color: Colors.white, size: 13),
                const SizedBox(width: 6),
                Text(
                  DateFormat('d MMM').format(DateTime.now()),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: KTheme.heroGradient,
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 52, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Brand name
                  Row(
                    children: [
                      Text(
                        'CARHABTI',
                        style: GoogleFonts.poppins(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: KTheme.yellow,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'AutoCare Assistant — Votre véhicule, notre priorité',
                    style: GoogleFonts.poppins(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 13,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Quick feature pills
                  Row(
                    children: [
                      _buildFeaturePill(
                          Icons.shield_rounded, 'Suivi complet'),
                      const SizedBox(width: 8),
                      _buildFeaturePill(
                          Icons.auto_graph_rounded, 'IA prédictive'),
                      const SizedBox(width: 8),
                      _buildFeaturePill(
                          Icons.notifications_active_rounded, 'Alertes'),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'CARHABTI',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(width: 4),
            Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: KTheme.yellow,
                shape: BoxShape.circle,
              ),
            ),
          ],
        ),
        centerTitle: false,
        titlePadding: const EdgeInsets.only(left: 16, bottom: 14),
      ),
    );
  }

  Widget _buildFeaturePill(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: KTheme.turquoiseLight, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.85),
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ─── STATS ROW ─────────────────────────────────────────────────────────────

  Widget _buildStatsRow() {
    final stats = [
      _StatData('83', 'Véhicules', Icons.directions_car_rounded,
          KTheme.turquoise, KTheme.turquoise.withOpacity(0.10)),
      _StatData('56', 'Services', Icons.build_rounded,
          KTheme.success, KTheme.successSoft),
      _StatData('10+', 'Utilisateurs', Icons.people_rounded,
          KTheme.purple, const Color(0xFFF3E5F5)),
      _StatData('5+', 'Garages', Icons.local_gas_station_rounded,
          KTheme.warning, KTheme.warningSoft),
    ];

    return Row(
      children: stats.map((s) {
        final isLast = s == stats.last;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: isLast ? 0 : 10),
            child: _buildStatCard(s),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildStatCard(_StatData data) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        border: Border.all(color: KTheme.border),
        boxShadow: KTheme.elevationLow,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: data.bgColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(data.icon, color: data.accentColor, size: 18),
          ),
          const SizedBox(height: 8),
          Text(
            data.value,
            style: GoogleFonts.poppins(
              fontSize: 17,
              fontWeight: FontWeight.w800,
              color: data.accentColor,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            data.label,
            style: KTheme.labelSM.copyWith(color: KTheme.textSecondary),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // ─── HEALTH BANNER ─────────────────────────────────────────────────────────

  Widget _buildHealthBanner() {
    return AnimatedBuilder(
      animation: _progressAnimation,
      builder: (context, _) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: KTheme.card,
            borderRadius: BorderRadius.circular(KTheme.radiusLG),
            border: Border.all(color: KTheme.border),
            boxShadow: KTheme.elevationLow,
          ),
          child: Row(
            children: [
              // Animated ring
              SizedBox(
                width: 72,
                height: 72,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    CircularProgressIndicator(
                      value: _progressAnimation.value,
                      strokeWidth: 7,
                      backgroundColor: KTheme.border,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Color.lerp(
                          KTheme.turquoise,
                          KTheme.cyan,
                          _progressAnimation.value,
                        )!,
                      ),
                    ),
                    Center(
                      child: Text(
                        '${(_progressAnimation.value * 100).round()}%',
                        style: GoogleFonts.poppins(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: KTheme.turquoise,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Santé du véhicule',
                      style: KTheme.headingSM,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Maintenez la santé de vos véhicules avec CARHABTI — suivi intelligent et alertes proactives.',
                      style: KTheme.bodySM,
                    ),
                    const SizedBox(height: 10),
                    KStatusBadge(
                      label: 'Score excellent',
                      color: KTheme.success,
                      icon: Icons.check_circle_rounded,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── REVIEWS CAROUSEL ──────────────────────────────────────────────────────

  Widget _buildReviewsCarousel() {
    const reviews = [
      _ReviewData(
        name: 'Abdeltaif Naim',
        initials: 'AN',
        review:
            "Grande application! m'a aidé à garder une trace de mon entretien.",
        rating: 5,
        color: KTheme.turquoise,
      ),
      _ReviewData(
        name: 'Ouni Salem',
        initials: 'OS',
        review: 'Très intuitive et facile à utiliser. Je la recommande.',
        rating: 4,
        color: KTheme.success,
      ),
      _ReviewData(
        name: 'ISSET TATAOUINE',
        initials: 'IT',
        review: 'Les rappels sont une bouée de sauvetage! Excellent travail.',
        rating: 5,
        color: KTheme.purple,
      ),
    ];

    return SizedBox(
      height: 158,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: reviews.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) => _buildReviewCard(reviews[index]),
      ),
    );
  }

  Widget _buildReviewCard(_ReviewData data) {
    return Container(
      width: 252,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        border: Border.all(color: KTheme.border),
        boxShadow: KTheme.elevationLow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Avatar
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: data.color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    data.initials,
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: data.color,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.name,
                      style: KTheme.labelLG.copyWith(fontSize: 13),
                      overflow: TextOverflow.ellipsis,
                    ),
                    // Stars
                    Row(
                      children: List.generate(
                        5,
                        (i) => Icon(
                          i < data.rating
                              ? Icons.star_rounded
                              : Icons.star_outline_rounded,
                          color: KTheme.yellow,
                          size: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            data.review,
            style: KTheme.bodySM.copyWith(height: 1.5),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // ─── SPONSORS CAROUSEL ─────────────────────────────────────────────────────

  Widget _buildSponsorsCarousel() {
    final sponsors = [
      _SponsorData(
          'assets/castrol_logo.webp', 'HUILE CASTROL', KTheme.turquoise),
      _SponsorData(
          'assets/totalenergy_logo.webp', 'HUILE TOTAL ENERGY', KTheme.danger),
      _SponsorData(
          'assets/motul_logo.webp', 'HUILE MOTUL', KTheme.success),
      _SponsorData(
          'assets/lm_logo.webp', 'HUILE LIQUIMOLY', KTheme.warning),
    ];

    return SizedBox(
      height: 130,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: sponsors.length,
        separatorBuilder: (_, __) => const SizedBox(width: 20),
        itemBuilder: (context, index) => _buildSponsorCard(sponsors[index]),
      ),
    );
  }

  Widget _buildSponsorCard(_SponsorData data) {
    return Container(
      width: 140,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        border: Border.all(color: KTheme.border),
        color: KTheme.card,
        boxShadow: KTheme.elevationLow,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              data.assetPath,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: data.accent.withOpacity(0.08),
                child: Icon(Icons.store_rounded,
                    color: data.accent.withOpacity(0.4), size: 36),
              ),
            ),
            // Gradient overlay + label
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.65),
                    ],
                  ),
                ),
                child: Text(
                  data.label,
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── CTA BUTTON ────────────────────────────────────────────────────────────

  Widget _buildCTAButton() {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.surface,
        border: Border(
          top: BorderSide(color: KTheme.border, width: 0.5),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      child: ScaleTransition(
        scale: _pulseAnimation,
        child: KGradientButton(
          label: 'Commencer maintenant',
          icon: Icons.directions_car_filled_rounded,
          gradient: KTheme.ctaGradient,
          onTap: () => Navigator.pushNamed(context, '/Commencer'),
        ),
      ),
    );
  }
}

// ─── DATA MODELS ─────────────────────────────────────────────────────────────

class _StatData {
  final String value;
  final String label;
  final IconData icon;
  final Color accentColor;
  final Color bgColor;
  const _StatData(
      this.value, this.label, this.icon, this.accentColor, this.bgColor);
}

class _ReviewData {
  final String name;
  final String initials;
  final String review;
  final int rating;
  final Color color;
  const _ReviewData(
      {required this.name,
      required this.initials,
      required this.review,
      required this.rating,
      required this.color});
}

class _SponsorData {
  final String assetPath;
  final String label;
  final Color accent;
  const _SponsorData(this.assetPath, this.label, this.accent);
}

// ─── REUSABLE CARDS (kept for backward compatibility) ─────────────────────────

class UserReviewCard extends StatelessWidget {
  final String userName;
  final String review;
  final int rating;

  const UserReviewCard({
    super.key,
    required this.userName,
    required this.review,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 252,
      margin: const EdgeInsets.only(right: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        border: Border.all(color: KTheme.border),
        boxShadow: KTheme.elevationLow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(userName,
              style: KTheme.labelLG.copyWith(fontSize: 14)),
          const SizedBox(height: 6),
          Text(review,
              style: KTheme.bodySM.copyWith(height: 1.5),
              maxLines: 3,
              overflow: TextOverflow.ellipsis),
          const SizedBox(height: 8),
          Row(
            children: List.generate(
              5,
              (i) => Icon(
                i < rating ? Icons.star_rounded : Icons.star_outline_rounded,
                color: KTheme.yellow,
                size: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ImageCard extends StatelessWidget {
  final String imageUrl;
  const ImageCard({super.key, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 140,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        image: DecorationImage(
          image: NetworkImage(imageUrl),
          fit: BoxFit.cover,
        ),
        border: Border.all(color: KTheme.border),
      ),
    );
  }
}

class ReviewCard extends StatelessWidget {
  final String userName;
  final String review;
  final int rating;

  const ReviewCard({
    super.key,
    required this.userName,
    required this.review,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) => UserReviewCard(
        userName: userName,
        review: review,
        rating: rating,
      );
}
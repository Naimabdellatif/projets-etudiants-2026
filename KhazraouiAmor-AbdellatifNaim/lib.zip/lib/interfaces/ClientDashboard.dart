// ignore_for_file: use_build_context_synchronously, deprecated_member_use, unused_field, unused_element

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:carhabti/magasin_model/Categorie.dart';
import 'package:carhabti/services/contextual_notification_service.dart';
import 'package:carhabti/prediction_dossier_dart/date.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/interfaces/ProfileCleint.dart';
import 'package:carhabti/interfaces/settings.dart';
import 'package:carhabti/pieces_form/vehicule_form.dart';
import 'package:carhabti/garages_pro/screens/garage_list_screen.dart';
import 'package:carhabti/interfaces/client_alerts_hub_page.dart';
import 'package:carhabti/services/notification_manager.dart';

// ═══════════════════════════════════════════════════════════════════════════════
//  ClientDashboard — visual redesign only (all logic & data methods unchanged)
// ══════════════════════
const _kBlue1 = Color(0xFF0D5C8A);
const _kBlue2 = Color(0xFF127BBC);
const _kBlue3 = Color(0xFF1AA3D8);
const _kBg = Color(0xFFF4F6FB);
const _kSurface = Colors.white;
const _kBorder = Color(0xFFEAEEF4);
const _kTextPrimary = Color(0xFF1A2340);
const _kTextSecondary = Color(0xFF8A94A6);
const _kSuccess = Color(0xFF43A047);
const _kWarning = Color(0xFFF57C00);
const _kDanger = Color(0xFFD32F2F);
const _kPurple = Color(0xFF5E35B1);

class ClientDashboard extends StatefulWidget {
  final String immatriculation;
  const ClientDashboard({super.key, required this.immatriculation});

  @override
  State<ClientDashboard> createState() => _ClientDashboardState();
}

class _ClientDashboardState extends State<ClientDashboard>
    with TickerProviderStateMixin {
  int _selectedIndex = 0;
  final Color _primaryColor = _kBlue2;
  final Color _accentColor = _kPurple;
  late AnimationController _animationController;
  String? _selectedVehicleImmatriculation;

  Future<void> _loadUserVehicles() async {
    final immatriculations = await _fetchUserVehicles();
    if (immatriculations.isNotEmpty) {
      final first = immatriculations.first;
      setState(() {
        _selectedVehicleImmatriculation = first;
      });
      await _persistActiveImmatriculation(first);
    }
  }

  Future<void> _persistActiveImmatriculation(String? immat) async {
    if (immat == null || immat.isEmpty) return;
    await const FlutterSecureStorage().write(
      key: 'last_active_immatriculation',
      value: immat,
    );
  }

  void _checkVehicleSelection() {
    if (_selectedVehicleImmatriculation == null) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => VehiculeInfoForm()),
      ).then((_) => _loadUserVehicles());
    }
  }

  final ContextualNotificationService _notificationService =
      ContextualNotificationService();
  int _alertsCount = 0;
  /// Non lues dans [app_notifications] (dont décisions sur rendez-vous garages).
  int _inboxUnreadCount = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _checkVehicleSelection());
    _selectedVehicleImmatriculation = widget.immatriculation;
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _initNotificationService();
  }

  Future<void> _initNotificationService() async {
    await _notificationService.initialize();
    if (_selectedVehicleImmatriculation != null) {
      _checkContextualNotifications();
      await _persistActiveImmatriculation(_selectedVehicleImmatriculation);
    }
    await _refreshInboxUnreadCount();
  }

  Future<void> _refreshInboxUnreadCount() async {
    try {
      final n = await NotificationManager().getUnreadNotificationsCount();
      if (mounted) setState(() => _inboxUnreadCount = n);
    } catch (_) {}
  }

  Future<void> _checkContextualNotifications() async {
    if (_selectedVehicleImmatriculation == null) return;
    final notificationsCount =
        await _notificationService.checkMaintenanceForActiveVehicle(
      immatriculation: _selectedVehicleImmatriculation!,
      context: context,
    );
    setState(() => _alertsCount = notificationsCount);
    debugPrint(
        'ℹ️ Notifications pour $_selectedVehicleImmatriculation: $notificationsCount alerte(s)');
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    ScreenUtil.init(context, designSize: const Size(375, 812));

    return Scaffold(
      backgroundColor: _kBg,
      appBar: _selectedIndex == 6 ? null : _buildAppBar(),
      body: _getCurrentPage(size),
      bottomNavigationBar: _buildBottomAppBar(
        _selectedIndex,
        (index) => setState(() => _selectedIndex = index),
      ),
      floatingActionButton: null,
    );
  }

  Widget _getCurrentPage(Size size) {
    switch (_selectedIndex) {
      case 0:
        return SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(16.w, 16.w, 16.w, 24.w),
          child: Column(
            children: [
              _buildVehicleSelector(),
              SizedBox(height: 20.h),
              _buildHealthStatusCard(),
              SizedBox(height: 20.h),
              _buildCarHealthChart(size),
              SizedBox(height: 20.h),
              _buildMaintenanceTimeline(),
              SizedBox(height: 20.h),
              _buildRecommendationsSection(),
            ],
          ),
        );
      case 1:
        return Categorie(immatriculation: _selectedVehicleImmatriculation!);
      case 2:
        return _navigateToFinancialAssistant();
      case 3:
        return _navigateToMechanicAssistant();
      case 4:
        return Profilecleint(
          immatriculation: _selectedVehicleImmatriculation!,
          initialData: {},
        );
      case 5:
        return SettingsScreen();
      case 6:
        return GarageListScreen(
          immatriculation: _selectedVehicleImmatriculation!,
        );
      default:
        return Center(
          child: Text(
            'Page non trouvée',
            style: GoogleFonts.poppins(
              fontSize: 16.sp,
              color: _kTextSecondary,
            ),
          ),
        );
    }
  }

  // ─── APP BAR ──────────────────────────────────────────────────────────────────

  AppBar _buildAppBar() {
    final hubBadge = _alertsCount + _inboxUnreadCount;
    return AppBar(
      elevation: 0,
      title: Text(
        'Tableau de bord',
        style: GoogleFonts.poppins(
          color: Colors.white,
          fontWeight: FontWeight.w700,
          fontSize: 18.sp,
          letterSpacing: 0.3,
        ),
      ),
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [_kBlue1, _kBlue2, _kBlue3],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      ),
      backgroundColor: _kBlue2,
      actions: [
        // Notification bell with badge
        Stack(
          children: [
            IconButton(
              icon: const Icon(Icons.notifications_rounded,
                  color: Colors.white, size: 22),
              tooltip: 'Notifications et rendez-vous',
              onPressed: _navigateToClientAlertsHub,
            ),
            if (hubBadge > 0)
              Positioned(
                right: 8,
                top: 8,
                child: Container(
                  constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: const BoxDecoration(
                    color: _kDanger,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      hubBadge > 99 ? '99+' : '$hubBadge',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
        // AI Assistant
        IconButton(
          icon: const Icon(Icons.smart_toy_rounded,
              color: Colors.white, size: 22),
          tooltip: 'Assistant IA',
          onPressed: () => setState(() => _selectedIndex = 3),
        ),
        // Refresh
        IconButton(
          icon:
              const Icon(Icons.refresh_rounded, color: Colors.white, size: 22),
          tooltip: 'Rafraîchir',
          onPressed: () {
            _checkContextualNotifications();
            _refreshInboxUnreadCount();
            _fetchVehicleInfo();
            _fetchPredictions();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Row(
                  children: [
                    Icon(Icons.sync_rounded, color: Colors.white, size: 16),
                    SizedBox(width: 8),
                    Text('Rafraîchissement en cours…'),
                  ],
                ),
                backgroundColor: _kBlue2,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                margin: const EdgeInsets.all(16),
                duration: const Duration(seconds: 1),
              ),
            );
          },
        ),
      ],
    );
  }

  // ─── VEHICLE SELECTOR ─────────────────────────────────────────────────────────

  Widget _buildVehicleSelector() {
    return FutureBuilder<List<String>>(
      future: _fetchUserVehicles(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: _kBlue2),
          );
        }
        if (snapshot.hasError) {
          return _buildErrorCard("Erreur de chargement des véhicules");
        }

        final immatriculations = snapshot.data ?? [];

        return Container(
          padding: EdgeInsets.all(14.w),
          decoration: BoxDecoration(
            color: _kSurface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _kBorder),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _kBlue2.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.directions_car_rounded,
                        color: _kBlue2, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Mes véhicules',
                    style: GoogleFonts.poppins(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w700,
                      color: _kTextPrimary,
                    ),
                  ),
                  const Spacer(),
                  _buildAddVehicleButton(),
                ],
              ),
              if (immatriculations.isEmpty)
                Padding(
                  padding: EdgeInsets.only(top: 12.h),
                  child: _buildInfoCard("Aucun véhicule enregistré"),
                ),
              if (immatriculations.isNotEmpty) ...[
                SizedBox(height: 12.h),
                Wrap(
                  spacing: 8.w,
                  runSpacing: 8.h,
                  children: immatriculations.map((immat) {
                    final isSelected = _selectedVehicleImmatriculation == immat;
                    return GestureDetector(
                      onTap: () {
                        setState(() => _selectedVehicleImmatriculation = immat);
                        _checkContextualNotifications();
                        _persistActiveImmatriculation(immat);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? _kBlue2.withOpacity(0.1)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: isSelected ? _kBlue2 : _kBorder,
                            width: isSelected ? 1.5 : 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (isSelected)
                              Container(
                                width: 7,
                                height: 7,
                                margin: const EdgeInsets.only(right: 6),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _kBlue2,
                                ),
                              ),
                            Text(
                              immat,
                              style: GoogleFonts.poppins(
                                fontSize: 13.sp,
                                fontWeight: isSelected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                                color: isSelected ? _kBlue2 : _kTextSecondary,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildAddVehicleButton() {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => VehiculeInfoForm()),
      ).then((_) => _loadUserVehicles()),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: _kSuccess.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _kSuccess.withOpacity(0.4)),
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.add_rounded, color: _kSuccess, size: 14),
            SizedBox(width: 4),
            Text(
              'Ajouter',
              style: TextStyle(
                color: _kSuccess,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── HEALTH STATUS CARD ───────────────────────────────────────────────────────

  Widget _buildHealthStatusCard() {
    return FutureBuilder<Map<String, dynamic>>(
      future: _fetchVehicleInfo(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Container(
            height: 60,
            alignment: Alignment.center,
            child: const CircularProgressIndicator(color: _kBlue2),
          );
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return _buildErrorCard(
              "Erreur de chargement des données du véhicule");
        }

        final vehicleData = snapshot.data!;

        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF0D5C8A), Color(0xFF127BBC), Color(0xFF1AA3D8)],
            ),
            boxShadow: [
              BoxShadow(
                color: _kBlue2.withOpacity(0.35),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 22.w, vertical: 24.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            vehicleData['marque'] ?? 'Véhicule',
                            style: GoogleFonts.poppins(
                              fontSize: 26.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 0.5,
                            ),
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            vehicleData['modele'] ?? 'Modèle inconnu',
                            style: GoogleFonts.poppins(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w500,
                              color: Colors.white70,
                            ),
                          ),
                          SizedBox(height: 10.h),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 5),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.18),
                              borderRadius: BorderRadius.circular(30),
                              border: Border.all(color: Colors.white24),
                            ),
                            child: Text(
                              _selectedVehicleImmatriculation ?? '',
                              style: GoogleFonts.poppins(
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 68.w,
                      height: 68.w,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white24, width: 1.5),
                      ),
                      child: Icon(
                        Icons.directions_car_filled_rounded,
                        color: Colors.white,
                        size: 34.sp,
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 22.h),

                // Detail chips row 1
                Row(
                  children: [
                    Expanded(
                      child: _buildVehicleDetailChip(
                        icon: Icons.calendar_today_rounded,
                        label: 'Année',
                        value: vehicleData['annee']?.toString() ?? 'N/A',
                      ),
                    ),
                    SizedBox(width: 10.w),
                    Expanded(
                      child: _buildVehicleDetailChip(
                        icon: Icons.palette_rounded,
                        label: 'Couleur',
                        value: vehicleData['couleur'] ?? 'N/A',
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 10.h),

                // Detail chips row 2
                _buildVehicleDetailChip(
                  icon: Icons.local_gas_station_rounded,
                  label: 'Carburant',
                  value: vehicleData['moteur'] ?? 'N/A',
                  fullWidth: true,
                ),

                SizedBox(height: 24.h),

                // Action buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildGlassButton(
                      icon: Icons.add_rounded,
                      label: 'Ajouter',
                      color: const Color(0xFF4CE3A0),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => VehiculeInfoForm()),
                      ),
                    ),
                    _buildGlassButton(
                      icon: Icons.edit_rounded,
                      label: 'Modifier',
                      color: const Color(0xFFFFA41B),
                      onTap: () => _handleVehicleEdit(context),
                    ),
                    _buildGlassButton(
                      icon: Icons.delete_rounded,
                      label: 'Supprimer',
                      color: const Color(0xFFFF5A5A),
                      onTap: () => _confirmVehicleDeletion(context),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildVehicleDetailChip({
    required IconData icon,
    required String label,
    required String value,
    bool fullWidth = false,
  }) {
    return Container(
      width: fullWidth ? double.infinity : null,
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.14),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        mainAxisSize: fullWidth ? MainAxisSize.max : MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Colors.white, size: 16.sp),
          ),
          SizedBox(width: 10.w),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 11.sp,
                  color: Colors.white70,
                ),
              ),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 13.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGlassButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      splashColor: color.withOpacity(0.2),
      highlightColor: Colors.transparent,
      child: Column(
        children: [
          Container(
            width: 50.w,
            height: 50.w,
            decoration: BoxDecoration(
              color: color.withOpacity(0.18),
              shape: BoxShape.circle,
              border: Border.all(color: color.withOpacity(0.5), width: 1.5),
            ),
            child: Icon(icon, color: color, size: 22.sp),
          ),
          SizedBox(height: 8.h),
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
              color: Colors.white.withOpacity(0.9),
            ),
          ),
        ],
      ),
    );
  }

  // ─── HEALTH CHART ─────────────────────────────────────────────────────────────

  Widget _buildCarHealthChart(Size size) {
    return Container(
      decoration: BoxDecoration(
        color: _kSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: EdgeInsets.all(18.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _kPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.auto_graph_rounded,
                    color: _kPurple, size: 18.sp),
              ),
              SizedBox(width: 10.w),
              Text(
                'Santé globale du véhicule',
                style: GoogleFonts.poppins(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w700,
                  color: _kTextPrimary,
                ),
              ),
            ],
          ),
          SizedBox(height: 18.h),
          FutureBuilder<Map<String, dynamic>>(
            future: _fetchPredictions(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return SizedBox(
                  height: size.width / 5,
                  child: const Center(
                    child: CircularProgressIndicator(color: _kBlue2),
                  ),
                );
              }
              if (snapshot.hasError || !snapshot.hasData) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline_rounded,
                          color: _kDanger, size: 36),
                      SizedBox(height: 8.h),
                      Text('Données non disponibles',
                          style: GoogleFonts.poppins(
                              color: _kTextSecondary, fontSize: 13.sp)),
                    ],
                  ),
                );
              }

              final predictions = snapshot.data!;
              final Map<String, double> componentWear = {
                'Huile': (predictions['oil_change'] as num?)?.toDouble() ?? 0.0,
                'Pneus': (predictions['tire_wear'] as num?)?.toDouble() ?? 0.0,
                'Freins':
                    (predictions['brake_wear'] as num?)?.toDouble() ?? 0.0,
                'Courroie':
                    (predictions['belt_risk'] as num?)?.toDouble() ?? 0.0,
                'Embrayage':
                    (predictions['clutch_wear'] as num?)?.toDouble() ?? 0.0,
                'Suspension':
                    (predictions['suspension_wear'] as num?)?.toDouble() ?? 0.0,
                'Batterie':
                    (predictions['battery_health'] as num?)?.toDouble() ?? 0.0,
              };

              final totalWear = componentWear.values.reduce((a, b) => a + b) /
                  componentWear.length;
              final healthPercentage = 100 - totalWear;

              final healthHistory = [
                FlSpot(0, (healthPercentage - 5).clamp(0, 100)),
                FlSpot(1, (healthPercentage - 3).clamp(0, 100)),
                FlSpot(2, (healthPercentage - 1).clamp(0, 100)),
                FlSpot(3, healthPercentage),
              ];
              final futurePrediction = [
                FlSpot(3, healthPercentage),
                FlSpot(4, (healthPercentage - 2).clamp(0, 100)),
                FlSpot(5, (healthPercentage - 4).clamp(0, 100)),
                FlSpot(6, (healthPercentage - 6).clamp(0, 100)),
              ];

              final status = _getMaintenanceStatus(totalWear);
              final healthColor = _getHealthColor(healthPercentage);
              final gradientColors = [
                healthColor.withOpacity(0.8),
                healthColor.withOpacity(0.2),
              ];

              return Column(
                children: [
                  Container(
                    height: 200.h,
                    padding:
                        EdgeInsets.only(right: 20.w, top: 16.h, bottom: 12.h),
                    child: LineChart(
                      LineChartData(
                        gridData: FlGridData(
                          show: true,
                          drawVerticalLine: true,
                          horizontalInterval: 20,
                          verticalInterval: 1,
                          getDrawingHorizontalLine: (value) => FlLine(
                            color: const Color(0xFFEAEEF4),
                            strokeWidth: 1,
                            dashArray: [5, 5],
                          ),
                          getDrawingVerticalLine: (value) => FlLine(
                            color: const Color(0xFFEAEEF4),
                            strokeWidth: 1,
                            dashArray: [5, 5],
                          ),
                        ),
                        titlesData: FlTitlesData(
                          show: true,
                          topTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: false)),
                          rightTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: false)),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 30,
                              interval: 1,
                              getTitlesWidget: (value, meta) {
                                const labels = {
                                  0: '3m',
                                  1: '2m',
                                  2: '1m',
                                  3: 'Auj',
                                  4: '1m',
                                  5: '2m',
                                  6: '3m',
                                };
                                final text = labels[value.toInt()] ?? '';
                                return Padding(
                                  padding: EdgeInsets.only(top: 8.h),
                                  child: Text(
                                    text,
                                    style: GoogleFonts.poppins(
                                      fontSize: 10.sp,
                                      color: value.toInt() == 3
                                          ? _kBlue2
                                          : _kTextSecondary,
                                      fontWeight: value.toInt() == 3
                                          ? FontWeight.w700
                                          : FontWeight.normal,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 38,
                              interval: 20,
                              getTitlesWidget: (value, meta) {
                                return Padding(
                                  padding: EdgeInsets.only(right: 8.w),
                                  child: Text(
                                    '${value.toInt()}%',
                                    style: GoogleFonts.poppins(
                                      fontSize: 10.sp,
                                      color: _kTextSecondary,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                        borderData: FlBorderData(
                          show: true,
                          border: Border.all(color: _kBorder, width: 1),
                        ),
                        minX: 0,
                        maxX: 6,
                        minY: 0,
                        maxY: 100,
                        lineTouchData: LineTouchData(
                          touchTooltipData: LineTouchTooltipData(
                            getTooltipColor: (spot) => const Color(0xFF1A2340),
                            getTooltipItems:
                                (List<LineBarSpot> touchedBarSpots) {
                              return touchedBarSpots.map((barSpot) {
                                final isHistory = barSpot.x <= 3;
                                return LineTooltipItem(
                                  '${isHistory ? 'Historique' : 'Prévision'}: ${barSpot.y.toStringAsFixed(1)}%',
                                  GoogleFonts.poppins(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12.sp,
                                  ),
                                );
                              }).toList();
                            },
                          ),
                        ),
                        lineBarsData: [
                          LineChartBarData(
                            spots: healthHistory,
                            isCurved: true,
                            color: healthColor,
                            barWidth: 3,
                            isStrokeCapRound: true,
                            dotData: FlDotData(
                              show: true,
                              getDotPainter: (spot, percent, barData, index) =>
                                  FlDotCirclePainter(
                                radius: 4,
                                color: healthColor,
                                strokeWidth: 2,
                                strokeColor: Colors.white,
                              ),
                            ),
                            belowBarData: BarAreaData(
                              show: true,
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: gradientColors,
                              ),
                            ),
                          ),
                          LineChartBarData(
                            spots: futurePrediction,
                            isCurved: true,
                            color: healthColor.withOpacity(0.5),
                            barWidth: 2,
                            isStrokeCapRound: true,
                            dashArray: [6, 4],
                            dotData: const FlDotData(show: false),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 8.h),
                  // Health summary chips
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildChartLegendItem(healthColor, 'Historique',
                          solid: true),
                      _buildChartLegendItem(
                          healthColor.withOpacity(0.5), 'Prévision',
                          solid: false),
                      _buildHealthScoreChip(healthPercentage, status),
                    ],
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildChartLegendItem(Color color, String label,
      {required bool solid}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 20,
          height: 3,
          decoration: BoxDecoration(
            color: solid ? color : Colors.transparent,
            border: solid ? null : Border.all(color: color),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: GoogleFonts.poppins(fontSize: 11.sp, color: _kTextSecondary),
        ),
      ],
    );
  }

  Widget _buildHealthScoreChip(double healthPct, Map<String, dynamic> status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: (status['color'] as Color).withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: (status['color'] as Color).withOpacity(0.4)),
      ),
      child: Text(
        '${healthPct.toStringAsFixed(1)}% — ${status['message']}',
        style: GoogleFonts.poppins(
          fontSize: 11.sp,
          fontWeight: FontWeight.w600,
          color: status['color'],
        ),
      ),
    );
  }

  // ─── MAINTENANCE TIMELINE ─────────────────────────────────────────────────────

  Widget _buildMaintenanceTimeline() {
    return FutureBuilder<Map<String, dynamic>>(
      future: _fetchPredictions(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: _kBlue2));
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return _buildErrorCard('Données de prédiction non disponibles');
        }

        WidgetsBinding.instance
            .addPostFrameCallback((_) => _saveAllMaintenanceDates());

        final predictions = snapshot.data!;
        final maintenanceItems = _processPredictions(predictions);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(
              icon: Icons.calendar_month_rounded,
              title: 'Calendrier de maintenance',
            ),
            SizedBox(height: 12.h),
            ...maintenanceItems.map((item) => _buildTimelineItem(item)),
          ],
        );
      },
    );
  }

  Widget _buildSectionHeader({required IconData icon, required String title}) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 20,
          decoration: BoxDecoration(
            color: _kBlue2,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Icon(icon, color: _kBlue2, size: 18.sp),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 16.sp,
            fontWeight: FontWeight.w700,
            color: _kTextPrimary,
          ),
        ),
      ],
    );
  }

  Widget _buildTimelineItem(Map<String, dynamic> item) {
    final status = _getMaintenanceStatus(item['value']);
    final String componentTitle = item['title'] as String;
    final String componentKey = _getComponentKey(componentTitle);
    final Color itemColor = item['color'] as Color;
    final Color statusColor = status['color'] as Color;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: _kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: Colors.transparent,
        ),
        child: ExpansionTile(
          tilePadding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 4.h),
          leading: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: itemColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(item['icon'] as IconData, color: itemColor, size: 22),
          ),
          title: Text(
            componentTitle,
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w700,
              fontSize: 14.sp,
              color: _kTextPrimary,
            ),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      status['message'] as String,
                      style: GoogleFonts.poppins(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w600,
                        color: statusColor,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '${(item['value'] as double?)?.toStringAsFixed(1) ?? '0.0'}%',
                    style: GoogleFonts.poppins(
                      fontSize: 11.sp,
                      color: _kTextSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 6.h),
              Text(
                'Prévu: ${DateFormat('dd/MM/yyyy').format(item['date'] as DateTime)}',
                style: GoogleFonts.poppins(
                  fontSize: 11.sp,
                  color: _kTextSecondary,
                ),
              ),
              SizedBox(height: 6.h),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: ((item['value'] as double?) ?? 0) / 100,
                  backgroundColor: const Color(0xFFEAEEF4),
                  color: statusColor,
                  minHeight: 5,
                ),
              ),
            ],
          ),
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 4.h, 14.w, 14.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildTimelineActionBtn(
                    icon: Icons.check_circle_outline_rounded,
                    label: 'Valider',
                    color: _kSuccess,
                    onTap: () => _confirmMaintenanceCompletion(
                        componentKey, componentTitle),
                  ),
                  _buildTimelineActionBtn(
                    icon: Icons.history_rounded,
                    label: "Historique",
                    color: _kBlue2,
                    onTap: () =>
                        _viewMaintenanceHistory(componentKey, componentTitle),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimelineActionBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 15),
            const SizedBox(width: 6),
            Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 12.sp,
                color: color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── RECOMMENDATIONS SECTION ──────────────────────────────────────────────────

  Widget _buildRecommendationsSection() {
    return FutureBuilder<Map<String, dynamic>>(
      future: _fetchPredictions(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: _kBlue2));
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return _buildErrorCard('Données de recommandations non disponibles');
        }

        final predictions = snapshot.data!;
        final componentWear = {
          'huile': {
            'value': (predictions['oil_change'] as num?)?.toDouble() ?? 0.0,
            'title': 'Vidange moteur',
            'icon': Icons.oil_barrel_rounded,
          },
          'pneus': {
            'value': (predictions['tire_wear'] as num?)?.toDouble() ?? 0.0,
            'title': 'Pneus',
            'icon': Icons.tire_repair_rounded,
          },
          'freins': {
            'value': (predictions['brake_wear'] as num?)?.toDouble() ?? 0.0,
            'title': 'Système de freinage',
            'icon': Icons.report_problem_rounded,
          },
          'courroie': {
            'value': (predictions['belt_risk'] as num?)?.toDouble() ?? 0.0,
            'title': 'Courroie de distribution',
            'icon': Icons.settings_applications_rounded,
          },
          'embrayage': {
            'value': (predictions['clutch_wear'] as num?)?.toDouble() ?? 0.0,
            'title': 'Embrayage',
            'icon': Icons.settings_input_component_rounded,
          },
          'amortisseurs': {
            'value':
                (predictions['suspension_wear'] as num?)?.toDouble() ?? 0.0,
            'title': 'Amortisseurs',
            'icon': Icons.shield_rounded,
          },
          'batterie': {
            'value': (predictions['battery_health'] as num?)?.toDouble() ?? 0.0,
            'title': 'Batterie',
            'icon': Icons.battery_charging_full_rounded,
          },
        };

        final componentsToShow = componentWear.entries
            .where((e) => ((e.value['value'] as double?) ?? 0) > 40)
            .toList()
          ..sort((a, b) => (b.value['value'] as double)
              .compareTo(a.value['value'] as double));

        return Container(
          decoration: BoxDecoration(
            color: _kSurface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _kBorder),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          padding: EdgeInsets.all(18.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionHeader(
                icon: Icons.recommend_rounded,
                title: "Conseils d'entretien",
              ),
              SizedBox(height: 16.h),
              if (componentsToShow.isEmpty)
                _buildInfoCard(
                    'Toutes les pièces sont en bon état. Continuez votre bon entretien!'),
              ...componentsToShow.map((component) {
                return _buildDetailedRecommendationCard(
                  component.key,
                  component.value['title'] as String,
                  component.value['icon'] as IconData,
                  component.value['value'] as double,
                );
              }),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDetailedRecommendationCard(
    String componentKey,
    String title,
    IconData icon,
    double wearValue,
  ) {
    final status = _getMaintenanceStatus(wearValue);
    final recommendations =
        _getRecommendationsForComponent(componentKey, wearValue);
    final statusColor = status['color'] as Color;

    return Container(
      margin: EdgeInsets.symmetric(vertical: 6.h),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFBFD),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _kBorder),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 2.h),
          leading: Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: statusColor, size: 18.sp),
          ),
          title: Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: _kTextPrimary,
            ),
          ),
          subtitle: Padding(
            padding: EdgeInsets.only(top: 4.h, bottom: 2.h),
            child: Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: wearValue / 100,
                      backgroundColor: const Color(0xFFEAEEF4),
                      color: statusColor,
                      minHeight: 4,
                    ),
                  ),
                ),
                SizedBox(width: 8.w),
                Text(
                  '${wearValue.toStringAsFixed(1)}%',
                  style: GoogleFonts.poppins(
                    fontSize: 11.sp,
                    color: statusColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 14.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      'État: ${status['message']}',
                      style: GoogleFonts.poppins(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w600,
                        color: statusColor,
                      ),
                    ),
                  ),
                  SizedBox(height: 10.h),
                  Text(
                    'Conseils:',
                    style: GoogleFonts.poppins(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w700,
                      color: _kTextPrimary,
                    ),
                  ),
                  SizedBox(height: 6.h),
                  ...recommendations.map((rec) {
                    return Padding(
                      padding: EdgeInsets.only(bottom: 7.h),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(top: 4),
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _kPurple.withOpacity(0.7),
                            ),
                          ),
                          SizedBox(width: 8.w),
                          Expanded(
                            child: Text(
                              rec,
                              style: GoogleFonts.poppins(
                                fontSize: 12.sp,
                                color: _kTextSecondary,
                                height: 1.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BOTTOM NAVIGATION ────────────────────────────────────────────────────────

  Widget _buildBottomAppBar(int selectedIndex, Function(int) onTap) {
    return Container(
      decoration: const BoxDecoration(
        color: _kSurface,
        border: Border(top: BorderSide(color: _kBorder, width: 0.5)),
        boxShadow: [],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildBottomNavItem(
                icon: Icons.home_rounded,
                label: 'Accueil',
                index: 0,
                selectedIndex: selectedIndex,
                onTap: onTap,
              ),
              _buildBottomNavItem(
                icon: Icons.store_rounded,
                label: 'Magasin',
                index: 1,
                selectedIndex: selectedIndex,
                onTap: onTap,
              ),
              _buildBottomNavItem(
                icon: Icons.account_balance_wallet_rounded,
                label: 'Finances',
                index: 2,
                selectedIndex: selectedIndex,
                onTap: onTap,
              ),
              _buildBottomNavItem(
                icon: Icons.person_rounded,
                label: 'Profil',
                index: 4,
                selectedIndex: selectedIndex,
                onTap: onTap,
              ),
              _buildBottomNavItem(
                icon: Icons.settings_rounded,
                label: 'Paramètres',
                index: 5,
                selectedIndex: selectedIndex,
                onTap: onTap,
              ),
              _buildBottomNavItem(
                icon: Icons.car_repair_rounded,
                label: 'Garages',
                index: 6,
                selectedIndex: selectedIndex,
                onTap: onTap,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNavItem({
    required IconData icon,
    required String label,
    required int index,
    required int selectedIndex,
    required Function(int) onTap,
  }) {
    final bool isSelected = index == selectedIndex;
    return GestureDetector(
      onTap: () => onTap(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? _kBlue2.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedScale(
              scale: isSelected ? 1.1 : 1.0,
              duration: const Duration(milliseconds: 200),
              child: Icon(
                icon,
                size: 22,
                color: isSelected ? _kBlue2 : _kTextSecondary,
              ),
            ),
            const SizedBox(height: 4),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 200),
              style: GoogleFonts.poppins(
                fontSize: 10,
                color: isSelected ? _kBlue2 : _kTextSecondary,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
              ),
              child: Text(label),
            ),
          ],
        ),
      ),
    );
  }

  // ─── UTILITY UI WIDGETS ───────────────────────────────────────────────────────

  Widget _buildErrorCard(String message) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kDanger.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kDanger.withOpacity(0.25)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: _kDanger, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: GoogleFonts.poppins(fontSize: 12.sp, color: _kDanger),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(String message) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kBlue2.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kBlue2.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline_rounded, color: _kBlue2, size: 18),
          SizedBox(width: 10.w),
          Expanded(
            child: Text(
              message,
              style: GoogleFonts.poppins(fontSize: 12.sp, color: _kBlue2),
            ),
          ),
        ],
      ),
    );
  }

  // ─── ALL LOGIC METHODS PRESERVED VERBATIM ────────────────────────────────────

  Color _getHealthColor(double healthPercentage) {
    if (healthPercentage > 75) return _kSuccess;
    if (healthPercentage > 50) return _kWarning;
    return _kDanger;
  }

  Map<String, dynamic> _getMaintenanceStatus(double? value) {
    if (value == null) {
      return {'message': 'Données non disponibles', 'color': Colors.grey};
    }
    if (value > 90) return {'message': 'Urgent 🔴', 'color': Colors.red};
    if (value > 75) {
      return {'message': 'Avertissement 🟠', 'color': Colors.orange};
    }
    if (value > 50) {
      return {'message': 'Bientôt requis 🟡', 'color': Colors.amber};
    }
    return {'message': 'Bon état 🟢', 'color': Colors.green};
  }

  String _getComponentKey(String componentTitle) {
    final Map<String, String> titleToKey = {
      'Vidange': 'vidange',
      'Pneus': 'pneus',
      'Freins': 'freins',
      'Embrayage': 'embrayage',
      'Courroie de distribution': 'courroie',
      'Les amortisseurs': 'amortisseurs',
      'La Batterie': 'batterie',
    };
    return titleToKey[componentTitle] ?? componentTitle.toLowerCase();
  }

  List<String> _getRecommendationsForComponent(
      String componentKey, double wearValue) {
    switch (componentKey) {
      case 'huile':
        if (wearValue > 75) {
          return [
            'Effectuez une vidange immédiatement.',
            'Vérifiez le niveau d\'huile quotidiennement.',
            'Évitez les longs trajets avant la vidange.',
            'Faites vérifier les joints d\'étanchéité.',
          ];
        } else if (wearValue > 50) {
          return [
            'Planifiez une vidange dans les prochaines semaines.',
            'Vérifiez le niveau d\'huile hebdomadairement.',
            'Contrôlez la couleur de l\'huile sur la jauge.',
            'Faites inspecter les filtres lors de la vidange.',
          ];
        } else {
          return [
            'Respectez les intervalles de vidange recommandés.',
            'Vérifiez le niveau d\'huile mensuellement.',
            'Utilisez une huile adaptée à votre moteur.',
            'Contrôlez les fuites d\'huile visuellement.',
          ];
        }
      case 'pneus':
        if (wearValue > 75) {
          return [
            'Remplacez les pneus immédiatement pour votre sécurité.',
            'Réduisez votre vitesse et évitez l\'autoroute.',
            'Vérifiez la pression des pneus chaque jour.',
            'Gardez un pneu de secours disponible.',
          ];
        } else if (wearValue > 50) {
          return [
            'Planifiez le remplacement des pneus rapidement.',
            'Faites contrôler l\'équilibrage et le parallélisme.',
            'Vérifiez la pression hebdomadairement.',
            'Évitez les routes avec graviers ou nids-de-poule.',
          ];
        } else {
          return [
            'Vérifiez la pression des pneus toutes les 2 semaines.',
            'Faites une rotation des pneus tous les 10 000 km.',
            'Évitez les démarrages et freinages brusques.',
            'Contrôlez l\'usure régulièrement.',
          ];
        }
      case 'freins':
        if (wearValue > 75) {
          return [
            'Faites inspecter les freins immédiatement.',
            'Évitez les vitesses élevées et freinages brusques.',
            'Prévoyez des distances de freinage plus longues.',
            'Remplacez les plaquettes et disques d\'urgence.',
          ];
        } else if (wearValue > 50) {
          return [
            'Planifiez le remplacement des plaquettes.',
            'Faites vérifier l\'épaisseur des disques.',
            'Contrôlez le niveau du liquide de frein.',
            'Évitez les freinages d\'urgence répétitifs.',
          ];
        } else {
          return [
            'Vérifiez le niveau du liquide de frein mensuellement.',
            'Faites inspecter les freins chaque 20 000 km.',
            'Adoptez une conduite anticipative pour préserver les freins.',
            'Contrôlez les bruits lors du freinage.',
          ];
        }
      case 'amortisseurs':
        if (wearValue > 75) {
          return [
            'Programmez le remplacement des amortisseurs dès que possible.',
            'Réduisez votre vitesse sur les routes irrégulières.',
            'Évitez les charges trop importantes.',
            'Soyez attentif aux bruits lors des bosses.',
          ];
        } else if (wearValue > 50) {
          return [
            'Faites inspecter les amortisseurs lors de votre prochain entretien.',
            'Évitez les routes en mauvais état.',
            'Répartissez uniformément les charges.',
            'Ajustez votre conduite.',
          ];
        } else {
          return [
            'Contrôle visuel des amortisseurs tous les 20 000 km.',
            'Vérifiez l\'absence de fuites d\'huile.',
            'Maintenez la pression correcte des pneus.',
            'Adoptez une conduite souple.',
          ];
        }
      case 'embrayage':
        if (wearValue > 75) {
          return [
            'Programmez rapidement le remplacement de l\'embrayage.',
            'Évitez les démarrages en côte.',
            'Limitez les accélérations brusques.',
            'Ne laissez pas votre pied reposer sur la pédale.',
          ];
        } else if (wearValue > 50) {
          return [
            'Surveillez les signes d\'usure: patinage, friction haute, bruits.',
            'Utilisez le frein à main en côte.',
            'Évitez la demi-pédale trop longtemps.',
            'Vérifiez le liquide d\'embrayage.',
          ];
        } else {
          return [
            'Adoptez une conduite souple.',
            'Passez les vitesses avec précision.',
            'Ne reposez jamais le pied sur la pédale.',
            'Réduisez la charge du véhicule.',
          ];
        }
      case 'courroie':
        if (wearValue > 75) {
          return [
            'Remplacement immédiat de la courroie de distribution.',
            'Évitez les longs trajets et conditions difficiles.',
            'Soyez attentif aux bruits inhabituels du moteur.',
            'Vérifiez l\'absence de fuites d\'huile.',
          ];
        } else if (wearValue > 50) {
          return [
            'Programmez un remplacement préventif.',
            'Faites inspecter la courroie lors du prochain entretien.',
            'Vérifiez la tension si applicable.',
            'Maintenez le compartiment moteur propre.',
          ];
        } else {
          return [
            'Respectez l\'intervalle de remplacement constructeur.',
            'Contrôlez l\'absence de craquelures ou effilochage.',
            'Évitez les démarrages à très froid.',
            'Vérifiez que les galets et pompe fonctionnent.',
          ];
        }
      default:
        return [
          'Suivez les recommandations du manuel de votre véhicule.',
          'Effectuez les entretiens réguliers chez un professionnel.',
          'Soyez attentif aux signes d\'usure ou bruits anormaux.',
        ];
    }
  }

  // ─── ALL DATA / NAVIGATION METHODS PRESERVED ─────────────────────────────────

  void _handleVehicleEdit(BuildContext context) async {
    if (_selectedVehicleImmatriculation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aucun véhicule sélectionné')),
      );
      return;
    }
    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) =>
            const Center(child: CircularProgressIndicator()),
      );
      final response = await Supabase.instance.client
          .from('voiture')
          .select()
          .eq('immatriculation', _selectedVehicleImmatriculation!)
          .single();
      Navigator.pop(context);
      final vehicleData = Map<String, dynamic>.from(response);
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => VehiculeInfoForm(
            immatriculation: _selectedVehicleImmatriculation!,
            initialData: vehicleData,
          ),
        ),
      );
      if (result == true) {
        setState(() {});
        _fetchVehicleInfo();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Véhicule modifié avec succès')),
        );
      }
    } catch (e) {
      debugPrint("Erreur lors de la modification: $e");
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Erreur de chargement: $e')));
    }
  }

  Future<void> _deleteVehicle() async {
    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(child: CircularProgressIndicator()),
      );
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Aucun utilisateur connecté')));
        return;
      }
      await Supabase.instance.client
          .from('maintenance_history')
          .delete()
          .eq('fk_immatriculation', _selectedVehicleImmatriculation!);
      await Supabase.instance.client
          .from('maintenance_dates')
          .delete()
          .eq('fk_immatriculation', _selectedVehicleImmatriculation!);
      await Supabase.instance.client
          .from('predictions')
          .delete()
          .eq('fk_immatriculation', _selectedVehicleImmatriculation!);
      await Supabase.instance.client.from('user_vehicles').delete().match({
        'user_id': user.id,
        'immatriculation': _selectedVehicleImmatriculation!,
      });
      await Supabase.instance.client
          .from('voiture')
          .delete()
          .eq('immatriculation', _selectedVehicleImmatriculation!)
          .select();
      Navigator.pop(context);
      setState(() => _selectedVehicleImmatriculation = null);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Véhicule supprimé avec succès'),
          backgroundColor: Colors.green,
        ),
      );
      _loadUserVehicles();
    } catch (e) {
      if (Navigator.canPop(context)) Navigator.pop(context);
      debugPrint("Erreur de suppression: $e");
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur lors de la suppression: $e')));
    }
  }

  void _confirmVehicleDeletion(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text('Confirmer la suppression',
            style: GoogleFonts.poppins(fontWeight: FontWeight.w700)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Voulez-vous vraiment supprimer ce véhicule ?',
                style: GoogleFonts.poppins(fontSize: 13)),
            const SizedBox(height: 10),
            Text(
              'Toutes les données associées seront définitivement supprimées.',
              style: GoogleFonts.poppins(color: _kDanger, fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Annuler',
                style: GoogleFonts.poppins(color: _kTextSecondary)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _deleteVehicle();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _kDanger,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            child: Text('Supprimer', style: GoogleFonts.poppins(fontSize: 13)),
          ),
        ],
      ),
    );
  }

  Future<Map<String, dynamic>> _fetchVehicleInfo() async {
    try {
      final response = await Supabase.instance.client
          .from('voiture')
          .select()
          .eq('immatriculation', _selectedVehicleImmatriculation as Object)
          .single();
      return response;
    } catch (e) {
      debugPrint("Erreur de récupération des infos véhicule: $e");
      return {};
    }
  }

  Future<Map<String, dynamic>> _fetchPredictions() async {
    try {
      if (_selectedVehicleImmatriculation == null) return {};
      final response = await Supabase.instance.client
          .from('predictions')
          .select()
          .eq('fk_immatriculation', _selectedVehicleImmatriculation!)
          .single();
      return response;
    } catch (e) {
      debugPrint("Erreur de chargement des prédictions: $e");
      return {};
    }
  }

  Future<void> _saveAllMaintenanceDates() async {
    if (_selectedVehicleImmatriculation == null) return;
    final predictions = await _fetchPredictions();
    final now = DateTime.now();
    await DateManager.insertMaintenanceDates(
      immatriculation: _selectedVehicleImmatriculation!,
      batterie: DateManager.calculateNextDateBatterie(
          baseDate: now,
          percentage: predictions['battery_health'] ?? 0.0,
          maxValue: 80000),
      amortisseurs: DateManager.calculateNextDateAmourtisseurs(
          baseDate: now,
          percentage: predictions['ShockAbsorber_Wear'] ?? 0.0,
          maxValue: 50000),
      embrayage: DateManager.calculateNextDateEmbrayage(
          baseDate: now,
          percentage: predictions['clutch_wear'] ?? 0.0,
          maxValue: 60000),
      freins: DateManager.calculateNextDateFreins(
          baseDate: now,
          percentage: predictions['brake_wear'] ?? 0.0,
          maxValue: 40000.0),
      courroie: DateManager.calculateNextDateCourroie(
          baseDate: now,
          percentage: predictions['belt_risk'] ?? 0.0,
          maxValue: 100000),
      vidange: DateManager.calculateNextDateVidange(
        baseDate: now,
        percentage: predictions['oil_change'] ?? 0.0,
        maxValue: 15000,
      ),
    );
  }

  List<Map<String, dynamic>> _processPredictions(
      Map<String, dynamic> predictions) {
    final now = DateTime.now();
    return [
      {
        'title': 'Vidange',
        'value': (predictions['oil_change'] as num?)?.toDouble() ?? 0.0,
        'date': DateManager.calculateNextDateVidange(
          baseDate: now,
          percentage: (predictions['oil_change'] as num?)?.toDouble() ?? 0.0,
          maxValue: 15000,
        ),
        'icon': Icons.oil_barrel_rounded,
        'color': Colors.blue,
      },
      {
        'title': 'Pneus',
        'value': (predictions['tire_wear'] as num?)?.toDouble() ?? 0.0,
        'date': DateManager.calculateNextDatePneus(
          baseDate: now,
          percentage: (predictions['tire_wear'] as num?)?.toDouble() ?? 0.0,
          maxValue: 10000,
        ),
        'icon': Icons.tire_repair_rounded,
        'color': Colors.orange,
      },
      {
        'title': 'Freins',
        'value': (predictions['brake_wear'] as num?)?.toDouble() ?? 0.0,
        'date': DateManager.calculateNextDateFreins(
          baseDate: now,
          percentage: (predictions['brake_wear'] as num?)?.toDouble() ?? 0.0,
          maxValue: 10000,
        ),
        'icon': Icons.report_problem_rounded,
        'color': Colors.red,
      },
      {
        'title': 'Embrayage',
        'value': (predictions['clutch_wear'] as num?)?.toDouble() ?? 0.0,
        'date': DateManager.calculateNextDateEmbrayage(
          baseDate: now,
          percentage: (predictions['clutch_wear'] as num?)?.toDouble() ?? 0.0,
          maxValue: 10000,
        ),
        'icon': Icons.engineering_rounded,
        'color': Colors.purple,
      },
      {
        'title': 'Courroie de distribution',
        'value': (predictions['belt_risk'] as num?)?.toDouble() ?? 0.0,
        'date': DateManager.calculateNextDateCourroie(
          baseDate: now,
          percentage: (predictions['belt_risk'] as num?)?.toDouble() ?? 0.0,
          maxValue: 10000,
        ),
        'icon': Icons.settings_input_antenna_rounded,
        'color': Colors.pink,
      },
      {
        'title': 'Les amortisseurs',
        'value': (predictions['ShockAbsorber_Wear'] as num?)?.toDouble() ?? 0.0,
        'date': DateManager.calculateNextDateAmourtisseurs(
          baseDate: now,
          percentage:
              (predictions['ShockAbsorber_Wear'] as num?)?.toDouble() ?? 0.0,
          maxValue: 10000,
        ),
        'icon': Icons.shield_rounded,
        'color': Colors.teal,
      },
      {
        'title': 'La Batterie',
        'value': (predictions['battery_health'] as num?)?.toDouble() ?? 0.0,
        'date': DateManager.calculateNextDateBatterie(
          baseDate: now,
          percentage:
              (predictions['battery_health'] as num?)?.toDouble() ?? 0.0,
          maxValue: 80000,
        ),
        'icon': Icons.battery_charging_full_rounded,
        'color': Colors.green,
      },
    ];
  }

  void _confirmMaintenanceCompletion(
      String componentKey, String componentTitle) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text('Confirmer le changement',
            style: GoogleFonts.poppins(fontWeight: FontWeight.w700)),
        content: Text(
          'Confirmez-vous avoir effectué le changement de "$componentTitle" ?',
          style: GoogleFonts.poppins(fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Annuler',
                style: GoogleFonts.poppins(color: _kTextSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _recordMaintenanceCompletion(componentKey);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _kSuccess,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            child: Text('Confirmer', style: GoogleFonts.poppins(fontSize: 13)),
          ),
        ],
      ),
    );
  }

  Future<void> _recordMaintenanceCompletion(String componentKey) async {
    try {
      if (_selectedVehicleImmatriculation == null) return;
      final now = DateTime.now();
      final columnName = 'changement_$componentKey';
      await Supabase.instance.client
          .from('maintenance_dates')
          .update({columnName: now.toIso8601String()}).eq(
              'fk_immatriculation', _selectedVehicleImmatriculation!);
      await Supabase.instance.client.from('maintenance_history').insert({
        'fk_immatriculation': _selectedVehicleImmatriculation,
        'component': componentKey,
        'date': now.toIso8601String(),
        'note': 'Changement effectué',
      });
      final Map<String, String> componentToPredictionKey = {
        'vidange': 'oil_change',
        'pneus': 'tire_wear',
        'freins': 'brake_wear',
        'embrayage': 'clutch_wear',
        'courroie': 'belt_risk',
        'amortisseurs': 'ShockAbsorber_Wear',
        'batterie': 'battery_health',
      };
      final predictionKey = componentToPredictionKey[componentKey];
      if (predictionKey != null) {
        await Supabase.instance.client.from('predictions').upsert({
          'fk_immatriculation': _selectedVehicleImmatriculation!,
          predictionKey: 0.0,
          'updated_at': now.toIso8601String(),
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Maintenance enregistrée! Usure réinitialisée.'),
          backgroundColor: _kSuccess,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ),
      );
      setState(() {});
    } catch (e) {
      debugPrint('Erreur lors de l\'enregistrement de la maintenance: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors de l\'enregistrement: ${e.toString()}'),
          backgroundColor: _kDanger,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ),
      );
    }
  }

  void _viewMaintenanceHistory(String componentKey, String componentTitle) {
    showDialog(
      context: context,
      builder: (context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: _fetchMaintenanceHistory(componentKey),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
              title: Text('Historique - $componentTitle',
                  style: GoogleFonts.poppins(fontWeight: FontWeight.w700)),
              content: const SizedBox(
                height: 100,
                child: Center(child: CircularProgressIndicator(color: _kBlue2)),
              ),
            );
          }
          if (snapshot.hasError) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
              title: Text('Erreur',
                  style: GoogleFonts.poppins(fontWeight: FontWeight.w700)),
              content: Text("Impossible de charger l'historique",
                  style: GoogleFonts.poppins()),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('OK', style: GoogleFonts.poppins(color: _kBlue2)),
                ),
              ],
            );
          }
          final historyItems = snapshot.data ?? [];
          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            title: Text('Historique - $componentTitle',
                style: GoogleFonts.poppins(fontWeight: FontWeight.w700)),
            content: SizedBox(
              width: double.maxFinite,
              child: historyItems.isEmpty
                  ? Center(
                      child: Text('Aucun historique disponible',
                          style: GoogleFonts.poppins(color: _kTextSecondary)))
                  : ListView.separated(
                      shrinkWrap: true,
                      itemCount: historyItems.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final item = historyItems[index];
                        final date = DateTime.parse(item['date']);
                        return ListTile(
                          leading: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: _kBlue2.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.engineering_rounded,
                                color: _kBlue2, size: 16),
                          ),
                          title: Text(
                            DateFormat('dd/MM/yyyy à HH:mm').format(date),
                            style: GoogleFonts.poppins(
                                fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            item['note'] ?? 'Maintenance effectuée',
                            style: GoogleFonts.poppins(
                                fontSize: 12, color: _kTextSecondary),
                          ),
                        );
                      },
                    ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child:
                    Text('Fermer', style: GoogleFonts.poppins(color: _kBlue2)),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _fetchMaintenanceHistory(
      String componentKey) async {
    try {
      if (_selectedVehicleImmatriculation == null) return [];
      final response = await Supabase.instance.client
          .from('maintenance_history')
          .select()
          .eq('fk_immatriculation', _selectedVehicleImmatriculation!)
          .eq('component', componentKey)
          .order('date', ascending: false);
      return (response as List).cast<Map<String, dynamic>>();
    } catch (e) {
      debugPrint('Erreur lors du chargement de l\'historique: $e');
      return [];
    }
  }

  double _getMaxValueForComponent(String componentKey) {
    switch (componentKey) {
      case 'vidange':
        return 15000.0;
      case 'pneus':
        return 10000.0;
      case 'freins':
        return 40000.0;
      case 'embrayage':
        return 60000.0;
      case 'courroie':
        return 100000.0;
      case 'amortisseurs':
        return 50000.0;
      case 'batterie':
        return 80000.0;
      default:
        return 10000.0;
    }
  }

  Future<List<String>> _fetchUserVehicles() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) return [];
      final response = await Supabase.instance.client
          .from('user_vehicles')
          .select('immatriculation')
          .eq('user_id', user.id);
      return (response as List)
          .map((e) => e['immatriculation'] as String)
          .toList();
    } catch (e) {
      return [];
    }
  }

  void _navigateToClientAlertsHub() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ClientAlertsHubPage(
          vehicleImmatriculation: _selectedVehicleImmatriculation,
        ),
      ),
    ).then((_) {
      _checkContextualNotifications();
      _refreshInboxUnreadCount();
    });
  }

  Widget _navigateToFinancialAssistant() {
    return FutureBuilder(
      future: Future.delayed(const Duration(milliseconds: 1)),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          Future.microtask(() {
            Navigator.pushNamed(
              context,
              '/financialAssistant/dashboard',
              arguments: _selectedVehicleImmatriculation,
            );
          });
        }
        return const Center(child: CircularProgressIndicator(color: _kBlue2));
      },
    );
  }

  Widget _navigateToMechanicAssistant() {
    return FutureBuilder(
      future: Future.delayed(const Duration(milliseconds: 1)),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          Future.microtask(() {
            Navigator.pushNamed(
              context,
              '/mechanicAssistant/dashboard',
              arguments: _selectedVehicleImmatriculation,
            );
          });
        }
        return const Center(child: CircularProgressIndicator(color: _kBlue2));
      },
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}

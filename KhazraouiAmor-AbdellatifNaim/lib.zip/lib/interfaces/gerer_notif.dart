// Planification des notifications locales — logique préservée intégralement
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:carhabti/supabase_connexion.dart';
import 'package:timezone/timezone.dart' as tz;

/// Planifie une notification locale à la date de maintenance donnée.
Future<void> scheduleNotification(DateTime? date) async {
  if (date == null) return;

  final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  await flutterLocalNotificationsPlugin.zonedSchedule(
    0,
    'Maintenance requise',
    'Date de remplacement arrivée à échéance',
    tz.TZDateTime.from(date, tz.local),
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'maintenance_channel',
        'Alertes maintenance',
        importance: Importance.high,
      ),
    ),
    matchDateTimeComponents: DateTimeComponents.dayOfMonthAndTime,
    androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
  );
}

/// Gestionnaire de notifications reçues en arrière-plan.
@pragma('vm:entry-point')
Future<void> _handleBackgroundNotification(
    NotificationResponse response) async {
  await Firebase.initializeApp();
  _processNotification(response.payload!);
}

/// Met à jour le champ [notified] dans Supabase pour le composant concerné.
void _processNotification(String payload) {
  supabase
      .from('notifications')
      .update({'notified': true}).eq('component', payload.split('|')[0]);
}
// ignore_for_file: use_build_context_synchronously, unused_element, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/pieces_form/amortisseurs_form.dart';
import 'package:carhabti/pieces_form/courroie_form.dart';
import 'package:carhabti/pieces_form/embrayage_form.dart';
import 'package:carhabti/pieces_form/freins_form.dart';
import 'package:carhabti/pieces_form/batterie_form.dart';
import 'package:carhabti/pieces_form/vidange_form.dart';
import 'package:carhabti/pieces_form/pneus_form.dart';
import 'package:carhabti/prediction_dossier_dart/prediction.dart';

 final String immatriculation;

  ShowScreen({
    super.key,
    this.facteurData,
    required this.predictions,
    required this.immatriculation,
  });

  @override
  State<ShowScreen> createState() => _ShowScreenState();
}

class _ShowScreenState extends State<ShowScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _headerController;
  late Animation<double> _headerFade;

  bool get _isLoggedIn => Supabase.instance.client.auth.currentUser != null;

  bool get _hasFacteurData =>
      widget.facteurData != null && widget.facteurData!.isNotEmpty;

  @override
  void initState() {
    super.initState();
    _headerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _headerFade =
        CurvedAnimation(parent: _headerController, curve: Curves.easeOut);
    _headerController.forward();
  }

  @override
  void dispose() {
    _headerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FB),
      body: CustomScrollView(
        slivers: [
          _buildSliverAppBar(context),
          SliverToBoxAdapter(child: _buildStatusBanner()),
          SliverToBoxAdapter(child: const SizedBox(height: 8)),
          SliverFillRemaining(
            hasScrollBody: true,
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _categories,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: Color(0xFF127BBC)),
                  );
                } else if (snapshot.hasError) {
                  return _buildErrorState(snapshot.error.toString());
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return _buildEmptyState();
                }

                final list = snapshot.data!;
                return Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                        itemCount: list.length,
                        itemBuilder: (context, index) {
                          return _AnimatedCard(
                            index: index,
                            child: _buildCategoryCard(list[index], context),
                          );
                        },
                      ),
                    ),
                    _buildPredictionButton(context),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ─── SLIVER APP BAR ──────────────────────────────────────────────────────────

  Widget _buildSliverAppBar(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 160,
      pinned: true,
      elevation: 0,
      backgroundColor: const Color(0xFF127BBC),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded,
            color: Colors.white, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0D5C8A), Color(0xFF127BBC), Color(0xFF1AA3D8)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: SafeArea(
            child: FadeTransition(
              opacity: _headerFade,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 36),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(Icons.directions_car_rounded,
                              color: Colors.white, size: 26),
                        ),
                        const SizedBox(width: 14),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Tableau de bord',
                              style: TextStyle(
                                  color: Colors.white70,
                                  fontSize: 13,
                                  letterSpacing: 0.4),
                            ),
                            Text(
                              widget.immatriculation,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        _buildDataChip(),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        title: const Text(
          'Pièces du véhicule',
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17),
        ),
        centerTitle: false,
        titlePadding: const EdgeInsets.only(left: 56, bottom: 14),
      ),
    );
  }

  Widget _buildDataChip() {
    final count = _hasFacteurData ? widget.facteurData!.length : 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white30),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _hasFacteurData
                ? Icons.cloud_done_rounded
                : Icons.cloud_off_rounded,
            color: Colors.white,
            size: 14,
          ),
          const SizedBox(width: 6),
          Text(
            _hasFacteurData ? '$count données' : 'Hors ligne',
            style: const TextStyle(color: Colors.white, fontSize: 12),
          ),
        ],
      ),
    );
  }

  // ─── STATUS BANNER ───────────────────────────────────────────────────────────

  Widget _buildStatusBanner() {
    if (!_hasFacteurData) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFFE8F5E9),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFA5D6A7)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: const Color(0xFF43A047),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.check_rounded,
                  color: Colors.white, size: 14),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Données synchronisées. Accédez aux détails de chaque composant.',
                style: TextStyle(
                    color: Color(0xFF2E7D32), fontSize: 13, height: 1.4),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── CATEGORY CARD ───────────────────────────────────────────────────────────

  Widget _buildCategoryCard(
      Map<String, dynamic> category, BuildContext context) {
    final status = _resolveStatus(category['key'] as String?);
    final bool hasData = status != null;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFEAEEF4)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _navigateToForm(category['route'] as Widget, context),
          splashColor: (category['color'] as Color).withOpacity(0.08),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: (category['color'] as Color).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    category['icon'] as IconData,
                    color: category['color'] as Color,
                    size: 26,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        category['title'] as String,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1A2340),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        category['subtitle'] as String,
                        style: const TextStyle(
                            fontSize: 12.5, color: Color(0xFF8A94A6)),
                      ),
                      if (hasData) ...[
                        const SizedBox(height: 6),
                        _buildStatusPill(status, category['color'] as Color),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: hasData
                            ? const Color(0xFF43A047)
                            : const Color(0xFFBDBDBD),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Icon(Icons.chevron_right_rounded,
                        color: Color(0xFFB0BAC9), size: 22),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusPill(String text, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          color: accent.withOpacity(0.9),
          fontWeight: FontWeight.w600,
        ),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  // ─── PREDICTION BUTTON ───────────────────────────────────────────────────────

  Widget _buildPredictionButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  PredictionScreen(immatriculation: widget.immatriculation),
            ),
          );
        },
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF5E35B1), Color(0xFF1976D2)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF5E35B1).withOpacity(0.35),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.auto_graph_rounded, color: Colors.white, size: 20),
              SizedBox(width: 10),
              Text(
                'Voir les prédictions',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── EMPTY / ERROR STATES ─────────────────────────────────────────────────────

  Widget _buildErrorState(String error) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.wifi_off_rounded,
              color: Color(0xFFB0BAC9), size: 48),
          const SizedBox(height: 12),
          Text(error,
              style: const TextStyle(color: Color(0xFF8A94A6), fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.inbox_rounded, color: Color(0xFFB0BAC9), size: 48),
          SizedBox(height: 12),
          Text('Aucune catégorie disponible',
              style: TextStyle(color: Color(0xFF8A94A6), fontSize: 14)),
        ],
      ),
    );
  }

  // ─── HELPERS ──────────────────────────────────────────────────────────────────

  String? _resolveStatus(String? key) {
    if (!_hasFacteurData || key == null) return null;
    final d = widget.facteurData!;
    switch (key) {
      case 'pneus':
        if (d['marque_pneus'] != null) return 'Marque: ${d['marque_pneus']}';
        if (d['date_installation_pneus'] != null) {
          return 'Installés le: ${d['date_installation_pneus'].toString().substring(0, 10)}';
        }
        break;
      case 'vidange':
        if (d['date_dernier_vidange'] != null) {
          return 'Dernière vidange: ${d['date_dernier_vidange'].toString().substring(0, 10)}';
        }
        if (d['age_de_vehicule'] != null) {
          return 'Âge du véhicule: ${d['age_de_vehicule']} ans';
        }
        break;
      case 'batterie':
        if (d['date_installation_batterie'] != null) {
          return 'Installée le: ${d['date_installation_batterie'].toString().substring(0, 10)}';
        }
        break;
      case 'courroie':
        if (d['dernier_remplacement_courroie'] != null) {
          return 'Remplacée le: ${d['dernier_remplacement_courroie'].toString().substring(0, 10)}';
        }
        break;
      case 'amortisseurs':
        if (d['date_installation_amortisseurs'] != null) {
          return 'Installés le: ${d['date_installation_amortisseurs'].toString().substring(0, 10)}';
        }
        break;
      case 'freins':
        if (d['date_remplacement_freins'] != null) {
          return 'Maintenance: ${d['date_remplacement_freins'].toString().substring(0, 10)}';
        }
        break;
      case 'embrayage':
        if (d['date_remplacement_embrayage'] != null) {
          return 'Remplacé le: ${d['date_remplacement_embrayage'].toString().substring(0, 10)}';
        }
        break;
    }
    return null;
  }

  // ─── NAVIGATION (logic unchanged) ─────────────────────────────────────────────

  void _navigateToForm(Widget form, BuildContext context) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null && form is PredictionScreen) return;
    try {
      final vehiculeExiste = await Supabase.instance.client
          .from("voiture")
          .select()
          .eq('immatriculation', widget.immatriculation)
          .maybeSingle();

      if (vehiculeExiste == null) {
        throw "Véhicule non enregistré. Créez-le d'abord !";
      }

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => form,
          settings: RouteSettings(arguments: widget.immatriculation),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.error_outline_rounded,
                  color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Expanded(child: Text('$e')),
            ],
          ),
          backgroundColor: const Color(0xFFD32F2F),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ),
      );
    }
  }

  Future<bool> isCategoryEnabled(String categoryKey) async => true;

  // ─── CATEGORIES DATA (logic unchanged) ──────────────────────────────────────

  Future<List<Map<String, dynamic>>> get _categories async {
    PostgrestMap pgMap = PostgrestMap();
    if (widget.facteurData != null && widget.facteurData!.isNotEmpty) {
      try {
        pgMap = PostgrestMap.from(widget.facteurData!);
      } catch (e) {
        debugPrint('Erreur PostgrestMap: $e');
      }
    }

    return [
      {
        'key': 'pneus',
        'title': 'Les Pneus',
        'subtitle': "Suivi d'usure et performance",
        'icon': Icons.tire_repair_rounded,
        'color': const Color(0xFFF57C00),
        'route': PneusForm(
          immatriculation: widget.immatriculation,
          initialData: pgMap,
        ),
      },
      {
        'key': 'vidange',
        'title': 'Vidange moteur',
        'subtitle': 'Historique et planification',
        'icon': Icons.oil_barrel_rounded,
        'color': const Color(0xFF1976D2),
        'route': VidangeForm(immatriculation: widget.immatriculation),
      },
      {
        'key': 'batterie',
        'title': 'Batterie',
        'subtitle': 'Santé et durée de vie',
        'icon': Icons.battery_charging_full_rounded,
        'color': const Color(0xFF388E3C),
        'route': BatterieForm(immatriculation: widget.immatriculation),
      },
      {
        'key': 'courroie',
        'title': 'Courroie de distribution',
        'subtitle': 'Usure et remplacement',
        'icon': Icons.settings_input_antenna_rounded,
        'color': const Color(0xFFD32F2F),
        'route': CourroieForm(immatriculation: widget.immatriculation),
      },
      {
        'key': 'amortisseurs',
        'title': 'Les Amortisseurs',
        'subtitle': 'Contrôle de performance',
        'icon': Icons.shield_rounded,
        'color': const Color(0xFF7B1FA2),
        'route': AmortisseursForm(immatriculation: widget.immatriculation),
      },
      {
        'key': 'embrayage',
        'title': 'Embrayage',
        'subtitle': 'Usure et réglages',
        'icon': Icons.engineering_rounded,
        'color': const Color(0xFF5D4037),
        'route': EmbrayageForm(immatriculation: widget.immatriculation),
      },
      {
        'key': 'freins',
        'title': 'Système de freins',
        'subtitle': 'Plaquettes et disques',
        'icon': Icons.stop_circle_rounded,
        'color': const Color(0xFFC2185B),
        'route': FreinsForm(immatriculation: widget.immatriculation),
      },
    ];
  }
}

// ─── ANIMATED CARD WRAPPER ────────────────────────────────────────────────────

class _AnimatedCard extends StatefulWidget {
  final int index;
  final Widget child;
  const _AnimatedCard({required this.index, required this.child});

  @override
  State<_AnimatedCard> createState() => _AnimatedCardState();
}

class _AnimatedCardState extends State<_AnimatedCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 450),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.12),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    Future.delayed(Duration(milliseconds: 60 * widget.index), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

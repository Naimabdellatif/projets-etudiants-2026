// ignore_for_file: unnecessary_cast, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Page principale ──────────────────────────────────────────────────────────

class PneusCategorie extends StatefulWidget {
  final List<int> pneuIds;
  final String? immatriculation;

  const PneusCategorie({
    super.key,
    this.pneuIds = const [],
    this.immatriculation,
  });

  @override
  State<PneusCategorie> createState() => _PneusCategorieState();
}

class _PneusCategorieState extends State<PneusCategorie> {
  bool isLoading = true;
  Map<String, dynamic>? pneusPrincipal;
  List<Map<String, dynamic>> autrePneus = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchPneusData();
  }

  Future<void> _fetchPneusData() async {
    setState(() { isLoading = true; _error = null; });

    if (widget.pneuIds.isEmpty) {
      setState(() => isLoading = false);
      return;
    }

    try {
      final response = await Supabase.instance.client
          .from('pneus')
          .select()
          .inFilter('id', widget.pneuIds);

      setState(() {
        if (response.isNotEmpty) {
          pneusPrincipal = response[0] as Map<String, dynamic>;
          if (response.length > 1) {
            autrePneus =
                List<Map<String, dynamic>>.from(response.sublist(1));
          }
        }
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Erreur lors de la récupération des pneus: $e';
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Pneus',
        icon: Icons.tire_repair_outlined,
        iconColor: KTheme.textPrimary,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5),
      );
    }
    if (_error != null) {
      return KErrorState(error: _error!, onRetry: _fetchPneusData);
    }
    if (pneusPrincipal == null) {
      return const KEmptyState(
        message: 'Aucun pneu trouvé\npour ce véhicule.',
        icon: Icons.tire_repair_outlined,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(pneu: pneusPrincipal!),
        if (autrePneus.isNotEmpty) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Autres pneus recommandés',
            icon: Icons.compare_arrows_rounded,
          ),
          ...autrePneus.map((p) => _SecondaryCard(pneu: p)),
        ],
      ],
    );
  }
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final Map<String, dynamic> pneu;
  const _PrimaryCard({required this.pneu});

  @override
  Widget build(BuildContext context) {
    final double prix =
        pneu['prix'] != null ? (pneu['prix'] as num).toDouble() : 0.0;

    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête dégradé anthracite (pneus) ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1A1A1A), Color(0xFF3D3D3D)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: pneu['image_url'] ?? '',
                  size: 88,
                  fallbackIcon: Icons.tire_repair_outlined,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(
                        pneu['marque'] ?? 'Marque inconnue',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        pneu['reference'] ?? 'Référence inconnue',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.75),
                          fontSize: 13,
                        ),
                      ),
                      if (pneu['dimension'] != null) ...[
                        const SizedBox(height: 6),
                        _DimensionBadge(dimension: pneu['dimension']),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                KPriceTag(prix: prix, fontSize: 18),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (pneu['dimension'] != null)
                  KSpecRow(
                    icon: Icons.straighten_rounded,
                    label: 'Dimension',
                    value: pneu['dimension'],
                  ),
                if (pneu['type'] != null)
                  KSpecRow(
                    icon: Icons.category_outlined,
                    label: 'Type',
                    value: pneu['type'],
                  ),
                if (pneu['qualite'] != null)
                  KSpecRow(
                    icon: Icons.workspace_premium_outlined,
                    label: 'Qualité',
                    value: pneu['qualite'],
                  ),
                if (pneu['position'] != null)
                  KSpecRow(
                    icon: Icons.tune_rounded,
                    label: 'Position',
                    value: pneu['position'],
                  ),
                if (pneu['pays_constructeur'] != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: pneu['pays_constructeur'],
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Badge dimension (affiché dans l'en-tête)
class _DimensionBadge extends StatelessWidget {
  final String dimension;
  const _DimensionBadge({required this.dimension});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.18),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.straighten_rounded, size: 12, color: Colors.white),
          const SizedBox(width: 4),
          Text(
            dimension,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final Map<String, dynamic> pneu;
  const _SecondaryCard({required this.pneu});

  @override
  Widget build(BuildContext context) {
    final double prix =
        pneu['prix'] != null ? (pneu['prix'] as num).toDouble() : 0.0;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: pneu['image_url'] ?? '',
            size: 72,
            fallbackIcon: Icons.tire_repair_outlined,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  pneu['marque'] ?? 'Marque inconnue',
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: KTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  pneu['reference'] ?? 'Référence inconnue',
                  style: const TextStyle(
                      fontSize: 12, color: KTheme.textSecondary),
                ),
                const SizedBox(height: 6),
                KPriceTag(prix: prix, fontSize: 13),
                const SizedBox(height: 6),
                Row(
                  children: [
                    if (pneu['dimension'] != null)
                      _chip(pneu['dimension'], const Color(0xFF3D3D3D)),
                    if (pneu['dimension'] != null && pneu['type'] != null)
                      const SizedBox(width: 6),
                    if (pneu['type'] != null)
                      _chip(pneu['type'], KTheme.navy),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.09),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }
}
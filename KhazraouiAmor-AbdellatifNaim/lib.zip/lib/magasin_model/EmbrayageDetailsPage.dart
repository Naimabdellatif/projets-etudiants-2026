// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Modèle ──────────────────────────────────────────────────────────────────

class Embrayage {
  final int id;
  final String imageUrl;
  final String reference;
  final String marque;
  final String nom;
  final double prix;
  final String? type;           // ex: "Kit complet", "Disque seul", "Mécanisme"
  final double? diametre;       // mm
  final int? nombreDents;
  final String? paysConstructeur;
  final String? normes;

  const Embrayage({
    required this.id,
    required this.imageUrl,
    required this.reference,
    required this.marque,
    required this.nom,
    required this.prix,
    this.type,
    this.diametre,
    this.nombreDents,
    this.paysConstructeur,
    this.normes,
  });

  factory Embrayage.fromMap(Map<String, dynamic> map) {
    return Embrayage(
      id:               map['id'] as int,
      imageUrl:         (map['image_url'] as String?) ?? '',
      reference:        (map['reference'] as String?) ?? '',
      marque:           (map['marque'] as String?) ?? '',
      nom:              (map['nom'] as String?) ?? '',
      prix:             (map['prix'] as num).toDouble(),
      type:             map['type'] as String?,
      diametre:         (map['diametre'] as num?)?.toDouble(),
      nombreDents:      map['nombre_dents'] as int?,
      paysConstructeur: map['pays_constructeur'] as String?,
      normes:           map['normes'] as String?,
    );
  }
}

// ─── Page principale ─────────────────────────────────────────────────────────

class EmbrayageDetailsPage extends StatefulWidget {
  final List<int> embrayageIds;
  final String? immatriculation;

  const EmbrayageDetailsPage({
    super.key,
    this.embrayageIds = const [],
    this.immatriculation,
  });

  @override
  State<EmbrayageDetailsPage> createState() => _EmbrayageDetailsPageState();
}

class _EmbrayageDetailsPageState extends State<EmbrayageDetailsPage> {
  List<Embrayage> _embrayages = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      if (widget.embrayageIds.isEmpty) {
        setState(() => _isLoading = false);
        return;
      }
      final res = await Supabase.instance.client
          .from('embrayage')
          .select()
          .inFilter('id', widget.embrayageIds);
      setState(() {
        _embrayages = res.map<Embrayage>((m) => Embrayage.fromMap(m)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Embrayage',
        icon: Icons.settings_backup_restore_rounded,
        iconColor: const Color(0xFF0077B6),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5));
    }
    if (_error != null) return KErrorState(error: _error!, onRetry: _fetch);
    if (_embrayages.isEmpty) {
      return const KEmptyState(
        message: "Aucun kit d'embrayage trouvé\npour ce véhicule.",
        icon: Icons.settings_backup_restore_rounded,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(embrayage: _embrayages.first),
        if (_embrayages.length > 1) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Alternatives recommandées',
            icon: Icons.compare_arrows_rounded,
          ),
          ..._embrayages.skip(1).map((e) => _SecondaryCard(embrayage: e)),
        ],
      ],
    );
  }
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final Embrayage embrayage;
  const _PrimaryCard({required this.embrayage});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF023E8A), Color(0xFF0077B6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: embrayage.imageUrl,
                  size: 88,
                  fallbackIcon: Icons.settings_backup_restore_rounded,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(embrayage.marque,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          )),
                      const SizedBox(height: 2),
                      Text(embrayage.nom,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.75),
                            fontSize: 13,
                          )),
                      const SizedBox(height: 4),
                      Text('Réf: ${embrayage.reference}',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.55),
                            fontSize: 12,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Type + prix en ligne
                if (embrayage.type != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _TypeChip(type: embrayage.type!),
                  ),
                KPriceTag(prix: embrayage.prix, fontSize: 18),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (embrayage.diametre != null)
                  KSpecRow(
                    icon: Icons.radio_button_unchecked_rounded,
                    label: 'Diamètre',
                    value: '${embrayage.diametre} mm',
                  ),
                if (embrayage.nombreDents != null)
                  KSpecRow(
                    icon: Icons.sync_alt_rounded,
                    label: 'Nombre de dents',
                    value: '${embrayage.nombreDents}',
                  ),
                if (embrayage.normes != null)
                  KSpecRow(
                    icon: Icons.verified_outlined,
                    label: 'Normes',
                    value: embrayage.normes!,
                  ),
                if (embrayage.paysConstructeur != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: embrayage.paysConstructeur!,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TypeChip extends StatelessWidget {
  final String type;
  const _TypeChip({required this.type});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0077B6).withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: const Color(0xFF0077B6).withOpacity(0.25),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.inventory_2_outlined,
              size: 14, color: Color(0xFF0077B6)),
          const SizedBox(width: 6),
          Text(type,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: Color(0xFF0077B6),
              )),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final Embrayage embrayage;
  const _SecondaryCard({required this.embrayage});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: embrayage.imageUrl,
            size: 72,
            fallbackIcon: Icons.settings_backup_restore_rounded,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(embrayage.marque,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                        color: KTheme.textPrimary)),
                const SizedBox(height: 2),
                Text(embrayage.nom,
                    style: const TextStyle(
                        fontSize: 12, color: KTheme.textSecondary)),
                const SizedBox(height: 6),
                KPriceTag(prix: embrayage.prix, fontSize: 13),
                if (embrayage.type != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(embrayage.type!,
                        style: const TextStyle(
                            fontSize: 12, color: KTheme.textSecondary)),
                  ),
                if (embrayage.diametre != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('Ø ${embrayage.diametre} mm',
                        style: const TextStyle(
                            fontSize: 12, color: KTheme.textSecondary)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

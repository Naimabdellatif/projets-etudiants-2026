// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Modèle ──────────────────────────────────────────────────────────────────

class FreinPlaquette {
  final int id;
  final String imageUrl;
  final String reference;
  final String marque;
  final String nom;
  final double prix;
  final String? type;         // ex: "Céramique", "Semi-métallique"
  final String? position;     // ex: "Avant", "Arrière", "Avant/Arrière"
  final String? paysConstructeur;
  final double? epaisseur;    // mm
  final String? normes;       // ex: "ECE R90"

  const FreinPlaquette({
    required this.id,
    required this.imageUrl,
    required this.reference,
    required this.marque,
    required this.nom,
    required this.prix,
    this.type,
    this.position,
    this.paysConstructeur,
    this.epaisseur,
    this.normes,
  });

  factory FreinPlaquette.fromMap(Map<String, dynamic> map) {
    return FreinPlaquette(
      id:               map['id'] as int,
      imageUrl:         (map['image_url'] as String?) ?? '',
      reference:        (map['reference'] as String?) ?? '',
      marque:           (map['marque'] as String?) ?? '',
      nom:              (map['nom'] as String?) ?? '',
      prix:             (map['prix'] as num).toDouble(),
      type:             map['type'] as String?,
      position:         map['position'] as String?,
      paysConstructeur: map['pays_constructeur'] as String?,
      epaisseur:        (map['epaisseur'] as num?)?.toDouble(),
      normes:           map['normes'] as String?,
    );
  }
}

// ─── Page principale ─────────────────────────────────────────────────────────

class FreinsDetailsPage extends StatefulWidget {
  final List<int> freinIds;
  final String? immatriculation;

  const FreinsDetailsPage({
    super.key,
    this.freinIds = const [],
    this.immatriculation,
  });

  @override
  State<FreinsDetailsPage> createState() => _FreinsDetailsPageState();
}

class _FreinsDetailsPageState extends State<FreinsDetailsPage> {
  List<FreinPlaquette> _freins = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      if (widget.freinIds.isEmpty) {
        setState(() => _isLoading = false);
        return;
      }
      final res = await Supabase.instance.client
          .from('freins')
          .select()
          .inFilter('id', widget.freinIds);
      setState(() {
        _freins = res.map<FreinPlaquette>((m) => FreinPlaquette.fromMap(m)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Plaquettes de frein',
        icon: Icons.stop_circle_outlined,
        iconColor: KTheme.accent,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5),
      );
    }
    if (_error != null) {
      return KErrorState(error: _error!, onRetry: _fetch);
    }
    if (_freins.isEmpty) {
      return const KEmptyState(
        message: 'Aucune plaquette de frein trouvée\npour ce véhicule.',
        icon: Icons.stop_circle_outlined,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(frein: _freins.first),
        if (_freins.length > 1) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Alternatives recommandées',
            icon: Icons.compare_arrows_rounded,
          ),
          ..._freins.skip(1).map((f) => _SecondaryCard(frein: f)),
        ],
      ],
    );
  }
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final FreinPlaquette frein;
  const _PrimaryCard({required this.frein});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête coloré ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [KTheme.navy, KTheme.navyLight],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: frein.imageUrl,
                  size: 88,
                  fallbackIcon: Icons.stop_circle_outlined,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(
                        frein.marque,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        frein.nom,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.75),
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Réf: ${frein.reference}',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.55),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                KPriceTag(prix: frein.prix, fontSize: 18),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (frein.type != null)
                  KSpecRow(
                    icon: Icons.category_outlined,
                    label: 'Type',
                    value: frein.type!,
                  ),
                if (frein.position != null)
                  KSpecRow(
                    icon: Icons.tune_rounded,
                    label: 'Position',
                    value: frein.position!,
                  ),
                if (frein.epaisseur != null)
                  KSpecRow(
                    icon: Icons.straighten_rounded,
                    label: 'Épaisseur',
                    value: '${frein.epaisseur} mm',
                  ),
                if (frein.normes != null)
                  KSpecRow(
                    icon: Icons.verified_outlined,
                    label: 'Normes',
                    value: frein.normes!,
                  ),
                if (frein.paysConstructeur != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: frein.paysConstructeur!,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final FreinPlaquette frein;
  const _SecondaryCard({required this.frein});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: frein.imageUrl,
            size: 72,
            fallbackIcon: Icons.stop_circle_outlined,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(frein.marque,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: KTheme.textPrimary,
                    )),
                const SizedBox(height: 2),
                Text(frein.nom,
                    style: const TextStyle(
                        fontSize: 12, color: KTheme.textSecondary)),
                const SizedBox(height: 6),
                KPriceTag(prix: frein.prix, fontSize: 13),
                if (frein.type != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(
                      children: [
                        const Icon(Icons.category_outlined,
                            size: 13, color: KTheme.textSecondary),
                        const SizedBox(width: 4),
                        Text(frein.type!,
                            style: const TextStyle(
                                fontSize: 12, color: KTheme.textSecondary)),
                      ],
                    ),
                  ),
                if (frein.position != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      children: [
                        const Icon(Icons.tune_rounded,
                            size: 13, color: KTheme.textSecondary),
                        const SizedBox(width: 4),
                        Text(frein.position!,
                            style: const TextStyle(
                                fontSize: 12, color: KTheme.textSecondary)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Modèle ──────────────────────────────────────────────────────────────────

class Batterie {
  final int id;
  final String imageUrl;
  final String reference;
  final String marque;
  final String nom;
  final double prix;
  final int? capacite;         // Ah
  final int? courantDemarrage; // A (CCA)
  final String? tension;       // ex: "12V"
  final String? technologie;   // ex: "AGM", "EFB", "Standard"
  final String? polarite;      // ex: "Positive droite"
  final String? paysConstructeur;
  final int? garantieMois;

  const Batterie({
    required this.id,
    required this.imageUrl,
    required this.reference,
    required this.marque,
    required this.nom,
    required this.prix,
    this.capacite,
    this.courantDemarrage,
    this.tension,
    this.technologie,
    this.polarite,
    this.paysConstructeur,
    this.garantieMois,
  });

  factory Batterie.fromMap(Map<String, dynamic> map) {
    return Batterie(
      id:                 map['id'] as int,
      imageUrl:           (map['image_url'] as String?) ?? '',
      reference:          (map['reference'] as String?) ?? '',
      marque:             (map['marque'] as String?) ?? '',
      nom:                (map['nom'] as String?) ?? '',
      prix:               (map['prix'] as num).toDouble(),
      capacite:           map['capacite'] as int?,
      courantDemarrage:   map['courant_demarrage'] as int?,
      tension:            map['tension'] as String?,
      technologie:        map['technologie'] as String?,
      polarite:           map['polarite'] as String?,
      paysConstructeur:   map['pays_constructeur'] as String?,
      garantieMois:       map['garantie_mois'] as int?,
    );
  }
}

// ─── Page principale ─────────────────────────────────────────────────────────

class BatterieDetailsPage extends StatefulWidget {
  final List<int> batterieIds;
  final String? immatriculation;

  const BatterieDetailsPage({
    super.key,
    this.batterieIds = const [],
    this.immatriculation,
  });

  @override
  State<BatterieDetailsPage> createState() => _BatterieDetailsPageState();
}

class _BatterieDetailsPageState extends State<BatterieDetailsPage> {
  List<Batterie> _batteries = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      if (widget.batterieIds.isEmpty) {
        setState(() => _isLoading = false);
        return;
      }
      final res = await Supabase.instance.client
          .from('batterie')
          .select()
          .inFilter('id', widget.batterieIds);
      setState(() {
        _batteries = res.map<Batterie>((m) => Batterie.fromMap(m)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Batteries',
        icon: Icons.battery_charging_full_rounded,
        iconColor: KTheme.gold,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5));
    }
    if (_error != null) return KErrorState(error: _error!, onRetry: _fetch);
    if (_batteries.isEmpty) {
      return const KEmptyState(
        message: 'Aucune batterie trouvée\npour ce véhicule.',
        icon: Icons.battery_charging_full_rounded,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(batterie: _batteries.first),
        if (_batteries.length > 1) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Alternatives recommandées',
            icon: Icons.compare_arrows_rounded,
          ),
          ..._batteries.skip(1).map((b) => _SecondaryCard(batterie: b)),
        ],
      ],
    );
  }
}

// ─── Indicateurs puissance ────────────────────────────────────────────────────

class _PowerIndicators extends StatelessWidget {
  final Batterie batterie;
  const _PowerIndicators({required this.batterie});

  @override
  Widget build(BuildContext context) {
    final items = <_PowerItem>[];
    if (batterie.capacite != null) {
      items.add(_PowerItem(
        icon: Icons.battery_full_rounded,
        label: 'Capacité',
        value: '${batterie.capacite} Ah',
        color: KTheme.success,
      ));
    }
    if (batterie.courantDemarrage != null) {
      items.add(_PowerItem(
        icon: Icons.bolt_rounded,
        label: 'CCA',
        value: '${batterie.courantDemarrage} A',
        color: KTheme.gold,
      ));
    }
    if (batterie.tension != null) {
      items.add(_PowerItem(
        icon: Icons.electrical_services_rounded,
        label: 'Tension',
        value: batterie.tension!,
        color: KTheme.accent,
      ));
    }
    if (items.isEmpty) return const SizedBox.shrink();

    return Row(
      children: items
          .map((item) => Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: _buildIndicator(item),
                ),
              ))
          .toList(),
    );
  }

  Widget _buildIndicator(_PowerItem item) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(
        color: item.color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(KTheme.radiusSM),
        border: Border.all(color: item.color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(item.icon, color: item.color, size: 22),
          const SizedBox(height: 4),
          Text(item.value,
              style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                  color: item.color)),
          Text(item.label,
              style: const TextStyle(
                  fontSize: 10,
                  color: KTheme.textSecondary,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

class _PowerItem {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _PowerItem(
      {required this.icon,
      required this.label,
      required this.value,
      required this.color});
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final Batterie batterie;
  const _PrimaryCard({required this.batterie});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: batterie.imageUrl,
                  size: 88,
                  fallbackIcon: Icons.battery_charging_full_rounded,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(batterie.marque,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          )),
                      const SizedBox(height: 2),
                      Text(batterie.nom,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.75),
                            fontSize: 13,
                          )),
                      const SizedBox(height: 4),
                      Text('Réf: ${batterie.reference}',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.55),
                            fontSize: 12,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    KPriceTag(prix: batterie.prix, fontSize: 18),
                    if (batterie.garantieMois != null) ...[
                      const SizedBox(width: 12),
                      _buildGarantie(batterie.garantieMois!),
                    ],
                  ],
                ),
                const SizedBox(height: 16),
                _PowerIndicators(batterie: batterie),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (batterie.technologie != null)
                  KSpecRow(
                    icon: Icons.memory_rounded,
                    label: 'Technologie',
                    value: batterie.technologie!,
                  ),
                if (batterie.polarite != null)
                  KSpecRow(
                    icon: Icons.swap_horiz_rounded,
                    label: 'Polarité',
                    value: batterie.polarite!,
                  ),
                if (batterie.paysConstructeur != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: batterie.paysConstructeur!,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGarantie(int mois) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: KTheme.navy.withOpacity(0.06),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.shield_outlined, size: 14, color: KTheme.navy),
          const SizedBox(width: 4),
          Text('Garantie $mois mois',
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: KTheme.navy)),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final Batterie batterie;
  const _SecondaryCard({required this.batterie});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: batterie.imageUrl,
            size: 72,
            fallbackIcon: Icons.battery_charging_full_rounded,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(batterie.marque,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                        color: KTheme.textPrimary)),
                const SizedBox(height: 2),
                Text(batterie.nom,
                    style: const TextStyle(
                        fontSize: 12, color: KTheme.textSecondary)),
                const SizedBox(height: 6),
                KPriceTag(prix: batterie.prix, fontSize: 13),
                const SizedBox(height: 6),
                Row(
                  children: [
                    if (batterie.capacite != null)
                      _chip('${batterie.capacite} Ah', KTheme.success),
                    if (batterie.capacite != null && batterie.courantDemarrage != null)
                      const SizedBox(width: 6),
                    if (batterie.courantDemarrage != null)
                      _chip('${batterie.courantDemarrage} A', KTheme.gold),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(text,
          style: TextStyle(
              fontSize: 11, fontWeight: FontWeight.w700, color: color)),
    );
  }
}

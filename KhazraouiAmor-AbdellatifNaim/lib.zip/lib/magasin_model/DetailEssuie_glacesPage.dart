// ignore_for_file: camel_case_types, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Modèle ──────────────────────────────────────────────────────────────────

class Refroidissement {
  final String id;
  final String imageUrl;
  final String nom;
  final String marque;
  final String? type;
  final double prix;
  final double? poids;
  final String? paysConstructeur;

  Refroidissement({
    required this.id,
    required this.imageUrl,
    required this.nom,
    required this.marque,
    this.type,
    required this.prix,
    this.poids,
    this.paysConstructeur,
  });

  factory Refroidissement.fromMap(Map<String, dynamic> map) {
    return Refroidissement(
      id:               map['id'].toString(),
      imageUrl:         map['image_url'] as String,
      nom:              map['nom'] as String,
      marque:           map['marque'] as String,
      type:             map['type'] as String?,
      prix:             (map['prix'] as num).toDouble(),
      poids:            (map['poids'] as num?)?.toDouble(),
      paysConstructeur: map['pays_constructeur'] as String?,
    );
  }
}

// ─── Page principale ──────────────────────────────────────────────────────────

class DetailEssuie_glacesPage extends StatefulWidget {
  final List<int> refroidissementIds;
  final String? immatriculation;

  const DetailEssuie_glacesPage({
    super.key,
    this.refroidissementIds = const [],
    this.immatriculation,
  });

  @override
  State<DetailEssuie_glacesPage> createState() =>
      _DetailEssuie_glacesPageState();
}

class _DetailEssuie_glacesPageState extends State<DetailEssuie_glacesPage> {
  List<Refroidissement> _refroidissementList = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchRefroidissementData();
  }

  Future<void> _fetchRefroidissementData() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      if (widget.refroidissementIds.isEmpty) {
        setState(() => _isLoading = false);
        return;
      }
      final stringIds =
          widget.refroidissementIds.map((id) => id.toString()).toList();
      final response = await Supabase.instance.client
          .from('eau_refroidissement')
          .select()
          .inFilter('id', stringIds);
      setState(() {
        _refroidissementList = response
            .map<Refroidissement>((item) => Refroidissement.fromMap(item))
            .toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Erreur lors de la récupération des données: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Liquide de Refroidissement',
        icon: Icons.water_drop_outlined,
        iconColor: const Color(0xFF0077B6),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5),
      );
    }
    if (_error != null) {
      return KErrorState(error: _error!, onRetry: _fetchRefroidissementData);
    }
    if (_refroidissementList.isEmpty) {
      return const KEmptyState(
        message: 'Aucun liquide de refroidissement trouvé\npour ce véhicule.',
        icon: Icons.water_drop_outlined,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(refroidissement: _refroidissementList.first),
        if (_refroidissementList.length > 1) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Autres liquides recommandés',
            icon: Icons.compare_arrows_rounded,
          ),
          ..._refroidissementList
              .skip(1)
              .map((r) => _SecondaryCard(refroidissement: r)),
        ],
      ],
    );
  }
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final Refroidissement refroidissement;
  const _PrimaryCard({required this.refroidissement});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête dégradé bleu cyan (liquide de refroidissement) ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF023E8A), Color(0xFF0096C7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: refroidissement.imageUrl,
                  size: 88,
                  fallbackIcon: Icons.water_drop_outlined,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(
                        refroidissement.nom,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        refroidissement.marque,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.75),
                          fontSize: 13,
                        ),
                      ),
                      if (refroidissement.type != null) ...[
                        const SizedBox(height: 6),
                        _TypeBadge(type: refroidissement.type!),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                KPriceTag(prix: refroidissement.prix, fontSize: 18),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (refroidissement.type != null)
                  KSpecRow(
                    icon: Icons.category_outlined,
                    label: 'Type',
                    value: refroidissement.type!,
                  ),
                if (refroidissement.poids != null)
                  KSpecRow(
                    icon: Icons.water_drop_outlined,
                    label: 'Contenance',
                    value: '${refroidissement.poids} L',
                  ),
                if (refroidissement.paysConstructeur != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: refroidissement.paysConstructeur!,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Badge type (affiché dans l'en-tête)
class _TypeBadge extends StatelessWidget {
  final String type;
  const _TypeBadge({required this.type});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.18),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.science_outlined, size: 12, color: Colors.white),
          const SizedBox(width: 4),
          Text(
            type,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final Refroidissement refroidissement;
  const _SecondaryCard({required this.refroidissement});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: refroidissement.imageUrl,
            size: 72,
            fallbackIcon: Icons.water_drop_outlined,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  refroidissement.nom,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: KTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  refroidissement.marque,
                  style: const TextStyle(
                      fontSize: 12, color: KTheme.textSecondary),
                ),
                const SizedBox(height: 6),
                KPriceTag(prix: refroidissement.prix, fontSize: 13),
                const SizedBox(height: 6),
                Row(
                  children: [
                    if (refroidissement.type != null)
                      _chip(refroidissement.type!, const Color(0xFF0096C7)),
                    if (refroidissement.type != null &&
                        refroidissement.poids != null)
                      const SizedBox(width: 6),
                    if (refroidissement.poids != null)
                      _chip('${refroidissement.poids} L', KTheme.navy),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.09),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }
}
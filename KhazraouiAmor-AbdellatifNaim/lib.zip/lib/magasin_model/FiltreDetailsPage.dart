import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Filtre {
  final int id;
  final String imageUrl;
  final String reference;
  final String nom;
  final String marque;
  final double prix;
  final String? paysConstructeur;

  Filtre({
    required this.id,
    required this.imageUrl,
    required this.reference,
    required this.nom,
    required this.marque,
    required this.prix,
    this.paysConstructeur,
  });

  factory Filtre.fromMap(Map<String, dynamic> map) {
    return Filtre(
      id: map['id'] as int,
      imageUrl: map['image_url'] as String,
      reference: map['reference'] as String,
      nom: map['nom'] as String,
      marque: map['marque'] as String,
      prix: (map['prix'] as num).toDouble(),
      paysConstructeur: map['pays_constructeur'] as String?,
    );
  }
}

class FiltreDetailsPage extends StatefulWidget {
  final List<int> filtreIds;
  final String? immatriculation;

  const FiltreDetailsPage(
      {super.key, this.filtreIds = const [], this.immatriculation});

  @override
  State<FiltreDetailsPage> createState() => _FiltreDetailsPageState();
}

class _FiltreDetailsPageState extends State<FiltreDetailsPage> {
  List<Filtre> _filtresList = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchFiltresData();
  }

  Future<void> _fetchFiltresData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      if (widget.filtreIds.isEmpty) {
        setState(() {
          _isLoading = false;
        });
        return;
      }

      final response = await Supabase.instance.client
          .from('filtres')
          .select()
          .inFilter('id', widget.filtreIds);

      setState(() {
        _filtresList =
            response.map<Filtre>((item) => Filtre.fromMap(item)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Erreur lors de la récupération des données: $e';
        _isLoading = false;
      });
      if (kDebugMode) {
        print(_error);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Détails Filtres', style: TextStyle(color: Colors.white)),
        centerTitle: true,
        backgroundColor: Colors.blue[800],
        elevation: 10,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            _error!,
            style: TextStyle(color: Colors.red, fontSize: 16),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    if (_filtresList.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Aucun filtre trouvé pour ce véhicule.',
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Afficher le filtre principal (premier de la liste)
          _buildPrimaryFilterCard(_filtresList[0]),

          SizedBox(height: 24),

          // Afficher les autres filtres recommandés
          if (_filtresList.length > 1) ...[
            Text(
              'Autres filtres recommandés',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.blue[800],
              ),
            ),
            SizedBox(height: 16),
            ..._filtresList
                .skip(1)
                .map((filtre) => _buildSecondaryFilterCard(filtre))
                ,
          ],
        ],
      ),
    );
  }

  Widget _buildPrimaryFilterCard(Filtre filtre) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Image
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    filtre.imageUrl,
                    height: 100,
                    width: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                        Icon(Icons.filter_alt, size: 48, color: Colors.grey),
                  ),
                ),
                SizedBox(width: 16),
                // Informations principales
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        filtre.nom,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue[800],
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        filtre.marque,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        filtre.reference,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[700],
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '${filtre.prix} TND',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[800],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (filtre.paysConstructeur != null) ...[
              SizedBox(height: 16),
              _buildSpecificationRow(
                  'Pays de fabrication', filtre.paysConstructeur!),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSecondaryFilterCard(Filtre filtre) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      margin: EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                filtre.imageUrl,
                height: 80,
                width: 80,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Icon(Icons.filter_alt, size: 40, color: Colors.grey),
              ),
            ),
            SizedBox(width: 16),
            // Détails
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    filtre.nom,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[800],
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    filtre.marque,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.black87,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '${filtre.prix} TND',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.green[800],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSpecificationRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Modèle ──────────────────────────────────────────────────────────────────

class HuileMoteur {
  final int id;
  final String imageUrl;
  final String reference;
  final String marque;
  final double prix;
  final String? type;
  final String? paysConstructeur;
  final String? viscosite;
  final double? poids;

  HuileMoteur({
    required this.id,
    required this.imageUrl,
    required this.reference,
    required this.marque,
    required this.prix,
    this.type,
    this.paysConstructeur,
    this.viscosite,
    this.poids,
  });

  factory HuileMoteur.fromMap(Map<String, dynamic> map) {
    return HuileMoteur(
      id:               map['id'] as int,
      imageUrl:         map['image_url'] as String,
      reference:        map['reference'] as String,
      marque:           map['marque'] as String,
      prix:             (map['prix'] as num).toDouble(),
      type:             map['type'] as String?,
      paysConstructeur: map['pays_constructeur'] as String?,
      viscosite:        map['viscosite'] as String?,
      poids:            (map['poids'] as num?)?.toDouble(),
    );
  }
}

// ─── Page principale ──────────────────────────────────────────────────────────

class DetailHuilePage extends StatefulWidget {
  final List<int> huileIds;
  final String? immatriculation;

  const DetailHuilePage({
    super.key,
    this.huileIds = const [],
    this.immatriculation,
  });

  @override
  State<DetailHuilePage> createState() => _DetailHuilePageState();
}

class _DetailHuilePageState extends State<DetailHuilePage> {
  List<HuileMoteur> _huilesList = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchHuileDetails();
  }

  Future<void> _fetchHuileDetails() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      if (widget.huileIds.isEmpty) {
        setState(() => _isLoading = false);
        return;
      }
      final response = await Supabase.instance.client
          .from('huile_moteur')
          .select()
          .inFilter('id', widget.huileIds);
      setState(() {
        _huilesList = response
            .map<HuileMoteur>((item) => HuileMoteur.fromMap(item))
            .toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Erreur lors de la récupération des données: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Huile Moteur',
        icon: Icons.oil_barrel_outlined,
        iconColor: KTheme.gold,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5),
      );
    }
    if (_error != null) {
      return KErrorState(error: _error!, onRetry: _fetchHuileDetails);
    }
    if (_huilesList.isEmpty) {
      return const KEmptyState(
        message: 'Aucune huile moteur trouvée\npour ce véhicule.',
        icon: Icons.oil_barrel_outlined,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(huile: _huilesList.first),
        if (_huilesList.length > 1) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Autres huiles recommandées',
            icon: Icons.compare_arrows_rounded,
          ),
          ..._huilesList.skip(1).map((h) => _SecondaryCard(huile: h)),
        ],
      ],
    );
  }
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final HuileMoteur huile;
  const _PrimaryCard({required this.huile});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête dégradé brun/ambre (huile moteur) ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF7B3F00), Color(0xFFB5651D)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: huile.imageUrl,
                  size: 88,
                  fallbackIcon: Icons.oil_barrel_outlined,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(
                        huile.marque,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        huile.reference,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.75),
                          fontSize: 13,
                        ),
                      ),
                      if (huile.viscosite != null) ...[
                        const SizedBox(height: 6),
                        _ViscositeBadge(viscosite: huile.viscosite!),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                KPriceTag(prix: huile.prix, fontSize: 18),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (huile.type != null)
                  KSpecRow(
                    icon: Icons.category_outlined,
                    label: 'Type',
                    value: huile.type!,
                  ),
                if (huile.viscosite != null)
                  KSpecRow(
                    icon: Icons.thermostat_rounded,
                    label: 'Viscosité',
                    value: huile.viscosite!,
                  ),
                if (huile.poids != null)
                  KSpecRow(
                    icon: Icons.water_drop_outlined,
                    label: 'Contenance',
                    value: '${huile.poids} L',
                  ),
                if (huile.paysConstructeur != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: huile.paysConstructeur!,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Badge viscosité (affiché dans l'en-tête)
class _ViscositeBadge extends StatelessWidget {
  final String viscosite;
  const _ViscositeBadge({required this.viscosite});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.18),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.thermostat_rounded, size: 12, color: Colors.white),
          const SizedBox(width: 4),
          Text(
            viscosite,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final HuileMoteur huile;
  const _SecondaryCard({required this.huile});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: huile.imageUrl,
            size: 72,
            fallbackIcon: Icons.oil_barrel_outlined,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  huile.marque,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: KTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  huile.reference,
                  style: const TextStyle(fontSize: 12, color: KTheme.textSecondary),
                ),
                const SizedBox(height: 6),
                KPriceTag(prix: huile.prix, fontSize: 13),
                const SizedBox(height: 6),
                Row(
                  children: [
                    if (huile.viscosite != null)
                      _chip(huile.viscosite!, const Color(0xFFB5651D)),
                    if (huile.viscosite != null && huile.poids != null)
                      const SizedBox(width: 6),
                    if (huile.poids != null)
                      _chip('${huile.poids} L', KTheme.navy),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.09),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }
}
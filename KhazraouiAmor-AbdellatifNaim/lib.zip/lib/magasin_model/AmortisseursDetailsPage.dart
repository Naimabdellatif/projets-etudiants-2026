// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Modèle ──────────────────────────────────────────────────────────────────

class Amortisseur {
  final int id;
  final String imageUrl;
  final String reference;
  final String marque;
  final String nom;
  final double prix;
  final String? type;           // ex: "Hydraulique", "Gaz", "Électronique"
  final String? position;       // ex: "Avant", "Arrière", "Avant gauche"
  final String? technologie;    // ex: "Monotube", "Bitube"
  final double? course;         // mm
  final String? paysConstructeur;
  final bool? ajustable;

  const Amortisseur({
    required this.id,
    required this.imageUrl,
    required this.reference,
    required this.marque,
    required this.nom,
    required this.prix,
    this.type,
    this.position,
    this.technologie,
    this.course,
    this.paysConstructeur,
    this.ajustable,
  });

  factory Amortisseur.fromMap(Map<String, dynamic> map) {
    return Amortisseur(
      id:               map['id'] as int,
      imageUrl:         (map['image_url'] as String?) ?? '',
      reference:        (map['reference'] as String?) ?? '',
      marque:           (map['marque'] as String?) ?? '',
      nom:              (map['nom'] as String?) ?? '',
      prix:             (map['prix'] as num).toDouble(),
      type:             map['type'] as String?,
      position:         map['position'] as String?,
      technologie:      map['technologie'] as String?,
      course:           (map['course'] as num?)?.toDouble(),
      paysConstructeur: map['pays_constructeur'] as String?,
      ajustable:        map['ajustable'] as bool?,
    );
  }
}

// ─── Page principale ─────────────────────────────────────────────────────────

class AmortisseursDetailsPage extends StatefulWidget {
  final List<int> amortisseurIds;
  final String? immatriculation;

  const AmortisseursDetailsPage({
    super.key,
    this.amortisseurIds = const [],
    this.immatriculation,
  });

  @override
  State<AmortisseursDetailsPage> createState() =>
      _AmortisseursDetailsPageState();
}

class _AmortisseursDetailsPageState extends State<AmortisseursDetailsPage> {
  List<Amortisseur> _amortisseurs = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      if (widget.amortisseurIds.isEmpty) {
        setState(() => _isLoading = false);
        return;
      }
      final res = await Supabase.instance.client
          .from('amortisseurs')
          .select()
          .inFilter('id', widget.amortisseurIds);
      setState(() {
        _amortisseurs =
            res.map<Amortisseur>((m) => Amortisseur.fromMap(m)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Amortisseurs',
        icon: Icons.shutter_speed_outlined,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5));
    }
    if (_error != null) return KErrorState(error: _error!, onRetry: _fetch);
    if (_amortisseurs.isEmpty) {
      return const KEmptyState(
        message: 'Aucun amortisseur trouvé\npour ce véhicule.',
        icon: Icons.shutter_speed_outlined,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(amortisseur: _amortisseurs.first),
        if (_amortisseurs.length > 1) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Alternatives recommandées',
            icon: Icons.compare_arrows_rounded,
          ),
          ..._amortisseurs.skip(1).map((a) => _SecondaryCard(amortisseur: a)),
        ],
      ],
    );
  }
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final Amortisseur amortisseur;
  const _PrimaryCard({required this.amortisseur});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF4A1942), Color(0xFF6B2D6B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: amortisseur.imageUrl,
                  size: 88,
                  fallbackIcon: Icons.shutter_speed_outlined,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (amortisseur.ajustable == true)
                        _buildAjustableBadge(),
                      if (amortisseur.ajustable != true)
                        const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(amortisseur.marque,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          )),
                      const SizedBox(height: 2),
                      Text(amortisseur.nom,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.75),
                            fontSize: 13,
                          )),
                      const SizedBox(height: 4),
                      Text('Réf: ${amortisseur.reference}',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.55),
                            fontSize: 12,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                KPriceTag(prix: amortisseur.prix, fontSize: 18),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (amortisseur.type != null)
                  KSpecRow(
                    icon: Icons.category_outlined,
                    label: 'Type',
                    value: amortisseur.type!,
                  ),
                if (amortisseur.position != null)
                  KSpecRow(
                    icon: Icons.tune_rounded,
                    label: 'Position',
                    value: amortisseur.position!,
                  ),
                if (amortisseur.technologie != null)
                  KSpecRow(
                    icon: Icons.build_circle_outlined,
                    label: 'Technologie',
                    value: amortisseur.technologie!,
                  ),
                if (amortisseur.course != null)
                  KSpecRow(
                    icon: Icons.height_rounded,
                    label: 'Course',
                    value: '${amortisseur.course} mm',
                  ),
                if (amortisseur.paysConstructeur != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: amortisseur.paysConstructeur!,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAjustableBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.purpleAccent.withOpacity(0.20),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.purpleAccent.withOpacity(0.5)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.tune_rounded, size: 12, color: Colors.purpleAccent),
          SizedBox(width: 4),
          Text('Ajustable',
              style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: Colors.purpleAccent)),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final Amortisseur amortisseur;
  const _SecondaryCard({required this.amortisseur});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: amortisseur.imageUrl,
            size: 72,
            fallbackIcon: Icons.shutter_speed_outlined,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(amortisseur.marque,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                        color: KTheme.textPrimary)),
                const SizedBox(height: 2),
                Text(amortisseur.nom,
                    style: const TextStyle(
                        fontSize: 12, color: KTheme.textSecondary)),
                const SizedBox(height: 6),
                KPriceTag(prix: amortisseur.prix, fontSize: 13),
                if (amortisseur.type != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('Type: ${amortisseur.type}',
                        style: const TextStyle(
                            fontSize: 12, color: KTheme.textSecondary)),
                  ),
                if (amortisseur.position != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('Position: ${amortisseur.position}',
                        style: const TextStyle(
                            fontSize: 12, color: KTheme.textSecondary)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

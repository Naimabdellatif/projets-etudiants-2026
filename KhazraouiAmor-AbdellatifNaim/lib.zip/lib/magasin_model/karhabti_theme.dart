// ignore_for_file: deprecated_member_use

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// ─────────────────────────────────────────────
///  CARHABTI – Design System v2.0
///  Palette, typographie, ombres et composants partagés
/// ─────────────────────────────────────────────

class KTheme {
  KTheme._();

  // ── Palette principale ───────────────────────
  static const Color turquoise     = Color(0xFF6FD3DE);
  static const Color turquoiseLight= Color(0xFF9FE5ED);
  static const Color turquoiseDark = Color(0xFF4ABCC8);
  static const Color navy          = Color(0xFF0D1B3E);
  static const Color navyLight     = Color(0xFF1A2F5E);
  static const Color navyMid       = Color(0xFF162848);
  static const Color cyan          = Color(0xFF26C6DA);
  static const Color cyanLight     = Color(0xFF80DEEA);
  static const Color yellow        = Color(0xFFFFD341);
  static const Color yellowSoft    = Color(0xFFFFF3C4);

  // ── Couleurs fonctionnelles ──────────────────
  static const Color success       = Color(0xFF10B981);
  static const Color successSoft   = Color(0xFFD1FAE5);
  static const Color warning       = Color(0xFFF59E0B);
  static const Color warningSoft   = Color(0xFFFEF3C7);
  static const Color danger        = Color(0xFFEF4444);
  static const Color dangerSoft    = Color(0xFFFEE2E2);
  static const Color info          = Color(0xFF3B82F6);
  static const Color infoSoft      = Color(0xFFDBEAFE);

  // ── Couleurs neutres ─────────────────────────
  static const Color surface       = Color(0xFFF4FAFB);
  static const Color surfaceAlt    = Color(0xFFEDF5F7);
  static const Color card          = Colors.white;
  static const Color border        = Color(0xFFDCEFF2);
  static const Color borderLight   = Color(0xFFE8F4F6);
  static const Color textPrimary   = Color(0xFF0D1B3E);
  static const Color textSecondary = Color(0xFF607D8B);
  static const Color textLight     = Color(0xFFB0BEC5);
  static const Color textOnDark    = Colors.white;

  // ── Couleurs legacy (backward compat) ────────
  static const Color accent        = Color(0xFFE63946);
  static const Color accentSoft    = Color(0xFFFFE8EA);
  static const Color gold          = Color(0xFFF4A225);
  static const Color purple        = Color(0xFF5E35B1);

  // ── Gradients ────────────────────────────────
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [navy, navyMid, turquoiseDark],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient ctaGradient = LinearGradient(
    colors: [turquoise, cyan],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static const LinearGradient heroGradient = LinearGradient(
    colors: [navy, Color(0xFF122040), turquoiseDark],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient cardGradient = LinearGradient(
    colors: [Color(0xFF0F2247), Color(0xFF163A5C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient accentGradient = LinearGradient(
    colors: [yellow, Color(0xFFFFBF00)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // ── Ombres (niveaux d'élévation) ─────────────
  static List<BoxShadow> elevationLow = [
    BoxShadow(
      color: Colors.black.withOpacity(0.04),
      blurRadius: 8,
      offset: const Offset(0, 2),
    ),
  ];

  static List<BoxShadow> elevationMedium = [
    BoxShadow(
      color: Colors.black.withOpacity(0.06),
      blurRadius: 16,
      offset: const Offset(0, 6),
    ),
  ];

  static List<BoxShadow> elevationHigh = [
    BoxShadow(
      color: Colors.black.withOpacity(0.10),
      blurRadius: 28,
      offset: const Offset(0, 10),
    ),
  ];

  static List<BoxShadow> elevationColored(Color color) => [
    BoxShadow(
      color: color.withOpacity(0.30),
      blurRadius: 20,
      offset: const Offset(0, 8),
    ),
  ];

  // ── Legacy shadows (backward compat) ─────────
  static List<BoxShadow> get cardShadow => elevationMedium;
  static List<BoxShadow> get subtleShadow => elevationLow;

  // ── Radius ──────────────────────────────────
  static const double radiusXS = 8.0;
  static const double radiusSM = 12.0;
  static const double radiusMD = 16.0;
  static const double radiusLG = 20.0;
  static const double radiusXL = 28.0;
  static const double radiusFull = 999.0;

  // ── Durées d'animation ──────────────────────
  static const Duration animFast   = Duration(milliseconds: 200);
  static const Duration animNormal = Duration(milliseconds: 350);
  static const Duration animSlow   = Duration(milliseconds: 600);

  // ── Typographie ─────────────────────────────
  static TextStyle headingXL = GoogleFonts.poppins(
    fontSize: 32,
    fontWeight: FontWeight.w800,
    color: textPrimary,
    letterSpacing: -0.5,
    height: 1.2,
  );

  static TextStyle headingLG = GoogleFonts.poppins(
    fontSize: 24,
    fontWeight: FontWeight.w700,
    color: textPrimary,
    letterSpacing: -0.3,
    height: 1.3,
  );

  static TextStyle headingMD = GoogleFonts.poppins(
    fontSize: 18,
    fontWeight: FontWeight.w700,
    color: textPrimary,
    height: 1.3,
  );

  static TextStyle headingSM = GoogleFonts.poppins(
    fontSize: 15,
    fontWeight: FontWeight.w600,
    color: textPrimary,
    height: 1.4,
  );

  static TextStyle bodyLG = GoogleFonts.poppins(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    color: textPrimary,
    height: 1.6,
  );

  static TextStyle bodyMD = GoogleFonts.poppins(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: textSecondary,
    height: 1.5,
  );

  static TextStyle bodySM = GoogleFonts.poppins(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: textSecondary,
    height: 1.5,
  );

  static TextStyle labelLG = GoogleFonts.poppins(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: textPrimary,
    letterSpacing: 0.3,
  );

  static TextStyle labelMD = GoogleFonts.poppins(
    fontSize: 12,
    fontWeight: FontWeight.w600,
    color: textSecondary,
    letterSpacing: 0.3,
  );

  static TextStyle labelSM = GoogleFonts.poppins(
    fontSize: 10,
    fontWeight: FontWeight.w500,
    color: textLight,
    letterSpacing: 0.5,
  );

  static TextStyle buttonText = GoogleFonts.poppins(
    fontSize: 16,
    fontWeight: FontWeight.w700,
    color: textOnDark,
    letterSpacing: 0.4,
  );

  // ── ThemeData global ────────────────────────
  static ThemeData get themeData => ThemeData(
    useMaterial3: true,
    fontFamily: GoogleFonts.poppins().fontFamily,
    colorScheme: ColorScheme.fromSeed(
      seedColor: turquoise,
      primary: navy,
      secondary: turquoise,
      tertiary: cyan,
      surface: surface,
      error: danger,
    ),
    scaffoldBackgroundColor: surface,
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      iconTheme: const IconThemeData(color: navy),
      titleTextStyle: headingMD.copyWith(color: navy),
    ),
    cardTheme: CardThemeData(
      color: card,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusLG),
        side: const BorderSide(color: border, width: 1),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMD),
        borderSide: const BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMD),
        borderSide: const BorderSide(color: border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMD),
        borderSide: const BorderSide(color: turquoise, width: 1.8),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: turquoise,
        foregroundColor: textOnDark,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMD),
        ),
        textStyle: buttonText,
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: turquoise,
        textStyle: labelLG.copyWith(color: turquoise),
      ),
    ),
    dividerTheme: const DividerThemeData(
      color: border,
      thickness: 1,
      space: 0,
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: navy,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusSM),
      ),
      contentTextStyle: bodySM.copyWith(color: textOnDark),
    ),
  );
}

/// ─────────────────────────────────────────────
///  Composants réutilisables v2.0
/// ─────────────────────────────────────────────

// ── Bouton gradient principal ──────────────────
class KGradientButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final IconData? icon;
  final LinearGradient? gradient;
  final double? width;
  final double height;
  final bool isLoading;

  const KGradientButton({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.gradient,
    this.width,
    this.height = 54,
    this.isLoading = false,
  });

  @override
  State<KGradientButton> createState() => _KGradientButtonState();
}

class _KGradientButtonState extends State<KGradientButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final grad = widget.gradient ?? KTheme.ctaGradient;
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) => Transform.scale(
          scale: _scaleAnimation.value,
          child: child,
        ),
        child: Container(
          width: widget.width ?? double.infinity,
          height: widget.height,
          decoration: BoxDecoration(
            gradient: grad,
            borderRadius: BorderRadius.circular(KTheme.radiusMD),
            boxShadow: KTheme.elevationColored(
              grad.colors.first,
            ),
          ),
          child: Center(
            child: widget.isLoading
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (widget.icon != null) ...[
                        Icon(widget.icon, color: Colors.white, size: 20),
                        const SizedBox(width: 10),
                      ],
                      Text(
                        widget.label,
                        style: KTheme.buttonText,
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

// ── Carte avec glassmorphism ───────────────────
class KGlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double? width;
  final double borderRadius;
  final Color? backgroundColor;
  final double blur;

  const KGlassCard({
    super.key,
    required this.child,
    this.padding,
    this.width,
    this.borderRadius = KTheme.radiusLG,
    this.backgroundColor,
    this.blur = 10,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          width: width,
          padding: padding ?? const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: backgroundColor ?? Colors.white.withOpacity(0.12),
            borderRadius: BorderRadius.circular(borderRadius),
            border: Border.all(
              color: Colors.white.withOpacity(0.15),
              width: 1,
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}

// ── Carte animée (avec scale au tap) ───────────
class KAnimatedCard extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final BoxDecoration? decoration;

  const KAnimatedCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding,
    this.margin,
    this.decoration,
  });

  @override
  State<KAnimatedCard> createState() => _KAnimatedCardState();
}

class _KAnimatedCardState extends State<KAnimatedCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.97).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onTap != null ? (_) => _controller.forward() : null,
      onTapUp: widget.onTap != null
          ? (_) {
              _controller.reverse();
              widget.onTap!();
            }
          : null,
      onTapCancel:
          widget.onTap != null ? () => _controller.reverse() : null,
      child: AnimatedBuilder(
        animation: _scaleAnim,
        builder: (context, child) => Transform.scale(
          scale: _scaleAnim.value,
          child: child,
        ),
        child: Container(
          padding: widget.padding ?? const EdgeInsets.all(16),
          margin: widget.margin,
          decoration: widget.decoration ??
              BoxDecoration(
                color: KTheme.card,
                borderRadius: BorderRadius.circular(KTheme.radiusLG),
                border: Border.all(color: KTheme.border),
                boxShadow: KTheme.elevationLow,
              ),
          child: widget.child,
        ),
      ),
    );
  }
}

// ── Section Header ─────────────────────────────
class KSectionHeader extends StatelessWidget {
  final String title;
  final IconData? icon;
  final Widget? trailing;

  const KSectionHeader({
    super.key,
    required this.title,
    this.icon,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 22,
            decoration: BoxDecoration(
              gradient: KTheme.ctaGradient,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          if (icon != null) ...[
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: KTheme.turquoise.withOpacity(0.12),
                borderRadius: BorderRadius.circular(KTheme.radiusXS),
              ),
              child: Icon(icon, size: 16, color: KTheme.turquoise),
            ),
            const SizedBox(width: 8),
          ],
          Expanded(
            child: Text(title, style: KTheme.headingSM),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

// ── Status Badge ───────────────────────────────
class KStatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;

  const KStatusBadge({
    super.key,
    required this.label,
    required this.color,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(KTheme.radiusFull),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: KTheme.labelSM.copyWith(
              color: color,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Input Field unifié ─────────────────────────
class KInputField extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode? focusNode;
  final String hint;
  final IconData? prefixIcon;
  final Widget? suffixIcon;
  final bool obscureText;
  final bool isFocused;
  final TextInputType? keyboardType;
  final String? Function(String?)? validator;

  const KInputField({
    super.key,
    required this.controller,
    this.focusNode,
    required this.hint,
    this.prefixIcon,
    this.suffixIcon,
    this.obscureText = false,
    this.isFocused = false,
    this.keyboardType,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: KTheme.animFast,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        color: isFocused ? Colors.white : KTheme.surface,
        border: Border.all(
          color: isFocused ? KTheme.turquoise : KTheme.border,
          width: isFocused ? 1.8 : 1.2,
        ),
        boxShadow: isFocused
            ? [
                BoxShadow(
                  color: KTheme.turquoise.withOpacity(0.18),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
              ]
            : [],
      ),
      child: TextFormField(
        controller: controller,
        focusNode: focusNode,
        obscureText: obscureText,
        keyboardType: keyboardType,
        validator: validator,
        style: GoogleFonts.poppins(
          fontSize: 15,
          color: KTheme.textPrimary,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          border: InputBorder.none,
          prefixIcon: prefixIcon != null
              ? Padding(
                  padding: const EdgeInsets.only(left: 16, right: 12),
                  child: Icon(
                    prefixIcon,
                    color: isFocused ? KTheme.turquoise : KTheme.textLight,
                    size: 22,
                  ),
                )
              : null,
          suffixIcon: suffixIcon,
          hintText: hint,
          hintStyle: GoogleFonts.poppins(
            color: KTheme.textLight,
            fontSize: 15,
            fontWeight: FontWeight.w400,
          ),
          contentPadding:
              const EdgeInsets.symmetric(vertical: 17, horizontal: 20),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════
//  Legacy Components (mis à jour avec palette v2)
// ═══════════════════════════════════════════════

// AppBar personnalisée pour toutes les pages détail
class KAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final IconData icon;
  final Color? iconColor;

  const KAppBar({
    super.key,
    required this.title,
    required this.icon,
    this.iconColor,
  });

  @override
  Size get preferredSize => const Size.fromHeight(70);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        boxShadow: KTheme.elevationLow,
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              // Bouton retour
              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: KTheme.surface,
                    borderRadius: BorderRadius.circular(KTheme.radiusXS),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      size: 18, color: KTheme.navy),
                ),
              ),
              const SizedBox(width: 14),
              // Icône catégorie
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: KTheme.turquoise.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(KTheme.radiusXS),
                ),
                child:
                    Icon(icon, size: 20, color: iconColor ?? KTheme.turquoise),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: KTheme.headingSM,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Badge « Recommandé »
class KBadgeRecommande extends StatelessWidget {
  const KBadgeRecommande({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: KTheme.yellow.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: KTheme.yellow.withOpacity(0.4)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.star_rounded, size: 12, color: KTheme.yellow),
          SizedBox(width: 4),
          Text(
            'Recommandé',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: KTheme.yellow,
            ),
          ),
        ],
      ),
    );
  }
}

// Ligne de spécification
class KSpecRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const KSpecRow({
    super.key,
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: KTheme.turquoise.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 14, color: KTheme.turquoise),
          ),
          const SizedBox(width: 10),
          Text(
            '$label:',
            style: KTheme.labelMD,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: KTheme.bodySM.copyWith(color: KTheme.textPrimary),
            ),
          ),
        ],
      ),
    );
  }
}

// Prix tag
class KPriceTag extends StatelessWidget {
  final double prix;
  final double fontSize;

  const KPriceTag({super.key, required this.prix, this.fontSize = 16});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: KTheme.successSoft,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        '${prix.toStringAsFixed(2)} TND',
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.w800,
          color: KTheme.success,
        ),
      ),
    );
  }
}

// Image produit avec fallback
class KProductImage extends StatelessWidget {
  final String imageUrl;
  final double size;
  final IconData fallbackIcon;

  const KProductImage({
    super.key,
    required this.imageUrl,
    this.size = 90,
    this.fallbackIcon = Icons.category_rounded,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(KTheme.radiusMD),
      child: Image.network(
        imageUrl,
        height: size,
        width: size,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => Container(
          height: size,
          width: size,
          decoration: BoxDecoration(
            color: KTheme.turquoise.withOpacity(0.08),
            borderRadius: BorderRadius.circular(KTheme.radiusMD),
          ),
          child: Icon(fallbackIcon,
              size: size * 0.45, color: KTheme.turquoise.withOpacity(0.3)),
        ),
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            height: size,
            width: size,
            decoration: BoxDecoration(
              color: KTheme.surface,
              borderRadius: BorderRadius.circular(KTheme.radiusMD),
            ),
            child: Center(
              child: CircularProgressIndicator(
                value: loadingProgress.expectedTotalBytes != null
                    ? loadingProgress.cumulativeBytesLoaded /
                        loadingProgress.expectedTotalBytes!
                    : null,
                strokeWidth: 2,
                color: KTheme.turquoise,
              ),
            ),
          );
        },
      ),
    );
  }
}

// État vide
class KEmptyState extends StatelessWidget {
  final String message;
  final IconData icon;

  const KEmptyState({
    super.key,
    required this.message,
    this.icon = Icons.search_off_rounded,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: KTheme.turquoise.withOpacity(0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(icon,
                  size: 52, color: KTheme.turquoise.withOpacity(0.4)),
            ),
            const SizedBox(height: 20),
            Text(
              message,
              style: KTheme.bodyMD,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// État d'erreur
class KErrorState extends StatelessWidget {
  final String error;
  final VoidCallback? onRetry;

  const KErrorState({super.key, required this.error, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline_rounded,
                size: 52, color: KTheme.danger),
            const SizedBox(height: 16),
            Text(error,
                style: KTheme.bodyMD, textAlign: TextAlign.center),
            if (onRetry != null) ...[
              const SizedBox(height: 20),
              KGradientButton(
                label: 'Réessayer',
                icon: Icons.refresh_rounded,
                onTap: onRetry!,
                width: 160,
                height: 44,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// Séparateur de section (legacy)
class KSectionTitle extends StatelessWidget {
  final String title;
  final IconData? icon;

  const KSectionTitle({super.key, required this.title, this.icon});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, size: 18, color: KTheme.turquoise),
            const SizedBox(width: 8),
          ],
          Text(
            title,
            style: KTheme.headingSM.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1.5,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    KTheme.turquoise.withOpacity(0.25),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:carhabti/magasin_model/pneus_categorie.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';
import 'DetailHuilePage.dart';
import 'DetailEssuie_glacesPage.dart';
import 'FiltreDetailsPage.dart';
import 'FreinsDetailsPage.dart';
import 'CourroieDetailsPage.dart';
import 'BatterieDetailsPage.dart';
import 'AmortisseursDetailsPage.dart';
import 'EmbrayageDetailsPage.dart';

void main() {
  runApp(const Categorie());
}

class Categorie extends StatelessWidget {
  final String? immatriculation;

  const Categorie({super.key, this.immatriculation});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CARHABTI',
      theme: KTheme.themeData,
      home: AutoPartsList(immatriculation: immatriculation),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Données statiques des catégories
// ─────────────────────────────────────────────────────────────────────────────

class _PartCategory {
  final String name;
  final IconData icon;
  final Color accentColor;
  final String subtitle;

  const _PartCategory({
    required this.name,
    required this.icon,
    required this.accentColor,
    required this.subtitle,
  });
}

const List<_PartCategory> _autoParts = [
  _PartCategory(
    name: 'Plaquettes de frein',
    icon: Icons.stop_circle_outlined,
    accentColor: Color(0xFFE63946),
    subtitle: 'Freinage & sécurité',
  ),
  _PartCategory(
    name: 'Courroie de distribution',
    icon: Icons.settings_input_component_rounded,
    accentColor: Color(0xFF1B4332),
    subtitle: 'Moteur & transmission',
  ),
  _PartCategory(
    name: 'Filtres',
    icon: Icons.filter_alt_outlined,
    accentColor: Color(0xFF457B9D),
    subtitle: 'Filtration & entretien',
  ),
  _PartCategory(
    name: 'Huile/Accessoires vidange',
    icon: Icons.oil_barrel_outlined,
    accentColor: Color(0xFFF4A225),
    subtitle: 'Lubrification moteur',
  ),
  _PartCategory(
    name: 'Liquide de refroidissement',
    icon: Icons.water_drop_outlined,
    accentColor: Color(0xFF0077B6),
    subtitle: 'Gestion thermique',
  ),
  _PartCategory(
    name: 'Embrayage',
    icon: Icons.settings_backup_restore_rounded,
    accentColor: Color(0xFF023E8A),
    subtitle: 'Transmission manuelle',
  ),
  _PartCategory(
    name: 'Batteries',
    icon: Icons.battery_charging_full_rounded,
    accentColor: Color(0xFF1A1A2E),
    subtitle: 'Alimentation électrique',
  ),
  _PartCategory(
    name: 'Amortisseurs',
    icon: Icons.shutter_speed_outlined,
    accentColor: Color(0xFF4A1942),
    subtitle: 'Suspension & confort',
  ),
  _PartCategory(
    name: 'Pneus',
    icon: Icons.tire_repair_outlined,
    accentColor: Color(0xFF2D2D2D),
    subtitle: 'Pneumatiques & jantes',
  ),
];

// ─────────────────────────────────────────────────────────────────────────────
//  Widget principal
// ─────────────────────────────────────────────────────────────────────────────

class AutoPartsList extends StatefulWidget {
  final String? immatriculation;

  const AutoPartsList({super.key, this.immatriculation});

  @override
  State<AutoPartsList> createState() => _AutoPartsListState();
}

class _AutoPartsListState extends State<AutoPartsList> {
  Map<String, List<int>> affectationPieces = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    if (widget.immatriculation != null) {
      _fetchAffectationPieces();
    } else {
      setState(() => isLoading = false);
    }
  }

  // ── Supabase ───────────────────────────────────────────────────────────────

  Future<void> _fetchAffectationPieces() async {
    try {
      final affResp = await Supabase.instance.client
          .from('affectation_pieces')
          .select('id')
          .eq('fk_immatriculation', widget.immatriculation!);

      if (affResp.isEmpty) {
        setState(() { isLoading = false; affectationPieces = {}; });
        return;
      }

      final int affId = affResp[0]['id'] as int;

      Future<List<int>> ids(String table, String col) async {
        final r = await Supabase.instance.client
            .from(table)
            .select(col)
            .eq('fk_affectation_id', affId);
        return r.map<int>((item) => item[col] as int).toList();
      }

      // Refroidissement retourne des strings dans certains cas
      final refResp = await Supabase.instance.client
          .from('affectation_refroidissement')
          .select('fk_refroidissement_id')
          .eq('fk_affectation_id', affId);
      final refIds = refResp
          .map((i) => int.tryParse(i['fk_refroidissement_id'].toString()) ?? 0)
          .where((id) => id > 0)
          .toList();

      final results = await Future.wait([
        ids('affectation_pneus',        'fk_pneu_id'),
        ids('affectation_batterie',     'fk_batterie_id'),
        ids('affectation_amortisseurs', 'fk_amortisseur_id'),
        ids('affectation_freins',       'fk_frein_id'),
        ids('affectation_courroie',     'fk_courroie_id'),
        ids('affectation_huile_moteur', 'fk_huile_moteur_id'),
        ids('affectation_filtres',      'fk_filtre_id'),
        ids('affectation_embrayage',    'fk_embrayage_id'),
      ]);

      setState(() {
        affectationPieces = {
          'pneus':          results[0],
          'batterie':       results[1],
          'amortisseurs':   results[2],
          'freins':         results[3],
          'courroie':       results[4],
          'huile_moteur':   results[5],
          'refroidissement': refIds,
          'filtres':        results[6],
          'embrayage':      results[7],
        };
        isLoading = false;
      });
    } catch (e) {
      debugPrint('Erreur affectation: $e');
      setState(() => isLoading = false);
    }
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        backgroundColor: KTheme.surface,
        body: Center(
          child: CircularProgressIndicator(
            color: KTheme.navy,
            strokeWidth: 2.5,
          ),
        ),
      );
    }

    if (affectationPieces.isEmpty && widget.immatriculation != null) {
      return Scaffold(
        backgroundColor: KTheme.surface,
        appBar: _buildAppBar(),
        body: const KEmptyState(
          message: 'Aucune pièce associée\nà cette immatriculation.',
          icon: Icons.car_repair_rounded,
        ),
      );
    }

    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          // ── Info immatriculation ──
          if (widget.immatriculation != null) _buildImmatBanner(),
          // ── Liste animée ──
          Expanded(
            child: AnimationLimiter(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
                itemCount: _autoParts.length,
                itemBuilder: (context, index) {
                  return AnimationConfiguration.staggeredList(
                    position: index,
                    duration: const Duration(milliseconds: 500),
                    child: SlideAnimation(
                      verticalOffset: 24.0,
                      child: FadeInAnimation(
                        child: _CategoryCard(
                          category: _autoParts[index],
                          onTap: () => _navigate(context, _autoParts[index].name),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(72),
      child: Container(
        decoration: BoxDecoration(
          color: KTheme.card,
          boxShadow: KTheme.subtleShadow,
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            child: Row(
              children: [
                // Logo
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: KTheme.navy,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.directions_car_rounded,
                      color: Colors.white, size: 20),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'CARHABTI',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: KTheme.navy,
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      'Pièces détachées',
                      style: TextStyle(
                        fontSize: 11,
                        color: KTheme.textSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: KTheme.accentSoft,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${_autoParts.length} catégories',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: KTheme.accent,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildImmatBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: KTheme.navy,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
      ),
      child: Row(
        children: [
          const Icon(Icons.badge_outlined, color: Colors.white70, size: 18),
          const SizedBox(width: 10),
          const Text(
            'Immatriculation :',
            style: TextStyle(
              color: Colors.white60,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            widget.immatriculation!,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  // ── Navigation ─────────────────────────────────────────────────────────────

  void _navigate(BuildContext context, String name) {
    switch (name) {
      case 'Huile/Accessoires vidange':
        Navigator.push(context, _route(DetailHuilePage(
          huileIds: affectationPieces['huile_moteur'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Filtres':
        Navigator.push(context, _route(FiltreDetailsPage(
          filtreIds: affectationPieces['filtres'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Liquide de refroidissement':
        Navigator.push(context, _route(DetailEssuie_glacesPage(
          refroidissementIds: affectationPieces['refroidissement'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Pneus':
        Navigator.push(context, _route(PneusCategorie(
          pneuIds: affectationPieces['pneus'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Plaquettes de frein':
        Navigator.push(context, _route(FreinsDetailsPage(
          freinIds: affectationPieces['freins'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Courroie de distribution':
        Navigator.push(context, _route(CourroieDetailsPage(
          courroieIds: affectationPieces['courroie'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Batteries':
        Navigator.push(context, _route(BatterieDetailsPage(
          batterieIds: affectationPieces['batterie'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Amortisseurs':
        Navigator.push(context, _route(AmortisseursDetailsPage(
          amortisseurIds: affectationPieces['amortisseurs'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      case 'Embrayage':
        Navigator.push(context, _route(EmbrayageDetailsPage(
          embrayageIds: affectationPieces['embrayage'] ?? [],
          immatriculation: widget.immatriculation,
        )));

      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$name – bientôt disponible'),
            behavior: SnackBarBehavior.floating,
            backgroundColor: KTheme.navy,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
          ),
        );
    }
  }

  PageRoute _route(Widget page) => MaterialPageRoute(builder: (_) => page);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Carte catégorie
// ─────────────────────────────────────────────────────────────────────────────

class _CategoryCard extends StatelessWidget {
  final _PartCategory category;
  final VoidCallback onTap;

  const _CategoryCard({required this.category, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(KTheme.radiusLG),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                // ── Icône ──
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: category.accentColor.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    category.icon,
                    color: category.accentColor,
                    size: 26,
                  ),
                ),
                const SizedBox(width: 14),

                // ── Texte ──
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        category.name,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: KTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        category.subtitle,
                        style: const TextStyle(
                          fontSize: 12,
                          color: KTheme.textSecondary,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),

                // ── Flèche ──
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: category.accentColor.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.chevron_right_rounded,
                    color: category.accentColor,
                    size: 20,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

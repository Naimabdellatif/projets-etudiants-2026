// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'carhabti_theme.dart';

// ─── Modèle ──────────────────────────────────────────────────────────────────

class Courroie {
  final int id;
  final String imageUrl;
  final String reference;
  final String marque;
  final String nom;
  final double prix;
  final String? type;             // ex: "Kit complet", "Courroie seule"
  final int? nombreDents;
  final double? longueur;         // mm
  final double? largeur;          // mm
  final String? paysConstructeur;
  final int? intervalleRemplacement; // km

  const Courroie({
    required this.id,
    required this.imageUrl,
    required this.reference,
    required this.marque,
    required this.nom,
    required this.prix,
    this.type,
    this.nombreDents,
    this.longueur,
    this.largeur,
    this.paysConstructeur,
    this.intervalleRemplacement,
  });

  factory Courroie.fromMap(Map<String, dynamic> map) {
    return Courroie(
      id:                     map['id'] as int,
      imageUrl:               (map['image_url'] as String?) ?? '',
      reference:              (map['reference'] as String?) ?? '',
      marque:                 (map['marque'] as String?) ?? '',
      nom:                    (map['nom'] as String?) ?? '',
      prix:                   (map['prix'] as num).toDouble(),
      type:                   map['type'] as String?,
      nombreDents:            map['nombre_dents'] as int?,
      longueur:               (map['longueur'] as num?)?.toDouble(),
      largeur:                (map['largeur'] as num?)?.toDouble(),
      paysConstructeur:       map['pays_constructeur'] as String?,
      intervalleRemplacement: map['intervalle_remplacement'] as int?,
    );
  }
}

// ─── Page principale ─────────────────────────────────────────────────────────

class CourroieDetailsPage extends StatefulWidget {
  final List<int> courroieIds;
  final String? immatriculation;

  const CourroieDetailsPage({
    super.key,
    this.courroieIds = const [],
    this.immatriculation,
  });

  @override
  State<CourroieDetailsPage> createState() => _CourroieDetailsPageState();
}

class _CourroieDetailsPageState extends State<CourroieDetailsPage> {
  List<Courroie> _courroies = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      if (widget.courroieIds.isEmpty) {
        setState(() => _isLoading = false);
        return;
      }
      final res = await Supabase.instance.client
          .from('courroie')
          .select()
          .inFilter('id', widget.courroieIds);
      setState(() {
        _courroies = res.map<Courroie>((m) => Courroie.fromMap(m)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      appBar: KAppBar(
        title: 'Courroie de distribution',
        icon: Icons.settings_input_component_rounded,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: KTheme.navy, strokeWidth: 2.5));
    }
    if (_error != null) return KErrorState(error: _error!, onRetry: _fetch);
    if (_courroies.isEmpty) {
      return const KEmptyState(
        message: 'Aucune courroie de distribution trouvée\npour ce véhicule.',
        icon: Icons.settings_input_component_rounded,
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        _PrimaryCard(courroie: _courroies.first),
        if (_courroies.length > 1) ...[
          const SizedBox(height: 28),
          const KSectionTitle(
            title: 'Alternatives recommandées',
            icon: Icons.compare_arrows_rounded,
          ),
          ..._courroies.skip(1).map((c) => _SecondaryCard(courroie: c)),
        ],
      ],
    );
  }
}

// ─── Alerte intervalle de remplacement ───────────────────────────────────────

class _IntervalleAlert extends StatelessWidget {
  final int km;
  const _IntervalleAlert({required this.km});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: KTheme.gold.withOpacity(0.10),
        borderRadius: BorderRadius.circular(KTheme.radiusSM),
        border: Border.all(color: KTheme.gold.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: KTheme.gold, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'À remplacer tous les ${_formatKm(km)}',
              style: const TextStyle(
                color: KTheme.gold,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatKm(int km) {
    if (km >= 1000) {
      return '${(km / 1000).toStringAsFixed(0)} 000 km';
    }
    return '$km km';
  }
}

// ─── Carte principale ─────────────────────────────────────────────────────────

class _PrimaryCard extends StatelessWidget {
  final Courroie courroie;
  const _PrimaryCard({required this.courroie});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusLG),
        boxShadow: KTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── En-tête ──
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1B4332), Color(0xFF2D6A4F)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(KTheme.radiusLG),
                topRight: Radius.circular(KTheme.radiusLG),
              ),
            ),
            child: Row(
              children: [
                KProductImage(
                  imageUrl: courroie.imageUrl,
                  size: 88,
                  fallbackIcon: Icons.settings_input_component_rounded,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const KBadgeRecommande(),
                      const SizedBox(height: 8),
                      Text(
                        courroie.marque,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        courroie.nom,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.75),
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Réf: ${courroie.reference}',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.55),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Corps ──
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    KPriceTag(prix: courroie.prix, fontSize: 18),
                    if (courroie.intervalleRemplacement != null) ...[
                      const SizedBox(width: 12),
                      Expanded(
                        child: _IntervalleAlert(
                            km: courroie.intervalleRemplacement!),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 18),
                const Divider(height: 1),
                const SizedBox(height: 18),
                if (courroie.type != null)
                  KSpecRow(
                    icon: Icons.category_outlined,
                    label: 'Type',
                    value: courroie.type!,
                  ),
                if (courroie.nombreDents != null)
                  KSpecRow(
                    icon: Icons.sync_alt_rounded,
                    label: 'Nombre de dents',
                    value: '${courroie.nombreDents}',
                  ),
                if (courroie.longueur != null)
                  KSpecRow(
                    icon: Icons.straighten_rounded,
                    label: 'Longueur',
                    value: '${courroie.longueur} mm',
                  ),
                if (courroie.largeur != null)
                  KSpecRow(
                    icon: Icons.width_normal_rounded,
                    label: 'Largeur',
                    value: '${courroie.largeur} mm',
                  ),
                if (courroie.paysConstructeur != null)
                  KSpecRow(
                    icon: Icons.public_rounded,
                    label: 'Fabrication',
                    value: courroie.paysConstructeur!,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Carte secondaire ─────────────────────────────────────────────────────────

class _SecondaryCard extends StatelessWidget {
  final Courroie courroie;
  const _SecondaryCard({required this.courroie});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: KTheme.card,
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        boxShadow: KTheme.subtleShadow,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          KProductImage(
            imageUrl: courroie.imageUrl,
            size: 72,
            fallbackIcon: Icons.settings_input_component_rounded,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(courroie.marque,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 15,
                        color: KTheme.textPrimary)),
                const SizedBox(height: 2),
                Text(courroie.nom,
                    style: const TextStyle(
                        fontSize: 12, color: KTheme.textSecondary)),
                const SizedBox(height: 6),
                KPriceTag(prix: courroie.prix, fontSize: 13),
                if (courroie.type != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('Type: ${courroie.type}',
                        style: const TextStyle(
                            fontSize: 12, color: KTheme.textSecondary)),
                  ),
                if (courroie.nombreDents != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text('${courroie.nombreDents} dents',
                        style: const TextStyle(
                            fontSize: 12, color: KTheme.textSecondary)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

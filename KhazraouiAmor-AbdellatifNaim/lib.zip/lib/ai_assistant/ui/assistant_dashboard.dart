// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

import '../services/gemini_ai_service.dart';

// Palette
const _kPrimary = Color(0xFF1E3A5F);
const _kAccent = Color(0xFF4E6AFF);
const _kSecondary = Color(0xFF00C6A2);
const _kBg = Color(0xFFF0F4F8);

class MechanicAssistantDashboard extends StatefulWidget {
  final String immatriculation;

  const MechanicAssistantDashboard({super.key, required this.immatriculation});

  @override
  State<MechanicAssistantDashboard> createState() =>
      _MechanicAssistantDashboardState();
}

class _MechanicAssistantDashboardState
    extends State<MechanicAssistantDashboard> with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  bool _serviceConfigured = false;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
    _serviceConfigured = GeminiAiService().isConfigured;
    HapticFeedback.lightImpact();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        title: Text(
          'Assistant IA Carhabti',
          style: GoogleFonts.montserrat(
              fontWeight: FontWeight.w700, fontSize: 18.sp),
        ),
        centerTitle: true,
        backgroundColor: _kPrimary,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(16)),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_rounded),
            tooltip: 'Paramètres',
            onPressed: _goToSettings,
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeCtrl,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.all(16.r),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeroCard().animate().slideY(begin: -0.1, duration: 500.ms),
              SizedBox(height: 24.h),
              _buildStatusBanner().animate().fadeIn(delay: 150.ms),
              SizedBox(height: 24.h),
              _buildFeatureGrid().animate().fadeIn(delay: 250.ms),
              SizedBox(height: 24.h),
              _buildCapabilitiesCard().animate().fadeIn(delay: 350.ms),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Hero Card
  // ---------------------------------------------------------------------------

  Widget _buildHeroCard() {
    return Container(
      padding: EdgeInsets.all(24.r),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_kPrimary, _kAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24.r),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'CARHABTI-AI',
                  style: GoogleFonts.montserrat(
                    fontSize: 22.sp,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 1,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  'Votre assistant automobile intelligent, alimenté par Google Gemini 2.0 Flash',
                  style: GoogleFonts.montserrat(
                    fontSize: 13.sp,
                    color: Colors.white.withOpacity(0.88),
                    height: 1.5,
                  ),
                ),
                SizedBox(height: 20.h),
                _buildStartButton(),
              ],
            ),
          ),
          SizedBox(width: 16.w),
          SizedBox(
            width: 80.w,
            height: 80.h,
            child: Lottie.asset(
              'assets/chatbotIcon.json',
              errorBuilder: (_, __, ___) => const Icon(
                Icons.smart_toy_rounded,
                color: Colors.white,
                size: 48,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStartButton() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: _goToChat,
        borderRadius: BorderRadius.circular(30),
        child: Ink(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.15),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.chat_bubble_rounded, color: _kAccent, size: 18.sp),
                SizedBox(width: 8.w),
                Text(
                  'Démarrer une conversation',
                  style: GoogleFonts.montserrat(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w700,
                    color: _kPrimary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Bannière de statut
  // ---------------------------------------------------------------------------

  Widget _buildStatusBanner() {
    final isOk = _serviceConfigured;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: isOk
            ? const Color(0xFFE8F5E9)
            : const Color(0xFFFFF3E0),
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(
          color: isOk ? Colors.green.shade300 : Colors.orange.shade300,
        ),
      ),
      child: Row(
        children: [
          Icon(
            isOk ? Icons.check_circle_rounded : Icons.warning_amber_rounded,
            color: isOk ? Colors.green.shade700 : Colors.orange.shade800,
            size: 22.sp,
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isOk ? 'Assistant opérationnel' : 'Configuration requise',
                  style: GoogleFonts.montserrat(
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w700,
                    color: isOk ? Colors.green.shade800 : Colors.orange.shade900,
                  ),
                ),
                Text(
                  isOk
                      ? 'Gemini 2.0 Flash · Véhicule : ${widget.immatriculation}'
                      : 'Ajoutez GEMINI_API_KEY dans le fichier .env',
                  style: GoogleFonts.montserrat(
                    fontSize: 11.sp,
                    color: isOk ? Colors.green.shade700 : Colors.orange.shade800,
                  ),
                ),
              ],
            ),
          ),
          if (!isOk)
            TextButton(
              onPressed: _goToSettings,
              child: Text(
                'Configurer',
                style: GoogleFonts.montserrat(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w700,
                  color: Colors.orange.shade800,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Grille de fonctionnalités
  // ---------------------------------------------------------------------------

  Widget _buildFeatureGrid() {
    final features = [
      (
        Icons.chat_bubble_outline_rounded,
        'Discussion',
        'Posez vos questions en FR, AR ou dialecte 🇹🇳',
        _kAccent,
        _goToChat,
      ),
      (
        Icons.build_circle_outlined,
        'Diagnostic',
        'Analysez les symptômes et obtenez des conseils',
        const Color(0xFFFF6B6B),
        _goToChat,
      ),
      (
        Icons.timeline_rounded,
        'Usure des pièces',
        'Interprétation des prédictions en langage clair',
        _kSecondary,
        _goToChat,
      ),
      (
        Icons.settings_rounded,
        'Paramètres IA',
        'Gérez l\'historique et la configuration',
        const Color(0xFFFF9800),
        _goToSettings,
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Fonctionnalités',
          style: GoogleFonts.montserrat(
            fontSize: 17.sp,
            fontWeight: FontWeight.w700,
            color: _kPrimary,
          ),
        ),
        SizedBox(height: 14.h),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12.w,
          mainAxisSpacing: 12.h,
          childAspectRatio: 1.1,
          children: features.asMap().entries.map((e) {
            final (icon, title, desc, color, onTap) = e.value;
            return _FeatureCard(
              icon: icon,
              title: title,
              description: desc,
              color: color,
              onTap: onTap,
            );
          }).toList(),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Carte des capacités
  // ---------------------------------------------------------------------------

  Widget _buildCapabilitiesCard() {
    final items = [
      (Icons.translate_rounded, 'Français, Arabe, Dialecte tunisien'),
      (Icons.history_rounded, 'Mémoire conversationnelle persistée'),
      (Icons.speed_rounded, 'Réponses rapides — Gemini 2.0 Flash'),
      (Icons.lock_rounded, 'Sécurisé — clé API stockée en local'),
      (Icons.cloud_off_rounded, 'Fonctionne avec n\'importe quelle connexion'),
    ];

    return Container(
      padding: EdgeInsets.all(20.r),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.12),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'À propos de CARHABTI-AI',
            style: GoogleFonts.montserrat(
              fontSize: 16.sp,
              fontWeight: FontWeight.w700,
              color: _kPrimary,
            ),
          ),
          SizedBox(height: 16.h),
          ...items.map((item) {
            final (icon, text) = item;
            return Padding(
              padding: EdgeInsets.only(bottom: 12.h),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8.r),
                    decoration: BoxDecoration(
                      color: _kAccent.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10.r),
                    ),
                    child: Icon(icon, color: _kAccent, size: 18.sp),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Text(
                      text,
                      style: GoogleFonts.montserrat(
                        fontSize: 13.sp,
                        color: Colors.grey.shade800,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Navigation
  // ---------------------------------------------------------------------------

  void _goToChat() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(
      context,
      '/mechanicAssistant/chat',
      arguments: widget.immatriculation,
    );
  }

  void _goToSettings() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(
      context,
      '/mechanicAssistant/modelManagement',
      arguments: widget.immatriculation,
    );
  }
}

// ---------------------------------------------------------------------------
// Carte de fonctionnalité
// ---------------------------------------------------------------------------

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final Color color;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(0.15)),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.12),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const Spacer(),
            Text(
              title,
              style: GoogleFonts.montserrat(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: const Color(0xFF1E3A5F),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.montserrat(
                fontSize: 11,
                color: Colors.grey.shade600,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

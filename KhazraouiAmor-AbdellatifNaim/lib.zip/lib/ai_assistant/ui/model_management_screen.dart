// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import '../services/gemini_ai_service.dart';
import '../services/conversation_history_service.dart';

const _kPrimary = Color(0xFF1E3A5F);
const _kAccent = Color(0xFF4E6AFF);
const _kBg = Color(0xFFF0F4F8);

/// Écran des paramètres et informations de l'assistant IA
class ModelManagementScreen extends StatefulWidget {
  const ModelManagementScreen({super.key});

  @override
  State<ModelManagementScreen> createState() => _ModelManagementScreenState();
}

class _ModelManagementScreenState extends State<ModelManagementScreen> {
  final GeminiAiService _aiService = GeminiAiService();
  String _vehicleId = '';
  int _historyCount = 0;
  bool _isLoading = false;

  // Etat de la clé API (masquée par défaut)
  bool _showApiKey = false;
  String _apiKeyDisplay = '';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is String && args.isNotEmpty) {
      _vehicleId = args;
      _loadStats();
    }
    _loadApiKeyInfo();
  }

  Future<void> _loadStats() async {
    if (_vehicleId.isEmpty) return;
    final count = await _aiService.getHistoryCount(_vehicleId);
    if (mounted) setState(() => _historyCount = count);
  }

  void _loadApiKeyInfo() {
    try {
      final key = dotenv.env['GEMINI_API_KEY'] ?? '';
      if (key.isEmpty) {
        _apiKeyDisplay = 'Non configurée';
      } else if (key.length > 8) {
        _apiKeyDisplay = '${key.substring(0, 6)}••••••••${key.substring(key.length - 4)}';
      } else {
        _apiKeyDisplay = '••••••••';
      }
    } catch (_) {
      _apiKeyDisplay = 'Non disponible';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        title: Text(
          'Paramètres Assistant IA',
          style: GoogleFonts.montserrat(
              fontWeight: FontWeight.w700, fontSize: 17.sp),
        ),
        backgroundColor: _kPrimary,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(16)),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.all(16.r),
        child: Column(
          children: [
            _buildModelInfoCard().animate().fadeIn(duration: 400.ms),
            SizedBox(height: 16.h),
            _buildApiKeyCard().animate().fadeIn(delay: 100.ms, duration: 400.ms),
            SizedBox(height: 16.h),
            _buildStatsCard().animate().fadeIn(delay: 200.ms, duration: 400.ms),
            SizedBox(height: 16.h),
            _buildDangerZone().animate().fadeIn(delay: 300.ms, duration: 400.ms),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Carte info modèle
  // ---------------------------------------------------------------------------

  Widget _buildModelInfoCard() {
    final isOk = _aiService.isConfigured;
    return _SettingsCard(
      title: 'Modèle IA actif',
      icon: Icons.smart_toy_rounded,
      iconColor: _kAccent,
      children: [
        _InfoRow(label: 'Modèle', value: 'Gemini 2.0 Flash'),
        _InfoRow(label: 'Fournisseur', value: 'Google AI Studio'),
        _InfoRow(label: 'Quota gratuit', value: '1 500 req/jour · 15 req/min'),
        _InfoRow(label: 'Latence estimée', value: '< 2 secondes'),
        _InfoRow(
          label: 'Statut',
          value: isOk ? '🟢 Opérationnel' : '🔴 Non configuré',
          valueColor: isOk ? Colors.green.shade700 : Colors.red.shade700,
        ),
        _InfoRow(label: 'Langues', value: 'FR • AR • Dialecte tunisien'),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Carte clé API
  // ---------------------------------------------------------------------------

  Widget _buildApiKeyCard() {
    return _SettingsCard(
      title: 'Configuration API',
      icon: Icons.key_rounded,
      iconColor: const Color(0xFFFF9800),
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Clé API Gemini',
                    style: GoogleFonts.montserrat(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey.shade700,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    _showApiKey
                        ? (dotenv.env['GEMINI_API_KEY'] ?? 'Non définie')
                        : _apiKeyDisplay,
                    style: GoogleFonts.sourceCodePro(
                      fontSize: 12.sp,
                      color: _kPrimary,
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: Icon(
                _showApiKey ? Icons.visibility_off : Icons.visibility,
                color: _kAccent,
                size: 20,
              ),
              onPressed: () => setState(() => _showApiKey = !_showApiKey),
            ),
          ],
        ),
        SizedBox(height: 12.h),
        Container(
          padding: EdgeInsets.all(12.r),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF8E1),
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(color: Colors.amber.shade200),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.info_outline, color: Colors.amber, size: 18),
              SizedBox(width: 8.w),
              Expanded(
                child: Text(
                  'La clé API est stockée dans le fichier .env à la racine du projet. '
                  'Obtenez une clé gratuite sur aistudio.google.com',
                  style: GoogleFonts.montserrat(
                    fontSize: 11.sp,
                    color: Colors.amber.shade900,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Carte statistiques
  // ---------------------------------------------------------------------------

  Widget _buildStatsCard() {
    return _SettingsCard(
      title: 'Historique de conversation',
      icon: Icons.history_rounded,
      iconColor: const Color(0xFF00C6A2),
      children: [
        _InfoRow(
          label: 'Véhicule actif',
          value: _vehicleId.isEmpty ? 'Aucun' : _vehicleId,
        ),
        _InfoRow(
          label: 'Messages enregistrés',
          value: _isLoading ? '...' : '$_historyCount messages',
        ),
        _InfoRow(
          label: 'Mémoire du contexte',
          value: '10 derniers tours envoyés au LLM',
        ),
        SizedBox(height: 12.h),
        if (_vehicleId.isNotEmpty)
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.refresh_rounded, size: 18),
              label: Text(
                'Actualiser les statistiques',
                style: GoogleFonts.montserrat(fontWeight: FontWeight.w600),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: _kAccent,
                side: BorderSide(color: _kAccent.withOpacity(0.4)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(vertical: 10),
              ),
              onPressed: _loadStats,
            ),
          ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Zone de danger
  // ---------------------------------------------------------------------------

  Widget _buildDangerZone() {
    return _SettingsCard(
      title: 'Zone de gestion',
      icon: Icons.manage_history_rounded,
      iconColor: Colors.red.shade400,
      children: [
        if (_vehicleId.isNotEmpty)
          _DangerButton(
            icon: Icons.delete_sweep_rounded,
            label: 'Effacer l\'historique de ce véhicule',
            subtitle: 'Supprime $_historyCount messages locaux',
            color: Colors.orange.shade700,
            onTap: _clearVehicleHistory,
          ),
        SizedBox(height: 12.h),
        _DangerButton(
          icon: Icons.delete_forever_rounded,
          label: 'Effacer tout l\'historique',
          subtitle: 'Supprime toutes les conversations de tous les véhicules',
          color: Colors.red.shade600,
          onTap: _clearAllHistory,
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Actions
  // ---------------------------------------------------------------------------

  Future<void> _clearVehicleHistory() async {
    final ok = await _confirmDialog(
      'Effacer l\'historique de $_vehicleId ?',
      'Cette action est irréversible.',
    );
    if (!ok) return;
    setState(() => _isLoading = true);
    await _aiService.clearHistory(_vehicleId);
    await _loadStats();
    setState(() => _isLoading = false);
    if (mounted) {
      _showSnack('Historique de $_vehicleId effacé ✓', Colors.green);
    }
  }

  Future<void> _clearAllHistory() async {
    final ok = await _confirmDialog(
      'Effacer TOUT l\'historique ?',
      'Toutes les conversations de tous les véhicules seront supprimées. '
          'Cette action est irréversible.',
    );
    if (!ok) return;
    setState(() => _isLoading = true);
    await ConversationHistoryServiceClearer().clearAll();
    setState(() {
      _historyCount = 0;
      _isLoading = false;
    });
    if (mounted) {
      _showSnack('Tout l\'historique effacé ✓', Colors.green);
    }
  }

  Future<bool> _confirmDialog(String title, String content) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title,
            style: GoogleFonts.montserrat(fontWeight: FontWeight.w700)),
        content: Text(content, style: GoogleFonts.montserrat()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Confirmer'),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.montserrat()),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

// Helper pour effacer tout l'historique depuis cet écran
class ConversationHistoryServiceClearer {
  Future<void> clearAll() {
    return ConversationHistoryService().clearAllHistory();
  }
}

// ---------------------------------------------------------------------------
// Widgets réutilisables
// ---------------------------------------------------------------------------

class _SettingsCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color iconColor;
  final List<Widget> children;

  const _SettingsCard({
    required this.title,
    required this.icon,
    required this.iconColor,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(20.r),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8.r),
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: Icon(icon, color: iconColor, size: 20.sp),
              ),
              SizedBox(width: 12.w),
              Text(
                title,
                style: GoogleFonts.montserrat(
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w700,
                  color: _kPrimary,
                ),
              ),
            ],
          ),
          SizedBox(height: 16.h),
          ...children,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const _InfoRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 10.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140.w,
            child: Text(
              label,
              style: GoogleFonts.montserrat(
                fontSize: 12.sp,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: GoogleFonts.montserrat(
                fontSize: 12.sp,
                fontWeight: FontWeight.w600,
                color: valueColor ?? _kPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DangerButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _DangerButton({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        onTap();
      },
      child: Container(
        padding: EdgeInsets.all(14.r),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14.r),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 22.sp),
            SizedBox(width: 12.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.montserrat(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w700,
                      color: color,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: GoogleFonts.montserrat(
                      fontSize: 11.sp,
                      color: color.withOpacity(0.7),
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded, color: color, size: 14.sp),
          ],
        ),
      ),
    );
  }
}

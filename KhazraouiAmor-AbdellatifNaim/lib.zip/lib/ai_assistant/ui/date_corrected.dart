import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:math'; // Importer pour clamp

/// Gère le calcul, le stockage et la mise à jour des dates de maintenance
/// basés sur les pourcentages d'usure des pièces du véhicule et les durées de vie standard.
class DateManager {
  static final _supabase = Supabase.instance.client;

  // Seuils de notification (jours) pour la configuration des alertes
  static const int criticalThreshold = 3;
  static const int warningThreshold = 7;
  static const int upcomingThreshold = 14;

  // Durées de vie moyennes standard en jours (basées sur les recherches)
  static const Map<String, int> _standardLifespansDays = {
    'battery_health': 720,       // ~4.5 ans
    'ShockAbsorber_Wear': 2190, // ~6 ans
    'clutch_wear': 2738,        // ~7.5 ans (150k km)
    'brake_wear': 730,          // ~2 ans (plaquettes)
    'belt_risk': 2555,          // ~7 ans (courroie distribution)
    'oil_change': 120,          // 1 an (vidange)
    'tire_wear': 1460,          // ~4 ans (pneus)
  };

  // Clés correspondantes dans la table maintenance_dates
  static const Map<String, String> _predictionKeyToDbColumn = {
    'battery_health': 'changement_batterie',
    'ShockAbsorber_Wear': 'changement_amortisseurs',
    'clutch_wear': 'changement_embrayage',
    'brake_wear': 'changement_freins',
    'belt_risk': 'changement_courroie',
    'oil_change': 'changement_vidange',
    'tire_wear': 'changement_pneus',
  };

  /// Insère ou met à jour les dates de maintenance pour un véhicule spécifique.
  static Future<bool> insertMaintenanceDates({
    required String immatriculation,
    DateTime? batterie,
    DateTime? amortisseurs,
    DateTime? embrayage,
    DateTime? freins,
    DateTime? courroie,
    DateTime? vidange,
    DateTime? pneus,
  }) async {
    try {
      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        if (kDebugMode) {
          print('❌ Impossible d`insérer des dates: véhicule $immatriculation inexistant');
        }
        return false;
      }

      final existingData = await _supabase
          .from('maintenance_dates')
          .select('id') // Sélectionner seulement l'ID pour vérifier l'existence
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      final datesData = {
        'changement_batterie': batterie?.toIso8601String(),
        'changement_amortisseurs': amortisseurs?.toIso8601String(),
        'changement_embrayage': embrayage?.toIso8601String(),
        'changement_freins': freins?.toIso8601String(),
        'changement_courroie': courroie?.toIso8601String(),
        'changement_vidange': vidange?.toIso8601String(),
        'changement_pneus': pneus?.toIso8601String(),
      };

      // Filtrer les clés nulles pour ne pas écraser des dates existantes avec null
      datesData.removeWhere((key, value) => value == null);

      if (datesData.isEmpty) {
        if (kDebugMode) {
          print('⚠️ Aucune date valide fournie pour $immatriculation. Aucune mise à jour effectuée.');
        }
        return false; // Retourner false car aucune action n'a été effectuée
      }

      if (existingData != null) {
        await _supabase.from('maintenance_dates')
            .update(datesData)
            .eq('fk_immatriculation', immatriculation);
        if (kDebugMode) {
          print("✅ Dates mises à jour avec succès pour $immatriculation!");
        }
      } else {
        datesData['fk_immatriculation'] = immatriculation;
        // created_at est généralement géré par la base de données, mais on peut le forcer si besoin
        // datesData['created_at'] = DateTime.now().toIso8601String(); 
        await _supabase.from('maintenance_dates').insert(datesData);
        if (kDebugMode) {
          print("✅ Dates insérées avec succès pour $immatriculation!");
        }
      }

      return true;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur d`enregistrement des dates de maintenance : $e');
      }
      return false;
    }
  }

  /// Vérifie si un véhicule existe avec l'immatriculation donnée.
  static Future<bool> _vehicleExists(String immatriculation) async {
    try {
      final result = await _supabase
          .from('voiture')
          .select('immatriculation')
          .eq('immatriculation', immatriculation)
          .maybeSingle();
      return result != null;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la vérification du véhicule: $e');
      }
      return false;
    }
  }

  /// Vérifie si des prédictions d'usure existent pour un véhicule.
  static Future<bool> predictionsExist(String immatriculation) async {
    try {
      final result = await _supabase
          .from('predictions')
          .select('id') // Sélectionner seulement l'ID
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();
      return result != null;
    } catch (e) {
      return false;
    }
  }

  /// Calcule la date de remplacement estimée pour une pièce.
  ///
  /// [baseDate]: La date à partir de laquelle calculer (typiquement DateTime.now()).
  /// [wearPercentage]: Le pourcentage d'usure actuel (0-100).
  /// [totalLifespanDays]: La durée de vie totale standard de la pièce en jours.
  ///
  /// Retourne la date estimée du prochain remplacement.
  static DateTime _calculateNextReplacementDate({
    required DateTime baseDate,
    required double wearPercentage,
    required int totalLifespanDays,
  }) {
    // S'assurer que le pourcentage est dans les limites [0, 100]
    final clampedPercentage = wearPercentage.clamp(0.0, 100.0);

    // Si l'usure est déjà à 100% ou plus, la date est maintenant ou dans le passé.
    if (clampedPercentage >= 100.0) {
      return baseDate; // Ou retourner une date légèrement passée si nécessaire
    }

    // Calculer le pourcentage de vie restante
    final remainingLifeRatio = (100.0 - clampedPercentage) / 100.0;

    // Calculer le nombre de jours restants estimés
    // Utiliser max(1, ...) pour s'assurer qu'on ajoute au moins 1 jour si la vie restante est très faible mais pas nulle
    final remainingDays = max(1, (totalLifespanDays * remainingLifeRatio).round());

    // Ajouter les jours restants à la date de base
    return baseDate.add(Duration(days: remainingDays));
  }

  // --- Méthodes de calcul spécifiques par pièce (utilisant la logique unifiée) ---

  static DateTime calculateNextDateBatterie({
    required DateTime baseDate,
    required double percentage,
  }) {
    final lifespan = _standardLifespansDays['battery_health'] ?? 1643; // Valeur par défaut
    return _calculateNextReplacementDate(
      baseDate: baseDate,
      wearPercentage: percentage,
      totalLifespanDays: lifespan,
    );
  }

  static DateTime calculateNextDateCourroie({
    required DateTime baseDate,
    required double percentage,
  }) {
    final lifespan = _standardLifespansDays['belt_risk'] ?? 2555;
    return _calculateNextReplacementDate(
      baseDate: baseDate,
      wearPercentage: percentage,
      totalLifespanDays: lifespan,
    );
  }

  static DateTime calculateNextDatePneus({
    required DateTime baseDate,
    required double percentage,
  }) {
    final lifespan = _standardLifespansDays['tire_wear'] ?? 1460;
    return _calculateNextReplacementDate(
      baseDate: baseDate,
      wearPercentage: percentage,
      totalLifespanDays: lifespan,
    );
  }

  static DateTime calculateNextDateFreins({
    required DateTime baseDate,
    required double percentage,
  }) {
    final lifespan = _standardLifespansDays['brake_wear'] ?? 730;
    return _calculateNextReplacementDate(
      baseDate: baseDate,
      wearPercentage: percentage,
      totalLifespanDays: lifespan,
    );
  }

  static DateTime calculateNextDateEmbrayage({
    required DateTime baseDate,
    required double percentage,
  }) {
    final lifespan = _standardLifespansDays['clutch_wear'] ?? 2738;
    return _calculateNextReplacementDate(
      baseDate: baseDate,
      wearPercentage: percentage,
      totalLifespanDays: lifespan,
    );
  }

  static DateTime calculateNextDateAmortisseurs({
    required DateTime baseDate,
    required double percentage,
  }) {
    final lifespan = _standardLifespansDays['ShockAbsorber_Wear'] ?? 2190;
    return _calculateNextReplacementDate(
      baseDate: baseDate,
      wearPercentage: percentage,
      totalLifespanDays: lifespan,
    );
  }

  static DateTime calculateNextDateVidange({
    required DateTime baseDate,
    required double percentage,
  }) {
    final lifespan = _standardLifespansDays['oil_change'] ?? 365;
    // Logique spécifique pour la vidange : si usure > 90%, prévoir dans 7 jours max
    if (percentage > 90.0) {
       final calculatedDate = _calculateNextReplacementDate(
         baseDate: baseDate,
         wearPercentage: percentage,
         totalLifespanDays: lifespan,
       );
       final sevenDaysFromNow = baseDate.add(const Duration(days: 7));
       // Retourne la date la plus proche : celle calculée ou dans 7 jours
       return calculatedDate.isBefore(sevenDaysFromNow) ? calculatedDate : sevenDaysFromNow;
    } else {
       return _calculateNextReplacementDate(
         baseDate: baseDate,
         wearPercentage: percentage,
         totalLifespanDays: lifespan,
       );
    }
  }

  /// Met à jour les dates de maintenance en fonction des pourcentages d'usure pour une voiture spécifique.
  /// Retourne true en cas de succès, false sinon.
  static Future<bool> updateMaintenanceDatesFromPredictions(String immatriculation) async {
    try {

      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        return false;
      }

      final predictions = await _supabase
          .from('predictions')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (predictions == null) {
        return false;
      }

      // Vérifier que les prédictions contiennent des données valides
      if (!_containsValidPredictions(predictions)) {
        return false;
      }

      final now = DateTime.now();

      // Calculer les dates en utilisant les nouvelles méthodes
      final batterie = calculateNextDateBatterie(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'battery_health'));

      final vidange = calculateNextDateVidange(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'oil_change'));

      final freins = calculateNextDateFreins(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'brake_wear'));

      final pneus = calculateNextDatePneus(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'tire_wear'));

      final amortisseurs = calculateNextDateAmortisseurs(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'ShockAbsorber_Wear'));

      final courroie = calculateNextDateCourroie(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'belt_risk'));

      final embrayage = calculateNextDateEmbrayage(
          baseDate: now,
          percentage: _getNumericValue(predictions, 'clutch_wear'));

      // Enregistrer les dates calculées
      final success = await insertMaintenanceDates(
        immatriculation: immatriculation,
        batterie: batterie,
        vidange: vidange,
        freins: freins,
        pneus: pneus,
        amortisseurs: amortisseurs,
        courroie: courroie,
        embrayage: embrayage,
      );

      if (success) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  /// Vérifie si les prédictions contiennent des données valides pour le calcul des dates.
  static bool _containsValidPredictions(Map<String, dynamic> predictions) {
    // Utiliser les clés de la map _standardLifespansDays comme référence
    for (final key in _standardLifespansDays.keys) {
      if (!predictions.containsKey(key) || predictions[key] == null) {
        return false;
      }
      // Optionnel: vérifier si la valeur est numérique
      if (_getNumericValue(predictions, key) < 0) { // L'usure ne peut être négative
         return false;
      }
    }
    return true;
  }

  /// Extrait une valeur numérique sécurisée depuis les prédictions.
  static double _getNumericValue(Map<String, dynamic> predictions, String key) {
    final value = predictions[key];
    if (value == null) return 0.0;
    if (value is int) return value.toDouble();
    if (value is double) return value;
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  /// Met à jour la date de maintenance pour une pièce spécifique suite à son remplacement.
  /// Retourne true en cas de succès.
  static Future<bool> updateComponentMaintenanceDate({
    required String immatriculation,
    required String componentDbKey, // Utiliser la clé de la DB (ex: 'changement_batterie')
    DateTime? customNextDate, // Permet de forcer une date si nécessaire
  }) async {
    try {
      final vehicleExists = await _vehicleExists(immatriculation);
      if (!vehicleExists) {
        return false;
      }

      // Trouver la clé de prédiction correspondante à la clé DB
      String? predictionKey;
      _predictionKeyToDbColumn.forEach((predKey, dbKey) {
        if (dbKey == componentDbKey) {
          predictionKey = predKey;
        }
      });

      if (predictionKey == null) {
         return false;
      }

      // Récupérer l'enregistrement existant pour s'assurer qu'il y a quelque chose à mettre à jour
      final existingData = await _supabase
          .from('maintenance_dates')
          .select('id')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (existingData == null) {
        // Si aucune entrée n'existe, on ne peut pas juste mettre à jour une colonne.
        // On pourrait soit échouer, soit créer une entrée avec seulement cette date.
        // Pour l'instant, on échoue pour éviter les données partielles.
        return false;
      }

      DateTime nextDate;
      if (customNextDate != null) {
        nextDate = customNextDate;
      } else {
        // Calculer la prochaine date basée sur la durée de vie standard
        final lifespanDays = _standardLifespansDays[predictionKey];
        if (lifespanDays == null) {
           return false; // Ne pas continuer si la durée de vie est inconnue
        }
        // La nouvelle date est aujourd'hui + la durée de vie complète
        nextDate = DateTime.now().add(Duration(days: lifespanDays));
      }

      // Mettre à jour uniquement la colonne concernée
      await _supabase.from('maintenance_dates')
          .update({componentDbKey: nextDate.toIso8601String()})
          .eq('fk_immatriculation', immatriculation);

      return true;

    } catch (e) {
      return false;
    }
  }
}


// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';

// ignore: unused_import
import '../models/conversation_turn.dart';
import '../services/gemini_ai_service.dart';

// ---------------------------------------------------------------------------
// Constantes de design
// ---------------------------------------------------------------------------
const _kPrimaryBlue = Color(0xFF1E3A5F);
const _kAccentBlue = Color(0xFF4E6AFF);
const _kBgColor = Color(0xFFF0F4F8);
const _kUserBubble = Color(0xFF1E3A5F);
const _kBotBubble = Colors.white;
const _kErrorBubble = Color(0xFFFFEBEE);

/// Suggestions rapides affichées quand le chat est vide
const _kQuickSuggestions = [
  ('🔧 État de mes pièces', 'Quel est l\'état d\'usure de mes pièces ?'),
  ('🛑 Mes freins', 'Quand dois-je changer mes freins ?'),
  ('💰 Mes dépenses', 'Donne-moi un résumé de mes dépenses ce mois-ci'),
  ('🔋 Batterie', 'Quel est l\'état de ma batterie ?'),
  ('⚙️ Entretien', 'Qu\'est-ce que je dois faire pour l\'entretien de mon véhicule ?'),
  ('🚗 Diagnostic', 'Mon moteur fait un bruit bizarre, comment diagnostiquer ?'),
];

// ---------------------------------------------------------------------------
// Widget principal
// ---------------------------------------------------------------------------

/// Écran de chat professionnel alimenté par l'API Gemini
class MechanicChatScreen extends StatefulWidget {
  const MechanicChatScreen({super.key});

  @override
  State<MechanicChatScreen> createState() => _MechanicChatScreenState();
}

class _MechanicChatScreenState extends State<MechanicChatScreen>
    with TickerProviderStateMixin {
  // Services
  final GeminiAiService _aiService = GeminiAiService();

  // État
  final List<_ChatMessage> _messages = [];
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _inputFocusNode = FocusNode();

  String _vehicleId = '';
  bool _isInitialized = false;
  bool _isLoading = false;
  bool _serviceConfigured = false;

  // Animation du bouton d'envoi
  late AnimationController _sendBtnController;

  @override
  void initState() {
    super.initState();
    _sendBtnController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _inputController.addListener(_onInputChanged);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isInitialized) {
      final args = ModalRoute.of(context)?.settings.arguments;
      _vehicleId = (args is String && args.isNotEmpty) ? args : 'UNKNOWN';
      _isInitialized = true;
      _initService();
    }
  }

  @override
  void dispose() {
    _inputController.removeListener(_onInputChanged);
    _inputController.dispose();
    _scrollController.dispose();
    _inputFocusNode.dispose();
    _sendBtnController.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------------
  // Initialisation
  // ---------------------------------------------------------------------------

  Future<void> _initService() async {
    final ok = _aiService.initialize();
    setState(() => _serviceConfigured = ok);

    if (!ok) {
      _addBotMessage(
        '⚠️ **Configuration manquante**\n\n'
        'La clé API Gemini n\'est pas configurée.\n'
        'Ajoutez `GEMINI_API_KEY=votre_cle` dans le fichier `.env` à la racine du projet.',
        isError: true,
      );
      return;
    }

    // Charger l'historique persisté
    final history = await _aiService.getHistory(_vehicleId);
    if (history.isNotEmpty && mounted) {
      setState(() {
        for (final turn in history) {
          _messages.add(_ChatMessage(
            text: turn.content,
            isUser: turn.role == 'user',
            timestamp: turn.timestamp,
          ));
        }
      });
      _scrollToBottom();
    } else if (mounted) {
      _addWelcomeMessage();
    }
  }

  void _addWelcomeMessage() {
    _addBotMessage(
      '👋 **Bonjour ! Je suis CARHABTI-AI**, votre assistant automobile intelligent.\n\n'
      'Je connais votre véhicule et son état en temps réel. '
      'Posez-moi vos questions en **français**, **arabe** ou en **dialecte tunisien** 🇹🇳\n\n'
      '_Exemples : "État de mes freins ?", "عندي مشكل في الفران", "شنوة حالة الروات ؟"_',
    );
  }

  // ---------------------------------------------------------------------------
  // Envoi de message
  // ---------------------------------------------------------------------------

  void _onInputChanged() {
    final hasText = _inputController.text.trim().isNotEmpty;
    if (hasText) {
      _sendBtnController.forward();
    } else {
      _sendBtnController.reverse();
    }
  }

  Future<void> _sendMessage(String text) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || _isLoading) return;

    HapticFeedback.lightImpact();
    _inputController.clear();
    _inputFocusNode.requestFocus();

    // Ajouter le message utilisateur immédiatement
    _addUserMessage(trimmed);

    // Démarrer l'indicateur de chargement
    setState(() => _isLoading = true);
    _scrollToBottom();

    // Appeler Gemini
    final response = await _aiService.sendMessage(
      trimmed,
      vehicleId: _vehicleId,
    );

    if (!mounted) return;
    setState(() => _isLoading = false);

    _addBotMessage(response.text, isError: response.isError);
    _scrollToBottom();
  }

  void _addUserMessage(String text) {
    setState(() {
      _messages.add(_ChatMessage(
        text: text,
        isUser: true,
        timestamp: DateTime.now(),
      ));
    });
  }

  void _addBotMessage(String text, {bool isError = false}) {
    if (!mounted) return;
    setState(() {
      _messages.add(_ChatMessage(
        text: text,
        isUser: false,
        isError: isError,
        timestamp: DateTime.now(),
      ));
    });
  }

  Future<void> _clearConversation() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Effacer la conversation'),
        content: const Text(
            'Voulez-vous supprimer tout l\'historique de cette conversation ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Effacer'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _aiService.clearHistory(_vehicleId);
      if (!mounted) return;
      setState(() => _messages.clear());
      _addWelcomeMessage();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBgColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty && !_isLoading
                ? _buildEmptyState()
                : _buildMessageList(),
          ),
          if (_isLoading) _buildTypingIndicator(),
          _buildInputBar(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _kPrimaryBlue,
      foregroundColor: Colors.white,
      elevation: 0,
      title: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.smart_toy_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'CARHABTI-AI',
                style: GoogleFonts.montserrat(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
              Row(
                children: [
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: _serviceConfigured ? Colors.greenAccent : Colors.orange,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    _serviceConfigured ? 'En ligne · Gemini 2.0 Flash' : 'Non configuré',
                    style: GoogleFonts.montserrat(
                      fontSize: 11,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
      actions: [
        if (_messages.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.delete_sweep_rounded),
            tooltip: 'Effacer la conversation',
            onPressed: _clearConversation,
          ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // Corps — Liste de messages
  // ---------------------------------------------------------------------------

  Widget _buildMessageList() {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
        itemCount: _messages.length,
        itemBuilder: (context, index) {
          final msg = _messages[index];
          return _MessageBubble(
            message: msg,
            key: ValueKey('msg_$index'),
          ).animate().fadeIn(duration: 300.ms).slideY(
                begin: 0.1,
                end: 0,
                duration: 300.ms,
                curve: Curves.easeOut,
              );
        },
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // État vide — suggestions rapides
  // ---------------------------------------------------------------------------

  Widget _buildEmptyState() {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Icône centrale
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: _kAccentBlue.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.smart_toy_rounded,
                  color: _kAccentBlue, size: 40),
            ).animate().scale(duration: 400.ms, curve: Curves.elasticOut),
            const SizedBox(height: 16),
            Text(
              'Comment puis-je vous aider ?',
              style: GoogleFonts.montserrat(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: _kPrimaryBlue,
              ),
            ).animate().fadeIn(delay: 100.ms),
            const SizedBox(height: 8),
            Text(
              'Posez une question ou choisissez une suggestion ci-dessous',
              textAlign: TextAlign.center,
              style: GoogleFonts.montserrat(
                fontSize: 13,
                color: Colors.grey.shade600,
              ),
            ).animate().fadeIn(delay: 150.ms),
            const SizedBox(height: 28),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: _kQuickSuggestions.asMap().entries.map((e) {
                final i = e.key;
                final (label, prompt) = e.value;
                return _SuggestionChip(
                  label: label,
                  onTap: () => _sendMessage(prompt),
                )
                    .animate()
                    .fadeIn(delay: Duration(milliseconds: 200 + i * 60))
                    .slideY(begin: 0.2, end: 0, duration: 300.ms);
              }).toList(),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Indicateur de frappe
  // ---------------------------------------------------------------------------

  Widget _buildTypingIndicator() {
    return Padding(
      padding: const EdgeInsets.only(left: 16, bottom: 8),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: _kAccentBlue.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.smart_toy_rounded, color: _kAccentBlue, size: 16),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(18),
                bottomLeft: Radius.circular(18),
                bottomRight: Radius.circular(18),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: _TypingDots(),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Barre de saisie
  // ---------------------------------------------------------------------------

  Widget _buildInputBar() {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: 8,
        bottom: MediaQuery.of(context).padding.bottom + 8,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Champ de texte
          Expanded(
            child: Container(
              constraints: const BoxConstraints(maxHeight: 120),
              decoration: BoxDecoration(
                color: _kBgColor,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _kAccentBlue.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _inputController,
                focusNode: _inputFocusNode,
                maxLines: null,
                textCapitalization: TextCapitalization.sentences,
                style: GoogleFonts.montserrat(fontSize: 14, color: Colors.black87),
                decoration: InputDecoration(
                  hintText: 'Posez votre question...',
                  hintStyle: GoogleFonts.montserrat(
                    fontSize: 14,
                    color: Colors.grey.shade400,
                  ),
                  border: InputBorder.none,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                ),
                onSubmitted: (v) => _sendMessage(v),
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Bouton d'envoi
          AnimatedBuilder(
            animation: _sendBtnController,
            builder: (context, _) {
              final scale = 1.0 + 0.08 * _sendBtnController.value;
              final bgColor = Color.lerp(
                Colors.grey.shade300,
                _kAccentBlue,
                _sendBtnController.value,
              )!;
              return Transform.scale(
                scale: scale,
                child: GestureDetector(
                  onTap: () => _sendMessage(_inputController.text),
                  child: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: bgColor,
                      shape: BoxShape.circle,
                      boxShadow: _sendBtnController.value > 0.5
                          ? [
                              BoxShadow(
                                color: _kAccentBlue.withOpacity(0.4),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ]
                          : [],
                    ),
                    child: const Icon(Icons.send_rounded,
                        color: Colors.white, size: 20),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Bulle de message
// ---------------------------------------------------------------------------

class _ChatMessage {
  final String text;
  final bool isUser;
  final bool isError;
  final DateTime timestamp;

  const _ChatMessage({
    required this.text,
    required this.isUser,
    this.isError = false,
    required this.timestamp,
  });
}

class _MessageBubble extends StatelessWidget {
  final _ChatMessage message;

  const _MessageBubble({required this.message, super.key});

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser) _buildAvatar(),
          if (!isUser) const SizedBox(width: 8),
          Flexible(
            child: Column(
              crossAxisAlignment:
                  isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                _buildBubble(context),
                const SizedBox(height: 4),
                Text(
                  _formatTime(message.timestamp),
                  style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                ),
              ],
            ),
          ),
          if (isUser) const SizedBox(width: 8),
          if (isUser) _buildUserAvatar(),
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: message.isError
            ? Colors.red.withOpacity(0.15)
            : _kAccentBlue.withOpacity(0.15),
        shape: BoxShape.circle,
      ),
      child: Icon(
        message.isError ? Icons.error_outline : Icons.smart_toy_rounded,
        color: message.isError ? Colors.red : _kAccentBlue,
        size: 16,
      ),
    );
  }

  Widget _buildUserAvatar() {
    return Container(
      width: 32,
      height: 32,
      decoration: const BoxDecoration(
        color: _kUserBubble,
        shape: BoxShape.circle,
      ),
      child: const Icon(Icons.person_rounded, color: Colors.white, size: 16),
    );
  }

  Widget _buildBubble(BuildContext context) {
    Color bgColor;
    if (message.isUser) {
      bgColor = _kUserBubble;
    } else if (message.isError) {
      bgColor = _kErrorBubble;
    } else {
      bgColor = _kBotBubble;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.78,
      ),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18),
          topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(message.isUser ? 18 : 4),
          bottomRight: Radius.circular(message.isUser ? 4 : 18),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.07),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: message.isUser
          ? SelectableText(
              message.text,
              style: GoogleFonts.montserrat(
                  fontSize: 14, color: Colors.white, height: 1.4),
            )
          : MarkdownBody(
              data: message.text,
              styleSheet: MarkdownStyleSheet(
                p: GoogleFonts.montserrat(
                  fontSize: 14,
                  color: message.isError ? Colors.red.shade800 : Colors.black87,
                  height: 1.5,
                ),
                strong: GoogleFonts.montserrat(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: message.isError ? Colors.red.shade800 : _kPrimaryBlue,
                ),
                em: GoogleFonts.montserrat(
                  fontSize: 13,
                  fontStyle: FontStyle.italic,
                  color: Colors.grey.shade600,
                ),
                listBullet: GoogleFonts.montserrat(
                  fontSize: 14,
                  color: Colors.black87,
                ),
                code: GoogleFonts.sourceCodePro(
                  fontSize: 13,
                  backgroundColor: Colors.grey.shade100,
                  color: _kAccentBlue,
                ),
                blockquote: GoogleFonts.montserrat(
                  fontSize: 13,
                  color: Colors.grey.shade700,
                  fontStyle: FontStyle.italic,
                ),
              ),
              selectable: true,
            ),
    );
  }

  String _formatTime(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}

// ---------------------------------------------------------------------------
// Chip de suggestion
// ---------------------------------------------------------------------------

class _SuggestionChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _SuggestionChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _kAccentBlue.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Text(
          label,
          style: GoogleFonts.montserrat(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: _kPrimaryBlue,
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Animation "en train d'écrire"
// ---------------------------------------------------------------------------

class _TypingDots extends StatefulWidget {
  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final delay = i * 0.3;
          final t = (_ctrl.value - delay).clamp(0.0, 1.0);
          final scale = 0.6 + 0.4 * (t < 0.5 ? t * 2 : (1 - t) * 2);
          return Transform.scale(
            scale: scale,
            child: Container(
              width: 8,
              height: 8,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: _kAccentBlue.withOpacity(0.7),
                shape: BoxShape.circle,
              ),
            ),
          );
        }),
      ),
    );
  }
}

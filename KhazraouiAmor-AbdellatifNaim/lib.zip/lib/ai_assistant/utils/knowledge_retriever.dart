import 'dart:convert';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'dart:io';
import 'package:flutter/foundation.dart';

import '../models/automotive_knowledge.dart';

/// Classe pour récupérer les connaissances automobiles pertinentes pour une question donnée
class KnowledgeRetriever {
  /// Liste de toutes les connaissances automobiles disponibles
  final List<AutomotiveKnowledge> _knowledgeBase = [];

  /// Indique si la base de connaissances a été chargée
  bool _isLoaded = false;

  /// Le nom du fichier de la base de connaissances
  static const String _knowledgeFileName = 'automotive_knowledge.json';

  /// Constructeur
  KnowledgeRetriever();

  /// Charge la base de connaissances depuis le stockage local
  Future<void> loadKnowledgeBase() async {
    if (_isLoaded) return;
    
    // Vérifier si on est sur le web
    if (kIsWeb) {
      debugPrint('Application en mode web, initialisation de la base de connaissances en mémoire uniquement');
      _initializeBaseKnowledgeInMemory();
      _isLoaded = true;
      return;
    }

    try {
      // Essayer d'accéder au répertoire des documents (seulement sur mobile)
      final dir = await getApplicationDocumentsDirectory();
      final filePath = path.join(dir.path, _knowledgeFileName);
      final file = File(filePath);

      if (await file.exists()) {
        final jsonString = await file.readAsString();
        final List<dynamic> jsonList = jsonDecode(jsonString);

        _knowledgeBase.clear();
        _knowledgeBase.addAll(
            jsonList.map((json) => AutomotiveKnowledge.fromMap(json)).toList());
      } else {
        // Si le fichier n'existe pas, initialiser avec des données de base
        await _initializeBaseKnowledge();
      }

      _isLoaded = true;
    } catch (e) {
      debugPrint('Erreur lors du chargement de la base de connaissances: $e');
      // En cas d'erreur avec path_provider, charger les données en mémoire sans persistance
      _initializeBaseKnowledgeInMemory();
      _isLoaded = true; // Marquer comme chargé même si c'est seulement en mémoire
    }
  }

  /// Initialise la base de connaissances avec des données de base
  Future<void> _initializeBaseKnowledge() async {
    _knowledgeBase.clear();

    // Ajouter quelques connaissances de base
    _knowledgeBase.addAll(_getBaseKnowledgeItems());
    
    // Sauvegarder les connaissances de base dans un fichier (seulement sur mobile)
    if (!kIsWeb) {
      try {
        await _saveKnowledgeBase();
      } catch (e) {
        debugPrint('Erreur lors de la sauvegarde initiale de la base de connaissances: $e');
      }
    }
  }
  
  /// Initialise la base de connaissances en mémoire seulement (sans accès disque)
  void _initializeBaseKnowledgeInMemory() {
    _knowledgeBase.clear();
    
    // Ajouter les mêmes connaissances de base, mais sans sauvegarde sur disque
    _knowledgeBase.addAll(_getBaseKnowledgeItems());
    
    debugPrint('Base de connaissances initialisée en mémoire seulement (pas de persistance)');
  }
  
  /// Renvoie les éléments de base de connaissances
  List<AutomotiveKnowledge> _getBaseKnowledgeItems() {
    return [
      AutomotiveKnowledge(
        id: 'engine-oil',
        category: 'moteur',
        title: 'Vidange d\'huile',
        content:
            'La vidange d\'huile doit être effectuée tous les 10 000 à 15 000 km ou une fois par an. '
            'Elle consiste à remplacer l\'huile moteur et le filtre à huile pour assurer une bonne lubrification du moteur. '
            'Une huile usée peut endommager le moteur et réduire ses performances.',
        keywords: ['huile', 'vidange', 'moteur', 'entretien', 'filtre à huile'],
        tunisianTerms: {'فيل': 'زيت', 'موتور': 'محرك', 'فيلتر': 'مصفاة'},
      ),
      AutomotiveKnowledge(
        id: 'brakes',
        category: 'freins',
        title: 'Entretien des freins',
        content:
            'Les plaquettes de frein doivent être vérifiées tous les 10 000 km et remplacées '
            'lorsqu\'elles atteignent une épaisseur inférieure à 3-4 mm. Les disques de frein ont une durée de vie d\'environ 60 000 à 80 000 km. '
            'Des freins usés peuvent compromettre la sécurité du véhicule.',
        keywords: ['freins', 'plaquettes', 'disques', 'sécurité'],
        tunisianTerms: {
          'فران': 'مكابح',
          'بلاكة': 'لوحة المكابح',
          'ديسك': 'قرص المكابح'
        },
      ),
      AutomotiveKnowledge(
        id: 'battery',
        category: 'électricité',
        title: 'Batterie',
        content:
            'La durée de vie moyenne d\'une batterie de voiture est de 3 à 5 ans. '
            'Si votre voiture a du mal à démarrer ou si les lumières faiblissent, c\'est peut-être un signe que la batterie doit être remplacée. '
            'Vérifiez régulièrement les bornes de la batterie pour éviter la corrosion.',
        keywords: ['batterie', 'électricité', 'démarrage', 'bornes'],
        tunisianTerms: {
          'بطارية': 'بطارية',
          'بورن': 'طرف البطارية',
          'الكهرباء': 'الكهرباء'
        },
      ),
      AutomotiveKnowledge(
        id: 'tires',
        category: 'pneumatiques',
        title: 'Pneus',
        content:
            'Les pneus doivent être remplacés quand la profondeur des sculptures est inférieure à 1,6 mm. '
            'La rotation des pneus est recommandée tous les 10 000 km pour assurer une usure uniforme. '
            'Vérifiez régulièrement la pression des pneus pour optimiser la tenue de route et la consommation de carburant.',
        keywords: ['pneus', 'roues', 'pression', 'sculptures'],
        tunisianTerms: {'روا': 'عجلة', 'كاوتشو': 'إطار', 'مطاط': 'مطاط'},
      ),
      AutomotiveKnowledge(
        id: 'air-filter',
        category: 'filtres',
        title: 'Filtre à air',
        content:
            'Le filtre à air doit être remplacé tous les 15 000 à 30 000 km. '
            'Un filtre à air encrassé réduit les performances du moteur et augmente la consommation de carburant. '
            'Le remplacement du filtre à air est une opération simple qui peut être effectuée soi-même.',
        keywords: ['filtre', 'air', 'moteur', 'performance'],
        tunisianTerms: {'فيلتر': 'مصفاة', 'هواء': 'هواء', 'موتور': 'محرك'},
      ),
    ];
  }
  
  /// Sauvegarde la base de connaissances dans un fichier local
  Future<void> _saveKnowledgeBase() async {
    // Ne pas essayer de sauvegarder sur le web
    if (kIsWeb) {
      debugPrint('Application en mode web, sauvegarde de la base de connaissances ignorée');
      return;
    }
    
    try {
      final dir = await getApplicationDocumentsDirectory();
      final filePath = path.join(dir.path, _knowledgeFileName);
      final file = File(filePath);

      final jsonList =
          _knowledgeBase.map((knowledge) => knowledge.toMap()).toList();
      final jsonString = jsonEncode(jsonList);

      await file.writeAsString(jsonString);
    } catch (e) {
      debugPrint('Erreur lors de la sauvegarde de la base de connaissances: $e');
      // Laisser la classe fonctionner en mode mémoire uniquement
    }
  }

  /// Récupère les connaissances pertinentes pour une question donnée
  Future<List<AutomotiveKnowledge>> retrieveRelevantKnowledge(String query,
      {int maxResults = 3}) async {
    if (!_isLoaded) {
      await loadKnowledgeBase();
    }

    // Extraire les mots-clés de la requête
    final Set<String> queryKeywords = _extractKeywords(query.toLowerCase());

    // Trier les connaissances par pertinence (nombre de mots-clés correspondants)
    final scoredKnowledge = _knowledgeBase.map((knowledge) {
      final Set<String> knowledgeKeywords = Set.from(knowledge.keywords);

      // Calculer le score de correspondance
      int matchScore = 0;
      for (final keyword in queryKeywords) {
        if (knowledgeKeywords
            .any((k) => k.contains(keyword) || keyword.contains(k))) {
          matchScore++;
        }

        // Bonus pour les mots-clés exacts
        if (knowledgeKeywords.contains(keyword)) {
          matchScore += 2;
        }

        // Vérifier dans le contenu aussi
        if (knowledge.content.toLowerCase().contains(keyword)) {
          matchScore++;
        }

        // Vérifier dans le titre aussi
        if (knowledge.title.toLowerCase().contains(keyword)) {
          matchScore += 2;
        }
      }

      return (knowledge, matchScore);
    }).toList();

    // Trier par score décroissant
    scoredKnowledge.sort((a, b) => b.$2.compareTo(a.$2));

    // Retourner les connaissances les plus pertinentes
    return scoredKnowledge
        .where((item) => item.$2 > 0) // Filtrer les résultats non pertinents
        .take(maxResults)
        .map((item) => item.$1)
        .toList();
  }

  /// Extrait les mots-clés d'une requête
  Set<String> _extractKeywords(String query) {
    // Mots à ignorer (stop words) en français et arabe
    final stopWords = {
      'le',
      'la',
      'les',
      'un',
      'une',
      'des',
      'du',
      'de',
      'et',
      'à',
      'au',
      'aux',
      'en',
      'dans',
      'sur',
      'avec',
      'sans',
      'pour',
      'par',
      'comment',
      'quand',
      'où',
      'pourquoi',
      'que',
      'qui',
      'quoi',
      'est',
      'sont',
      'être',
      'ال',
      'في',
      'من',
      'إلى',
      'على',
      'هو',
      'هي',
      'هم',
      'كيف',
      'لماذا',
      'متى',
      'أين',
    };

    // Normaliser et tokenizer la requête
    final normalizedQuery = query
        .toLowerCase()
        .replaceAll(RegExp(r'[.,;:!?()]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    final words = normalizedQuery.split(' ');

    // Filtrer les mots vides et courts
    return words
        .where((word) => word.length > 2 && !stopWords.contains(word))
        .toSet();
  }

  /// Ajoute une nouvelle connaissance à la base
  Future<void> addKnowledge(AutomotiveKnowledge knowledge) async {
    if (!_isLoaded) {
      await loadKnowledgeBase();
    }

    _knowledgeBase.add(knowledge);
    try {
      await _saveKnowledgeBase();
    } catch (e) {
      debugPrint('Erreur lors de l\'ajout d\'une connaissance: $e');
    }
  }

  /// Obtient toutes les connaissances
  Future<List<AutomotiveKnowledge>> getAllKnowledge() async {
    if (!_isLoaded) {
      await loadKnowledgeBase();
    }

    return List.from(_knowledgeBase);
  }
}

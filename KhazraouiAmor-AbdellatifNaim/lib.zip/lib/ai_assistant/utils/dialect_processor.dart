import '../models/tunisian_dialect_mappings.dart';

/// Classe pour la normalisation et la conversion entre dialecte tunisien et arabe standard
class DialectProcessor {
  final TunisianDialectMappings _mappings;

  /// Constructeur
  DialectProcessor(this._mappings);

  /// Normalise un texte en dialecte tunisien vers l'arabe standard
  String normalizeToStandardArabic(String tunisianText) {
    String normalizedText = tunisianText;

    // Remplacer les modèles de phrases
    _mappings.sentencePatterns.forEach((tunisianPattern, standardPattern) {
      normalizedText =
          normalizedText.replaceAll(tunisianPattern, standardPattern);
    });

    // Remplacer les termes techniques
    _mappings.technicalTerms.forEach((tunisianTerm, standardTerm) {
      // Utiliser une expression régulière pour s'assurer que seuls les mots entiers sont remplacés
      final RegExp regExp = RegExp(r'\b' + RegExp.escape(tunisianTerm) + r'\b');
      normalizedText = normalizedText.replaceAll(regExp, standardTerm);
    });

    // Remplacer les expressions communes
    _mappings.commonExpressions.forEach((tunisianExpr, standardExpr) {
      normalizedText = normalizedText.replaceAll(tunisianExpr, standardExpr);
    });

    return normalizedText;
  }

  /// Convertit un texte en arabe standard vers le dialecte tunisien
  String convertToTunisianDialect(String standardText) {
    String tunisianText = standardText;

    // Inverser les mappings pour convertir de l'arabe standard au dialecte tunisien
    final Map<String, String> invertedTechnicalTerms =
        _mappings.technicalTerms.map((k, v) => MapEntry(v, k));

    final Map<String, String> invertedCommonExpressions =
        _mappings.commonExpressions.map((k, v) => MapEntry(v, k));

    final Map<String, String> invertedSentencePatterns =
        _mappings.sentencePatterns.map((k, v) => MapEntry(v, k));

    // Remplacer les modèles de phrases
    invertedSentencePatterns.forEach((standardPattern, tunisianPattern) {
      tunisianText = tunisianText.replaceAll(standardPattern, tunisianPattern);
    });

    // Remplacer les termes techniques
    invertedTechnicalTerms.forEach((standardTerm, tunisianTerm) {
      final RegExp regExp = RegExp(r'\b' + RegExp.escape(standardTerm) + r'\b');
      tunisianText = tunisianText.replaceAll(regExp, tunisianTerm);
    });

    // Remplacer les expressions communes
    invertedCommonExpressions.forEach((standardExpr, tunisianExpr) {
      tunisianText = tunisianText.replaceAll(standardExpr, tunisianExpr);
    });

    return tunisianText;
  }

  /// Détecte si un texte contient principalement du dialecte tunisien
  bool isTunisianDialect(String text) {
    int tunisianMarkers = 0;

    // Vérifier les expressions communes du dialecte tunisien
    for (String expr in _mappings.commonExpressions.keys) {
      if (text.contains(expr)) {
        tunisianMarkers++;
      }
    }

    // Vérifier les termes techniques tunisiens
    for (String term in _mappings.technicalTerms.keys) {
      if (text.contains(term)) {
        tunisianMarkers++;
      }
    }

    // Vérifier les modèles de phrases tunisiens
    for (String pattern in _mappings.sentencePatterns.keys) {
      if (text.contains(pattern)) {
        tunisianMarkers++;
      }
    }

    // Si plus de 2 marqueurs tunisiens sont trouvés, considérer que c'est du dialecte tunisien
    return tunisianMarkers > 2;
  }
}

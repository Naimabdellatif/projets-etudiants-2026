import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Fournit le contexte contextuel du véhicule et de son historique
/// pour enrichir le prompt système envoyé à Gemini.
class CarhabtiContextProvider {
  final SupabaseClient _supabase = Supabase.instance.client;

  // Singleton
  static final CarhabtiContextProvider _instance =
      CarhabtiContextProvider._internal();
  factory CarhabtiContextProvider() => _instance;
  CarhabtiContextProvider._internal();

  /// Construit un bloc de contexte textuel riche pour le system prompt.
  /// Renvoie une chaîne vide si les données ne sont pas disponibles.
  Future<String> buildContextBlock(String vehicleId) async {
    try {
      final futures = await Future.wait([
        _getVehicleInfo(vehicleId),
        _getWearData(vehicleId),
        _getRecentExpenses(vehicleId),
      ]);

      // ignore: unnecessary_cast
      final vehicleInfo = futures[0] as Map<String, dynamic>?;
      final wearData = futures[1] as Map<String, dynamic>;
      final expenses = futures[2] as Map<String, dynamic>;

      final buffer = StringBuffer();

      // --- Informations véhicule ---
      if (vehicleInfo != null) {
        buffer.writeln('## Informations du véhicule de l\'utilisateur');
        buffer.writeln('- Immatriculation : ${vehicleInfo['immatriculation'] ?? vehicleId}');
        buffer.writeln('- Marque : ${vehicleInfo['marque'] ?? 'Non renseignée'}');
        buffer.writeln('- Modèle : ${vehicleInfo['modele'] ?? 'Non renseigné'}');
        buffer.writeln('- Année : ${vehicleInfo['annee'] ?? 'Non renseignée'}');
        buffer.writeln('- Kilométrage actuel : ${vehicleInfo['kilometrage'] ?? 'Inconnu'} km');
        buffer.writeln('- Carburant : ${vehicleInfo['type_carburant'] ?? 'Non renseigné'}');
        buffer.writeln('- Type de route habituel : ${vehicleInfo['type_route'] ?? 'Non renseigné'}');
        buffer.writeln('- Style de conduite : ${vehicleInfo['style_conduite'] ?? 'Non renseigné'}');
      } else {
        buffer.writeln('## Véhicule');
        buffer.writeln('- Immatriculation : $vehicleId (détails non disponibles)');
      }

      // --- État des pièces (prédictions d'usure) ---
      if (wearData.isNotEmpty) {
        buffer.writeln('\n## État des pièces (prédictions d\'usure)');
        wearData.forEach((piece, data) {
          if (data is Map) {
            final usure = data['usure_pourcentage'];
            final dateRemplacement = data['date_remplacement'];
            if (usure != null) {
              buffer.write('- $piece : ${usure.toStringAsFixed(1)}% usure');
              if (dateRemplacement != null) {
                buffer.write(' (remplacement prévu : $dateRemplacement)');
              }
              buffer.writeln();
            }
          }
        });
      }

      // --- Dépenses récentes ---
      if (expenses['total'] != null) {
        buffer.writeln('\n## Données financières (30 derniers jours)');
        buffer.writeln('- Total dépenses : ${expenses['total']} TND');
        if (expenses['categories'] != null) {
          final cats = expenses['categories'] as Map<String, dynamic>;
          cats.forEach((cat, montant) {
            buffer.writeln('  • $cat : $montant TND');
          });
        }
      }

      return buffer.toString();
    } catch (e) {
      debugPrint('[CarhabtiContextProvider] Erreur construction contexte: $e');
      return '## Véhicule\n- Immatriculation : $vehicleId';
    }
  }

  /// Récupère les informations générales du véhicule
  Future<Map<String, dynamic>?> _getVehicleInfo(String vehicleId) async {
    try {
      final response = await _supabase
          .from('voiture')
          .select()
          .eq('immatriculation', vehicleId)
          .maybeSingle();
      return response;
    } catch (e) {
      debugPrint('[CarhabtiContextProvider] Erreur véhicule: $e');
      return null;
    }
  }

  /// Récupère les données d'usure des pièces depuis Supabase
  Future<Map<String, dynamic>> _getWearData(String vehicleId) async {
    final result = <String, dynamic>{};
    try {
      final pieceTables = {
        'Pneus': 'pneus',
        'Vidange': 'vidange',
        'Batterie': 'batterie',
        'Courroie de distribution': 'courroie',
        'Amortisseurs': 'amortisseurs',
        'Freins': 'freins',
        'Embrayage': 'embrayage',
      };

      for (final entry in pieceTables.entries) {
        try {
          final data = await _supabase
              .from(entry.value)
              .select('usure_pourcentage, date_remplacement, kilometrage_remplacement')
              .eq('immatriculation', vehicleId)
              .maybeSingle();
          if (data != null) {
            result[entry.key] = data;
          }
        } catch (_) {
          // Table peut ne pas exister ou colonne différente — ignorer silencieusement
        }
      }
    } catch (e) {
      debugPrint('[CarhabtiContextProvider] Erreur pièces: $e');
    }
    return result;
  }

  /// Récupère les dépenses des 30 derniers jours
  Future<Map<String, dynamic>> _getRecentExpenses(String vehicleId) async {
    try {
      final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));
      final response = await _supabase
          .from('vehicle_expenses')
          .select('amount, category')
          .eq('vehicle_id', vehicleId)
          .gte('date', thirtyDaysAgo.toIso8601String());

      if (response.isEmpty) return {};

      double total = 0;
      final categories = <String, double>{};
      for (final expense in response) {
        final amount = (expense['amount'] as num?)?.toDouble() ?? 0;
        final category = expense['category'] as String? ?? 'Autre';
        total += amount;
        categories[category] = (categories[category] ?? 0) + amount;
      }

      return {
        'total': total.toStringAsFixed(2),
        'categories': categories.map((k, v) => MapEntry(k, v.toStringAsFixed(2))),
      };
    } catch (e) {
      debugPrint('[CarhabtiContextProvider] Erreur dépenses: $e');
      return {};
    }
  }
}

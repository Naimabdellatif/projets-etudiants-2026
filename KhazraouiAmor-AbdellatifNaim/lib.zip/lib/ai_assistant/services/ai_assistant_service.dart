// Ce fichier est conservé pour la compatibilité des imports existants.
// L'assistant IA utilise désormais GeminiAiService.
// Voir : lib/ai_assistant/services/gemini_ai_service.dart

export 'gemini_ai_service.dart';

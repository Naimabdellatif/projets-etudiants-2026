// ignore_for_file: dead_code

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

import '../models/conversation_turn.dart';
import 'conversation_history_service.dart';
import 'Carhabti_context_provider.dart';

/// Résultat d'une génération de réponse IA
class AiResponse {
  final String text;
  final bool isError;
  final String? errorCode;

  const AiResponse({
    required this.text,
    this.isError = false,
    this.errorCode,
  });

  factory AiResponse.error(String message, {String? code}) =>
      AiResponse(text: message, isError: true, errorCode: code);
}

/// Service principal d'IA alimenté par l'API Google Gemini.
/// - Modèle : gemini-2.0-flash (gratuit, 1 500 req/jour)
/// - Architecture : RAG léger (contexte Supabase injecté dans le system prompt)
/// - Multi-tour : historique conversationnel persisté par vehicleId
/// - Multilingue : Français, Arabe, Dialecte tunisien
class GeminiAiService {
  // --------------------------------------------------------------------------
  // Configuration
  // --------------------------------------------------------------------------

  static const String _model = 'gemini-2.0-flash';
  static const String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  /// Nombre maximum de tokens dans la réponse
  static const int _maxOutputTokens = 1024;

  /// Température (0 = déterministe, 1 = créatif). 0.7 = bon équilibre.
  static const double _temperature = 0.7;

  // --------------------------------------------------------------------------
  // Dépendances
  // --------------------------------------------------------------------------

  final ConversationHistoryService _historyService = ConversationHistoryService();
  final CarhabtiContextProvider _contextProvider = CarhabtiContextProvider();
  final http.Client _httpClient = http.Client();

  // Singleton
  static final GeminiAiService _instance = GeminiAiService._internal();
  factory GeminiAiService() => _instance;
  GeminiAiService._internal();

  // --------------------------------------------------------------------------
  // API Key
  // --------------------------------------------------------------------------

  String? _apiKey;

  /// Initialise le service avec la clé API depuis .env
  /// Retourne `true` si la clé est disponible.
  bool initialize() {
    try {
      _apiKey = dotenv.env['GEMINI_API_KEY'];
      if (_apiKey == null || _apiKey!.isEmpty) {
        debugPrint('[GeminiAiService] ⚠️ GEMINI_API_KEY non trouvée dans .env');
        return false;
      }
      debugPrint('[GeminiAiService] ✅ Service initialisé (modèle: $_model)');
      return true;
    } catch (e) {
      debugPrint('[GeminiAiService] Erreur initialisation: $e');
      return false;
    }
  }

  bool get isConfigured => _apiKey != null && _apiKey!.isNotEmpty;

  // --------------------------------------------------------------------------
  // Point d'entrée principal
  // --------------------------------------------------------------------------

  /// Envoie un message utilisateur et retourne la réponse de l'assistant.
  /// [vehicleId] est l'immatriculation du véhicule actif.
  Future<AiResponse> sendMessage(
    String userMessage, {
    required String vehicleId,
  }) async {
    // Vérification de la configuration
    if (!isConfigured) {
      return AiResponse.error(
        'L\'assistant IA n\'est pas configuré. Veuillez ajouter votre clé API Gemini dans le fichier .env.',
        code: 'NO_API_KEY',
      );
    }

    if (userMessage.trim().isEmpty) {
      return AiResponse.error('Le message ne peut pas être vide.', code: 'EMPTY_MESSAGE');
    }

    try {
      // 1. Construire le contexte véhicule depuis Supabase
      final contextBlock = await _contextProvider.buildContextBlock(vehicleId);

      // 2. Récupérer l'historique conversationnel
      final history = await _historyService.getHistoryForLlm(vehicleId);

      // 3. Construire le corps de la requête Gemini
      final requestBody = _buildRequestBody(
        userMessage: userMessage,
        contextBlock: contextBlock,
        history: history,
      );

      // 4. Appel HTTP à l'API Gemini
      final response = await _callGeminiApi(requestBody);

      // 5. Persister les deux tours (user + model)
      await _historyService.addTurn(vehicleId, ConversationTurn.user(userMessage));
      await _historyService.addTurn(vehicleId, ConversationTurn.model(response.text));

      return response;
    } on GeminiApiException catch (e) {
      return AiResponse.error(e.userFriendlyMessage, code: e.code);
    } catch (e) {
      debugPrint('[GeminiAiService] Erreur inattendue: $e');
      return AiResponse.error(
        'Une erreur inattendue s\'est produite. Veuillez réessayer.',
        code: 'UNKNOWN',
      );
    }
  }

  // --------------------------------------------------------------------------
  // Construction du prompt et de la requête
  // --------------------------------------------------------------------------

  String _buildSystemPrompt(String contextBlock) {
    return '''Tu es CARHABTI-AI, l'assistant automobile intelligent de l'application Carhabti.
Tu es expert en mécanique automobile, maintenance préventive et gestion du budget automobile.

## Ton rôle
- Analyser les symptômes décrits et poser des questions de diagnostic pertinentes
- Interpréter les données d'usure des pièces pour donner des conseils personnalisés
- Expliquer les codes d'erreur OBD-II en langage clair
- Suggérer des actions (continuer à rouler / aller chez un mécanicien / urgence)
- Aider à comprendre les dépenses et optimiser le budget automobile

## Données du véhicule de l'utilisateur
$contextBlock

## Instructions importantes
1. **Langue** : Réponds dans la même langue que l'utilisateur (français, arabe standard, ou dialecte tunisien). Si l'utilisateur mélange les langues, adapte-toi.
2. **Personnalisation** : Utilise TOUJOURS les données du véhicule ci-dessus pour personnaliser tes réponses. Ne donne jamais des conseils génériques si tu as des données spécifiques.
3. **Sécurité** : Priorise toujours la sécurité. Si un problème est dangereux, dis-le clairement.
4. **Concision** : Tes réponses doivent être claires et utiles. Utilise des listes à puces quand c'est approprié.
5. **Honnêteté** : Si tu n'es pas certain d'un diagnostic, dis-le et recommande une visite chez un professionnel.
6. **Domaine** : Tu ne réponds qu'aux questions liées à l'automobile, la maintenance, le budget auto, et les services de Carhabti.
7. **Format** : Utilise le Markdown (gras, listes) pour structurer tes réponses lisibles.

## Termes du dialecte tunisien à reconnaître
- روا / كاوتشو = pneus
- فران = freins  
- فيل = huile moteur
- موتور = moteur
- بطارية = batterie
- كوريم = courroie de distribution
- ديبرياج / بلاكاج = embrayage
- شوك / ديكور = amortisseurs
- بواجي / بوجي = bougies
- شنوا / شنوة = qu'est-ce que / quel
- علاش = pourquoi
- وقتاش = quand
- كيفاش = comment
- عندي مشكل = j'ai un problème
- ماشي = ne marche pas / non''';
  }

  /// Construit le corps complet de la requête REST Gemini
  Map<String, dynamic> _buildRequestBody({
    required String userMessage,
    required String contextBlock,
    required List<ConversationTurn> history,
  }) {
    final systemPrompt = _buildSystemPrompt(contextBlock);

    // Les tours d'historique précédents (format Gemini)
    final List<Map<String, dynamic>> contents = [];

    // Ajouter l'historique précédent
    for (final turn in history) {
      contents.add(turn.toGeminiPart());
    }

    // Ajouter le message actuel de l'utilisateur
    contents.add({
      'role': 'user',
      'parts': [
        {'text': userMessage}
      ],
    });

    return {
      'system_instruction': {
        'parts': [
          {'text': systemPrompt}
        ]
      },
      'contents': contents,
      'generationConfig': {
        'maxOutputTokens': _maxOutputTokens,
        'temperature': _temperature,
        'topK': 40,
        'topP': 0.95,
        'responseMimeType': 'text/plain',
      },
      'safetySettings': [
        {
          'category': 'HARM_CATEGORY_HARASSMENT',
          'threshold': 'BLOCK_ONLY_HIGH',
        },
        {
          'category': 'HARM_CATEGORY_HATE_SPEECH',
          'threshold': 'BLOCK_ONLY_HIGH',
        },
        {
          'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
          'threshold': 'BLOCK_ONLY_HIGH',
        },
        {
          'category': 'HARM_CATEGORY_DANGEROUS_CONTENT',
          'threshold': 'BLOCK_ONLY_HIGH',
        },
      ],
    };
  }

  // --------------------------------------------------------------------------
  // Appel HTTP à l'API Gemini
  // --------------------------------------------------------------------------

  Future<AiResponse> _callGeminiApi(Map<String, dynamic> requestBody) async {
    final url = Uri.parse(
        '$_baseUrl/$_model:generateContent?key=$_apiKey');

    debugPrint('[GeminiAiService] → Appel API Gemini ($_model)');

    http.Response httpResponse;
    try {
      httpResponse = await _httpClient
          .post(
            url,
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
            },
            body: jsonEncode(requestBody),
          )
          .timeout(const Duration(seconds: 30));
    } on Exception catch (e) {
      throw GeminiApiException(
        'Impossible de contacter le serveur. Vérifiez votre connexion Internet.',
        code: 'NETWORK_ERROR',
        originalError: e,
      );
    }

    debugPrint('[GeminiAiService] ← Réponse HTTP ${httpResponse.statusCode}');

    if (httpResponse.statusCode == 200) {
      return _parseSuccessResponse(httpResponse.body);
    } else {
      _handleErrorResponse(httpResponse.statusCode, httpResponse.body);
      // Unreachable, _handleErrorResponse always throws
      throw GeminiApiException('Erreur inconnue', code: 'UNKNOWN');
    }
  }

  AiResponse _parseSuccessResponse(String body) {
    try {
      final json = jsonDecode(body) as Map<String, dynamic>;
      final candidates = json['candidates'] as List<dynamic>?;

      if (candidates == null || candidates.isEmpty) {
        // Vérifier si le contenu a été bloqué
        final promptFeedback = json['promptFeedback'] as Map<String, dynamic>?;
        final blockReason = promptFeedback?['blockReason'];
        if (blockReason != null) {
          return AiResponse.error(
            'Votre message n\'a pas pu être traité en raison des politiques de sécurité. '
            'Veuillez reformuler votre question.',
            code: 'BLOCKED_CONTENT',
          );
        }
        return AiResponse.error(
          'L\'assistant n\'a pas pu générer de réponse. Veuillez réessayer.',
          code: 'EMPTY_RESPONSE',
        );
      }

      final candidate = candidates[0] as Map<String, dynamic>;
      final content = candidate['content'] as Map<String, dynamic>?;
      final parts = content?['parts'] as List<dynamic>?;
      final text = (parts?.isNotEmpty == true)
          ? parts![0]['text'] as String? ?? ''
          : '';

      if (text.isEmpty) {
        return AiResponse.error(
          'L\'assistant a retourné une réponse vide. Veuillez réessayer.',
          code: 'EMPTY_TEXT',
        );
      }

      return AiResponse(text: text.trim());
    } catch (e) {
      debugPrint('[GeminiAiService] Erreur parsing réponse: $e\nBody: $body');
      throw GeminiApiException(
        'Erreur lors du traitement de la réponse du serveur.',
        code: 'PARSE_ERROR',
        originalError: e,
      );
    }
  }

  Never _handleErrorResponse(int statusCode, String body) {
    String userMessage;
    String code;

    switch (statusCode) {
      case 400:
        userMessage = 'Requête invalide. Le message est peut-être trop long.';
        code = 'BAD_REQUEST';
        break;
      case 401:
      case 403:
        userMessage =
            'Clé API invalide ou expirée. Vérifiez votre configuration dans le fichier .env.';
        code = 'AUTH_ERROR';
        break;
      case 429:
        userMessage =
            'Limite de requêtes atteinte (quota Gemini). Veuillez patienter quelques minutes avant de réessayer.';
        code = 'RATE_LIMIT';
        break;
      case 500:
      case 502:
      case 503:
        userMessage =
            'Le service Gemini est temporairement indisponible. Veuillez réessayer dans quelques instants.';
        code = 'SERVER_ERROR';
        break;
      default:
        userMessage =
            'Erreur de communication avec l\'assistant (code $statusCode). Veuillez réessayer.';
        code = 'HTTP_$statusCode';
    }

    debugPrint('[GeminiAiService] Erreur API $statusCode: $body');
    throw GeminiApiException(userMessage, code: code);
  }

  // --------------------------------------------------------------------------
  // Méthodes utilitaires
  // --------------------------------------------------------------------------

  /// Efface l'historique de conversation pour un véhicule
  Future<void> clearHistory(String vehicleId) =>
      _historyService.clearHistory(vehicleId);

  /// Retourne le nombre de tours dans l'historique
  Future<int> getHistoryCount(String vehicleId) =>
      _historyService.getTurnCount(vehicleId);

  /// Retourne l'historique complet (pour affichage)
  Future<List<ConversationTurn>> getHistory(String vehicleId) =>
      _historyService.loadHistory(vehicleId);

  void dispose() {
    _httpClient.close();
  }
}

// --------------------------------------------------------------------------
// Exception personnalisée
// --------------------------------------------------------------------------

class GeminiApiException implements Exception {
  final String userFriendlyMessage;
  final String code;
  final Object? originalError;

  const GeminiApiException(
    this.userFriendlyMessage, {
    required this.code,
    this.originalError,
  });

  @override
  String toString() =>
      'GeminiApiException[$code]: $userFriendlyMessage (original: $originalError)';
}

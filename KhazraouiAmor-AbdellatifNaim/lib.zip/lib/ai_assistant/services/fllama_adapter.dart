// Adaptateur fllama supprimé.
// L'assistant IA utilise désormais l'API Gemini via HTTP REST.
// Voir : lib/ai_assistant/services/gemini_ai_service.dart

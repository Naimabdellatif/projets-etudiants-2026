import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/conversation_turn.dart';

/// Service de persistance de l'historique de conversation par véhicule.
/// Utilise SharedPreferences pour un stockage léger et fiable.
class ConversationHistoryService {
  static const String _keyPrefix = 'Carhabti_chat_history_';

  /// Nombre maximum de tours conservés en mémoire et persistés
  static const int maxTurns = 40;

  /// Nombre maximum de tours envoyés au LLM (pour limiter les tokens)
  static const int maxTurnsForLlm = 10;

  // Singleton
  static final ConversationHistoryService _instance =
      ConversationHistoryService._internal();
  factory ConversationHistoryService() => _instance;
  ConversationHistoryService._internal();

  /// Cache en mémoire par vehicleId
  final Map<String, List<ConversationTurn>> _cache = {};

  /// Charge l'historique d'un véhicule depuis le stockage local
  Future<List<ConversationTurn>> loadHistory(String vehicleId) async {
    if (_cache.containsKey(vehicleId)) {
      return List.from(_cache[vehicleId]!);
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonString = prefs.getString('$_keyPrefix$vehicleId');
      if (jsonString == null || jsonString.isEmpty) {
        _cache[vehicleId] = [];
        return [];
      }
      final List<dynamic> jsonList = jsonDecode(jsonString);
      final turns =
          jsonList.map((e) => ConversationTurn.fromJson(e as Map<String, dynamic>)).toList();
      _cache[vehicleId] = turns;
      return List.from(turns);
    } catch (e) {
      debugPrint('[ConversationHistoryService] Erreur chargement: $e');
      _cache[vehicleId] = [];
      return [];
    }
  }

  /// Sauvegarde un tour de conversation
  Future<void> addTurn(String vehicleId, ConversationTurn turn) async {
    final history = await loadHistory(vehicleId);
    history.add(turn);
    // Limiter la taille
    if (history.length > maxTurns) {
      history.removeRange(0, history.length - maxTurns);
    }
    _cache[vehicleId] = history;
    await _persist(vehicleId, history);
  }

  /// Retourne les N derniers tours pour le contexte LLM
  Future<List<ConversationTurn>> getHistoryForLlm(String vehicleId) async {
    final history = await loadHistory(vehicleId);
    if (history.length <= maxTurnsForLlm) return List.from(history);
    return history.sublist(history.length - maxTurnsForLlm);
  }

  /// Efface l'historique d'un véhicule
  Future<void> clearHistory(String vehicleId) async {
    _cache[vehicleId] = [];
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('$_keyPrefix$vehicleId');
    } catch (e) {
      debugPrint('[ConversationHistoryService] Erreur suppression: $e');
    }
  }

  /// Efface tous les historiques (tous les véhicules)
  Future<void> clearAllHistory() async {
    _cache.clear();
    try {
      final prefs = await SharedPreferences.getInstance();
      final keys =
          prefs.getKeys().where((k) => k.startsWith(_keyPrefix)).toList();
      for (final key in keys) {
        await prefs.remove(key);
      }
    } catch (e) {
      debugPrint('[ConversationHistoryService] Erreur suppression totale: $e');
    }
  }

  /// Nombre de tours pour un véhicule
  Future<int> getTurnCount(String vehicleId) async {
    final history = await loadHistory(vehicleId);
    return history.length;
  }

  Future<void> _persist(
      String vehicleId, List<ConversationTurn> turns) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonList = turns.map((t) => t.toJson()).toList();
      await prefs.setString('$_keyPrefix$vehicleId', jsonEncode(jsonList));
    } catch (e) {
      debugPrint('[ConversationHistoryService] Erreur persistance: $e');
    }
  }
}

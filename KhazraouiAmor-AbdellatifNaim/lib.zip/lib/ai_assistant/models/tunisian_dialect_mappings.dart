/// Classe pour gérer les mappings entre le dialecte tunisien et l'arabe standard
class TunisianDialectMappings {
  /// Termes techniques automobiles en dialecte tunisien et leur équivalent en arabe standard
  final Map<String, String> technicalTerms;

  /// Expressions communes en dialecte tunisien et leur équivalent en arabe standard
  final Map<String, String> commonExpressions;

  /// Modèles de phrases/structures grammaticales en dialecte tunisien et leur équivalent en arabe standard
  final Map<String, String> sentencePatterns;

  /// Constructeur
  TunisianDialectMappings({
    required this.technicalTerms,
    required this.commonExpressions,
    required this.sentencePatterns,
  });

  /// Vérifie si un terme technique spécifique existe dans les mappings
  bool hasTechnicalTerm(String term) {
    return technicalTerms.containsKey(term.toLowerCase());
  }

  /// Récupère l'équivalent d'un terme technique en arabe standard
  String? getStandardArabicTerm(String tunisianTerm) {
    return technicalTerms[tunisianTerm.toLowerCase()];
  }

  /// Convertit l'objet en Map pour le stockage
  Map<String, dynamic> toMap() {
    return {
      'technicalTerms': technicalTerms,
      'commonExpressions': commonExpressions,
      'sentencePatterns': sentencePatterns,
    };
  }

  /// Crée un mapping à partir d'une Map
  factory TunisianDialectMappings.fromMap(Map<String, dynamic> map) {
    return TunisianDialectMappings(
      technicalTerms: Map<String, String>.from(map['technicalTerms']),
      commonExpressions: Map<String, String>.from(map['commonExpressions']),
      sentencePatterns: Map<String, String>.from(map['sentencePatterns']),
    );
  }

  /// Données initiales de base pour les mappings du dialecte tunisien
  factory TunisianDialectMappings.initial() {
    return TunisianDialectMappings(
      technicalTerms: {
        'موتور': 'محرك', // moteur
        'فران': 'مكابح', // freins
        'روا': 'عجلة', // roue
        'كاروسا': 'هيكل', // carrosserie
        'بلاكاج': 'دبرياج', // embrayage
        'ديبرياج': 'قابض', // embrayage
        'ديكور': 'ممتص الصدمات', // amortisseur
        'بواط': 'علبة السرعة', // boîte de vitesse
        'كارديان': 'عمود نقل الحركة', // cardan
        'كابل': 'سلك', // câble
        'بلومب': 'رصاص', // plomb
        'بطارية': 'بطارية', // batterie
        'فيل': 'زيت', // huile
        'فيلتر': 'مصفاة', // filtre
        'بوجي': 'شمعة الإشعال', // bougie
        'كوريم': 'سير المحرك', // courroie
        'بومبا': 'مضخة', // pompe
        'رادياتور': 'مبرد', // radiateur
        'كلاكسون': 'زمور', // klaxon
        'شوك': 'ممتص الصدمات', // amortisseur
        // Nouveaux termes techniques automobiles
        'سوباب': 'صمام', // soupape
        'صوباب': 'صمام', // soupape (autre orthographe)
        'المراسل': 'الصمامات', // les soupapes
        'دوزان': 'ضبط', // réglage
        'جونتة': 'حشية', // joint
        'جنط': 'إطار العجلة', // jante
        'ديمارور': 'بادئ التشغيل', // démarreur
        'كاربوراتور': 'المكربن', // carburateur
        'دينامو': 'المولد', // alternateur
        'كابلاج': 'أسلاك', // câblage
        'كوليس': 'مزلاق', // coulisse
        'سوفلاج': 'نفخ', // soufflage
        'ديغاجاج': 'تنظيف', // dégagement
        'بلوكاج': 'انسداد', // blocage
        'بيال': 'ذراع التوصيل', // bielle
        'تايتن': 'شد', // serrer
        'تورن الفولون': 'تدوير عجلة الموازنة', // tourner le volant moteur
        'رولمان': 'محمل', // roulement
        'سوبابة': 'صمام', // une soupape
        'كولاس': 'رأس المحرك', // culasse
      },
      commonExpressions: {
        'شنوا': 'ما هو', // qu'est-ce que
        'علاش': 'لماذا', // pourquoi
        'وقتاش': 'متى', // quand
        'فاش': 'في أي', // dans lequel
        'وين': 'أين', // où
        'باش': 'سوف', // pour
        'كيفاش': 'كيف', // comment
        'شكون': 'من', // qui
        // Nouvelles expressions communes
        'فما': 'يوجد', // il y a
        'ماشي': 'ليس', // ne pas
        'برشا': 'كثير', // beaucoup
        'مانيش': 'أنا لست', // je ne suis pas
        'خاطر': 'لأن', // parce que
        'ماهوش': 'ليس هو', // ce n'est pas
        'باهي': 'جيد', // bon
        'يزي': 'يكفي', // ça suffit
        'بالزربة': 'بسرعة', // rapidement
        'توا': 'الآن', // maintenant
        'بالسيف': 'بصعوبة', // difficilement
        'بش': 'سوف', // variante de باش
        'هاني': 'أنا هنا', // me voici
        'معناها': 'يعني', // cela signifie
        'فيسع': 'بسرعة', // rapidement
        'شوية': 'قليلاً', // un peu
      },
      sentencePatterns: {
        'عندي مشكل في': 'لدي مشكلة في', // j'ai un problème dans/avec
        'العربية متمشيش': 'السيارة لا تعمل', // la voiture ne fonctionne pas
        'ينجم يكون': 'قد يكون', // il peut être
        'لازم تبدل': 'يجب أن تغير', // tu dois changer
        // Nouveaux modèles de phrases
        'مانجمش نشغل': 'لا أستطيع تشغيل', // je ne peux pas faire fonctionner
        'كي نشد': 'عندما أضغط على', // quand j'appuie sur
        'كل مرة كي': 'في كل مرة عندما', // chaque fois que
        'نسمع فيه صوت': 'أسمع صوتًا من', // j'entends un bruit de
        'تطلعلي حاجة': 'تظهر لي شيء', // quelque chose m'apparaît
        'ماهوش ماشي': 'لا يعمل', // il ne fonctionne pas
        'يخبط في': 'يطرق في', // il frappe dans
        'مانعرفش شنوة': 'لا أعرف ما', // je ne sais pas quoi/ce que
        'وقتلي نمشي': 'عندما أسير', // quand je roule
        'وقتلي نزيد في': 'عندما أزيد من', // quand j'augmente
        'بش نبدل': 'سوف أغير', // je vais changer
        'صارتلي مشكلة': 'حدثت لي مشكلة', // j'ai eu un problème
      },
    );
  }
}

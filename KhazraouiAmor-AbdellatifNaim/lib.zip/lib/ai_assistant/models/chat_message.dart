// Ce fichier est conservé uniquement pour éviter les erreurs d'import résiduels.
// Toute la logique de chat est dans lib/ai_assistant/ui/chat_screen.dart
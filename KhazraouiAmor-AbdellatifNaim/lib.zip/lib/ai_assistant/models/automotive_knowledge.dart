/// Représente une information de connaissances mécaniques automobiles
class AutomotiveKnowledge {
  /// Identifiant unique de la connaissance
  final String id;

  /// Catégorie de la connaissance (ex: moteur, freins, transmission)
  final String category;

  /// Sous-catégorie plus spécifique
  final String? subcategory;

  /// Titre de la connaissance
  final String title;

  /// Contenu détaillé de la connaissance
  final String content;

  /// Termes/mots-clés associés à cette connaissance (pour la recherche)
  final List<String> keywords;

  /// Termes techniques en dialecte tunisien liés à cette connaissance
  final Map<String, String>? tunisianTerms;

  /// Constructeur
  AutomotiveKnowledge({
    required this.id,
    required this.category,
    this.subcategory,
    required this.title,
    required this.content,
    required this.keywords,
    this.tunisianTerms,
  });

  /// Convertit l'objet en Map pour le stockage
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'category': category,
      'subcategory': subcategory,
      'title': title,
      'content': content,
      'keywords': keywords,
      'tunisianTerms': tunisianTerms,
    };
  }

  /// Crée une connaissance à partir d'une Map
  factory AutomotiveKnowledge.fromMap(Map<String, dynamic> map) {
    return AutomotiveKnowledge(
      id: map['id'],
      category: map['category'],
      subcategory: map['subcategory'],
      title: map['title'],
      content: map['content'],
      keywords: List<String>.from(map['keywords']),
      tunisianTerms: map['tunisianTerms'] != null
          ? Map<String, String>.from(map['tunisianTerms'])
          : null,
    );
  }
}

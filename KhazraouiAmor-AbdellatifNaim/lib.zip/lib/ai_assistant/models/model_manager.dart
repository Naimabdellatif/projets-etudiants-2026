// AiModelManager supprimé — plus de gestion de modèle local.
// L'assistant IA utilise l'API Gemini (cloud).
// Voir : lib/ai_assistant/services/gemini_ai_service.dart

/// Classe stub conservée pour la compatibilité des références existantes
@Deprecated('Utilisez GeminiAiService à la place')
class AiModelManager {
  Future<bool> isModelDownloaded() async => true;
  Future<String?> getModelPath({Function(double)? onProgress}) async => null;
  Future<int> getModelSize() async => 0;
  Future<bool> deleteModel() async => true;
}

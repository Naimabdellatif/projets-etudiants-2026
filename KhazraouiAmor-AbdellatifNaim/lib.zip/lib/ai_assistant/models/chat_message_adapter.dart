import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:uuid/uuid.dart';

/// Adaptateur pour créer des messages de chat compatibles avec flutter_chat_ui
class ChatMessageAdapter {
  /// Crée un message utilisateur
  static types.TextMessage createUserMessage(String text) {
    return types.TextMessage(
      author: types.User(id: 'user'),
      id: const Uuid().v4(),
      text: text,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
  }

  /// Crée un message assistant
  static types.TextMessage createAssistantMessage(String text) {
    return types.TextMessage(
      author: types.User(id: 'bot'),
      id: const Uuid().v4(),
      text: text,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
  }
}

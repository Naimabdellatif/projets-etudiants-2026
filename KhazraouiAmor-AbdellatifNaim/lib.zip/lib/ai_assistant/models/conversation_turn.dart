/// Représente un tour de conversation (un message utilisateur ou modèle)
/// Compatible avec le format de l'API Gemini (roles: 'user' et 'model')
class ConversationTurn {
  /// Rôle : 'user' pour l'utilisateur, 'model' pour l'assistant IA
  final String role;

  /// Contenu textuel du message
  final String content;

  /// Horodatage du message
  final DateTime timestamp;

  const ConversationTurn({
    required this.role,
    required this.content,
    required this.timestamp,
  });

  /// Crée un tour utilisateur
  factory ConversationTurn.user(String content) => ConversationTurn(
        role: 'user',
        content: content,
        timestamp: DateTime.now(),
      );

  /// Crée un tour modèle (réponse IA)
  factory ConversationTurn.model(String content) => ConversationTurn(
        role: 'model',
        content: content,
        timestamp: DateTime.now(),
      );

  /// Sérialise vers Map pour l'API Gemini
  Map<String, dynamic> toGeminiPart() => {
        'role': role,
        'parts': [
          {'text': content}
        ],
      };

  /// Sérialise vers Map pour la persistance locale
  Map<String, dynamic> toJson() => {
        'role': role,
        'content': content,
        'timestamp': timestamp.toIso8601String(),
      };

  /// Désérialise depuis Map (persistance locale)
  factory ConversationTurn.fromJson(Map<String, dynamic> json) =>
      ConversationTurn(
        role: json['role'] as String,
        content: json['content'] as String,
        timestamp: DateTime.parse(json['timestamp'] as String),
      );

  @override
  String toString() => 'ConversationTurn(role: $role, content: ${content.substring(0, content.length.clamp(0, 50))}...)';
}

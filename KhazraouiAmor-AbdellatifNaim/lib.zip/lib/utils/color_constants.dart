import 'package:flutter/material.dart';

class ColorConstants {
  // Couleurs principales de l'application
  static const Color primaryColor = Color(0xFF2E5D7E);
  static const Color accentColor = Color(0xFF6A11CB);
  static const Color secondaryColor = Color(0xFF00C8FF);

  // Couleurs de l'assistant financier
  static const Color budgetGreen = Color(0xFF4CE3A0);
  static const Color budgetYellow = Color(0xFFFFA41B);
  static const Color budgetOrange = Color(0xFFFF8C42);
  static const Color budgetRed = Color(0xFFFF5A5A);

  // Gradients de fond
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primaryColor, accentColor],
  );

  static const LinearGradient secondaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [secondaryColor, primaryColor],
  );

  // Couleurs pour les catégories de dépenses
  static const Map<String, Color> expenseCategoryColors = {
    'carburant': Color(0xFF4361EE),
    'entretien': Color(0xFF3A86FF),
    'reparation': Color(0xFFFF006E),
    'assurance': Color(0xFF8338EC),
    'parking': Color(0xFFFB8500),
    'peage': Color(0xFFFFBE0B),
    'lavage': Color(0xFF00BBF9),
    'accessoires': Color(0xFF00F5D4),
    'amende': Color(0xFFFF595E),
    'autre': Color(0xFF6C757D),
  };

  // Couleurs sémantiques
  static const Color success = Color(0xFF4ECB71);
  static const Color warning = Color(0xFFFFD166);
  static const Color error = Color(0xFFEF476F);
  static const Color info = Color(0xFF118AB2);

  // Couleurs neutres
  static const Color textPrimary = Color(0xFF212529);
  static const Color textSecondary = Color(0xFF6C757D);
  static const Color background = Color(0xFFF8F9FA);
  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color divider = Color(0xFFE9ECEF);
}

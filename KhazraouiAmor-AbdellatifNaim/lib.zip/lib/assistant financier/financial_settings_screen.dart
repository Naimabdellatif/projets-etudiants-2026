// ignore_for_file: unused_field, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/assistant financier/services/expense_service.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:carhabti/assistant financier/services/finance_notification_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── Design System ────────────────────────────────────────────────────────────
class _DS {
  static const bg        = Color(0xFF0D1117);
  static const surface   = Color(0xFF161B22);
  static const glass     = Color(0xFF1C2333);
  static const border    = Color(0xFF30363D);
  static const cyan      = Color(0xFF00D4FF);
  static const gold      = Color(0xFFFFB84D);
  static const emerald   = Color(0xFF00E676);
  static const violet    = Color(0xFFBB86FC);
  static const amber     = Color(0xFFFFAB40);
  static const danger    = Color(0xFFFF5252);
  static const textPrimary   = Color(0xFFE6EDF3);
  static const textSecondary = Color(0xFF8B949E);
  static const textMuted     = Color(0xFF484F58);

  static TextStyle display(double size, {Color? color, FontWeight w = FontWeight.w700}) =>
      GoogleFonts.syne(fontSize: size, fontWeight: w, color: color ?? textPrimary, letterSpacing: -0.4);

  static TextStyle body(double size, {Color? color, FontWeight w = FontWeight.w400}) =>
      GoogleFonts.dmSans(fontSize: size, fontWeight: w, color: color ?? textSecondary, height: 1.5);

  static BoxDecoration card({Color? accent}) => BoxDecoration(
    color: surface,
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: accent?.withOpacity(0.2) ?? border),
    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))],
  );
}

class FinancialSettingsScreen extends StatefulWidget {
  final String immatriculation;
  final Function(double) onBudgetUpdated;

  const FinancialSettingsScreen({
    super.key,
    required this.immatriculation,
    required this.onBudgetUpdated,
  });

  @override
  State<FinancialSettingsScreen> createState() => _FinancialSettingsScreenState();
}

class _FinancialSettingsScreenState extends State<FinancialSettingsScreen> {
  final _expenseService = ExpenseService();
  final _notificationService = FinanceNotificationService();
  final _budgetController = TextEditingController();
  bool _isLoading = true;
  bool _notificationsEnabled = true;
  bool _recurringExpensesEnabled = true;
  final bool _receiptStorageEnabled = true;
  final String _currency = 'TND';

  bool _budgetAlertsEnabled = true;
  bool _recurringRemindersEnabled = true;
  bool _insightsEnabled = true;
  bool _anomalyAlertsEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadBudget();
    _loadUserSettings();
    _loadNotificationPreferences();
  }

  @override
  void dispose() {
    _budgetController.dispose();
    super.dispose();
  }

  Future<void> _loadBudget() async {
    setState(() { _isLoading = true; });
    try {
      final budget = await _expenseService.getMonthlyBudget(widget.immatriculation);
      setState(() {
        _budgetController.text = budget > 0 ? budget.toString() : '';
        _isLoading = false;
      });
    } catch (e) {
      setState(() { _isLoading = false; });
      _showError('Erreur lors du chargement du budget: $e');
    }
  }

  Future<void> _saveBudget() async {
    final budgetText = _budgetController.text.trim();
    if (budgetText.isEmpty) { _showError('Veuillez entrer un montant valide'); return; }
    final budget = double.tryParse(budgetText.replaceAll(',', '.'));
    if (budget == null || budget <= 0) { _showError('Veuillez entrer un montant valide'); return; }
    setState(() { _isLoading = true; });
    try {
      await _expenseService.setMonthlyBudget(widget.immatriculation, budget);
      _showSuccess('Budget mensuel mis à jour');
      setState(() { _isLoading = false; });
      widget.onBudgetUpdated(budget);
    } catch (e) {
      setState(() { _isLoading = false; });
      _showError('Erreur lors de la mise à jour du budget: $e');
    }
  }

  Future<void> _exportExpenses() async {
    setState(() { _isLoading = true; });
    try {
      final expenses = await _expenseService.exportExpenses(widget.immatriculation);
      final jsonData = jsonEncode(expenses);
      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/karhabti_expenses.json');
      await file.writeAsString(jsonData);
      await Share.shareXFiles([XFile(file.path)], text: 'Exportation des dépenses carhabti', subject: 'Exportation des dépenses carhabti');
      setState(() { _isLoading = false; });
    } catch (e) {
      setState(() { _isLoading = false; });
      _showError('Erreur lors de l\'exportation: $e');
    }
  }

  Future<void> _importExpenses() async {
    try {
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        await Permission.storage.request();
        status = await Permission.storage.status;
        if (!status.isGranted) { _showError('Permission d\'accès aux fichiers refusée'); return; }
      }
      final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
      if (result == null || result.files.isEmpty) return;
      setState(() { _isLoading = true; });
      final file = File(result.files.single.path!);
      final jsonData = await file.readAsString();
      try {
        final data = jsonDecode(jsonData) as List;
        final expenses = List<Map<String, dynamic>>.from(data.map((item) => Map<String, dynamic>.from(item)));
        final count = await _expenseService.importExpenses(widget.immatriculation, expenses);
        _showSuccess('$count dépenses importées avec succès');
      } catch (e) { _showError('Fichier JSON invalide: $e'); }
    } catch (e) { _showError('Erreur lors de l\'importation: $e'); }
    finally { setState(() { _isLoading = false; }); }
  }

  Future<void> _loadUserSettings() async {}

  Future<void> _loadNotificationPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _budgetAlertsEnabled = prefs.getBool('enable_budget_alerts') ?? true;
        _recurringRemindersEnabled = prefs.getBool('enable_recurring_reminders') ?? true;
        _insightsEnabled = prefs.getBool('enable_financial_insights') ?? true;
        _anomalyAlertsEnabled = prefs.getBool('enable_anomaly_alerts') ?? true;
      });
    } catch (e) { debugPrint('Erreur lors du chargement des préférences de notification: $e'); }
  }

  Future<void> _saveNotificationPreferences() async {
    try {
      await _notificationService.saveNotificationPreferences(
        enableBudgetAlerts: _budgetAlertsEnabled,
        enableRecurringReminders: _recurringRemindersEnabled,
        enableInsights: _insightsEnabled,
        enableAnomalyAlerts: _anomalyAlertsEnabled,
      );
      _showSuccess('Préférences de notification enregistrées');
    } catch (e) { _showError('Erreur lors de l\'enregistrement des préférences: $e'); }
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(Icons.check_circle_rounded, color: _DS.bg, size: 18.sp),
        SizedBox(width: 10.w),
        Text(message, style: _DS.body(13.sp, color: _DS.bg, w: FontWeight.w600)),
      ]),
      backgroundColor: _DS.emerald,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.all(12.w),
    ));
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message, style: _DS.body(13.sp, color: Colors.white)),
      backgroundColor: _DS.danger,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.all(12.w),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _DS.bg,
      appBar: AppBar(
        backgroundColor: _DS.bg,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: _DS.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _DS.border),
            ),
            child: Icon(Icons.arrow_back_ios_new_rounded, color: _DS.textPrimary, size: 15.sp),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Paramètres financiers', style: _DS.display(17.sp)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _DS.border.withOpacity(0.5)),
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: _DS.cyan, strokeWidth: 2))
          : SingleChildScrollView(
              padding: EdgeInsets.all(16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 8.h),
                  _buildSectionHeader('Budget mensuel', Icons.account_balance_wallet_outlined, _DS.gold),
                  SizedBox(height: 12.h),
                  _buildBudgetCard(),
                  SizedBox(height: 28.h),
                  _buildSectionHeader('Données', Icons.storage_outlined, _DS.cyan),
                  SizedBox(height: 12.h),
                  _buildDataCard(),
                  SizedBox(height: 28.h),
                  _buildSectionHeader('Notifications', Icons.notifications_outlined, _DS.violet),
                  SizedBox(height: 12.h),
                  _buildNotificationsCard(),
                  SizedBox(height: 28.h),
                  _buildSectionHeader('Notifications intelligentes', Icons.psychology_outlined, _DS.amber),
                  SizedBox(height: 12.h),
                  _buildSmartNotificationsCard(),
                  SizedBox(height: 28.h),
                  _buildSectionHeader('Confidentialité', Icons.shield_outlined, _DS.danger),
                  SizedBox(height: 12.h),
                  _buildPrivacyCard(),
                  SizedBox(height: 40.h),
                ],
              ),
            ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, Color accentColor) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(6.w),
          decoration: BoxDecoration(
            color: accentColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: accentColor.withOpacity(0.25)),
          ),
          child: Icon(icon, color: accentColor, size: 16.sp),
        ),
        SizedBox(width: 10.w),
        Text(title, style: _DS.display(15.sp, w: FontWeight.w700)),
      ],
    );
  }

  Widget _buildBudgetCard() {
    return Container(
      decoration: _DS.card(accent: _DS.gold),
      padding: EdgeInsets.all(18.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Définissez votre budget mensuel pour suivre vos dépenses par rapport à votre objectif.',
            style: _DS.body(13.sp),
          ),
          SizedBox(height: 16.h),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: _DS.glass,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _DS.border),
                  ),
                  child: TextField(
                    controller: _budgetController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    style: _DS.body(15.sp, color: _DS.textPrimary, w: FontWeight.w500),
                    cursorColor: _DS.gold,
                    decoration: InputDecoration(
                      labelText: 'Budget mensuel',
                      labelStyle: _DS.body(12.sp, color: _DS.textMuted),
                      prefixIcon: Icon(Icons.currency_lira, color: _DS.gold.withOpacity(0.7), size: 18.sp),
                      suffixText: 'TND',
                      suffixStyle: _DS.body(13.sp, color: _DS.gold, w: FontWeight.w600),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              GestureDetector(
                onTap: _saveBudget,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 14.h),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [_DS.gold, const Color(0xFFFF8F00)]),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: _DS.gold.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))],
                  ),
                  child: Text('Sauver', style: _DS.body(13.sp, color: _DS.bg, w: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDataCard() {
    return Container(
      decoration: _DS.card(accent: _DS.cyan),
      child: Column(
        children: [
          _buildActionTile(
            icon: Icons.upload_file_rounded,
            iconColor: _DS.cyan,
            title: 'Exporter les dépenses',
            subtitle: 'Télécharger un fichier JSON de vos données',
            onTap: _exportExpenses,
          ),
          Divider(color: _DS.border, height: 1),
          _buildActionTile(
            icon: Icons.download_rounded,
            iconColor: _DS.emerald,
            title: 'Importer des dépenses',
            subtitle: 'Charger un fichier JSON existant',
            onTap: _importExpenses,
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationsCard() {
    return Container(
      decoration: _DS.card(accent: _DS.violet),
      padding: EdgeInsets.all(16.w),
      child: Column(
        children: [
          _buildSwitchRow(
            title: 'Notifications financières',
            subtitle: 'Recevoir des alertes sur vos finances',
            value: _notificationsEnabled,
            accentColor: _DS.violet,
            onChanged: (v) => setState(() => _notificationsEnabled = v),
          ),
          SizedBox(height: 12.h),
          Divider(color: _DS.border),
          SizedBox(height: 12.h),
          _buildSwitchRow(
            title: 'Rappels paiements récurrents',
            subtitle: 'Recevoir des rappels pour vos dépenses récurrentes',
            value: _recurringExpensesEnabled,
            accentColor: _DS.violet,
            onChanged: (v) => setState(() => _recurringExpensesEnabled = v),
          ),
          SizedBox(height: 12.h),
          Divider(color: _DS.border),
          SizedBox(height: 12.h),
          _buildSwitchRow(
            title: 'Rapports mensuels',
            subtitle: 'Résumé de vos dépenses à la fin du mois',
            value: false,
            accentColor: _DS.violet,
            onChanged: (v) => setState(() => _notificationsEnabled = v),
          ),
        ],
      ),
    );
  }

  Widget _buildSmartNotificationsCard() {
    return Container(
      decoration: _DS.card(accent: _DS.amber),
      padding: EdgeInsets.all(16.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Personnalisez les alertes intelligentes.', style: _DS.body(13.sp)),
          SizedBox(height: 16.h),
          _buildSwitchRow(
            title: 'Alertes budget',
            subtitle: 'Approche ou dépassement de votre budget',
            value: _budgetAlertsEnabled,
            accentColor: _DS.amber,
            onChanged: (v) { setState(() => _budgetAlertsEnabled = v); _saveNotificationPreferences(); },
          ),
          SizedBox(height: 12.h),
          Divider(color: _DS.border),
          SizedBox(height: 12.h),
          _buildSwitchRow(
            title: 'Rappels dépenses récurrentes',
            subtitle: 'Rappels pour vos paiements récurrents',
            value: _recurringRemindersEnabled,
            accentColor: _DS.amber,
            onChanged: (v) { setState(() => _recurringRemindersEnabled = v); _saveNotificationPreferences(); },
          ),
          SizedBox(height: 12.h),
          Divider(color: _DS.border),
          SizedBox(height: 12.h),
          _buildSwitchRow(
            title: 'Analyses personnalisées',
            subtitle: 'Conseils basés sur vos habitudes de dépenses',
            value: _insightsEnabled,
            accentColor: _DS.violet,
            onChanged: (v) { setState(() => _insightsEnabled = v); _saveNotificationPreferences(); },
          ),
          SizedBox(height: 12.h),
          Divider(color: _DS.border),
          SizedBox(height: 12.h),
          _buildSwitchRow(
            title: 'Alertes anomalies',
            subtitle: 'Détection des dépenses inhabituelles',
            value: _anomalyAlertsEnabled,
            accentColor: _DS.danger,
            onChanged: (v) { setState(() => _anomalyAlertsEnabled = v); _saveNotificationPreferences(); },
          ),
        ],
      ),
    );
  }

  Widget _buildPrivacyCard() {
    return Container(
      decoration: _DS.card(accent: _DS.danger),
      child: _buildActionTile(
        icon: Icons.delete_forever_rounded,
        iconColor: _DS.danger,
        title: 'Supprimer toutes les dépenses',
        subtitle: 'Cette action est irréversible',
        onTap: _confirmDeleteAllExpenses,
        dangerous: true,
      ),
    );
  }

  Widget _buildActionTile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool dangerous = false,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Row(
          children: [
            Container(
              width: 40.w, height: 40.w,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: iconColor.withOpacity(0.25)),
              ),
              child: Icon(icon, color: iconColor, size: 18.sp),
            ),
            SizedBox(width: 14.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: _DS.body(14.sp, color: dangerous ? _DS.danger : _DS.textPrimary, w: FontWeight.w500)),
                  SizedBox(height: 2.h),
                  Text(subtitle, style: _DS.body(12.sp)),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: _DS.textMuted, size: 18.sp),
          ],
        ),
      ),
    );
  }

  Widget _buildSwitchRow({
    required String title,
    required String subtitle,
    required bool value,
    required Color accentColor,
    required Function(bool) onChanged,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: _DS.body(14.sp, color: _DS.textPrimary, w: FontWeight.w500)),
              SizedBox(height: 2.h),
              Text(subtitle, style: _DS.body(12.sp)),
            ],
          ),
        ),
        SizedBox(width: 12.w),
        GestureDetector(
          onTap: () => onChanged(!value),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 46.w, height: 25.h,
            decoration: BoxDecoration(
              color: value ? accentColor.withOpacity(0.15) : _DS.glass,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: value ? accentColor.withOpacity(0.5) : _DS.border),
            ),
            child: Stack(
              children: [
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 200),
                  left: value ? 21.w : 2.w,
                  top: 2.h,
                  child: Container(
                    width: 21.w, height: 21.h,
                    decoration: BoxDecoration(
                      color: value ? accentColor : _DS.textMuted,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _confirmDeleteAllExpenses() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: _DS.glass,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: _DS.border)),
        child: Padding(
          padding: EdgeInsets.all(24.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56.w, height: 56.w,
                decoration: BoxDecoration(
                  color: _DS.danger.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: _DS.danger.withOpacity(0.3)),
                ),
                child: Icon(Icons.delete_forever_rounded, color: _DS.danger, size: 28.sp),
              ),
              SizedBox(height: 16.h),
              Text('Supprimer toutes les dépenses', style: _DS.display(17.sp), textAlign: TextAlign.center),
              SizedBox(height: 8.h),
              Text(
                'Êtes-vous sûr de vouloir supprimer définitivement toutes vos dépenses ? Cette action est irréversible.',
                style: _DS.body(13.sp),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24.h),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: _DS.border),
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text('Annuler', style: _DS.body(14.sp, color: _DS.textSecondary, w: FontWeight.w500)),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () { Navigator.pop(context); _showError('Fonctionnalité non implémentée'); },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _DS.danger,
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text('Supprimer tout', style: _DS.body(14.sp, color: Colors.white, w: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
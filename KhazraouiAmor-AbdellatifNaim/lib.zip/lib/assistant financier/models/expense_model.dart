import 'package:intl/intl.dart';

// ─── Mois français statiques (pas de dépendance à la locale intl) ─────────────
const List<String> _frMonthNames = [
  '', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
  'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre',
];

String frenchMonthYear(DateTime date) {
  final m = _frMonthNames[date.month];
  final label = '$m ${date.year}';
  return label[0].toUpperCase() + label.substring(1);
}

String frenchMonthOnly(DateTime date) {
  return _frMonthNames[date.month];
}

// ─── Enum catégories ───────────────────────────────────────────────────────────
enum ExpenseCategory {
  carburant, entretien, reparation, assurance,
  parking, peage, lavage, accessoires, amende, autre
}

extension ExpenseCategoryExtension on ExpenseCategory {
  String get displayName {
    switch (this) {
      case ExpenseCategory.carburant:    return 'Carburant';
      case ExpenseCategory.entretien:    return 'Entretien';
      case ExpenseCategory.reparation:   return 'Réparation';
      case ExpenseCategory.assurance:    return 'Assurance';
      case ExpenseCategory.parking:      return 'Parking';
      case ExpenseCategory.peage:        return 'Péage';
      case ExpenseCategory.lavage:       return 'Lavage';
      case ExpenseCategory.accessoires:  return 'Accessoires';
      case ExpenseCategory.amende:       return 'Amende';
      case ExpenseCategory.autre:        return 'Autre';
    }
  }

  String get icon {
    switch (this) {
      case ExpenseCategory.carburant:    return 'assets/icons/gas.png';
      case ExpenseCategory.entretien:    return 'assets/icons/maintenance.png';
      case ExpenseCategory.reparation:   return 'assets/icons/repair.png';
      case ExpenseCategory.assurance:    return 'assets/icons/insurance.png';
      case ExpenseCategory.parking:      return 'assets/icons/parking.png';
      case ExpenseCategory.peage:        return 'assets/icons/toll.png';
      case ExpenseCategory.lavage:       return 'assets/icons/wash.png';
      case ExpenseCategory.accessoires:  return 'assets/icons/accessories.png';
      case ExpenseCategory.amende:       return 'assets/icons/fine.png';
      case ExpenseCategory.autre:        return 'assets/icons/other.png';
    }
  }

  String toLowerCase() => name.toLowerCase();
  int compareTo(ExpenseCategory other) => name.compareTo(other.name);
}

// ─── Modèle Expense ────────────────────────────────────────────────────────────
class Expense {
  final String?          id;
  final String           immatriculation;
  final String?          vehicleId;
  final ExpenseCategory  category;
  final String?          subcategory;
  final double           amount;
  final DateTime         date;
  final String?          description;
  final String?          vendor;
  final String?          receiptUrl;
  final double?          mileage;
  final bool             isRecurring;
  final String?          recurringPeriod;
  final String?          recurringFrequency;
  final List<String>?    tags;

  Expense({
    this.id,
    required this.immatriculation,
    this.vehicleId,
    required this.category,
    this.subcategory,
    required this.amount,
    required this.date,
    this.description,
    this.vendor,
    this.receiptUrl,
    this.mileage,
    this.isRecurring = false,
    this.recurringPeriod,
    this.recurringFrequency,
    this.tags,
  });

  factory Expense.fromJson(Map<String, dynamic> json) {
    // ── Champs critiques null-safe ─────────────────────────────────────────
    final rawDate   = json['date'];
    final rawAmount = json['amount'];
    final immat     = (json['immatriculation'] as String?)?.trim() ?? '';

    DateTime parsedDate;
    try {
      parsedDate = rawDate != null ? DateTime.parse(rawDate.toString()) : DateTime.now();
    } catch (_) {
      parsedDate = DateTime.now();
    }

    double parsedAmount;
    try {
      parsedAmount = rawAmount != null ? (rawAmount as num).toDouble() : 0.0;
    } catch (_) {
      parsedAmount = 0.0;
    }

    return Expense(
      id:                 json['id'] as String?,
      immatriculation:    immat,
      vehicleId:          (json['vehicle_id'] as String?) ?? immat,
      category:           _categoryFromString(json['category']?.toString() ?? ''),
      subcategory:        json['subcategory'] as String?,
      amount:             parsedAmount,
      date:               parsedDate,
      description:        json['description'] as String?,
      vendor:             json['vendor'] as String?,
      receiptUrl:         json['receipt_url'] as String?,
      mileage:            (json['mileage'] as num?)?.toDouble(),
      isRecurring:        (json['is_recurring'] as bool?) ?? false,
      recurringPeriod:    json['recurring_period'] as String?,
      recurringFrequency: (json['recurring_frequency'] as String?)
                              ?? (json['recurring_period'] as String?),
      tags: json['tags'] != null ? List<String>.from(json['tags'] as List) : null,
    );
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{
      'immatriculation':    immatriculation,
      'category':           category.name,
      'amount':             amount,
      'date':               date.toIso8601String(),
      'description':        description,
      'vendor':             vendor,
      'receipt_url':        receiptUrl,
      'mileage':            mileage,
      'is_recurring':       isRecurring,
      'recurring_period':   recurringPeriod ?? recurringFrequency,
      'recurring_frequency': recurringFrequency ?? recurringPeriod,
      'tags':               tags,
      'vehicle_id':         vehicleId ?? immatriculation,
      'subcategory':        subcategory,
    };
    if (id != null && id!.isNotEmpty) data['id'] = id;
    return data;
  }

  Expense copyWith({
    String?         id,
    String?         immatriculation,
    String?         vehicleId,
    ExpenseCategory? category,
    String?         subcategory,
    double?         amount,
    DateTime?       date,
    String?         description,
    String?         vendor,
    String?         receiptUrl,
    double?         mileage,
    bool?           isRecurring,
    String?         recurringPeriod,
    String?         recurringFrequency,
    List<String>?   tags,
  }) => Expense(
    id:                 id               ?? this.id,
    immatriculation:    immatriculation  ?? this.immatriculation,
    vehicleId:          vehicleId        ?? this.vehicleId,
    category:           category         ?? this.category,
    subcategory:        subcategory      ?? this.subcategory,
    amount:             amount           ?? this.amount,
    date:               date             ?? this.date,
    description:        description      ?? this.description,
    vendor:             vendor           ?? this.vendor,
    receiptUrl:         receiptUrl       ?? this.receiptUrl,
    mileage:            mileage          ?? this.mileage,
    isRecurring:        isRecurring      ?? this.isRecurring,
    recurringPeriod:    recurringPeriod  ?? this.recurringPeriod,
    recurringFrequency: recurringFrequency ?? this.recurringFrequency,
    tags:               tags             ?? this.tags,
  );

  String get formattedDate       => DateFormat('dd/MM/yyyy').format(date);
  String get formattedAmount     => '${amount.toStringAsFixed(2)} TND';
  String get categoryDisplayName => category.displayName;

  static ExpenseCategory _categoryFromString(String s) {
    try {
      return ExpenseCategory.values.firstWhere((c) => c.name == s);
    } catch (_) {
      return ExpenseCategory.autre;
    }
  }
}

// ─── Catégories ────────────────────────────────────────────────────────────────
class ExpenseCategories {
  static const String carburant   = 'Carburant';
  static const String entretien   = 'Entretien';
  static const String reparation  = 'Réparation';
  static const String assurance   = 'Assurance';
  static const String parking     = 'Parking';
  static const String peage       = 'Péage';
  static const String lavage      = 'Lavage';
  static const String accessoires = 'Accessoires';
  static const String amende      = 'Amende';
  static const String autre       = 'Autre';

  static List<String> getAllCategories() => [
    carburant, entretien, reparation, assurance,
    parking, peage, lavage, accessoires, amende, autre,
  ];

  static Map<String, List<String>> getSubcategories() => {
    entretien:   ['Vidange','Pneus','Freins','Batterie','Filtres','Amortisseurs','Courroie','Révision','Autre'],
    reparation:  ['Moteur','Transmission','Électrique','Carrosserie','Climatisation','Autre'],
    carburant:   ['Essence','Diesel','GPL','Électricité'],
    assurance:   ['Prime annuelle','Complément','Franchise'],
    parking:     ['Urbain','Aéroport','Résidence','Autre'],
    peage:       ['Autoroute','Pont/Tunnel','Autre'],
    lavage:      ['Intérieur','Extérieur','Complet','Autre'],
    accessoires: ['Multimédia','Confort','Sécurité','Autre'],
    amende:      ['Stationnement','Vitesse','Autre'],
    autre:       [],
  };
}
// ignore_for_file: deprecated_member_use

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/assistant financier/services/expense_service.dart';
import 'package:carhabti/utils/color_constants.dart';
import 'package:carhabti/assistant financier/add_expense_screen.dart';
import 'package:intl/intl.dart';
// SUPPRIMÉ : import 'dart:ui'; (ImageFilter n'est plus utilisé)

class BudgetProgressCard extends StatefulWidget {
  final String immatriculation;
  final double monthlyBudget;

  const BudgetProgressCard({
    super.key,
    required this.immatriculation,
    required this.monthlyBudget,
  });

  @override
  // ignore: library_private_types_in_public_api
  _BudgetProgressCardState createState() => _BudgetProgressCardState();
}

class _BudgetProgressCardState extends State<BudgetProgressCard>
    with SingleTickerProviderStateMixin {
  final ExpenseService _expenseService = ExpenseService();
  late AnimationController _animationController;
  late Animation<double> _progressAnimation;
  bool _isLoading = true;
  Map<String, dynamic> _budgetStatus = {
    'budget': 0.0,
    'spent': 0.0,
    'remaining': 0.0,
    'percentUsed': 0.0,
    'status': 'Chargement...'
  };

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _progressAnimation = Tween<double>(begin: 0.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );

    _loadBudgetStatus();
  }

  Future<void> _loadBudgetStatus() async {
    try {
      final budgetStatus = await _expenseService.getBudgetStatus(
        widget.immatriculation,
        widget.monthlyBudget,
      );

      setState(() {
        _budgetStatus = budgetStatus;
        _isLoading = false;

        // Mettre à jour l'animation avec la valeur réelle
        _progressAnimation = Tween<double>(
          begin: 0.0,
          end: (budgetStatus['percentUsed'] as double).clamp(0.0, 100.0) / 100,
        ).animate(
          CurvedAnimation(
            parent: _animationController,
            curve: Curves.easeOutCubic,
          ),
        );
      });

      _animationController.forward();
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors du chargement du statut du budget: $e');
      }
      setState(() => _isLoading = false);
    }
  }

  @override
  void didUpdateWidget(BudgetProgressCard oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.monthlyBudget != widget.monthlyBudget) {
      _loadBudgetStatus();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Obtenir le mois actuel en français
    final now = DateTime.now();
    final currentMonth = DateFormat('MMMM', 'fr_FR').format(now);
    final capitalizedMonth =
        currentMonth[0].toUpperCase() + currentMonth.substring(1);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
            spreadRadius: 5,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20.r),
        // SUPPRIMÉ : BackdropFilter(ImageFilter.blur(...))
        // Le blur GPU était le pire offenseur de performance sur émulateur.
        // À chaque frame du clavier, le shader blur était ré-compilé et ré-appliqué.
        // Remplacement simple : gradient dégradé sans effects GPU.
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(0.95),
                Colors.white.withOpacity(0.90),
              ],
            ),
            borderRadius: BorderRadius.circular(20.r),
            border: Border.all(
              color: Colors.grey.shade200,
              width: 1.5,
            ),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.r),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Budget - $capitalizedMonth',
                          style: GoogleFonts.poppins(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey[800],
                          ),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          '${widget.monthlyBudget.toStringAsFixed(0)} TND',
                          style: GoogleFonts.poppins(
                            fontSize: 22.sp,
                            fontWeight: FontWeight.bold,
                            color: ColorConstants.primaryColor,
                          ),
                        ),
                      ],
                    ),
                    _buildBudgetStatusIndicator(),
                  ],
                ),
                SizedBox(height: 20.h),
                _isLoading ? _buildLoadingProgress() : _buildBudgetProgress(),
                SizedBox(height: 16.h),
                _buildBudgetDetails(),
                SizedBox(height: 16.h),
                _buildAddExpenseButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingProgress() {
    return Column(
      children: [
        SizedBox(
          height: 10.h,
          child: LinearProgressIndicator(
            backgroundColor: Colors.grey[200],
            valueColor:
                AlwaysStoppedAnimation<Color>(ColorConstants.primaryColor),
          ),
        ),
        SizedBox(height: 8.h),
        Text(
          'Chargement du statut du budget...',
          style: GoogleFonts.poppins(
            fontSize: 12.sp,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildBudgetProgress() {
    final percentUsed = _budgetStatus['percentUsed'] as double;
    final Color progressColor = _getBudgetStatusColor(percentUsed);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Dépensé: ${_budgetStatus['spent'].toStringAsFixed(0)} TND',
              style: GoogleFonts.poppins(
                fontSize: 13.sp,
                color: Colors.grey[700],
              ),
            ),
            Text(
              'Restant: ${_budgetStatus['remaining'].toStringAsFixed(0)} TND',
              style: GoogleFonts.poppins(
                fontSize: 13.sp,
                fontWeight: FontWeight.w500,
                color: Colors.grey[700],
              ),
            ),
          ],
        ),
        SizedBox(height: 8.h),
        Stack(
          children: [
            // Fond de la barre de progression
            Container(
              height: 12.h,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(6.r),
              ),
            ),
            // Barre de progression animée
            AnimatedBuilder(
              animation: _progressAnimation,
              builder: (context, child) {
                return FractionallySizedBox(
                  widthFactor: _progressAnimation.value,
                  child: Container(
                    height: 12.h,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          progressColor.withOpacity(0.7),
                          progressColor,
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(6.r),
                      boxShadow: [
                        BoxShadow(
                          color: progressColor.withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
        SizedBox(height: 8.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              '${percentUsed.toStringAsFixed(1)}% utilisé',
              style: GoogleFonts.poppins(
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
                color: progressColor,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBudgetStatusIndicator() {
    if (_isLoading) {
      return SizedBox(
        width: 24.w,
        height: 24.h,
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor:
              AlwaysStoppedAnimation<Color>(ColorConstants.primaryColor),
        ),
      );
    }

    final percentUsed = _budgetStatus['percentUsed'] as double;
    final Color statusColor = _getBudgetStatusColor(percentUsed);
    final String statusText = _budgetStatus['status'] as String;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(
          color: statusColor.withOpacity(0.5),
          width: 1,
        ),
      ),
      child: Text(
        statusText,
        style: GoogleFonts.poppins(
          fontSize: 12.sp,
          fontWeight: FontWeight.w600,
          color: statusColor,
        ),
      ),
    );
  }

  Widget _buildBudgetDetails() {
    if (_isLoading) {
      return SizedBox.shrink();
    }

    final percentUsed = _budgetStatus['percentUsed'] as double;
    String budgetTip;

    if (percentUsed < 50) {
      budgetTip = 'Votre budget est en bonne santé ! Continuez ainsi.';
    } else if (percentUsed < 80) {
      budgetTip = 'Surveillez vos dépenses pour le reste du mois.';
    } else if (percentUsed < 100) {
      budgetTip = 'Attention ! Limitez vos dépenses non essentielles.';
    } else {
      budgetTip =
          'Budget dépassé ! Analysez vos dépenses pour le mois prochain.';
    }

    return Container(
      padding: EdgeInsets.all(12.r),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(
          color: Colors.grey[300]!,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.lightbulb_outline,
            color: ColorConstants.accentColor,
            size: 22.sp,
          ),
          SizedBox(width: 10.w),
          Expanded(
            child: Text(
              budgetTip,
              style: GoogleFonts.poppins(
                fontSize: 12.sp,
                color: Colors.grey[700],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddExpenseButton() {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => AddExpenseScreen(
              immatriculation: widget.immatriculation,
            ),
          ),
        ).then((_) => _loadBudgetStatus());
      },
      borderRadius: BorderRadius.circular(10.r),
      child: Ink(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              ColorConstants.primaryColor,
              ColorConstants.accentColor,
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(10.r),
          boxShadow: [
            BoxShadow(
              color: ColorConstants.primaryColor.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 12.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.add_circle_outline,
                color: Colors.white,
                size: 18.sp,
              ),
              SizedBox(width: 8.w),
              Text(
                'Ajouter une dépense',
                style: GoogleFonts.poppins(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getBudgetStatusColor(double percentUsed) {
    if (percentUsed < 50) {
      return ColorConstants.budgetGreen;
    } else if (percentUsed < 80) {
      return ColorConstants.budgetYellow;
    } else if (percentUsed < 100) {
      return ColorConstants.budgetOrange;
    } else {
      return ColorConstants.budgetRed;
    }
  }
}

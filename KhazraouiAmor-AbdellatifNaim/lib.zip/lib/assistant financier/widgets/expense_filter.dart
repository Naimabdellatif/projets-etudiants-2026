// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:carhabti/assistant financier/models/expense_model.dart';
import 'package:intl/intl.dart';

class ExpenseFilter extends StatefulWidget {
  final Function(Map<String, dynamic>) onFilterChanged;
  final Map<String, dynamic> initialFilters;

  const ExpenseFilter({
    super.key,
    required this.onFilterChanged,
    this.initialFilters = const {},
  });

  @override
  State<ExpenseFilter> createState() => _ExpenseFilterState();
}

class _ExpenseFilterState extends State<ExpenseFilter> {
  late Map<String, dynamic> _filters;
  final _fromDateController = TextEditingController();
  final _toDateController = TextEditingController();
  final _minAmountController = TextEditingController();
  final _maxAmountController = TextEditingController();

  @override
  void initState() {
    super.initState();

    // Initialiser les filtres avec les valeurs par défaut ou celles fournies
    _filters = {
      'categories': <String>[],
      'fromDate': null,
      'toDate': null,
      'minAmount': null,
      'maxAmount': null,
      'tags': <String>[],
      'vendors': <String>[],
      'sortBy': 'date',
      'sortDirection': 'desc',
    };

    // Appliquer les filtres initiaux s'ils existent
    if (widget.initialFilters.isNotEmpty) {
      _filters.addAll(widget.initialFilters);

      // Mettre à jour les contrôleurs de texte
      if (_filters['fromDate'] != null) {
        _fromDateController.text =
            DateFormat('dd/MM/yyyy').format(_filters['fromDate']);
      }

      if (_filters['toDate'] != null) {
        _toDateController.text =
            DateFormat('dd/MM/yyyy').format(_filters['toDate']);
      }

      if (_filters['minAmount'] != null) {
        _minAmountController.text = _filters['minAmount'].toString();
      }

      if (_filters['maxAmount'] != null) {
        _maxAmountController.text = _filters['maxAmount'].toString();
      }
    }
  }

  @override
  void dispose() {
    _fromDateController.dispose();
    _toDateController.dispose();
    _minAmountController.dispose();
    _maxAmountController.dispose();
    super.dispose();
  }

  void _updateFilter(String key, dynamic value) {
    setState(() {
      _filters[key] = value;
    });
    widget.onFilterChanged(_filters);
  }

  Future<void> _selectDate(BuildContext context, bool isFromDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isFromDate
          ? (_filters['fromDate'] ?? DateTime.now())
          : (_filters['toDate'] ?? DateTime.now()),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );

    if (picked != null) {
      setState(() {
        if (isFromDate) {
          _filters['fromDate'] = picked;
          _fromDateController.text = DateFormat('dd/MM/yyyy').format(picked);
        } else {
          _filters['toDate'] = picked;
          _toDateController.text = DateFormat('dd/MM/yyyy').format(picked);
        }
      });
      widget.onFilterChanged(_filters);
    }
  }

  void _resetFilters() {
    setState(() {
      _filters = {
        'categories': <String>[],
        'fromDate': null,
        'toDate': null,
        'minAmount': null,
        'maxAmount': null,
        'tags': <String>[],
        'vendors': <String>[],
        'sortBy': 'date',
        'sortDirection': 'desc',
      };

      _fromDateController.clear();
      _toDateController.clear();
      _minAmountController.clear();
      _maxAmountController.clear();
    });

    widget.onFilterChanged(_filters);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Filtres',
                style: TextStyle(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextButton(
                onPressed: _resetFilters,
                child: Text(
                  'Réinitialiser',
                  style: TextStyle(
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16.h),
          Text(
            'Catégorie',
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8.h),
          _buildCategoryFilter(),
          SizedBox(height: 16.h),
          Text(
            'Période',
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8.h),
          _buildDateRangeFilter(),
          SizedBox(height: 16.h),
          Text(
            'Montant',
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8.h),
          _buildAmountRangeFilter(),
          SizedBox(height: 16.h),
          Text(
            'Tri',
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8.h),
          _buildSortOptions(),
          SizedBox(height: 24.h),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).primaryColor,
                padding: EdgeInsets.symmetric(vertical: 12.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.r),
                ),
              ),
              child: Text(
                'Appliquer les filtres',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return Wrap(
      spacing: 8.w,
      runSpacing: 8.h,
      children: ExpenseCategories.getAllCategories().map((category) {
        final isSelected = (_filters['categories'] as List).contains(category);

        return FilterChip(
          label: Text(category),
          selected: isSelected,
          onSelected: (selected) {
            final List<String> categories =
                List<String>.from(_filters['categories']);

            if (selected) {
              categories.add(category);
            } else {
              categories.remove(category);
            }

            _updateFilter('categories', categories);
          },
          backgroundColor: Colors.grey.shade200,
          selectedColor: Theme.of(context).primaryColor.withOpacity(0.2),
          checkmarkColor: Theme.of(context).primaryColor,
          labelStyle: TextStyle(
            color: isSelected ? Theme.of(context).primaryColor : Colors.black87,
            fontSize: 12.sp,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildDateRangeFilter() {
    return Row(
      children: [
        Expanded(
          child: TextFormField(
            controller: _fromDateController,
            decoration: InputDecoration(
              hintText: 'De',
              prefixIcon: Icon(Icons.calendar_today, size: 20.sp),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 12.w,
                vertical: 12.h,
              ),
            ),
            readOnly: true,
            onTap: () => _selectDate(context, true),
          ),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: TextFormField(
            controller: _toDateController,
            decoration: InputDecoration(
              hintText: 'À',
              prefixIcon: Icon(Icons.calendar_today, size: 20.sp),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 12.w,
                vertical: 12.h,
              ),
            ),
            readOnly: true,
            onTap: () => _selectDate(context, false),
          ),
        ),
      ],
    );
  }

  Widget _buildAmountRangeFilter() {
    return Row(
      children: [
        Expanded(
          child: TextFormField(
            controller: _minAmountController,
            decoration: InputDecoration(
              hintText: 'Min',
              prefixIcon: Icon(Icons.euro, size: 20.sp),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 12.w,
                vertical: 12.h,
              ),
            ),
            keyboardType: TextInputType.number,
            onChanged: (value) {
              _updateFilter(
                  'minAmount', value.isEmpty ? null : double.tryParse(value));
            },
          ),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: TextFormField(
            controller: _maxAmountController,
            decoration: InputDecoration(
              hintText: 'Max',
              prefixIcon: Icon(Icons.euro, size: 20.sp),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 12.w,
                vertical: 12.h,
              ),
            ),
            keyboardType: TextInputType.number,
            onChanged: (value) {
              _updateFilter(
                  'maxAmount', value.isEmpty ? null : double.tryParse(value));
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSortOptions() {
    return Row(
      children: [
        Expanded(
          child: DropdownButtonFormField<String>(
            initialValue: _filters['sortBy'],
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.r),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 12.w,
                vertical: 12.h,
              ),
            ),
            items: [
              DropdownMenuItem(value: 'date', child: Text('Date')),
              DropdownMenuItem(value: 'amount', child: Text('Montant')),
              DropdownMenuItem(value: 'category', child: Text('Catégorie')),
            ],
            onChanged: (value) {
              if (value != null) {
                _updateFilter('sortBy', value);
              }
            },
          ),
        ),
        SizedBox(width: 12.w),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade400),
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Row(
            children: [
              _buildSortDirectionButton('asc', Icons.arrow_upward),
              Container(
                width: 1,
                height: 30.h,
                color: Colors.grey.shade400,
              ),
              _buildSortDirectionButton('desc', Icons.arrow_downward),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSortDirectionButton(String direction, IconData icon) {
    final isSelected = _filters['sortDirection'] == direction;

    return InkWell(
      onTap: () => _updateFilter('sortDirection', direction),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 12.w,
          vertical: 8.h,
        ),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).primaryColor.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.horizontal(
            left: direction == 'asc' ? Radius.circular(12.r) : Radius.zero,
            right: direction == 'desc' ? Radius.circular(12.r) : Radius.zero,
          ),
        ),
        child: Icon(
          icon,
          size: 20.sp,
          color: isSelected
              ? Theme.of(context).primaryColor
              : Colors.grey.shade600,
        ),
      ),
    );
  }
}

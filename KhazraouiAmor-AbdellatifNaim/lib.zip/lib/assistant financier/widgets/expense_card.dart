// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/assistant financier/models/expense_model.dart';
import 'package:carhabti/utils/color_constants.dart';
import 'package:intl/intl.dart';

class ExpenseCard extends StatelessWidget {
  final Expense expense;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final bool showActions;

  const ExpenseCard({
    super.key,
    required this.expense,
    this.onTap,
    this.onDelete,
    this.showActions = false,
  });

  @override
  Widget build(BuildContext context) {
    // Déterminer la couleur selon la catégorie
    // Utilisation du nom de l'enum pour la clé de couleur
    Color categoryColor =
        ColorConstants.expenseCategoryColors[expense.category.name] ??
            ColorConstants.expenseCategoryColors['autre']!;

    // Formater la date en français
    String formattedDate =
        DateFormat('dd MMM yyyy', 'fr_FR').format(expense.date);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16.r),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(
            color: Colors.grey.shade100,
            width: 1,
          ),
        ),
        margin: EdgeInsets.symmetric(vertical: 4.h),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16.r),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              splashColor: categoryColor.withOpacity(0.1),
              highlightColor: categoryColor.withOpacity(0.05),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                child: Row(
                  children: [
                    // Indicateur de catégorie
                    _buildCategoryIndicator(categoryColor),
                    SizedBox(width: 16.w),

                    // Informations principales
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                expense.subcategory ?? expense.categoryDisplayName,
                                style: GoogleFonts.poppins(
                                  fontSize: 15.sp,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey[800],
                                ),
                              ),
                              if (expense.isRecurring) _buildRecurringBadge(),
                            ],
                          ),
                          if (expense.subcategory != null)
                            Text(
                              expense.categoryDisplayName,
                              style: GoogleFonts.poppins(
                                fontSize: 11.sp,
                                color: Colors.grey[500],
                              ),
                            ),
                          SizedBox(height: 4.h),
                          if (expense.description != null &&
                              expense.description!.isNotEmpty)
                            Text(
                              expense.description!,
                              style: GoogleFonts.poppins(
                                fontSize: 12.sp,
                                color: Colors.grey[600],
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          SizedBox(height: 4.h),
                          Row(
                            children: [
                              Icon(
                                Icons.calendar_today_outlined,
                                size: 12.sp,
                                color: Colors.grey[500],
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                formattedDate,
                                style: GoogleFonts.poppins(
                                  fontSize: 12.sp,
                                  color: Colors.grey[500],
                                ),
                              ),
                              if (expense.vendor != null &&
                                  expense.vendor!.isNotEmpty) ...[
                                SizedBox(width: 8.w),
                                Icon(
                                  Icons.store_outlined,
                                  size: 12.sp,
                                  color: Colors.grey[500],
                                ),
                                SizedBox(width: 4.w),
                                Text(
                                  expense.vendor!,
                                  style: GoogleFonts.poppins(
                                    fontSize: 12.sp,
                                    color: Colors.grey[500],
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Montant
                    Padding(
                      padding: EdgeInsets.only(left: 8.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '${expense.amount.toStringAsFixed(2)} TND',
                            style: GoogleFonts.poppins(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.bold,
                              color: categoryColor,
                            ),
                          ),
                          if (expense.receiptUrl != null)
                            Padding(
                              padding: EdgeInsets.only(top: 4.h),
                              child: Icon(
                                Icons.receipt_outlined,
                                size: 14.sp,
                                color: Colors.grey[400],
                              ),
                            ),
                        ],
                      ),
                    ),

                    // Bouton de suppression (optionnel)
                    if (onDelete != null)
                      Padding(
                        padding: EdgeInsets.only(left: 8.w),
                        child: IconButton(
                          icon: Icon(
                            Icons.delete_outline,
                            color: Colors.grey[400],
                            size: 22.sp,
                          ),
                          onPressed: onDelete,
                          splashRadius: 24.r,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryIndicator(Color color) {
    return Container(
      width: 44.w,
      height: 44.w,
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: _getCategoryIcon(expense.category, color),
      ),
    );
  }

  Widget _buildRecurringBadge() {
    return Container(
      margin: EdgeInsets.only(left: 8.w),
      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: ColorConstants.info.withOpacity(0.15),
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.repeat,
            size: 10.sp,
            color: ColorConstants.info,
          ),
          SizedBox(width: 2.w),
          Text(
            'Récurrent',
            style: GoogleFonts.poppins(
              fontSize: 9.sp,
              fontWeight: FontWeight.w500,
              color: ColorConstants.info,
            ),
          ),
        ],
      ),
    );
  }

  Widget _getCategoryIcon(ExpenseCategory category, Color color) {
    IconData iconData;

    switch (category) {
      case ExpenseCategory.carburant:
        iconData = Icons.local_gas_station;
        break;
      case ExpenseCategory.entretien:
        iconData = Icons.build;
        break;
      case ExpenseCategory.reparation:
        iconData = Icons.handyman;
        break;
      case ExpenseCategory.assurance:
        iconData = Icons.security;
        break;
      case ExpenseCategory.parking:
        iconData = Icons.local_parking;
        break;
      case ExpenseCategory.peage:
        iconData = Icons.toll;
        break;
      case ExpenseCategory.lavage:
        iconData = Icons.water_drop;
        break;
      case ExpenseCategory.accessoires:
        iconData = Icons.car_repair;
        break;
      case ExpenseCategory.amende:
        iconData = Icons.gavel;
        break;
      case ExpenseCategory.autre:
        iconData = Icons.more_horiz;
        break;
    }

    return Icon(
      iconData,
      color: color,
      size: 22.sp,
    );
  }
}

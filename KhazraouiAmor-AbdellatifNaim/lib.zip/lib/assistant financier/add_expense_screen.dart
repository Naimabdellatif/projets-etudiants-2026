// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:carhabti/assistant financier/models/expense_model.dart';
import 'package:carhabti/assistant financier/services/expense_service.dart';
// SUPPRIMÉ : flutter_animate — il ré-exécutait les animations via le controller
// externe à chaque rebuild déclenché par l'ouverture du clavier, causant un gel.

class _DS {
  static const bg        = Color(0xFF0D1117);
  static const surface   = Color(0xFF161B22);
  static const glass     = Color(0xFF1C2333);
  static const border    = Color(0xFF30363D);
  static const cyan      = Color(0xFF00D4FF);
  static const gold      = Color(0xFFFFB84D);
  static const emerald   = Color(0xFF00E676);
  static const danger    = Color(0xFFFF5252);
  static const textPrimary   = Color(0xFFE6EDF3);
  static const textSecondary = Color(0xFF8B949E);
  static const textMuted     = Color(0xFF484F58);

  static TextStyle display(double size, {Color? color, FontWeight w = FontWeight.w700}) =>
      GoogleFonts.syne(fontSize: size, fontWeight: w, color: color ?? textPrimary, letterSpacing: -0.4);

  static TextStyle body(double size, {Color? color, FontWeight w = FontWeight.w400}) =>
      GoogleFonts.dmSans(fontSize: size, fontWeight: w, color: color ?? textSecondary, height: 1.5);

  static BoxDecoration card({Color? borderColor, double radius = 16}) => BoxDecoration(
    color: surface,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: borderColor ?? border, width: 1),
    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))],
  );

  static InputDecoration inputDeco({required String label, required String hint, required IconData icon, Color? accentColor}) {
    final ac = accentColor ?? cyan;
    return InputDecoration(
      labelText: label,
      hintText: hint,
      labelStyle: body(13.sp, color: textMuted),
      hintStyle: body(14.sp, color: textMuted),
      prefixIcon: Icon(icon, color: ac.withOpacity(0.7), size: 20.sp),
      filled: true,
      fillColor: glass,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: ac, width: 1.5)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: danger)),
      focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: danger, width: 1.5)),
      contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
      errorStyle: body(11.sp, color: danger),
    );
  }
}

class AddExpenseScreen extends StatefulWidget {
  final String immatriculation;
  final Expense? expense;

  const AddExpenseScreen({
    super.key,
    required this.immatriculation,
    this.expense,
  });

  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  // SUPPRIMÉ : SingleTickerProviderStateMixin + AnimationController.
  // L'AnimationController avec flutter_animate (controller externe) se
  // re-déclenchait à chaque rebuild lié au clavier → gel sur émulateur.
  // Remplacement par un simple bool + AnimatedOpacity géré nativement.

  final _formKey = GlobalKey<FormState>();
  final _expenseService = ExpenseService();

  // Animation d'entrée simple : pas de controller externe, pas de flutter_animate.
  bool _contentVisible = false;

  late ExpenseCategory _selectedCategory;
  String? _selectedSubcategory;
  final List<String> _selectedTags = [];

  final _amountController      = TextEditingController();
  final _descriptionController = TextEditingController();
  final _vendorController      = TextEditingController();
  final _dateController        = TextEditingController();

  bool _isRecurring = false;
  String? _recurringFrequency;
  bool _isLoading = false;
  DateTime _selectedDate = DateTime.now();

  final List<String> _recurringOptions = ['Mensuel', 'Trimestriel', 'Semestriel', 'Annuel'];

  @override
  void initState() {
    super.initState();
    _selectedCategory = ExpenseCategory.carburant;

    if (widget.expense != null) {
      _selectedCategory    = widget.expense!.category;
      _selectedSubcategory = widget.expense!.subcategory;
      _selectedDate        = widget.expense!.date;
      _isRecurring         = widget.expense!.isRecurring;
      _recurringFrequency  = widget.expense!.recurringFrequency;
      _amountController.text      = widget.expense!.amount.toString();
      _descriptionController.text = widget.expense!.description ?? '';
      _vendorController.text      = widget.expense!.vendor ?? '';
      _dateController.text        = DateFormat('dd/MM/yyyy').format(widget.expense!.date);
      if (widget.expense!.tags != null && widget.expense!.tags!.isNotEmpty) {
        _selectedTags.addAll(widget.expense!.tags!);
      }
    } else {
      _dateController.text = DateFormat('dd/MM/yyyy').format(_selectedDate);
    }

    // Déclencher l'animation d'entrée après le premier frame.
    // Un seul WidgetsBinding, pas de Future.delayed chaîné.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) setState(() => _contentVisible = true);
    });
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    _vendorController.dispose();
    _dateController.dispose();
    super.dispose();
  }

  void _updateSelectedCategory(String categoryDisplayName) {
    setState(() {
      _selectedCategory    = _categoryFromDisplayName(categoryDisplayName);
      _selectedSubcategory = null;
    });
  }

  ExpenseCategory _categoryFromDisplayName(String displayName) {
    try {
      return ExpenseCategory.values.firstWhere((c) => c.displayName == displayName);
    } catch (_) {
      return ExpenseCategory.autre;
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    // Pas d'interaction avec un AnimationController ici.
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.dark(
              primary: Color(0xFF00D4FF),
              onPrimary: Color(0xFF0D1117),
              surface: Color(0xFF161B22),
              onSurface: Color(0xFFE6EDF3),
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _dateController.text = DateFormat('dd/MM/yyyy').format(picked);
      });
    }
  }

  void _toggleTag(String tag) {
    setState(() {
      if (_selectedTags.contains(tag)) {
        _selectedTags.remove(tag);
      } else {
        _selectedTags.add(tag);
      }
    });
  }

  Future<void> _saveExpense() async {
    if (_formKey.currentState!.validate()) {
      setState(() { _isLoading = true; });
      try {
        final amount = double.parse(_amountController.text.replaceAll(',', '.'));
        final expense = Expense(
          id: widget.expense?.id,
          immatriculation: widget.immatriculation,
          vehicleId: widget.immatriculation,
          category: _selectedCategory,
          subcategory: _selectedSubcategory,
          amount: amount,
          date: _selectedDate,
          description: _descriptionController.text.isNotEmpty ? _descriptionController.text : null,
          vendor: _vendorController.text.isNotEmpty ? _vendorController.text : null,
          tags: _selectedTags.isNotEmpty ? _selectedTags : null,
          isRecurring: _isRecurring,
          recurringFrequency: _isRecurring ? _recurringFrequency : null,
        );
        if (widget.expense == null) {
          await _expenseService.addExpense(expense);
          _showSuccessSnackBar('Dépense ajoutée avec succès');
        } else {
          await _expenseService.updateExpense(expense);
          _showSuccessSnackBar('Dépense mise à jour avec succès');
        }
        if (mounted) Navigator.pop(context, true);
      } catch (e) {
        _showErrorSnackBar('Erreur: $e');
      } finally {
        if (mounted) setState(() { _isLoading = false; });
      }
    } else {
      HapticFeedback.mediumImpact();
    }
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(Icons.check_circle_rounded, color: _DS.bg, size: 20.sp),
        SizedBox(width: 12.w),
        Text(message, style: _DS.body(14.sp, color: _DS.bg, w: FontWeight.w600)),
      ]),
      backgroundColor: _DS.emerald,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      margin: EdgeInsets.all(12.w),
      duration: const Duration(seconds: 2),
    ));
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(Icons.error_outline_rounded, color: Colors.white, size: 20.sp),
        SizedBox(width: 12.w),
        Expanded(child: Text(message, style: _DS.body(14.sp, color: Colors.white, w: FontWeight.w500))),
      ]),
      backgroundColor: _DS.danger,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      margin: EdgeInsets.all(12.w),
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.expense != null;
    return Scaffold(
      backgroundColor: _DS.bg,
      // resizeToAvoidBottomInset: true (défaut) — le Scaffold gère le clavier
      // correctement. Mettre false forçait un conflit de layout sur émulateur.
      appBar: AppBar(
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: _DS.bg,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
        ),
        leading: IconButton(
          icon: Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: _DS.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _DS.border),
            ),
            child: Icon(Icons.arrow_back_ios_new_rounded, color: _DS.textPrimary, size: 15.sp),
          ),
          onPressed: () { if (mounted) Navigator.pop(context); },
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(isEditing ? 'Modifier la dépense' : 'Nouvelle dépense', style: _DS.display(17.sp)),
            Text(widget.immatriculation, style: _DS.body(11.sp, color: _DS.cyan)),
          ],
        ),
        actions: [
          if (isEditing)
            Padding(
              padding: EdgeInsets.only(right: 12.w),
              child: IconButton(
                icon: Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: _DS.danger.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _DS.danger.withOpacity(0.25)),
                  ),
                  child: Icon(Icons.delete_outline_rounded, color: _DS.danger, size: 18.sp),
                ),
                onPressed: _confirmDelete,
              ),
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _DS.border.withOpacity(0.5)),
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: _DS.cyan, strokeWidth: 2))
          : AnimatedOpacity(
              // Animation d'entrée simple et sûre : ne se re-déclenche PAS
              // lors des rebuilds liés au clavier (contrairement à flutter_animate
              // avec controller externe qui re-jouait à chaque setState).
              opacity: _contentVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 350),
              curve: Curves.easeOut,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 20.h),
                      _buildAmountHero(),
                      SizedBox(height: 20.h),
                      _buildSectionCard(title: 'Catégorie', icon: Icons.category_outlined, child: _buildCategorySelector()),
                      SizedBox(height: 12.h),
                      if ((_buildSubcategoryContent()) != null) ...[
                        _buildSectionCard(title: 'Sous-catégorie', icon: Icons.layers_outlined, child: _buildSubcategoryContent()!),
                        SizedBox(height: 12.h),
                      ],
                      _buildSectionCard(title: 'Date', icon: Icons.calendar_today_outlined, child: _buildDateField()),
                      SizedBox(height: 12.h),
                      _buildSectionCard(title: 'Description', icon: Icons.notes_rounded, child: _buildDescriptionField()),
                      SizedBox(height: 12.h),
                      _buildSectionCard(title: 'Fournisseur', icon: Icons.store_outlined, child: _buildVendorField()),
                      SizedBox(height: 12.h),
                      _buildSectionCard(title: 'Récurrence', icon: Icons.repeat_rounded, child: _buildRecurringToggle()),
                      SizedBox(height: 12.h),
                      if (_isRecurring) ...[
                        _buildSectionCard(title: 'Fréquence', icon: Icons.schedule_outlined, child: _buildRecurringFrequencySelector()),
                        SizedBox(height: 12.h),
                      ],
                      _buildSectionCard(title: 'Tags', icon: Icons.local_offer_outlined, child: _buildTagSelector()),
                      SizedBox(height: 32.h),
                      _buildSaveButton(isEditing),
                      // Padding pour que le bouton reste visible au-dessus du clavier
                      SizedBox(height: MediaQuery.of(context).viewInsets.bottom + 40.h),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  Widget _buildAmountHero() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_DS.cyan.withOpacity(0.08), _DS.gold.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _DS.cyan.withOpacity(0.2)),
      ),
      padding: EdgeInsets.all(20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8.w),
                decoration: BoxDecoration(
                  color: _DS.gold.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _DS.gold.withOpacity(0.25)),
                ),
                child: Icon(Icons.payments_outlined, color: _DS.gold, size: 18.sp),
              ),
              SizedBox(width: 10.w),
              Text('Montant', style: _DS.display(15.sp)),
            ],
          ),
          SizedBox(height: 16.h),
          // Pas de .animate() ici — TextField seul, sans flutter_animate
          TextFormField(
            controller: _amountController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            style: GoogleFonts.syne(fontSize: 28.sp, fontWeight: FontWeight.w700, color: _DS.textPrimary),
            decoration: InputDecoration(
              hintText: '0.00',
              hintStyle: GoogleFonts.syne(fontSize: 28.sp, fontWeight: FontWeight.w700, color: _DS.textMuted),
              suffixText: 'TND',
              suffixStyle: _DS.body(16.sp, color: _DS.gold, w: FontWeight.w600),
              filled: true,
              fillColor: Colors.transparent,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              errorBorder: UnderlineInputBorder(borderSide: BorderSide(color: _DS.danger)),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) return 'Veuillez entrer un montant';
              if (double.tryParse(value.replaceAll(',', '.')) == null) return 'Montant invalide';
              return null;
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSectionCard({required String title, required IconData icon, required Widget child}) {
    return Container(
      decoration: _DS.card(),
      padding: EdgeInsets.all(16.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: _DS.cyan.withOpacity(0.8), size: 18.sp),
              SizedBox(width: 8.w),
              Text(title, style: _DS.display(14.sp, w: FontWeight.w600)),
            ],
          ),
          SizedBox(height: 14.h),
          child,
        ],
      ),
    );
  }

  Widget _buildCategorySelector() {
    return Wrap(
      spacing: 8.w,
      runSpacing: 8.h,
      children: ExpenseCategories.getAllCategories().map((category) {
        final isSelected = _selectedCategory.displayName == category;
        return GestureDetector(
          onTap: () { _updateSelectedCategory(category); HapticFeedback.selectionClick(); },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 8.h),
            decoration: BoxDecoration(
              color: isSelected ? _DS.cyan.withOpacity(0.12) : _DS.glass,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isSelected ? _DS.cyan.withOpacity(0.5) : _DS.border,
                width: isSelected ? 1.5 : 1,
              ),
            ),
            child: Text(
              category,
              style: _DS.body(13.sp, color: isSelected ? _DS.cyan : _DS.textSecondary, w: isSelected ? FontWeight.w600 : FontWeight.w400),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget? _buildSubcategoryContent() {
    final subcategories = ExpenseCategories.getSubcategories()[_selectedCategory.displayName] ?? [];
    if (subcategories.isEmpty) return null;
    return Wrap(
      spacing: 8.w,
      runSpacing: 8.h,
      children: subcategories.map((sub) {
        final isSelected = _selectedSubcategory == sub;
        return GestureDetector(
          onTap: () { setState(() { _selectedSubcategory = isSelected ? null : sub; }); HapticFeedback.selectionClick(); },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 8.h),
            decoration: BoxDecoration(
              color: isSelected ? _DS.gold.withOpacity(0.1) : _DS.glass,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: isSelected ? _DS.gold.withOpacity(0.4) : _DS.border, width: isSelected ? 1.5 : 1),
            ),
            child: Text(sub, style: _DS.body(13.sp, color: isSelected ? _DS.gold : _DS.textSecondary, w: isSelected ? FontWeight.w600 : FontWeight.w400)),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildDateField() {
    return GestureDetector(
      onTap: () => _selectDate(context),
      child: AbsorbPointer(
        child: TextFormField(
          controller: _dateController,
          style: _DS.body(15.sp, color: _DS.textPrimary),
          decoration: _DS.inputDeco(label: 'Date de la dépense', hint: 'jj/mm/aaaa', icon: Icons.calendar_today_outlined),
          validator: (value) {
            if (value == null || value.isEmpty) return 'Veuillez sélectionner une date';
            return null;
          },
        ),
      ),
    );
  }

  Widget _buildDescriptionField() {
    return TextFormField(
      controller: _descriptionController,
      maxLines: 3,
      style: _DS.body(14.sp, color: _DS.textPrimary),
      // Pas de onTap/onEditingComplete liés à un AnimationController.
      textInputAction: TextInputAction.next,
      onEditingComplete: () => FocusScope.of(context).nextFocus(),
      decoration: _DS.inputDeco(label: 'Description (facultatif)', hint: 'Ajoutez une description...', icon: Icons.notes_rounded),
    );
  }

  Widget _buildVendorField() {
    return TextFormField(
      controller: _vendorController,
      style: _DS.body(14.sp, color: _DS.textPrimary),
      textInputAction: TextInputAction.done,
      decoration: _DS.inputDeco(label: 'Fournisseur (facultatif)', hint: 'Nom du fournisseur/garage...', icon: Icons.store_outlined),
    );
  }

  Widget _buildRecurringToggle() {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Dépense récurrente', style: _DS.body(14.sp, color: _DS.textPrimary, w: FontWeight.w500)),
              SizedBox(height: 3.h),
              Text('Activer pour les dépenses régulières', style: _DS.body(12.sp, color: _DS.textMuted)),
            ],
          ),
        ),
        GestureDetector(
          onTap: () {
            setState(() {
              _isRecurring = !_isRecurring;
              if (!_isRecurring) { _recurringFrequency = null; }
              else { _recurringFrequency ??= _recurringOptions.first; }
            });
            HapticFeedback.selectionClick();
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 48.w, height: 26.h,
            decoration: BoxDecoration(
              color: _isRecurring ? _DS.cyan.withOpacity(0.2) : _DS.glass,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: _isRecurring ? _DS.cyan.withOpacity(0.5) : _DS.border),
            ),
            child: Stack(
              children: [
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 200),
                  left: _isRecurring ? 22.w : 2.w,
                  top: 2.h,
                  child: Container(
                    width: 22.w, height: 22.h,
                    decoration: BoxDecoration(
                      color: _isRecurring ? _DS.cyan : _DS.textMuted,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRecurringFrequencySelector() {
    return Wrap(
      spacing: 8.w,
      runSpacing: 8.h,
      children: _recurringOptions.map((freq) {
        final isSelected = _recurringFrequency == freq;
        return GestureDetector(
          onTap: () { setState(() { _recurringFrequency = freq; }); HapticFeedback.selectionClick(); },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 9.h),
            decoration: BoxDecoration(
              color: isSelected ? _DS.emerald.withOpacity(0.1) : _DS.glass,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: isSelected ? _DS.emerald.withOpacity(0.4) : _DS.border, width: isSelected ? 1.5 : 1),
            ),
            child: Text(freq, style: _DS.body(13.sp, color: isSelected ? _DS.emerald : _DS.textSecondary, w: isSelected ? FontWeight.w600 : FontWeight.w400)),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTagSelector() {
    final List<String> suggestedTags = ['Urgence', 'Prévention', 'Garantie', 'Professionnel', 'Voyage', 'Concessionnaire', 'Remboursable'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Sélectionnez des tags pour catégoriser votre dépense', style: _DS.body(12.sp, color: _DS.textMuted)),
        SizedBox(height: 12.h),
        Wrap(
          spacing: 8.w,
          runSpacing: 8.h,
          children: suggestedTags.map((tag) {
            final isSelected = _selectedTags.contains(tag);
            return GestureDetector(
              onTap: () { _toggleTag(tag); HapticFeedback.selectionClick(); },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 7.h),
                decoration: BoxDecoration(
                  color: isSelected ? _DS.gold.withOpacity(0.1) : _DS.glass,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: isSelected ? _DS.gold.withOpacity(0.4) : _DS.border, width: isSelected ? 1.5 : 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (isSelected) ...[
                      Icon(Icons.check_rounded, size: 12.sp, color: _DS.gold),
                      SizedBox(width: 4.w),
                    ],
                    Text(tag, style: _DS.body(12.sp, color: isSelected ? _DS.gold : _DS.textSecondary, w: isSelected ? FontWeight.w600 : FontWeight.w400)),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSaveButton(bool isEditing) {
    // Pas de .animate() — bouton simple sans flutter_animate
    return SizedBox(
      width: double.infinity,
      height: 54.h,
      child: ElevatedButton(
        onPressed: _saveExpense,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.r)),
          padding: EdgeInsets.zero,
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [_DS.cyan, const Color(0xFF0099CC)]),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: _DS.cyan.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 6))],
          ),
          child: Container(
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(isEditing ? Icons.update_rounded : Icons.save_rounded, size: 20.sp, color: _DS.bg),
                SizedBox(width: 10.w),
                Text(
                  isEditing ? 'Mettre à jour' : 'Enregistrer la dépense',
                  style: _DS.body(15.sp, color: _DS.bg, w: FontWeight.w700),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: _DS.glass,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: _DS.border)),
        child: Padding(
          padding: EdgeInsets.all(24.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56.w, height: 56.w,
                decoration: BoxDecoration(
                  color: _DS.danger.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: _DS.danger.withOpacity(0.3)),
                ),
                child: Icon(Icons.warning_amber_rounded, color: _DS.danger, size: 28.sp),
              ),
              SizedBox(height: 16.h),
              Text('Supprimer la dépense', style: _DS.display(17.sp), textAlign: TextAlign.center),
              SizedBox(height: 8.h),
              Text(
                'Êtes-vous sûr de vouloir supprimer cette dépense ? Cette action est irréversible.',
                style: _DS.body(13.sp),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24.h),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: _DS.border),
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text('Annuler', style: _DS.body(14.sp, color: _DS.textSecondary, w: FontWeight.w500)),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _deleteExpense,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _DS.danger,
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text('Supprimer', style: _DS.body(14.sp, color: Colors.white, w: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _deleteExpense() async {
    if (widget.expense?.id == null) return;
    Navigator.pop(context);
    setState(() { _isLoading = true; });
    try {
      await _expenseService.deleteExpense(widget.expense!.id!);
      _showSuccessSnackBar('Dépense supprimée avec succès');
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _showErrorSnackBar('Erreur lors de la suppression: $e');
    } finally {
      if (mounted) setState(() { _isLoading = false; });
    }
  }
}
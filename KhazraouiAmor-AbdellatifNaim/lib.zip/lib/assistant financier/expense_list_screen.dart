// ignore_for_file: deprecated_member_use

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:carhabti/assistant financier/models/expense_model.dart';
import 'package:carhabti/assistant financier/services/expense_service.dart';
import 'package:carhabti/assistant financier/widgets/expense_card.dart';
import 'package:carhabti/assistant financier/widgets/expense_filter.dart';

// ─── Design System ────────────────────────────────────────────────────────────
class _DS {
  static const bg        = Color(0xFF0D1117);
  static const surface   = Color(0xFF161B22);
  static const glass     = Color(0xFF1C2333);
  static const border    = Color(0xFF30363D);
  static const cyan      = Color(0xFF00D4FF);
  static const gold      = Color(0xFFFFB84D);
  static const danger    = Color(0xFFFF5252);
  static const textPrimary   = Color(0xFFE6EDF3);
  static const textSecondary = Color(0xFF8B949E);
  static const textMuted     = Color(0xFF484F58);

  static TextStyle display(double size, {Color? color, FontWeight w = FontWeight.w700}) =>
      GoogleFonts.syne(fontSize: size, fontWeight: w, color: color ?? textPrimary, letterSpacing: -0.4);

  static TextStyle body(double size, {Color? color, FontWeight w = FontWeight.w400}) =>
      GoogleFonts.dmSans(fontSize: size, fontWeight: w, color: color ?? textSecondary, height: 1.5);
}

class ExpenseListScreen extends StatefulWidget {
  final String immatriculation;

  const ExpenseListScreen({
    super.key,
    required this.immatriculation,
  });

  @override
  State<ExpenseListScreen> createState() => _ExpenseListScreenState();
}

class _ExpenseListScreenState extends State<ExpenseListScreen>
    with SingleTickerProviderStateMixin {
  final _expenseService = ExpenseService();
  List<Expense> _expenses = [];
  bool _isLoading = true;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  // Debounce : évite de déclencher une requête Supabase à chaque frappe clavier.
  // Sans ce timer, chaque caractère tapé lançait getExpenses() → freeze émulateur.
  Timer? _searchDebounce;

  Map<String, dynamic> _filters = {
    'categories': <String>[],
    'fromDate': null,
    'toDate': null,
    'minAmount': null,
    'maxAmount': null,
    'tags': <String>[],
    'vendors': <String>[],
    'sortBy': 'date',
    'sortDirection': 'desc',
  };

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _loadExpenses();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _fadeCtrl.dispose();
    _searchDebounce?.cancel(); // Annuler le timer si l'écran est détruit
    super.dispose();
  }

  Future<void> _loadExpenses() async {
    setState(() { _isLoading = true; });
    try {
      final now = DateTime.now();
      final oneYearAgo = DateTime(now.year - 1, now.month, now.day);
      Map<String, DateTime> period = {
        'startDate': _filters['fromDate'] ?? oneYearAgo,
        'endDate': _filters['toDate'] ?? now,
      };
      final expenses = await _expenseService.getExpenses(widget.immatriculation, period);
      var filteredExpenses = expenses.where((expense) {
        if (_filters['categories'].isNotEmpty && !_filters['categories'].contains(expense.category)) return false;
        if (_filters['minAmount'] != null && expense.amount < _filters['minAmount']) return false;
        if (_filters['maxAmount'] != null && expense.amount > _filters['maxAmount']) return false;
        if (_filters['tags'].isNotEmpty && (expense.tags == null || !expense.tags!.any((tag) => _filters['tags'].contains(tag)))) return false;
        if (_filters['vendors'].isNotEmpty && (expense.vendor == null || !_filters['vendors'].contains(expense.vendor))) return false;
        if (_searchQuery.isNotEmpty) {
          final query = _searchQuery.toLowerCase();
          final matchesCategory = expense.category.toLowerCase().contains(query);
          final matchesSubcategory = expense.subcategory?.toLowerCase().contains(query) ?? false;
          final matchesDescription = expense.description?.toLowerCase().contains(query) ?? false;
          final matchesVendor = expense.vendor?.toLowerCase().contains(query) ?? false;
          if (!matchesCategory && !matchesSubcategory && !matchesDescription && !matchesVendor) return false;
        }
        return true;
      }).toList();
      filteredExpenses.sort((a, b) {
        int comparison;
        switch (_filters['sortBy']) {
          case 'amount':    comparison = a.amount.compareTo(b.amount); break;
          case 'category':  comparison = a.category.compareTo(b.category); break;
          case 'date':
          default:          comparison = a.date.compareTo(b.date); break;
        }
        return _filters['sortDirection'] == 'desc' ? -comparison : comparison;
      });
      setState(() { _expenses = filteredExpenses; _isLoading = false; });
      _fadeCtrl.forward(from: 0);
    } catch (e) {
      setState(() { _isLoading = false; });
      _showError('Erreur de chargement: $e');
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: _DS.body(13.sp, color: Colors.white)),
        backgroundColor: _DS.danger,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: EdgeInsets.all(12.w),
      ),
    );
  }

  void _navigateToExpenseDetail(Expense expense) {
    Navigator.pushNamed(context, '/financialAssistant/expenseDetail',
      arguments: {'expense': expense, 'immatriculation': widget.immatriculation},
    ).then((_) => _loadExpenses());
  }

  void _navigateToAddExpense() {
    Navigator.pushNamed(context, '/financialAssistant/addExpense',
      arguments: widget.immatriculation,
    ).then((_) => _loadExpenses());
  }

  void _showFilterSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _DS.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
        side: BorderSide(color: _DS.border),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.5,
        expand: false,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          child: ExpenseFilter(
            initialFilters: _filters,
            onFilterChanged: (filters) { setState(() { _filters = filters; }); },
          ),
        ),
      ),
    ).then((_) => _loadExpenses());
  }

  double get _totalAmount => _expenses.fold(0, (sum, e) => sum + e.amount);

  @override
  Widget build(BuildContext context) {
    final hasActiveFilters = _filters['categories'].isNotEmpty ||
        _filters['fromDate'] != null ||
        _filters['toDate'] != null ||
        _filters['minAmount'] != null ||
        _filters['maxAmount'] != null;

    return Scaffold(
      backgroundColor: _DS.bg,
      appBar: AppBar(
        backgroundColor: _DS.bg,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: _DS.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _DS.border),
            ),
            child: Icon(Icons.arrow_back_ios_new_rounded, color: _DS.textPrimary, size: 15.sp),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Dépenses', style: _DS.display(18.sp)),
            if (!_isLoading)
              Text('${_expenses.length} entrée${_expenses.length > 1 ? 's' : ''}',
                  style: _DS.body(11.sp, color: _DS.textMuted)),
          ],
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 12.w),
            child: GestureDetector(
              onTap: _showFilterSheet,
              child: Container(
                padding: EdgeInsets.all(9.w),
                decoration: BoxDecoration(
                  color: hasActiveFilters ? _DS.cyan.withOpacity(0.12) : _DS.surface,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: hasActiveFilters ? _DS.cyan.withOpacity(0.4) : _DS.border,
                  ),
                ),
                child: Icon(
                  Icons.tune_rounded,
                  color: hasActiveFilters ? _DS.cyan : _DS.textSecondary,
                  size: 18.sp,
                ),
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _DS.border.withOpacity(0.5)),
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: _DS.cyan, strokeWidth: 2))
          : FadeTransition(
              opacity: _fadeAnim,
              child: Column(
                children: [
                  // Barre de recherche
                  Padding(
                    padding: EdgeInsets.fromLTRB(16.w, 14.h, 16.w, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: _DS.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _searchQuery.isNotEmpty ? _DS.cyan.withOpacity(0.3) : _DS.border),
                      ),
                      child: TextField(
                        controller: _searchController,
                        style: _DS.body(14.sp, color: _DS.textPrimary),
                        cursorColor: _DS.cyan,
                        decoration: InputDecoration(
                          hintText: 'Rechercher une dépense...',
                          hintStyle: _DS.body(14.sp, color: _DS.textMuted),
                          prefixIcon: Icon(Icons.search_rounded, color: _DS.textMuted, size: 20.sp),
                          suffixIcon: _searchQuery.isNotEmpty
                              ? IconButton(
                                  icon: Icon(Icons.close_rounded, color: _DS.textMuted, size: 18.sp),
                                  onPressed: () {
                                    _searchDebounce?.cancel();
                                    setState(() { _searchController.clear(); _searchQuery = ''; });
                                    _loadExpenses();
                                  },
                                )
                              : null,
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 13.h),
                        ),
                        onChanged: (value) {
                          setState(() { _searchQuery = value; });
                          // Debounce 400ms : on attend que l'utilisateur
                          // arrête de taper avant de lancer la requête.
                          _searchDebounce?.cancel();
                          _searchDebounce = Timer(const Duration(milliseconds: 400), _loadExpenses);
                        },
                      ),
                    ),
                  ),

                  // Chips filtres actifs
                  if (hasActiveFilters || _searchQuery.isNotEmpty) ...[
                    SizedBox(height: 10.h),
                    _buildFilterChips(),
                  ],

                  // Stats bar
                  if (_expenses.isNotEmpty) ...[
                    SizedBox(height: 12.h),
                    _buildStatsBar(),
                  ],

                  SizedBox(height: 8.h),

                  // Liste
                  Expanded(
                    child: _expenses.isEmpty
                        ? _buildEmptyState()
                        : ListView.builder(
                            padding: EdgeInsets.fromLTRB(16.w, 4.h, 16.w, 100.h),
                            itemCount: _expenses.length,
                            itemBuilder: (context, index) => Padding(
                              padding: EdgeInsets.only(bottom: 8.h),
                              child: ExpenseCard(
                                expense: _expenses[index],
                                onTap: () => _navigateToExpenseDetail(_expenses[index]),
                                showActions: true,
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
      floatingActionButton: _expenses.isNotEmpty
          ? FloatingActionButton(
              backgroundColor: _DS.cyan,
              onPressed: _navigateToAddExpense,
              child: Icon(Icons.add_rounded, color: _DS.bg, size: 24.sp),
            )
          : null,
    );
  }

  Widget _buildStatsBar() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.w),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_DS.cyan.withOpacity(0.06), _DS.gold.withOpacity(0.04)],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _DS.border),
        ),
        child: Row(
          children: [
            Icon(Icons.receipt_long_rounded, color: _DS.cyan.withOpacity(0.7), size: 16.sp),
            SizedBox(width: 8.w),
            Text('${_expenses.length} dépenses', style: _DS.body(13.sp, color: _DS.textSecondary)),
            const Spacer(),
            Text(
              NumberFormat.currency(locale: 'fr', symbol: 'TND ', decimalDigits: 2).format(_totalAmount),
              style: _DS.display(14.sp, color: _DS.gold),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80.w, height: 80.w,
            decoration: BoxDecoration(
              color: _DS.surface,
              shape: BoxShape.circle,
              border: Border.all(color: _DS.border),
            ),
            child: Icon(Icons.receipt_long_outlined, size: 36.sp, color: _DS.textMuted),
          ),
          SizedBox(height: 20.h),
          Text('Aucune dépense trouvée', style: _DS.display(17.sp)),
          SizedBox(height: 8.h),
          Text('Ajoutez votre première dépense', style: _DS.body(13.sp)),
          SizedBox(height: 24.h),
          GestureDetector(
            onTap: _navigateToAddExpense,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_DS.cyan, const Color(0xFF0099CC)]),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(color: _DS.cyan.withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 4))],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.add_rounded, color: _DS.bg, size: 18.sp),
                  SizedBox(width: 8.w),
                  Text('Ajouter une dépense', style: _DS.body(14.sp, color: _DS.bg, w: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    final chips = <Widget>[];

    if (_filters['fromDate'] != null || _filters['toDate'] != null) {
      final fromDate = _filters['fromDate'] != null ? DateFormat('dd/MM/yy').format(_filters['fromDate']) : '';
      final toDate = _filters['toDate'] != null ? DateFormat('dd/MM/yy').format(_filters['toDate']) : '';
      chips.add(_buildFilterChip('$fromDate – $toDate', () {
        setState(() { _filters['fromDate'] = null; _filters['toDate'] = null; }); _loadExpenses();
      }));
    }
    if (_filters['categories'].isNotEmpty) {
      chips.add(_buildFilterChip('${_filters['categories'].length} catégories', () {
        setState(() { _filters['categories'] = <String>[]; }); _loadExpenses();
      }));
    }
    if (_filters['minAmount'] != null || _filters['maxAmount'] != null) {
      final min = _filters['minAmount'] != null ? _filters['minAmount'].toString() : '';
      final max = _filters['maxAmount'] != null ? _filters['maxAmount'].toString() : '';
      final text = min.isNotEmpty && max.isNotEmpty ? '$min – $max TND' : min.isNotEmpty ? '>$min TND' : '<$max TND';
      chips.add(_buildFilterChip(text, () {
        setState(() { _filters['minAmount'] = null; _filters['maxAmount'] = null; }); _loadExpenses();
      }));
    }
    if (_searchQuery.isNotEmpty) {
      chips.add(_buildFilterChip('"$_searchQuery"', () {
        setState(() { _searchController.clear(); _searchQuery = ''; }); _loadExpenses();
      }));
    }
    if (chips.isEmpty) return const SizedBox.shrink();

    return SizedBox(
      height: 32.h,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        itemCount: chips.length,
        separatorBuilder: (_, __) => SizedBox(width: 8.w),
        itemBuilder: (_, i) => chips[i],
      ),
    );
  }

  Widget _buildFilterChip(String label, VoidCallback onDelete) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: _DS.glass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _DS.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: _DS.body(11.sp, color: _DS.textSecondary, w: FontWeight.w500)),
          SizedBox(width: 6.w),
          GestureDetector(
            onTap: onDelete,
            child: Icon(Icons.close_rounded, size: 14.sp, color: _DS.textMuted),
          ),
        ],
      ),
    );
  }
}
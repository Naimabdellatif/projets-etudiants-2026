// ignore_for_file: empty_catches

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:carhabti/assistant financier/services/expense_service.dart';
import 'package:carhabti/assistant financier/models/expense_model.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

// Enum pour les priorités de notification
enum NotificationPriorityLevel { low, medium, high }

class FinanceNotificationService {
  final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();
  final ExpenseService _expenseService = ExpenseService();

  // Seuils pour les alertes budgétaires
  static const double _budgetWarningThreshold = 0.7; // 70% du budget
  static const double _budgetCriticalThreshold = 0.9; // 90% du budget

  // Canaux de notification
  static const String _budgetChannelId = 'budget_alerts';
  static const String _recurringChannelId = 'recurring_expenses';
  static const String _insightChannelId = 'financial_insights';
  static const String _anomalyChannelId = 'spending_anomalies';

  // Préférences de notification - valeurs par défaut
  static const bool _defaultBudgetAlertsEnabled = true;
  static const bool _defaultRecurringRemindersEnabled = true;
  static const bool _defaultInsightsEnabled = true;
  static const bool _defaultAnomalyAlertsEnabled = true;

  // Singleton
  static final FinanceNotificationService _instance =
      FinanceNotificationService._internal();

  FinanceNotificationService._internal();

  factory FinanceNotificationService() {
    return _instance;
  }

  Future<void> initialize() async {
    tz_data.initializeTimeZones();

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: DarwinInitializationSettings(),
    );

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Configurer les canaux de notification pour Android
    await _setupNotificationChannels();
  }

  Future<void> _setupNotificationChannels() async {
    // Canal pour les alertes budgétaires
    const AndroidNotificationChannel budgetChannel = AndroidNotificationChannel(
      _budgetChannelId,
      'Alertes Budgétaires',
      description: 'Notifications sur l\'état de votre budget mensuel',
      importance: Importance.high,
    );

    // Canal pour les rappels de dépenses récurrentes
    const AndroidNotificationChannel recurringChannel =
        AndroidNotificationChannel(
      _recurringChannelId,
      'Dépenses Récurrentes',
      description: 'Rappels pour vos dépenses récurrentes à venir',
      importance: Importance.high,
    );

    // Canal pour les analyses financières
    const AndroidNotificationChannel insightChannel =
        AndroidNotificationChannel(
      _insightChannelId,
      'Analyses Financières',
      description: 'Analyses et conseils personnalisés',
      importance: Importance.defaultImportance,
    );

    // Canal pour les anomalies de dépenses
    const AndroidNotificationChannel anomalyChannel =
        AndroidNotificationChannel(
      _anomalyChannelId,
      'Alertes Anomalies',
      description: 'Alertes pour des tendances de dépenses inhabituelles',
      importance: Importance.high,
    );

    final androidPlugin =
        _notificationsPlugin.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin != null) {
      await androidPlugin.createNotificationChannel(budgetChannel);
      await androidPlugin.createNotificationChannel(recurringChannel);
      await androidPlugin.createNotificationChannel(insightChannel);
      await androidPlugin.createNotificationChannel(anomalyChannel);
    }
  }

  void _onNotificationTapped(NotificationResponse response) {
  }

  // =========== VÉRIFICATIONS BUDGÉTAIRES ===========

  /// Vérifie le statut du budget et envoie des notifications si nécessaire
  Future<void> checkBudgetStatus(String immatriculation) async {
    if (!await _isNotificationTypeEnabled('budget_alerts')) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      final monthlyBudget =
          await _expenseService.getMonthlyBudget(immatriculation);

      if (monthlyBudget <= 0) return; // Pas de budget défini

      final budgetStatus =
          await _expenseService.getBudgetStatus(immatriculation, monthlyBudget);
      final percentUsed = budgetStatus['percentUsed'] as double;

      // Vérifier si on a déjà envoyé des alertes ce mois-ci pour éviter la duplication
      final now = DateTime.now();
      final currentMonth = '${now.year}-${now.month}';
      final warningAlertSent =
          prefs.getBool('budget_warning_$currentMonth') ?? false;
      final criticalAlertSent =
          prefs.getBool('budget_critical_$currentMonth') ?? false;

      // Alerte de seuil critique (90%)
      if (percentUsed >= _budgetCriticalThreshold * 100 && !criticalAlertSent) {
        await _showBudgetAlert(
          immatriculation,
          'Alerte Budget Critique',
          'Vous avez utilisé ${percentUsed.toStringAsFixed(1)}% de votre budget mensuel. Limitez vos dépenses!',
          NotificationPriorityLevel.high,
        );
        await prefs.setBool('budget_warning_$currentMonth', true);
        await prefs.setBool('budget_critical_$currentMonth', true);
      }
      // Alerte d'avertissement (70%)
      else if (percentUsed >= _budgetWarningThreshold * 100 &&
          !warningAlertSent) {
        await _showBudgetAlert(
          immatriculation,
          'Avertissement Budget',
          'Vous avez utilisé ${percentUsed.toStringAsFixed(1)}% de votre budget mensuel.',
          NotificationPriorityLevel.medium,
        );
        await prefs.setBool('budget_warning_$currentMonth', true);
      }

      // Réinitialiser les drapeaux le 1er du mois
      if (now.day == 1) {
        final lastMonth = now.month == 1
            ? '${now.year - 1}-12'
            : '${now.year}-${now.month - 1}';
        await prefs.remove('budget_warning_$lastMonth');
        await prefs.remove('budget_critical_$lastMonth');
      }
    } catch (e) {
    }
  }

  Future<void> _showBudgetAlert(
    String immatriculation,
    String title,
    String body,
    NotificationPriorityLevel priority,
  ) async {
    NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        _budgetChannelId,
        'Alertes Budgétaires',
        channelDescription: 'Notifications sur l\'état de votre budget mensuel',
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    await _notificationsPlugin.show(
      _generateNotificationId('budget', immatriculation),
      title,
      body,
      details,
      payload: 'budget_alert:$immatriculation',
    );

    // Sauvegarder dans l'historique
    await _saveNotificationToHistory(immatriculation, title, body, 'budget');
  }

  // =========== DÉPENSES RÉCURRENTES ===========

  /// Vérifie les dépenses récurrentes et planifie des rappels
  Future<void> scheduleRecurringExpenseReminders(String immatriculation) async {
    if (!await _isNotificationTypeEnabled('recurring_reminders')) return;

    try {
      final expenses = await _expenseService.getExpenses(immatriculation);
      final recurringExpenses = expenses.where((e) => e.isRecurring).toList();

      if (recurringExpenses.isEmpty) return;

      for (final expense in recurringExpenses) {
        // Ignorer si pas de période récurrente définie
        if (expense.recurringPeriod == null &&
            expense.recurringFrequency == null) {
          continue;
        }

        final period = expense.recurringPeriod ?? expense.recurringFrequency!;
        final nextDueDate = _calculateNextDueDate(expense.date, period);

        // Ignorer si la date est passée
        if (nextDueDate.isBefore(DateTime.now())) continue;

        // Planifier un rappel 3 jours avant
        final reminderDate = nextDueDate.subtract(const Duration(days: 3));
        if (reminderDate.isAfter(DateTime.now())) {
          _scheduleRecurringExpenseReminder(
            immatriculation,
            expense,
            nextDueDate,
            reminderDate,
          );
        }
      }
    } catch (e) {
    }
  }

  Future<void> _scheduleRecurringExpenseReminder(
    String immatriculation,
    Expense expense,
    DateTime dueDate,
    DateTime reminderDate,
  ) async {
    final formatter = DateFormat('dd/MM/yyyy');
    final notificationId = _generateNotificationId(
        'recurring', '${immatriculation}_${expense.id}');

    final String title = 'Rappel: ${expense.categoryDisplayName}';
    final String body =
        'Vous avez une dépense récurrente de ${expense.formattedAmount} prévue le ${formatter.format(dueDate)}.';

    final tz.TZDateTime scheduledDate =
        tz.TZDateTime.from(reminderDate, tz.local);

    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        _recurringChannelId,
        'Dépenses Récurrentes',
        channelDescription: 'Rappels pour vos dépenses récurrentes à venir',
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    await _notificationsPlugin.zonedSchedule(
      notificationId,
      title,
      body,
      scheduledDate,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );

    // Sauvegarder dans l'historique quand la notification est planifiée
    // Mais seulement si la date de rappel est aujourd'hui
    if (reminderDate.day == DateTime.now().day &&
        reminderDate.month == DateTime.now().month &&
        reminderDate.year == DateTime.now().year) {
      await _saveNotificationToHistory(
          immatriculation, title, body, 'recurring');
    }
  }

  DateTime _calculateNextDueDate(DateTime lastDate, String period) {
    final now = DateTime.now();
    DateTime nextDate = lastDate;

    // Si la date est déjà passée, calculer la prochaine date
    if (lastDate.isBefore(now)) {
      switch (period.toLowerCase()) {
        case 'mensuel':
          // Trouver la prochaine date jusqu'à ce qu'elle soit dans le futur
          while (nextDate.isBefore(now)) {
            nextDate =
                DateTime(nextDate.year, nextDate.month + 1, nextDate.day);
          }
          break;
        case 'trimestriel':
          while (nextDate.isBefore(now)) {
            nextDate =
                DateTime(nextDate.year, nextDate.month + 3, nextDate.day);
          }
          break;
        case 'semestriel':
          while (nextDate.isBefore(now)) {
            nextDate =
                DateTime(nextDate.year, nextDate.month + 6, nextDate.day);
          }
          break;
        case 'annuel':
          while (nextDate.isBefore(now)) {
            nextDate =
                DateTime(nextDate.year + 1, nextDate.month, nextDate.day);
          }
          break;
        default:
          // Par défaut, mensuel
          while (nextDate.isBefore(now)) {
            nextDate =
                DateTime(nextDate.year, nextDate.month + 1, nextDate.day);
          }
      }
    }

    return nextDate;
  }

  // =========== ANALYSES ET CONSEILS ===========

  /// Génère des analyses financières personnalisées et des conseils
  Future<void> generateFinancialInsights(String immatriculation) async {
    if (!await _isNotificationTypeEnabled('insights')) return;

    try {
      final expenses = await _expenseService.getExpenses(immatriculation);
      if (expenses.isEmpty) return;

      // 1. Analyse des catégories de dépenses principales
      final Map<ExpenseCategory, double> categoryStats =
          await _expenseService.getExpenseStatsByCategory(immatriculation);

      if (categoryStats.isEmpty) return;

      // Trouver la catégorie avec le plus de dépenses
      MapEntry<ExpenseCategory, double> topCategory =
          categoryStats.entries.reduce((a, b) => a.value > b.value ? a : b);

      // 2. Comparer avec les mois précédents
      final now = DateTime.now();
      final startOfMonth = DateTime(now.year, now.month, 1);
      final startOfLastMonth = DateTime(now.year, now.month - 1, 1);

      // Dépenses du mois courant
      double currentMonthTotal = expenses
          .where((e) =>
              e.date.isAfter(startOfMonth) ||
              e.date.isAtSameMomentAs(startOfMonth))
          .fold(0, (sum, e) => sum + e.amount);

      // Dépenses du mois précédent
      double lastMonthTotal = expenses
          .where((e) =>
              (e.date.isAfter(startOfLastMonth) ||
                  e.date.isAtSameMomentAs(startOfLastMonth)) &&
              e.date.isBefore(startOfMonth))
          .fold(0, (sum, e) => sum + e.amount);

      // Générer un message personnalisé
      String insightMessage = '';

      // Comparaison avec le mois précédent
      if (lastMonthTotal > 0) {
        double percentChange =
            ((currentMonthTotal - lastMonthTotal) / lastMonthTotal) * 100;

        if (percentChange >= 20) {
          insightMessage =
              'Vos dépenses ont augmenté de ${percentChange.abs().toStringAsFixed(1)}% par rapport au mois dernier. La catégorie ${topCategory.key.displayName} représente votre poste de dépense principal.';
        } else if (percentChange <= -10) {
          insightMessage =
              'Bravo! Vos dépenses ont diminué de ${percentChange.abs().toStringAsFixed(1)}% par rapport au mois dernier. Continuez ainsi!';
        }
      }

      // Conseil sur la catégorie principale
      if (insightMessage.isEmpty) {
        insightMessage =
            'Votre catégorie de dépense principale est ${topCategory.key.displayName} (${topCategory.value.toStringAsFixed(0)} TND). Essayez d\'établir un budget spécifique pour cette catégorie.';
      }

      // Envoyer la notification d'analyse
      await _showInsightNotification(immatriculation, insightMessage);
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors de la génération des analyses: $e');
      }
    }
  }

  Future<void> _showInsightNotification(
      String immatriculation, String message) async {
    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        _insightChannelId,
        'Analyses Financières',
        channelDescription: 'Analyses et conseils personnalisés',
        importance: Importance.defaultImportance,
        priority: Priority.defaultPriority,
        icon: '@mipmap/ic_launcher',
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    await _notificationsPlugin.show(
      _generateNotificationId('insight', immatriculation),
      'Conseil financier personnalisé',
      message,
      details,
      payload: 'financial_insight:$immatriculation',
    );

    // Sauvegarder dans l'historique
    await _saveNotificationToHistory(
        immatriculation, 'Conseil financier personnalisé', message, 'insight');
  }

  // =========== ALERTES D'ANOMALIES ===========

  /// Détecte les anomalies dans les dépenses et envoie des alertes
  Future<void> detectSpendingAnomalies(String immatriculation) async {
    if (!await _isNotificationTypeEnabled('anomaly_alerts')) return;

    try {
      final expenses = await _expenseService.getExpenses(immatriculation);
      if (expenses.length < 5) return; // Pas assez de données pour l'analyse

      // 1. Calculer la moyenne des dépenses
      final double averageExpense =
          expenses.fold(0.0, (sum, expense) => sum + expense.amount) /
              expenses.length;

      // 2. Trouver les dépenses récentes anormalement élevées (200% au-dessus de la moyenne)
      final DateTime lastMonth =
          DateTime.now().subtract(const Duration(days: 30));
      final List<Expense> recentExpenses =
          expenses.where((e) => e.date.isAfter(lastMonth)).toList();

      final List<Expense> anomalies =
          recentExpenses.where((e) => e.amount >= averageExpense * 2).toList();

      if (anomalies.isEmpty) return;

      // Envoyer une alerte pour la plus grande anomalie
      final Expense biggestAnomaly =
          anomalies.reduce((a, b) => a.amount > b.amount ? a : b);

      final String title = 'Dépense inhabituelle détectée';
      final String body =
          'Une dépense de ${biggestAnomaly.formattedAmount} en ${biggestAnomaly.categoryDisplayName} est nettement supérieure à vos habitudes.';

      await _showAnomalyAlert(immatriculation, title, body, biggestAnomaly.id);
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors de la détection des anomalies: $e');
      }
    }
  }

  Future<void> _showAnomalyAlert(String immatriculation, String title,
      String body, String? expenseId) async {
    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        _anomalyChannelId,
        'Alertes Anomalies',
        channelDescription:
            'Alertes pour des tendances de dépenses inhabituelles',
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    await _notificationsPlugin.show(
      _generateNotificationId('anomaly', immatriculation),
      title,
      body,
      details,
      payload: 'spending_anomaly:$immatriculation:$expenseId',
    );

    // Sauvegarder dans l'historique
    await _saveNotificationToHistory(immatriculation, title, body, 'anomaly');
  }

  // =========== PROGRAMMATION ET UTILITAIRES ===========

  /// Programme toutes les vérifications régulières
  Future<void> scheduleDailyChecks(String immatriculation) async {
    // Planifier les vérifications quotidiennes à 9h du matin
    final now = DateTime.now();
    DateTime scheduledTime = DateTime(now.year, now.month, now.day, 9, 0);

    // Si l'heure est déjà passée, planifier pour le lendemain
    if (scheduledTime.isBefore(now)) {
      scheduledTime = scheduledTime.add(const Duration(days: 1));
    }

    // Programmer les vérifications selon un timer
    Timer.periodic(const Duration(days: 1), (_) {
      checkBudgetStatus(immatriculation);
      scheduleRecurringExpenseReminders(immatriculation);
      detectSpendingAnomalies(immatriculation);

      // Générer des insights une fois par semaine (le dimanche)
      if (DateTime.now().weekday == DateTime.sunday) {
        generateFinancialInsights(immatriculation);
      }
    });

    // Faire la première vérification immédiatement
    checkBudgetStatus(immatriculation);
    scheduleRecurringExpenseReminders(immatriculation);
    detectSpendingAnomalies(immatriculation);
  }

  // Générer un ID de notification unique
  int _generateNotificationId(String type, String identifier) {
    return '${type}_$identifier'.hashCode %
        2147483647; // S'assurer qu'il est dans les limites des entiers Android
  }

  // Vérifier si un type de notification est activé
  Future<bool> _isNotificationTypeEnabled(String notificationType) async {
    final prefs = await SharedPreferences.getInstance();
    switch (notificationType) {
      case 'budget_alerts':
        return prefs.getBool('enable_budget_alerts') ??
            _defaultBudgetAlertsEnabled;
      case 'recurring_reminders':
        return prefs.getBool('enable_recurring_reminders') ??
            _defaultRecurringRemindersEnabled;
      case 'insights':
        return prefs.getBool('enable_financial_insights') ??
            _defaultInsightsEnabled;
      case 'anomaly_alerts':
        return prefs.getBool('enable_anomaly_alerts') ??
            _defaultAnomalyAlertsEnabled;
      default:
        return true;
    }
  }

  // Enregistrer les préférences de notification
  Future<void> saveNotificationPreferences({
    bool? enableBudgetAlerts,
    bool? enableRecurringReminders,
    bool? enableInsights,
    bool? enableAnomalyAlerts,
  }) async {
    final prefs = await SharedPreferences.getInstance();

    if (enableBudgetAlerts != null) {
      await prefs.setBool('enable_budget_alerts', enableBudgetAlerts);
    }

    if (enableRecurringReminders != null) {
      await prefs.setBool(
          'enable_recurring_reminders', enableRecurringReminders);
    }

    if (enableInsights != null) {
      await prefs.setBool('enable_financial_insights', enableInsights);
    }

    if (enableAnomalyAlerts != null) {
      await prefs.setBool('enable_anomaly_alerts', enableAnomalyAlerts);
    }
  }

  // Enregistrer la notification dans l'historique
  Future<void> _saveNotificationToHistory(
    String immatriculation,
    String title,
    String body,
    String type,
  ) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<String> existingNotifications =
          prefs.getStringList('finance_notifications_$immatriculation') ?? [];

      // Format: titre||message||type||timestamp||read
      final String entry =
          '$title||$body||$type||${DateTime.now().toIso8601String()}||false';

      existingNotifications.add(entry);
      await prefs.setStringList(
          'finance_notifications_$immatriculation', existingNotifications);
    } catch (e) {
      if (kDebugMode) {
        print(
          'Erreur lors de l\'enregistrement de la notification dans l\'historique: $e');
      }
    }
  }

  /// Récupère l'historique des notifications financières pour un véhicule
  Future<List<Map<String, dynamic>>> getNotificationHistory(
      String immatriculation) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<String> notifData =
          prefs.getStringList('finance_notifications_$immatriculation') ?? [];

      final List<Map<String, dynamic>> notifications = [];

      for (final entry in notifData) {
        final parts = entry.split('||');
        if (parts.length >= 4) {
          notifications.add({
            'title': parts[0],
            'body': parts[1],
            'type': parts[2],
            'timestamp': DateTime.parse(parts[3]),
            'read': parts.length > 4 ? parts[4] == 'true' : false,
          });
        }
      }

      // Trier par date (plus récent en premier)
      notifications.sort((a, b) =>
          (b['timestamp'] as DateTime).compareTo(a['timestamp'] as DateTime));

      return notifications;
    } catch (e) {
      if (kDebugMode) {
        print(
          'Erreur lors de la récupération de l\'historique des notifications: $e');
      }
      return [];
    }
  }
}

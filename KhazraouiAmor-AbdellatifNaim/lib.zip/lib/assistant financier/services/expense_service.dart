// ignore_for_file: avoid_print, curly_braces_in_flow_control_structures

import 'package:flutter/material.dart';
import 'package:carhabti/assistant financier/models/expense_model.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart' as uuid_lib;
import 'dart:typed_data';

class ExpenseService {
  final SupabaseClient _supabase = Supabase.instance.client;
  final String _table = 'vehicle_expenses';

  // ─── Parse null-safe ──────────────────────────────────────────────────────
  static Expense? _safeFromJson(dynamic raw) {
    try {
      final m = Map<String, dynamic>.from(raw as Map);
      if (m['date'] == null || m['immatriculation'] == null) return null;
      return Expense.fromJson(m);
    } catch (_) {
      return null;
    }
  }

  // ─── Noms de mois statiques (sans locale intl) ────────────────────────────
  static const List<String> _frMonths = [
    '', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
    'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre',
  ];
  static String _frMonth(int month) => _frMonths[month];

  // ─── Récupérer toutes les dépenses ────────────────────────────────────────
  Future<List<Expense>> getExpenses(String immatriculation,
      [Map<String, DateTime>? period]) async {
    try {
      var query = _supabase
          .from(_table)
          .select()
          .eq('immatriculation', immatriculation);

      if (period != null) {
        final startDate = period['startDate'];
        final endDate   = period['endDate'];
        if (startDate != null) query = query.gte('date', startDate.toIso8601String());
        if (endDate   != null) query = query.lte('date', endDate.toIso8601String());
      }

      final response = await query.order('date', ascending: false);
      return (response as List).map(_safeFromJson).whereType<Expense>().toList();
    } catch (e) {
      throw Exception('Erreur lors de la récupération des dépenses: $e');
    }
  }

  // ─── Récupérer une dépense par ID ─────────────────────────────────────────
  Future<Expense> getExpenseById(String expenseId) async {
    try {
      final response = await _supabase.from(_table).select().eq('id', expenseId).single();
      return Expense.fromJson(response);
    } catch (e) {
      throw Exception('Erreur lors de la récupération de la dépense: $e');
    }
  }

  // ─── Ajouter une dépense ──────────────────────────────────────────────────
  Future<Expense> addExpense(Expense expense) async {
    try {
      final String id = expense.id?.isNotEmpty == true
          ? expense.id!
          : const uuid_lib.Uuid().v4();

      final Map<String, dynamic> data = expense.toJson();
      data['id'] = id;
      data.remove('recurring_frequency');
      data.remove('vehicle_id');
      data.remove('subcategory');
      data.remove('tags');
      if (expense.recurringFrequency != null) {
        data['recurring_period'] = expense.recurringFrequency;
      }

      debugPrint('Insertion: ${data.toString()}');
      await _supabase.from(_table).insert(data);
      return expense.copyWith(id: id);
    } catch (e) {
      debugPrint('Erreur ajout: $e');
      throw Exception('Erreur lors de l\'ajout de la dépense: $e');
    }
  }

  // ─── Mettre à jour une dépense ────────────────────────────────────────────
  Future<void> updateExpense(Expense expense) async {
    try {
      if (expense.id == null) throw Exception('ID manquant');
      final Map<String, dynamic> data = expense.toJson();
      data.remove('recurring_frequency');
      data.remove('vehicle_id');
      data.remove('subcategory');
      data.remove('tags');
      if (expense.recurringFrequency != null) {
        data['recurring_period'] = expense.recurringFrequency;
      }
      await _supabase.from(_table).update(data).eq('id', expense.id!);
    } catch (e) {
      throw Exception('Erreur lors de la mise à jour de la dépense: $e');
    }
  }

  // ─── Supprimer une dépense ────────────────────────────────────────────────
  Future<void> deleteExpense(String expenseId) async {
    try {
      await _supabase.from(_table).delete().eq('id', expenseId);
    } catch (e) {
      throw Exception('Erreur lors de la suppression de la dépense: $e');
    }
  }

  // ─── Dépenses par catégorie ───────────────────────────────────────────────
  Future<List<Expense>> getExpensesByCategory(
      String immatriculation, ExpenseCategory category) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('immatriculation', immatriculation)
          .eq('category', category.name)
          .order('date', ascending: false);
      return (response as List).map(_safeFromJson).whereType<Expense>().toList();
    } catch (e) {
      throw Exception('Erreur lors de la récupération par catégorie: $e');
    }
  }

  // ─── Dépenses par période ─────────────────────────────────────────────────
  Future<List<Expense>> getExpensesByPeriod(
      String immatriculation, DateTime startDate, DateTime endDate) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('immatriculation', immatriculation)
          .gte('date', startDate.toIso8601String())
          .lte('date', endDate.toIso8601String())
          .order('date', ascending: false);
      return (response as List).map(_safeFromJson).whereType<Expense>().toList();
    } catch (e) {
      throw Exception('Erreur lors de la récupération par période: $e');
    }
  }

  // ─── Stats catégorie — toutes dates ──────────────────────────────────────
  Future<Map<ExpenseCategory, double>> getExpenseStatsByCategory(
      String immatriculation) async {
    try {
      final expenses = await getExpenses(immatriculation);
      final Map<ExpenseCategory, double> stats = {};
      for (final e in expenses) {
        stats[e.category] = (stats[e.category] ?? 0) + e.amount;
      }
      return stats;
    } catch (e) {
      throw Exception('Erreur lors du calcul des statistiques: $e');
    }
  }

  // ─── Stats catégorie — période donnée (ex: mois courant) ─────────────────
  Future<Map<ExpenseCategory, double>> getExpenseStatsByCategoryForPeriod(
      String immatriculation, DateTime startDate, DateTime endDate) async {
    try {
      final expenses = await getExpensesByPeriod(immatriculation, startDate, endDate);
      final Map<ExpenseCategory, double> stats = {};
      for (final e in expenses) {
        stats[e.category] = (stats[e.category] ?? 0) + e.amount;
      }
      return stats;
    } catch (e) {
      throw Exception('Erreur lors du calcul des statistiques par période: $e');
    }
  }

  // ─── Dépenses récentes du mois courant ───────────────────────────────────
  Future<List<Expense>> getRecentExpensesCurrentMonth(
      String immatriculation, {int limit = 5}) async {
    try {
      final now          = DateTime.now();
      final startOfMonth = DateTime(now.year, now.month, 1);
      final endOfMonth   = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
      final expenses     = await getExpensesByPeriod(
          immatriculation, startOfMonth, endOfMonth);
      expenses.sort((a, b) => b.date.compareTo(a.date));
      return expenses.take(limit).toList();
    } catch (e) {
      throw Exception('Erreur récentes mois courant: $e');
    }
  }

  // ─── Dépenses mensuelles pour une année — SANS locale intl ───────────────
  Future<Map<String, double>> getMonthlyExpensesForYear(
      String immatriculation, int year) async {
    try {
      final startDate = DateTime(year, 1, 1);
      final endDate   = DateTime(year, 12, 31, 23, 59, 59);
      final expenses  = await getExpensesByPeriod(immatriculation, startDate, endDate);

      // Initialiser les 12 mois avec 0
      final Map<String, double> monthlyStats = {};
      for (int i = 1; i <= 12; i++) {
        monthlyStats[_frMonth(i)] = 0;
      }

      for (final expense in expenses) {
        final key = _frMonth(expense.date.month);
        monthlyStats[key] = (monthlyStats[key] ?? 0) + expense.amount;
      }

      return monthlyStats;
    } catch (e) {
      throw Exception('Erreur lors du calcul des dépenses mensuelles: $e');
    }
  }

  // ─── Statut budget ────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getBudgetStatus(
      String immatriculation, double budget) async {
    try {
      final now          = DateTime.now();
      final startOfMonth = DateTime(now.year, now.month, 1);
      final endOfMonth   = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
      final expenses     = await getExpensesByPeriod(
          immatriculation, startOfMonth, endOfMonth);

      final totalExpenses = expenses.fold<double>(0, (s, e) => s + e.amount);
      final percentUsed   = budget > 0 ? (totalExpenses / budget) * 100 : 0.0;

      String status;
      if (percentUsed < 50) {
        status = 'Bon';
      } else if (percentUsed < 80)  status = 'Attention';
      else if (percentUsed < 100) status = 'Critique';
      else                        status = 'Dépassé';

      return {
        'budget':      budget,
        'spent':       totalExpenses,
        'remaining':   budget - totalExpenses,
        'percentUsed': percentUsed,
        'status':      status,
      };
    } catch (e) {
      throw Exception('Erreur lors du calcul du statut du budget: $e');
    }
  }

  // ─── Upload pièce jointe ──────────────────────────────────────────────────
  Future<String> uploadAttachment(String immatriculation, String expenseId,
      Uint8List fileBytes, String fileName) async {
    try {
      final filePath = 'expenses/$immatriculation/$expenseId/$fileName';
      await _supabase.storage.from('vehicle_expenses').uploadBinary(filePath, fileBytes);
      return _supabase.storage.from('vehicle_expenses').getPublicUrl(filePath);
    } catch (e) {
      throw Exception('Erreur upload pièce jointe: $e');
    }
  }

  // ─── Supprimer pièce jointe ───────────────────────────────────────────────
  Future<void> deleteAttachment(
      String immatriculation, String expenseId, String fileName) async {
    try {
      final filePath = 'expenses/$immatriculation/$expenseId/$fileName';
      await _supabase.storage.from('vehicle_expenses').remove([filePath]);
    } catch (e) {
      throw Exception('Erreur suppression pièce jointe: $e');
    }
  }

  // ─── Budget mensuel — lecture ─────────────────────────────────────────────
  Future<double> getMonthlyBudget(String immatriculation) async {
    try {
      final response = await _supabase
          .from('user_financial_settings')
          .select('monthly_budget')
          .eq('immatriculation', immatriculation)
          .single();
      final val = response['monthly_budget'];
      return val != null ? (val as num).toDouble() : 1000.0;
    } catch (_) {
      return 1000.0;
    }
  }

  // ─── Budget mensuel — écriture ────────────────────────────────────────────
  Future<void> setMonthlyBudget(String immatriculation, double budget) async {
    try {
      final exists = await _supabase
          .from('user_financial_settings')
          .select('immatriculation')
          .eq('immatriculation', immatriculation)
          .maybeSingle();

      if (exists != null) {
        await _supabase.from('user_financial_settings')
            .update({'monthly_budget': budget})
            .eq('immatriculation', immatriculation);
      } else {
        await _supabase.from('user_financial_settings').insert({
          'immatriculation': immatriculation,
          'monthly_budget':  budget,
          'user_id':         _supabase.auth.currentUser?.id,
        });
      }
    } catch (e) {
      throw Exception('Erreur mise à jour budget: $e');
    }
  }

  // ─── Export JSON ──────────────────────────────────────────────────────────
  Future<List<Map<String, dynamic>>> exportExpenses(String immatriculation) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('immatriculation', immatriculation);
      return List<Map<String, dynamic>>.from(response as List);
    } catch (e) {
      throw Exception('Erreur exportation: $e');
    }
  }

  // ─── Import JSON ──────────────────────────────────────────────────────────
  Future<int> importExpenses(
      String immatriculation, List<Map<String, dynamic>> expenses) async {
    try {
      int count = 0;
      for (var data in expenses) {
        data['immatriculation'] = immatriculation;
        data['id']              = const uuid_lib.Uuid().v4();
        await _supabase.from(_table).insert(data);
        count++;
      }
      return count;
    } catch (e) {
      throw Exception('Erreur importation: $e');
    }
  }
}
// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:carhabti/assistant financier/services/finance_notification_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── Design System ────────────────────────────────────────────────────────────
class _DS {
  static const bg        = Color(0xFF0D1117); // charbon profond
  static const surface   = Color(0xFF161B22); // surface card
  static const glass     = Color(0xFF1C2333); // glassmorphism
  static const border    = Color(0xFF30363D); // bordures subtiles
  static const cyan      = Color(0xFF00D4FF); // accent primaire
  static const gold      = Color(0xFFFFB84D); // accent secondaire
  static const emerald   = Color(0xFF00E676); // succès/récurrent
  static const violet    = Color(0xFFBB86FC); // insight
  static const amber     = Color(0xFFFFAB40); // anomalie
  static const danger    = Color(0xFFFF5252); // erreur
  static const textPrimary   = Color(0xFFE6EDF3);
  static const textSecondary = Color(0xFF8B949E);
  static const textMuted     = Color(0xFF484F58);

  static TextStyle display(double size, {Color? color, FontWeight w = FontWeight.w700}) =>
      GoogleFonts.syne(fontSize: size, fontWeight: w, color: color ?? textPrimary, letterSpacing: -0.5);

  static TextStyle body(double size, {Color? color, FontWeight w = FontWeight.w400}) =>
      GoogleFonts.dmSans(fontSize: size, fontWeight: w, color: color ?? textSecondary, height: 1.5);

  static BoxDecoration card({Color? borderColor, double radius = 16}) => BoxDecoration(
    color: surface,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: borderColor ?? border, width: 1),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 24, offset: const Offset(0, 8)),
    ],
  );

  static BoxDecoration glowCard(Color glowColor) => BoxDecoration(
    color: surface,
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: glowColor.withOpacity(0.35), width: 1),
    boxShadow: [
      BoxShadow(color: glowColor.withOpacity(0.12), blurRadius: 20, spreadRadius: 0, offset: const Offset(0, 4)),
      BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 16, offset: const Offset(0, 8)),
    ],
  );
}

class FinanceNotificationHistoryScreen extends StatefulWidget {
  final String immatriculation;

  const FinanceNotificationHistoryScreen({
    super.key,
    required this.immatriculation,
  });

  @override
  State<FinanceNotificationHistoryScreen> createState() =>
      _FinanceNotificationHistoryScreenState();
}

class _FinanceNotificationHistoryScreenState
    extends State<FinanceNotificationHistoryScreen>
    with SingleTickerProviderStateMixin {
  final FinanceNotificationService _notificationService =
      FinanceNotificationService();
  List<Map<String, dynamic>> _notifications = [];
  bool _isLoading = true;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _loadNotifications();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadNotifications() async {
    setState(() { _isLoading = true; });
    try {
      final notifications = await _notificationService
          .getNotificationHistory(widget.immatriculation);
      setState(() {
        _notifications = notifications;
        _isLoading = false;
      });
      _fadeCtrl.forward();
    } catch (e) {
      debugPrint('Erreur lors du chargement des notifications: $e');
      setState(() { _isLoading = false; });
    }
  }

  Future<void> _markAllAsRead() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<String> updatedEntries = [];
      for (final notif in _notifications) {
        final timestamp = (notif['timestamp'] as DateTime).toIso8601String();
        final entry = '${notif['title']}||${notif['body']}||${notif['type']}||$timestamp||true';
        updatedEntries.add(entry);
        notif['read'] = true;
      }
      await prefs.setStringList('finance_notifications_${widget.immatriculation}', updatedEntries);
      setState(() {});
    } catch (e) {
      // ignore: avoid_print
      print('Erreur lors du marquage des notifications: $e');
    }
  }

  Future<void> _clearAllNotifications() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: _DS.glass,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: EdgeInsets.all(24.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56.w, height: 56.w,
                decoration: BoxDecoration(
                  color: _DS.danger.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: _DS.danger.withOpacity(0.3)),
                ),
                child: Icon(Icons.delete_sweep_rounded, color: _DS.danger, size: 26.sp),
              ),
              SizedBox(height: 16.h),
              Text('Effacer l\'historique', style: _DS.display(18.sp)),
              SizedBox(height: 8.h),
              Text(
                'Voulez-vous vraiment effacer tout l\'historique des notifications ?',
                style: _DS.body(14.sp),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24.h),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(color: _DS.border),
                        ),
                      ),
                      child: Text('Annuler', style: _DS.body(14.sp, color: _DS.textSecondary, w: FontWeight.w500)),
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context, true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _DS.danger,
                        padding: EdgeInsets.symmetric(vertical: 12.h),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text('Effacer', style: _DS.body(14.sp, color: Colors.white, w: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirm == true) {
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove('finance_notifications_${widget.immatriculation}');
        setState(() { _notifications = []; });
      } catch (e) {
        debugPrint('Erreur lors de la suppression des notifications: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final unreadCount = _notifications.where((n) => n['read'] == false).length;

    return Scaffold(
      backgroundColor: _DS.bg,
      appBar: AppBar(
        backgroundColor: _DS.bg,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: _DS.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _DS.border),
            ),
            child: Icon(Icons.arrow_back_ios_new_rounded, color: _DS.textPrimary, size: 16.sp),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Notifications', style: _DS.display(18.sp)),
            if (!_isLoading && _notifications.isNotEmpty)
              Text('${_notifications.length} au total · $unreadCount non lues',
                  style: _DS.body(11.sp, color: _DS.textMuted)),
          ],
        ),
        actions: [
          if (_notifications.isNotEmpty)
            Padding(
              padding: EdgeInsets.only(right: 12.w),
              child: IconButton(
                icon: Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: _DS.danger.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _DS.danger.withOpacity(0.25)),
                  ),
                  child: Icon(Icons.delete_sweep_rounded, color: _DS.danger, size: 18.sp),
                ),
                onPressed: _clearAllNotifications,
              ),
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _DS.border.withOpacity(0.5)),
        ),
      ),
      body: _isLoading
          ? _buildLoader()
          : FadeTransition(opacity: _fadeAnim, child: _buildNotificationsList()),
    );
  }

  Widget _buildLoader() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 36.w, height: 36.w,
            child: CircularProgressIndicator(
              color: _DS.cyan, strokeWidth: 2,
            ),
          ),
          SizedBox(height: 16.h),
          Text('Chargement...', style: _DS.body(14.sp, color: _DS.textMuted)),
        ],
      ),
    );
  }

  Widget _buildNotificationsList() {
    if (_notifications.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80.w, height: 80.w,
              decoration: BoxDecoration(
                color: _DS.surface,
                shape: BoxShape.circle,
                border: Border.all(color: _DS.border),
              ),
              child: Icon(Icons.notifications_off_outlined, size: 36.sp, color: _DS.textMuted),
            ),
            SizedBox(height: 20.h),
            Text('Aucune notification', style: _DS.display(18.sp)),
            SizedBox(height: 8.h),
            SizedBox(
              width: 260.w,
              child: Text(
                'Vous n\'avez pas encore reçu de notifications financières',
                style: _DS.body(14.sp),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        if (_notifications.any((notif) => notif['read'] == false))
          Padding(
            padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                GestureDetector(
                  onTap: _markAllAsRead,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 7.h),
                    decoration: BoxDecoration(
                      color: _DS.cyan.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _DS.cyan.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.done_all_rounded, color: _DS.cyan, size: 15.sp),
                        SizedBox(width: 6.w),
                        Text('Tout marquer comme lu', style: _DS.body(12.sp, color: _DS.cyan, w: FontWeight.w500)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        SizedBox(height: 8.h),
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
            itemCount: _notifications.length,
            itemBuilder: (context, index) {
              final notif = _notifications[index];
              final DateTime timestamp = notif['timestamp'];
              final bool isRead = notif['read'] ?? false;
              final String type = notif['type'] ?? 'info';
              final color = _getNotificationColor(type);

              return Padding(
                padding: EdgeInsets.only(bottom: 10.h),
                child: GestureDetector(
                  onTap: () {
                    if (!isRead) {
                      setState(() { notif['read'] = true; });
                      _updateNotificationStatus(index, true);
                    }
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    decoration: isRead ? _DS.card() : _DS.glowCard(color),
                    child: Padding(
                      padding: EdgeInsets.all(16.w),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Icône
                          Container(
                            width: 42.w, height: 42.w,
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: color.withOpacity(0.25)),
                            ),
                            child: Icon(_getNotificationIcon(type), color: color, size: 20.sp),
                          ),
                          SizedBox(width: 12.w),
                          // Contenu
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        notif['title'] ?? 'Notification',
                                        style: _DS.display(14.sp, w: isRead ? FontWeight.w500 : FontWeight.w700),
                                      ),
                                    ),
                                    if (!isRead)
                                      Container(
                                        width: 8.w, height: 8.w,
                                        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                                      ),
                                  ],
                                ),
                                SizedBox(height: 4.h),
                                Text(notif['body'] ?? '', style: _DS.body(13.sp)),
                                SizedBox(height: 8.h),
                                Row(
                                  children: [
                                    Icon(Icons.access_time_rounded, size: 11.sp, color: _DS.textMuted),
                                    SizedBox(width: 4.w),
                                    Text(
                                      DateFormat('dd MMM yyyy · HH:mm', 'fr').format(timestamp),
                                      style: _DS.body(11.sp, color: _DS.textMuted),
                                    ),
                                    SizedBox(width: 10.w),
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
                                      decoration: BoxDecoration(
                                        color: color.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Text(
                                        _getTypeLabel(type),
                                        style: _DS.body(10.sp, color: color, w: FontWeight.w600),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _updateNotificationStatus(int index, bool read) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final notifData = prefs.getStringList('finance_notifications_${widget.immatriculation}') ?? [];
      if (index < notifData.length) {
        final parts = notifData[index].split('||');
        if (parts.length >= 4) {
          notifData[index] = '${parts[0]}||${parts[1]}||${parts[2]}||${parts[3]}||true';
          await prefs.setStringList('finance_notifications_${widget.immatriculation}', notifData);
        }
      }
    } catch (e) {
      debugPrint('Erreur lors de la mise à jour du statut de notification: $e');
    }
  }

  String _getTypeLabel(String type) {
    switch (type.toLowerCase()) {
      case 'budget':    return 'Budget';
      case 'recurring': return 'Récurrent';
      case 'insight':   return 'Analyse';
      case 'anomaly':   return 'Anomalie';
      default:          return 'Info';
    }
  }

  IconData _getNotificationIcon(String type) {
    switch (type.toLowerCase()) {
      case 'budget':    return Icons.account_balance_wallet_outlined;
      case 'recurring': return Icons.repeat_rounded;
      case 'insight':   return Icons.bar_chart_rounded;
      case 'anomaly':   return Icons.warning_amber_rounded;
      default:          return Icons.notifications_outlined;
    }
  }

  Color _getNotificationColor(String type) {
    switch (type.toLowerCase()) {
      case 'budget':    return _DS.cyan;
      case 'recurring': return _DS.emerald;
      case 'insight':   return _DS.violet;
      case 'anomaly':   return _DS.amber;
      default:          return _DS.gold;
    }
  }
}
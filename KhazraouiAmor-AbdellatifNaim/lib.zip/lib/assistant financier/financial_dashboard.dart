// ignore_for_file: deprecated_member_use, unused_field, unused_local_variable, unused_element, library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/assistant financier/models/expense_model.dart';
import 'package:carhabti/assistant financier/services/expense_service.dart';
import 'package:carhabti/assistant financier/widgets/expense_card.dart';
import 'package:carhabti/assistant financier/widgets/budget_progress_card.dart';
import 'package:carhabti/assistant financier/add_expense_screen.dart';
import 'package:carhabti/assistant financier/expense_list_screen.dart';
import 'package:carhabti/assistant financier/financial_settings_screen.dart';
import 'package:carhabti/assistant financier/services/finance_notification_service.dart';
import 'package:carhabti/assistant financier/notification_history_screen.dart';
import 'package:flutter/services.dart';
// intl not needed — using static French month names from expense_model.dart

class FinanceDesignSystem {
  // ── Couleurs fondation ─────────────────────────────────────────────────────
  static const Color bgBase     = Color(0xFFF7F9FC); // Fond global blanc-bleuté
  static const Color bgCard     = Color(0xFFFFFFFF); // Cartes blanches pures
  static const Color bgMuted    = Color(0xFFF0F4F8); // Zones secondaires
  static const Color bgAccent   = Color(0xFFEBF9FA); // Teinte primaire très légère

  // ── Couleurs d'accentuation ────────────────────────────────────────────────
  static const Color primary    = Color(0xFF3DC9D3); // Turquoise menthe doux
  static const Color primaryDeep= Color(0xFF1FA7B0); // Turquoise profond (hover)
  static const Color secondary  = Color(0xFF6EC99A); // Vert sauge apaisant
  static const Color accent     = Color(0xFFF0A051); // Ambre chaleureux
  static const Color violet     = Color(0xFF9B8FE8); // Violet lavande
  static const Color rose       = Color(0xFFE88FA0); // Rose poudré
  static const Color warning    = Color(0xFFEA6060); // Rouge corail doux

  // ── Textes ─────────────────────────────────────────────────────────────────
  static const Color textPrimary   = Color(0xFF1C2B35); // Quasi-noir bleuté
  static const Color textSecondary = Color(0xFF5A7184); // Gris ardoise
  static const Color textMuted     = Color(0xFF9EB1BF); // Gris très clair

  // ── Bordures & séparateurs ─────────────────────────────────────────────────
  static const Color border     = Color(0xFFE3ECF2); // Bordure légère
  static const Color borderAccent = Color(0xFFCDE9EC); // Bordure turquoise

  // ── Gradients ──────────────────────────────────────────────────────────────
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF3DC9D3), Color(0xFF1FA7B0)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient secondaryGradient = LinearGradient(
    colors: [Color(0xFF6EC99A), Color(0xFF4AAD7A)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient accentGradient = LinearGradient(
    colors: [Color(0xFFF0A051), Color(0xFFE07832)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient warningGradient = LinearGradient(
    colors: [Color(0xFFEA6060), Color(0xFFCC3A3A)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient headerGradient = LinearGradient(
    colors: [Color(0xFF3DC9D3), Color(0xFF2CB8C3), Color(0xFF1FA7B0)],
    begin: Alignment.topLeft, end: Alignment.bottomCenter,
  );
  static const LinearGradient violetGradient = LinearGradient(
    colors: [Color(0xFF9B8FE8), Color(0xFF7B6FD0)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  // ── Typographie ─────────────────────────────────────────────────────────────
  // Nunito : arrondie, amicale, moderne sans être banale
  static TextStyle displayLarge  = GoogleFonts.nunito(fontSize: 26.sp, fontWeight: FontWeight.w800, color: textPrimary, letterSpacing: -0.6);
  static TextStyle displayMedium = GoogleFonts.nunito(fontSize: 22.sp, fontWeight: FontWeight.w800, color: textPrimary, letterSpacing: -0.4);
  static TextStyle displaySmall  = GoogleFonts.nunito(fontSize: 20.sp, fontWeight: FontWeight.w700, color: textPrimary, letterSpacing: -0.3);
  static TextStyle headingLarge  = GoogleFonts.nunito(fontSize: 18.sp, fontWeight: FontWeight.w700, color: textPrimary);
  static TextStyle headingMedium = GoogleFonts.nunito(fontSize: 16.sp, fontWeight: FontWeight.w700, color: textPrimary);
  static TextStyle headingSmall  = GoogleFonts.nunito(fontSize: 14.sp, fontWeight: FontWeight.w700, color: textPrimary);
  // DM Sans : corps, très lisible
  static TextStyle bodyLarge   = GoogleFonts.dmSans(fontSize: 16.sp, color: textSecondary, height: 1.55);
  static TextStyle bodyMedium  = GoogleFonts.dmSans(fontSize: 14.sp, color: textSecondary, height: 1.5);
  static TextStyle bodySmall   = GoogleFonts.dmSans(fontSize: 12.sp, color: textMuted, height: 1.4);
  static TextStyle labelLarge  = GoogleFonts.dmSans(fontSize: 14.sp, fontWeight: FontWeight.w600, color: textPrimary);
  static TextStyle labelMedium = GoogleFonts.dmSans(fontSize: 12.sp, fontWeight: FontWeight.w600, color: textSecondary);
  static TextStyle labelSmall  = GoogleFonts.dmSans(fontSize: 11.sp, fontWeight: FontWeight.w500, color: textMuted);

  // ── Décorations cartes ──────────────────────────────────────────────────────
  static BoxDecoration get cardDecoration => BoxDecoration(
    color: bgCard,
    borderRadius: BorderRadius.circular(20.r),
    border: Border.all(color: border, width: 1),
    boxShadow: [
      BoxShadow(color: const Color(0xFF3DC9D3).withOpacity(0.06), blurRadius: 20, offset: const Offset(0, 8)),
      BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
    ],
  );
  static BoxDecoration get subtleCardDecoration => BoxDecoration(
    color: bgCard,
    borderRadius: BorderRadius.circular(16.r),
    border: Border.all(color: border, width: 1),
    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 3))],
  );
  static BoxDecoration get elevatedCardDecoration => BoxDecoration(
    color: bgCard,
    borderRadius: BorderRadius.circular(24.r),
    border: Border.all(color: borderAccent, width: 1.2),
    boxShadow: [
      BoxShadow(color: const Color(0xFF3DC9D3).withOpacity(0.12), blurRadius: 28, offset: const Offset(0, 12)),
      BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
    ],
  );

  // ── Couleurs graphiques ─────────────────────────────────────────────────────
  static const List<Color> chartColors = [
    Color(0xFF3DC9D3), // Turquoise
    Color(0xFF6EC99A), // Vert sauge
    Color(0xFFF0A051), // Ambre
    Color(0xFF9B8FE8), // Violet lavande
    Color(0xFFE88FA0), // Rose poudré
    Color(0xFF5BB8E0), // Bleu ciel
    Color(0xFFBB8CEA), // Mauve
    Color(0xFFF5C76A), // Jaune doux
    Color(0xFF72D4A0), // Vert menthe
    Color(0xFFF08080), // Saumon
  ];

  // ── Courbes & espacements ───────────────────────────────────────────────────
  static const Curve easeCurve          = Curves.easeOutQuint;
  static const Curve fastOutSlowInCurve = Curves.fastOutSlowIn;
  static const Curve bounceCurve        = Curves.elasticOut;

  static const double spacingXs  = 4;
  static const double spacingSm  = 8;
  static const double spacingMd  = 16;
  static const double spacingLg  = 24;
  static const double spacingXl  = 32;
  static const double spacing2xl = 48;

  static const Color successColor = secondary;
  static const Color errorColor   = warning;
  static const Color infoColor    = primary;
  static const Color neutralColor = textMuted;

  // Alias rétro-compatibilité (utilisés dans les sous-widgets existants)
  static const Color dark     = bgBase;
  static const Color surface  = bgCard;
  static const Color glass    = bgMuted;
  static const Color borderCol = border;
  static const Color light    = bgBase;
  static const Color cardBg   = bgCard;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WIDGET PRINCIPAL
// ═══════════════════════════════════════════════════════════════════════════════
class FinancialDashboard extends StatefulWidget {
  final String immatriculation;

  const FinancialDashboard({super.key, required this.immatriculation});

  @override
  _FinancialDashboardState createState() => _FinancialDashboardState();
}

class _FinancialDashboardState extends State<FinancialDashboard>
    with TickerProviderStateMixin {

  final ExpenseService _expenseService = ExpenseService();
  final FinanceNotificationService _notificationService = FinanceNotificationService();

  final List<String> _monthAbbreviations = ['Jan','Fév','Mar','Avr','Mai','Juin','Juil','Aoû','Sep','Oct','Nov','Déc'];
  final List<String> _monthOrder = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _scaleController;
  late AnimationController _chartAnimationController;

  late Animation<double> _fadeAnimation;
  late Animation<Offset>  _slideAnimation;
  late Animation<double>  _scaleAnimation;
  late Animation<double>  _chartAnimation;

  bool   _isLoading          = true;
  double _monthlyBudget      = 1000;
  int?   _hoveredSectionIndex;
  int?   _touchedBarGroupIndex;
  Map<ExpenseCategory, double> _expenseStats    = {};
  List<Expense>                _recentExpenses  = [];
  Map<String, double>          _monthlyExpenses = {};

  // ── Cycle de vie ────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark, // icônes sombres sur fond clair
    ));
    _setupAnimations();
    _initializeNotificationService();
    _loadDashboardData();
  }

  void _setupAnimations() {
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _fadeAnimation  = CurvedAnimation(parent: _fadeController, curve: FinanceDesignSystem.easeCurve);

    _slideController = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _slideAnimation  = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideController, curve: FinanceDesignSystem.fastOutSlowInCurve));

    _scaleController = AnimationController(vsync: this, duration: const Duration(milliseconds: 150));
    _scaleAnimation  = Tween<double>(begin: 1.0, end: 0.97)
        .animate(CurvedAnimation(parent: _scaleController, curve: Curves.easeInOut));

    _chartAnimationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _chartAnimation = CurvedAnimation(parent: _chartAnimationController, curve: FinanceDesignSystem.fastOutSlowInCurve);
  }

  Future<void> _initializeNotificationService() async {
    try {
      await _notificationService.initialize();
      await _notificationService.scheduleDailyChecks(widget.immatriculation);
    } catch (e) {
      debugPrint('Erreur notifications financières: $e');
    }
  }

  // ── Libellé du mois courant (statique, sans locale intl) ─────────────────
  String _currentMonthLabel() {
    const months = [
      '', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
    ];
    final now = DateTime.now();
    return '${months[now.month]} ${now.year}';
  }

  Future<void> _loadDashboardData() async {
    setState(() => _isLoading = true);
    try {
      await Future.delayed(const Duration(milliseconds: 250));
      final now          = DateTime.now();
      final startOfMonth = DateTime(now.year, now.month, 1);
      final endOfMonth   = DateTime(now.year, now.month + 1, 0, 23, 59, 59);

      // Stats et dépenses récentes scoped au mois courant
      final expenseStats    = await _expenseService
          .getExpenseStatsByCategoryForPeriod(widget.immatriculation, startOfMonth, endOfMonth);
      final recentExpenses  = await _expenseService
          .getRecentExpensesCurrentMonth(widget.immatriculation, limit: 5);
      final monthlyExpenses = await _expenseService
          .getMonthlyExpensesForYear(widget.immatriculation, now.year);
      if (mounted) {
        setState(() {
          _expenseStats    = expenseStats;
          _recentExpenses  = recentExpenses;
          _monthlyExpenses = monthlyExpenses;
          _isLoading       = false;
        });
        _fadeController.forward();
        Future.delayed(const Duration(milliseconds: 120), () => _slideController.forward());
        Future.delayed(const Duration(milliseconds: 280), () => _chartAnimationController.forward());
      }
    } catch (e) {
      debugPrint('Erreur chargement dashboard: $e');
      if (mounted) {
        setState(() => _isLoading = false);
        _showErrorSnackBar();
      }
    }
  }

  void _showErrorSnackBar() {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(Icons.error_outline_rounded, color: Colors.white, size: 18.sp),
        SizedBox(width: 10.w),
        Expanded(child: Text('Erreur lors du chargement des données.',
            style: GoogleFonts.dmSans(fontWeight: FontWeight.w500, color: Colors.white))),
      ]),
      backgroundColor: FinanceDesignSystem.warning,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      margin: EdgeInsets.all(16.r),
      duration: const Duration(seconds: 4),
      action: SnackBarAction(label: 'Réessayer', textColor: Colors.white, onPressed: _loadDashboardData),
    ));
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _scaleController.dispose();
    _chartAnimationController.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // BUILD PRINCIPAL
  // ══════════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: FinanceDesignSystem.bgBase,
        body: _isLoading ? _buildLoadingView() : _buildBody(),
        // FAB moderne avec gradient
        floatingActionButton: _isLoading ? null : _buildFab(),
        floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      ),
    );
  }

  // ── FAB ────────────────────────────────────────────────────────────────────
  Widget _buildFab() {
    return Container(
      width: 56.w,
      height: 56.w,
      decoration: BoxDecoration(
        gradient: FinanceDesignSystem.primaryGradient,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: FinanceDesignSystem.primary.withOpacity(0.40),
            blurRadius: 20, offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _addNewExpense,
          borderRadius: BorderRadius.circular(28.r),
          splashColor: Colors.white.withOpacity(0.2),
          child: Icon(Icons.add_rounded, color: Colors.white, size: 26.sp),
        ),
      ),
    );
  }

  // ── Loading ────────────────────────────────────────────────────────────────
  Widget _buildLoadingView() {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          width: 72.w, height: 72.w,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: FinanceDesignSystem.primaryGradient,
            boxShadow: [BoxShadow(color: FinanceDesignSystem.primary.withOpacity(0.25), blurRadius: 24, spreadRadius: 4)],
          ),
          child: Center(
            child: SizedBox(
              width: 30.w, height: 30.w,
              child: const CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
            ),
          ),
        ),
        SizedBox(height: 20.h),
        Text('Assistant Financier', style: FinanceDesignSystem.headingMedium),
        SizedBox(height: 6.h),
        Text('Chargement de vos données…', style: FinanceDesignSystem.bodySmall),
      ]),
    );
  }

  // ── Corps principal ─────────────────────────────────────────────────────────
  Widget _buildBody() {
    return RefreshIndicator(
      onRefresh: _loadDashboardData,
      color: FinanceDesignSystem.primary,
      backgroundColor: FinanceDesignSystem.bgCard,
      displacement: 40.h,
      strokeWidth: 2,
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        slivers: [
          _buildSliverHeader(),
          SliverPadding(
            padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 100.h),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                SizedBox(height: 20.h),

                // ── Stats rapides ─────────────────────────────────────────
                _buildQuickStats(),
                SizedBox(height: 24.h),

                // ── Carte budget ──────────────────────────────────────────
                _buildBudgetCard(),
                SizedBox(height: 28.h),

                // ── Graphique camembert ───────────────────────────────────
                _buildSectionHeader('Répartition — ${_currentMonthLabel()}', Icons.donut_large_rounded),
                SizedBox(height: 12.h),
                _buildExpenseChart(),
                SizedBox(height: 28.h),

                // ── Graphique barres mensuelles ───────────────────────────
                _buildSectionHeader('Dépenses mensuelles', Icons.bar_chart_rounded),
                SizedBox(height: 12.h),
                _buildMonthlyExpensesChart(),
                SizedBox(height: 28.h),

                // ── Dépenses récentes ─────────────────────────────────────
                _buildSectionHeader('Récentes — ${_currentMonthLabel()}', Icons.receipt_long_rounded),
                SizedBox(height: 12.h),
                _buildRecentExpensesList(),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  // ── Header avec gradient (remplace SliverAppBar lourd) ────────────────────
  SliverPersistentHeader _buildSliverHeader() {
    return SliverPersistentHeader(
      pinned: true,
      delegate: _GradientHeaderDelegate(
        immatriculation: widget.immatriculation,
        onBack: () => Navigator.pop(context),
        onNotifications: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => FinanceNotificationHistoryScreen(immatriculation: widget.immatriculation))),
        onSettings: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => FinancialSettingsScreen(
                immatriculation: widget.immatriculation,
                onBudgetUpdated: (b) => setState(() => _monthlyBudget = b)))),
        onExpenseList: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => ExpenseListScreen(immatriculation: widget.immatriculation)))
            .then((_) => _loadDashboardData()),
      ),
    );
  }

  // ── Tuiles de stats rapides ────────────────────────────────────────────────
  Widget _buildQuickStats() {
    final total = _expenseStats.values.fold<double>(0, (s, a) => s + a);
    final ratio = _monthlyBudget > 0 ? (total / _monthlyBudget).clamp(0.0, 1.0) : 0.0;
    final remaining = (_monthlyBudget - total).clamp(0.0, double.infinity);
    final isOver = total > _monthlyBudget;

    return FadeTransition(
      opacity: _fadeAnimation,
      child: Row(children: [
        Expanded(child: _buildStatTile(
          label: 'Total dépenses',
          value: '${total.toStringAsFixed(0)} TND',
          icon: Icons.trending_down_rounded,
          gradient: FinanceDesignSystem.primaryGradient,
        )),
        SizedBox(width: 12.w),
        Expanded(child: _buildStatTile(
          label: isOver ? 'Dépassement' : 'Disponible',
          value: '${remaining.toStringAsFixed(0)} TND',
          icon: isOver ? Icons.warning_amber_rounded : Icons.account_balance_wallet_outlined,
          gradient: isOver ? FinanceDesignSystem.warningGradient : FinanceDesignSystem.secondaryGradient,
        )),
        SizedBox(width: 12.w),
        Expanded(child: _buildStatTile(
          label: 'Catégories',
          value: '${_expenseStats.length}',
          icon: Icons.category_outlined,
          gradient: FinanceDesignSystem.violetGradient,
        )),
      ]),
    );
  }

  Widget _buildStatTile({
    required String label,
    required String value,
    required IconData icon,
    required LinearGradient gradient,
  }) {
    return Container(
      padding: EdgeInsets.all(14.r),
      decoration: BoxDecoration(
        color: FinanceDesignSystem.bgCard,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: FinanceDesignSystem.border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 3))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 34.w, height: 34.w,
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: BorderRadius.circular(10.r),
          ),
          child: Icon(icon, color: Colors.white, size: 17.sp),
        ),
        SizedBox(height: 10.h),
        Text(value, style: GoogleFonts.nunito(
          fontSize: 15.sp, fontWeight: FontWeight.w800, color: FinanceDesignSystem.textPrimary,
        )),
        SizedBox(height: 2.h),
        Text(label, style: FinanceDesignSystem.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
      ]),
    );
  }

  // ── Carte budget ───────────────────────────────────────────────────────────
  Widget _buildBudgetCard() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SlideTransition(
        position: _slideAnimation,
        child: GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => FinancialSettingsScreen(
                  immatriculation: widget.immatriculation,
                  onBudgetUpdated: (b) => setState(() => _monthlyBudget = b)))),
          child: Container(
            decoration: FinanceDesignSystem.elevatedCardDecoration,
            child: BudgetProgressCard(
              immatriculation: widget.immatriculation,
              monthlyBudget: _monthlyBudget,
            ),
          ),
        ),
      ),
    );
  }

  // ── En-tête de section ─────────────────────────────────────────────────────
  Widget _buildSectionHeader(String title, IconData icon) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Row(children: [
        Container(
          width: 34.w, height: 34.w,
          decoration: BoxDecoration(
            color: FinanceDesignSystem.primary.withOpacity(0.10),
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(color: FinanceDesignSystem.borderAccent),
          ),
          child: Icon(icon, size: 17.sp, color: FinanceDesignSystem.primary),
        ),
        SizedBox(width: 10.w),
        Text(title, style: FinanceDesignSystem.headingMedium),
        SizedBox(width: 12.w),
        Expanded(
          child: Container(
            height: 1,
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Color(0xFFCDE9EC), Colors.transparent]),
            ),
          ),
        ),
      ]),
    );
  }

  // ── Graphique camembert ────────────────────────────────────────────────────
  Widget _buildExpenseChart() {
    if (_expenseStats.isEmpty) {
      return _buildEmptyStateCard(
          'Aucune dépense ce mois',
          'Ajoutez des dépenses pour visualiser les statistiques de ${_currentMonthLabel()}',
          Icons.pie_chart_outline_rounded);
    }

    final totalExpenses = _expenseStats.values.fold<double>(0, (s, a) => s + a);
    final List<PieChartSectionData> sections   = [];
    final List<Widget>              indicators = [];

    int colorIndex = 0;
    _expenseStats.forEach((category, amount) {
      final percentage = (amount / totalExpenses) * 100;
      final color      = FinanceDesignSystem.chartColors[colorIndex % FinanceDesignSystem.chartColors.length];
      final isHovered  = _hoveredSectionIndex == colorIndex;

      sections.add(PieChartSectionData(
        value:      amount,
        title:      '${percentage.toStringAsFixed(0)}%',
        color:      color,
        radius:     isHovered ? 72.r : 58.r,
        titleStyle: GoogleFonts.nunito(
          color: Colors.white, fontWeight: FontWeight.w800,
          fontSize: isHovered ? 13.sp : 11.sp,
        ),
      ));

      indicators.add(Padding(
        padding: EdgeInsets.only(bottom: 10.h),
        child: Row(children: [
          Container(
            width: 10.w, height: 10.w,
            decoration: BoxDecoration(
              color: color, shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color.withOpacity(0.35), blurRadius: 4)],
            ),
          ),
          SizedBox(width: 10.w),
          Expanded(child: Text(category.displayName, style: FinanceDesignSystem.bodySmall.copyWith(color: FinanceDesignSystem.textSecondary))),
          Text('${amount.toStringAsFixed(0)} TND',
              style: FinanceDesignSystem.labelMedium.copyWith(color: color, fontWeight: FontWeight.w700)),
        ]),
      ));
      colorIndex++;
    });

    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        decoration: FinanceDesignSystem.cardDecoration,
        padding: EdgeInsets.all(20.r),
        child: Column(children: [
          // Camembert
          SizedBox(
            height: 200.h,
            child: PieChart(PieChartData(
              sections: sections,
              centerSpaceRadius: 44.r,
              sectionsSpace: 3,
              startDegreeOffset: -90,
              pieTouchData: PieTouchData(
                touchCallback: (event, response) {
                  setState(() {
                    if (!event.isInterestedForInteractions || response == null || response.touchedSection == null) {
                      _hoveredSectionIndex = null;
                    } else {
                      _hoveredSectionIndex = response.touchedSection!.touchedSectionIndex;
                    }
                  });
                },
              ),
            )),
          ),

          SizedBox(height: 18.h),

          // Légende
          Container(
            padding: EdgeInsets.all(14.r),
            decoration: BoxDecoration(
              color: FinanceDesignSystem.bgMuted,
              borderRadius: BorderRadius.circular(14.r),
              border: Border.all(color: FinanceDesignSystem.border),
            ),
            child: Column(children: indicators),
          ),

          SizedBox(height: 14.h),

          // Total
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
            decoration: BoxDecoration(
              gradient: FinanceDesignSystem.primaryGradient,
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.calculate_outlined, color: Colors.white, size: 16.sp),
              SizedBox(width: 8.w),
              Text('Total : ${totalExpenses.toStringAsFixed(2)} TND',
                  style: GoogleFonts.nunito(color: Colors.white, fontSize: 14.sp, fontWeight: FontWeight.w700)),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── Graphique barres mensuelles ────────────────────────────────────────────
  Widget _buildMonthlyExpensesChart() {
    if (_monthlyExpenses.isEmpty) {
      return _buildEmptyStateCard(
          'Aucune dépense mensuelle',
          'Vos dépenses mensuelles s\'afficheront ici',
          Icons.bar_chart_rounded);
    }

    final months = _monthlyExpenses.keys.toList()
      ..sort((a, b) => _monthOrder.indexOf(a.toLowerCase()).compareTo(_monthOrder.indexOf(b.toLowerCase())));

    final barGroups = <BarChartGroupData>[];
    for (int i = 0; i < months.length; i++) {
      final double amount  = _monthlyExpenses[months[i]] ?? 0;
      final bool isTouched = _touchedBarGroupIndex == i;

      barGroups.add(BarChartGroupData(
        x: i,
        barRods: [
          BarChartRodData(
            toY:   amount,
            width: isTouched ? 18.w : 14.w,
            gradient: LinearGradient(
              colors: [
                FinanceDesignSystem.primary.withOpacity(0.55),
                FinanceDesignSystem.primary,
              ],
              begin: Alignment.bottomCenter,
              end:   Alignment.topCenter,
            ),
            borderRadius: BorderRadius.only(
              topLeft:  Radius.circular(6.r),
              topRight: Radius.circular(6.r),
            ),
            backDrawRodData: BackgroundBarChartRodData(
              show: true,
              toY:   _monthlyBudget,
              color: FinanceDesignSystem.bgMuted,
            ),
          ),
        ],
      ));
    }

    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        decoration: FinanceDesignSystem.cardDecoration,
        padding: EdgeInsets.symmetric(vertical: 20.h, horizontal: 12.w),
        child: Column(children: [
          SizedBox(
            height: 200.h,
            child: Padding(
              padding: EdgeInsets.only(right: 10.w, top: 10.h),
              child: BarChart(BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: _monthlyBudget * 1.2,
                titlesData: FlTitlesData(
                  show: true,
                  topTitles:   const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value < 0 || value >= months.length) return const SizedBox();
                        return Padding(
                          padding: EdgeInsets.only(top: 6.h),
                          child: Text(months[value.toInt()][0].toUpperCase(),
                              style: FinanceDesignSystem.bodySmall.copyWith(fontSize: 10.sp, fontWeight: FontWeight.w600)),
                        );
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 44.w,
                      getTitlesWidget: (value, meta) {
                        if (value == 0) return const SizedBox();
                        return Padding(
                          padding: EdgeInsets.only(right: 6.w),
                          child: Text('${value.toInt()}',
                              style: FinanceDesignSystem.bodySmall.copyWith(fontSize: 9.sp)),
                        );
                      },
                    ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: _monthlyBudget / 4,
                  getDrawingHorizontalLine: (value) => FlLine(
                    color: FinanceDesignSystem.border,
                    strokeWidth: 1,
                    dashArray: [4, 6],
                  ),
                ),
                barGroups: barGroups,
                barTouchData: BarTouchData(
                  touchCallback: (event, response) {
                    setState(() {
                      if (!event.isInterestedForInteractions || response == null || response.spot == null) {
                        _touchedBarGroupIndex = null;
                      } else {
                        _touchedBarGroupIndex = response.spot!.touchedBarGroupIndex;
                      }
                    });
                  },
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipColor: (_) => FinanceDesignSystem.textPrimary,
                    tooltipBorderRadius: BorderRadius.circular(8.r),
                    tooltipBorder: const BorderSide(color: FinanceDesignSystem.borderAccent),
                    getTooltipItem: (group, groupIndex, rod, rodIndex) => BarTooltipItem(
                      '${months[group.x]}\n${rod.toY.toStringAsFixed(0)} TND',
                      FinanceDesignSystem.labelSmall.copyWith(color: Colors.white, height: 1.4),
                    ),
                  ),
                ),
              )),
            ),
          ),
          SizedBox(height: 12.h),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _buildLegendDot(FinanceDesignSystem.primary, 'Dépenses'),
            SizedBox(width: 20.w),
            _buildLegendDot(FinanceDesignSystem.bgMuted, 'Budget', border: FinanceDesignSystem.border),
          ]),
        ]),
      ),
    );
  }

  Widget _buildLegendDot(Color color, String label, {Color? border}) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 10.w, height: 10.w,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: border != null ? Border.all(color: border) : null,
          boxShadow: border == null ? [BoxShadow(color: color.withOpacity(0.35), blurRadius: 4)] : null,
        ),
      ),
      SizedBox(width: 6.w),
      Text(label, style: FinanceDesignSystem.bodySmall),
    ]);
  }

  // ── Liste des dépenses récentes ────────────────────────────────────────────
  Widget _buildRecentExpensesList() {
    if (_recentExpenses.isEmpty) {
      return _buildEmptyStateCard(
          'Aucune dépense ce mois',
          'Vos dépenses de ${_currentMonthLabel()} s\'afficheront ici',
          Icons.receipt_long_rounded);
    }
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Column(
        children: _recentExpenses.map((expense) => Padding(
          padding: EdgeInsets.only(bottom: 10.h),
          child: ExpenseCard(expense: expense, onTap: () => _editExpense(expense)),
        )).toList(),
      ),
    );
  }

  // ── État vide ──────────────────────────────────────────────────────────────
  Widget _buildEmptyStateCard(String title, String subtitle, IconData icon) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        decoration: FinanceDesignSystem.cardDecoration,
        padding: EdgeInsets.all(32.r),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 64.w, height: 64.w,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                FinanceDesignSystem.primary.withOpacity(0.10),
                FinanceDesignSystem.primary.withOpacity(0.05),
              ]),
              shape: BoxShape.circle,
              border: Border.all(color: FinanceDesignSystem.borderAccent, width: 1.5),
            ),
            child: Icon(icon, size: 28.sp, color: FinanceDesignSystem.primary.withOpacity(0.75)),
          ),
          SizedBox(height: 16.h),
          Text(title, style: FinanceDesignSystem.headingSmall, textAlign: TextAlign.center),
          SizedBox(height: 6.h),
          Text(subtitle, style: FinanceDesignSystem.bodySmall, textAlign: TextAlign.center),
          SizedBox(height: 20.h),
          GestureDetector(
            onTap: _addNewExpense,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
              decoration: BoxDecoration(
                gradient: FinanceDesignSystem.primaryGradient,
                borderRadius: BorderRadius.circular(12.r),
                boxShadow: [BoxShadow(color: FinanceDesignSystem.primary.withOpacity(0.28), blurRadius: 14, offset: const Offset(0, 5))],
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.add_rounded, color: Colors.white, size: 16.sp),
                SizedBox(width: 6.w),
                Text('Ajouter une dépense',
                    style: FinanceDesignSystem.labelMedium.copyWith(color: Colors.white, fontWeight: FontWeight.w700)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  // ── Helpers navigation ─────────────────────────────────────────────────────
  void _addNewExpense() {
    Navigator.push(context, MaterialPageRoute(
        builder: (_) => AddExpenseScreen(immatriculation: widget.immatriculation)))
        .then((_) => _loadDashboardData());
  }

  void _editExpense(Expense expense) {
    Navigator.push(context, MaterialPageRoute(
        builder: (_) => AddExpenseScreen(immatriculation: widget.immatriculation, expense: expense)))
        .then((_) => _loadDashboardData());
  }

  Widget _buildAnimatedCard({
    required BoxDecoration decoration,
    required VoidCallback onTap,
    required Widget child,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(margin: EdgeInsets.symmetric(vertical: 6.h), decoration: decoration, child: child),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// DELEGATE HEADER : bandeau gradient avec titre + actions
// ═══════════════════════════════════════════════════════════════════════════════
class _GradientHeaderDelegate extends SliverPersistentHeaderDelegate {
  final String      immatriculation;
  final VoidCallback onBack;
  final VoidCallback onNotifications;
  final VoidCallback onSettings;
  final VoidCallback onExpenseList;

  const _GradientHeaderDelegate({
    required this.immatriculation,
    required this.onBack,
    required this.onNotifications,
    required this.onSettings,
    required this.onExpenseList,
  });

  @override
  double get minExtent => kToolbarHeight + 12;
  @override
  double get maxExtent => 140;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    final progress = (shrinkOffset / (maxExtent - minExtent)).clamp(0.0, 1.0);
    final titleOpacity = 1.0;

    return Container(
      decoration: const BoxDecoration(
        gradient: FinanceDesignSystem.headerGradient,
        borderRadius: BorderRadius.only(
          bottomLeft:  Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        boxShadow: [
          BoxShadow(color: Color(0x283DC9D3), blurRadius: 20, offset: Offset(0, 8)),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Ligne 1 : retour + actions
              Row(children: [
                // Bouton retour
                GestureDetector(
                  onTap: onBack,
                  child: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.20),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white.withOpacity(0.30)),
                    ),
                    child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
                  ),
                ),
                const Spacer(),
                // Actions
                _HeaderActionBtn(icon: Icons.notifications_outlined, onTap: onNotifications),
                const SizedBox(width: 8),
                _HeaderActionBtn(icon: Icons.settings_outlined, onTap: onSettings),
                const SizedBox(width: 8),
                _HeaderActionBtn(icon: Icons.list_alt_outlined, onTap: onExpenseList),
              ]),

              // Ligne 2 : titre (masquée quand complètement contracté)
              if (progress < 0.85)
                Opacity(
                  opacity: (1 - progress * 1.5).clamp(0.0, 1.0),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(
                      'Assistant Financier',
                      style: GoogleFonts.nunito(
                        fontSize: 22, fontWeight: FontWeight.w800,
                        color: Colors.white, letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(children: [
                      const Icon(Icons.directions_car_rounded, color: Colors.white70, size: 13),
                      const SizedBox(width: 5),
                      Text(immatriculation, style: GoogleFonts.dmSans(
                        color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w500,
                      )),
                    ]),
                  ]),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  bool shouldRebuild(covariant _GradientHeaderDelegate oldDelegate) =>
      oldDelegate.immatriculation != immatriculation;
}

// Bouton action dans le header
class _HeaderActionBtn extends StatelessWidget {
  final IconData     icon;
  final VoidCallback onTap;

  const _HeaderActionBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.20),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.30)),
        ),
        child: Icon(icon, color: Colors.white, size: 18),
      ),
    );
  }
}
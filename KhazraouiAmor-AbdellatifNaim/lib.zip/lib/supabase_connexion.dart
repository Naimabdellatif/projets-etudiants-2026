import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> initSupabase() async 
{
  await Supabase.initialize(
    url: 'https://ixlkwjxvbbprbgqcghjx.supabase.co',
    anonKey: 
        'sb_publishable_C_GUwW7ev6l_D6bMhnOoUQ_mc7IYc7C',
  );
}

final supabase = Supabase.instance.client;

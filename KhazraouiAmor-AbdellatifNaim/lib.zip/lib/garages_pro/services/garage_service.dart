import 'dart:async';
import 'dart:math' show sin, cos, sqrt, atan2, pi;
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/supabase_connexion.dart';
import 'package:carhabti/garages_pro/models/garage.dart';
import 'package:carhabti/garages_pro/models/appointment.dart';
import 'package:carhabti/garages_pro/models/review.dart';

/// Service centralisant tous les appels Supabase pour le module Garages PRO.
class GarageService {
  final SupabaseClient _client = supabase;
  RealtimeChannel? _appointmentChannel;

  // ─── GARAGES ────────────────────────────────────────────────────────────────

  /// Récupère la liste des garages avec filtres optionnels.
  Future<List<Garage>> getGarages({
    String? searchQuery,
    List<String>? specialites,
    double? lat,
    double? lng,
    double? maxDistanceKm,
    String? sortBy,
  }) async {
    try {
      var query = _client.from('garages').select();

      if (searchQuery != null && searchQuery.isNotEmpty) {
        query = query.or(
          'nom.ilike.%$searchQuery%,ville.ilike.%$searchQuery%,adresse.ilike.%$searchQuery%',
        );
      }

      final response = await query.order('nom', ascending: true);
      List<Garage> garages = (response as List)
          .map((e) => Garage.fromMap(e as Map<String, dynamic>))
          .toList();

      // Filtrage par spécialités côté client
      if (specialites != null &&
          specialites.isNotEmpty &&
          !specialites.contains('Tous') &&
          !specialites.contains('Près de moi')) {
        garages = garages.where((g) {
          return g.specialites.any((s) => specialites.any((sp) =>
              s.toLowerCase().contains(sp.toLowerCase()) ||
              sp.toLowerCase().contains(s.toLowerCase())));
        }).toList();
      }

      // Filtrage par distance
      if (maxDistanceKm != null && lat != null && lng != null) {
        garages = garages.where((g) {
          final d = calculateDistance(lat, lng, g.latitude, g.longitude);
          return d <= maxDistanceKm;
        }).toList();
      }

      // Tri
      if (sortBy == 'distance' && lat != null && lng != null) {
        garages.sort((a, b) {
          final da = calculateDistance(lat, lng, a.latitude, a.longitude);
          final db = calculateDistance(lat, lng, b.latitude, b.longitude);
          return da.compareTo(db);
        });
      } else if (sortBy == 'note') {
        garages.sort((a, b) => b.noteMoyenne.compareTo(a.noteMoyenne));
      } else if (sortBy == 'alpha') {
        garages.sort((a, b) => a.nom.compareTo(b.nom));
      }

      return garages;
    } catch (e) {
      debugPrint('❌ Erreur getGarages: $e');
      return [];
    }
  }

  /// Récupère les garages triés par distance depuis la position donnée.
  Future<List<Garage>> getGaragesWithDistance({
    required double lat,
    required double lng,
    double? maxDistanceKm,
  }) async {
    return getGarages(
      lat: lat,
      lng: lng,
      maxDistanceKm: maxDistanceKm,
      sortBy: 'distance',
    );
  }

  /// Récupère les garages dans un rayon donné autour de la position.
  Future<List<Garage>> getNearbyGarages({
    required double lat,
    required double lng,
    double radiusKm = 20,
  }) async {
    return getGarages(
      lat: lat,
      lng: lng,
      maxDistanceKm: radiusKm,
      sortBy: 'distance',
    );
  }

  /// Recherche textuelle de garages par nom, ville, adresse ou spécialité.
  Future<List<Garage>> searchGarages(String query) async {
    if (query.trim().isEmpty) return getGarages();
    return getGarages(searchQuery: query.trim());
  }

  /// Récupère un garage par son identifiant.
  Future<Garage?> getGarageById(String id) async {
    try {
      final response =
          await _client.from('garages').select().eq('id', id).maybeSingle();
      if (response == null) return null;
      return Garage.fromMap(response);
    } catch (e) {
      debugPrint('❌ Erreur getGarageById: $e');
      return null;
    }
  }

  // ─── RENDEZ-VOUS ────────────────────────────────────────────────────────────

  /// Récupère les rendez-vous d'un utilisateur avec les infos garage jointes.
  Future<List<Appointment>> getUserAppointments(String userId) async {
    try {
      final response = await _client
          .from('rendez_vous')
          .select(
              '*, garages:garage_id(nom, photo_couverture, ville, telephone)')
          .eq('user_id', userId)
          .order('date_rendez_vous', ascending: false)
          .order('heure_rendez_vous', ascending: false);
      return (response as List)
          .map((e) => Appointment.fromMap(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('❌ Erreur getUserAppointments: $e');
      return [];
    }
  }

  /// Récupère les rendez-vous d'un garage pour une date donnée.
  Future<List<Appointment>> getAppointmentsByGarage(
      String garageId, DateTime date) async {
    try {
      final dateStr = date.toIso8601String().split('T')[0];
      final response = await _client
          .from('rendez_vous')
          .select()
          .eq('garage_id', garageId)
          .eq('date_rendez_vous', dateStr)
          .neq('statut', 'annule');
      return (response as List)
          .map((e) => Appointment.fromMap(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('❌ Erreur getAppointmentsByGarage: $e');
      return [];
    }
  }

  /// Récupère les créneaux horaires déjà réservés pour un garage à une date.
  /// Retourne une liste de chaînes au format 'HH:mm'.
  Future<List<String>> getBookedTimeSlots(
      String garageId, DateTime date) async {
    final appointments = await getAppointmentsByGarage(garageId, date);
    return appointments
        .map((a) =>
            '${a.heureRendezVous.hour.toString().padLeft(2, '0')}:${a.heureRendezVous.minute.toString().padLeft(2, '0')}')
        .toList();
  }

  /// Crée un nouveau rendez-vous.
  Future<bool> createAppointment(Appointment appointment) async {
    try {
      await _client.from('rendez_vous').insert(appointment.toMap());
      debugPrint('✅ Rendez-vous créé avec succès');
      return true;
    } catch (e) {
      debugPrint('❌ Erreur createAppointment: $e');
      return false;
    }
  }

  /// Annule un rendez-vous.
  Future<bool> cancelAppointment(String appointmentId) async {
    try {
      await _client.from('rendez_vous').update({
        'statut': 'annule',
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', appointmentId);
      debugPrint('✅ Rendez-vous annulé');
      return true;
    } catch (e) {
      debugPrint('❌ Erreur cancelAppointment: $e');
      return false;
    }
  }

  /// Met à jour le statut d'un rendez-vous.
  Future<bool> updateAppointmentStatus(
      String appointmentId, String status) async {
    try {
      await _client.from('rendez_vous').update({
        'statut': status,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', appointmentId);
      return true;
    } catch (e) {
      debugPrint('❌ Erreur updateAppointmentStatus: $e');
      return false;
    }
  }

  // ─── AVIS ───────────────────────────────────────────────────────────────────

  /// Récupère les avis d'un garage.
  Future<List<Review>> getGarageReviews(String garageId) async {
    try {
      final response = await _client
          .from('avis_garages')
          .select()
          .eq('garage_id', garageId)
          .order('created_at', ascending: false);
      return (response as List)
          .map((e) => Review.fromMap(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('❌ Erreur getGarageReviews: $e');
      return [];
    }
  }

  /// Crée un avis client.
  Future<bool> createReview(Review review) async {
    try {
      await _client.from('avis_garages').insert(review.toMap());
      debugPrint('✅ Avis créé avec succès');
      return true;
    } catch (e) {
      debugPrint('❌ Erreur createReview: $e');
      return false;
    }
  }

  /// Vérifie si un utilisateur peut laisser un avis sur un garage
  /// (doit avoir un RDV terminé et pas déjà d'avis).
  Future<bool> canUserReviewGarage(String userId, String garageId) async {
    try {
      final rdvResponse = await _client
          .from('rendez_vous')
          .select('id')
          .eq('user_id', userId)
          .eq('garage_id', garageId)
          .eq('statut', 'termine')
          .limit(1);
      if ((rdvResponse as List).isEmpty) return false;

      final avisResponse = await _client
          .from('avis_garages')
          .select('id')
          .eq('user_id', userId)
          .eq('garage_id', garageId)
          .limit(1);
      return (avisResponse as List).isEmpty;
    } catch (e) {
      debugPrint('❌ Erreur canUserReviewGarage: $e');
      return false;
    }
  }

  /// Vérifie si un utilisateur a au moins un rendez-vous terminé avec un garage.
  Future<bool> hasCompletedAppointment(
      String userId, String garageId) async {
    try {
      final response = await _client
          .from('rendez_vous')
          .select('id')
          .eq('user_id', userId)
          .eq('garage_id', garageId)
          .eq('statut', 'termine')
          .limit(1);
      return (response as List).isNotEmpty;
    } catch (e) {
      debugPrint('❌ Erreur hasCompletedAppointment: $e');
      return false;
    }
  }

  /// Vérifie si un utilisateur a déjà laissé un avis pour un rendez-vous précis.
  Future<bool> hasReviewForAppointment(
      String userId, String garageId, String rendezVousId) async {
    try {
      final response = await _client
          .from('avis_garages')
          .select('id')
          .eq('user_id', userId)
          .eq('garage_id', garageId)
          .eq('rendez_vous_id', rendezVousId)
          .limit(1);
      return (response as List).isNotEmpty;
    } catch (e) {
      debugPrint('❌ Erreur hasReviewForAppointment: $e');
      return false;
    }
  }

  // ─── REALTIME ───────────────────────────────────────────────────────────────

  /// S'abonne aux changements en temps réel sur les rendez-vous d'un utilisateur.
  RealtimeChannel subscribeToAppointmentChanges(
    String userId,
    Function(Map<String, dynamic>) onChange,
  ) {
    _appointmentChannel = _client.channel('appointments_$userId');

    _appointmentChannel!.onPostgresChanges(
      event: PostgresChangeEvent.all,
      schema: 'public',
      table: 'rendez_vous',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'user_id',
        value: userId,
      ),
      callback: (PostgresChangePayload payload) {
        debugPrint('🔄 Changement Realtime détecté sur rendez_vous');
        onChange(payload.newRecord);
      },
    );

    _appointmentChannel!.subscribe();
    debugPrint('📡 Abonnement Realtime actif pour $userId');
    return _appointmentChannel!;
  }

  /// Se désabonne des changements en temps réel.
  void unsubscribeFromAppointments() {
    if (_appointmentChannel != null) {
      _client.removeChannel(_appointmentChannel!);
      _appointmentChannel = null;
      debugPrint('📡 Abonnement Realtime supprimé');
    }
  }

  // ─── UTILITAIRES ────────────────────────────────────────────────────────────

  /// Calcule la distance entre deux coordonnées GPS (formule de Haversine).
  /// Retourne la distance en kilomètres.
  static double calculateDistance(
      double lat1, double lon1, double lat2, double lon2) {
    const double earthRadius = 6371; // km
    final double dLat = (lat2 - lat1) * pi / 180;
    final double dLon = (lon2 - lon1) * pi / 180;
    final double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1 * pi / 180) *
            cos(lat2 * pi / 180) *
            sin(dLon / 2) *
            sin(dLon / 2);
    final double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return earthRadius * c;
  }
}
import 'dart:async';
import 'dart:math' show sin, cos, sqrt, atan2, pi;
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

/// Résultat de la localisation avec la position et des helpers de distance.
class LocationResult {
  final Position position;

  LocationResult(this.position);

  double get latitude => position.latitude;
  double get longitude => position.longitude;

  /// Calcule la distance en km depuis cette position jusqu'aux coordonnées données.
  double distanceTo(double lat, double lng) {
    return LocationService.calculateDistance(
        position.latitude, position.longitude, lat, lng);
  }
}

/// Service de géolocalisation pour le module Garages PRO.
class LocationService {
  // ─── PERMISSIONS ────────────────────────────────────────────────────────────

  /// Demande les permissions de localisation.
  /// Retourne `true` si la permission est accordée.
  static Future<bool> requestPermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      debugPrint('⚠️ Service de localisation désactivé');
      return false;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        debugPrint('⚠️ Permission de localisation refusée');
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      debugPrint('⚠️ Permission de localisation refusée définitivement');
      return false;
    }

    return true;
  }

  /// Vérifie si le service de localisation est activé.
  static Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  /// Ouvre les paramètres de localisation de l'appareil.
  static Future<void> openLocationSettings() async {
    await Geolocator.openLocationSettings();
  }

  // ─── POSITION ──────────────────────────────────────────────────────────────

  /// Récupère la position GPS actuelle de l'utilisateur.
  /// Retourne `null` si la permission est refusée ou le service indisponible.
  static Future<Position?> getCurrentPosition() async {
    final hasPermission = await requestPermission();
    if (!hasPermission) return null;

    try {
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 10),
        ),
      );
    } catch (e) {
      debugPrint('❌ Erreur getCurrentPosition: $e');
      return null;
    }
  }

  /// Récupère la position GPS actuelle encapsulée dans un [LocationResult].
  static Future<LocationResult?> getCurrentLocationResult() async {
    final pos = await getCurrentPosition();
    return pos != null ? LocationResult(pos) : null;
  }

  /// Retourne un flux de positions GPS en temps réel.
  /// [distanceFilter] : distance minimale en mètres entre deux mises à jour (défaut : 50m).
  static Stream<Position> getPositionStream({int distanceFilter = 50}) {
    return Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: distanceFilter,
      ),
    );
  }

  /// Retourne la dernière position connue (peut être null).
  static Future<Position?> getLastKnownPosition() async {
    try {
      return await Geolocator.getLastKnownPosition();
    } catch (e) {
      debugPrint('❌ Erreur getLastKnownPosition: $e');
      return null;
    }
  }

  // ─── CALCULS ───────────────────────────────────────────────────────────────

  /// Calcule la distance entre deux coordonnées GPS (formule de Haversine).
  /// Retourne la distance en kilomètres.
  static double calculateDistance(
      double lat1, double lon1, double lat2, double lon2) {
    const double earthRadius = 6371; // km
    final double dLat = (lat2 - lat1) * pi / 180;
    final double dLon = (lon2 - lon1) * pi / 180;
    final double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1 * pi / 180) *
            cos(lat2 * pi / 180) *
            sin(dLon / 2) *
            sin(dLon / 2);
    final double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return earthRadius * c;
  }

  /// Formate une distance pour l'affichage.
  /// Moins de 1 km → affichage en mètres (ex: "850 m").
  /// Plus de 1 km → affichage avec 1 décimale (ex: "2,4 km").
  static String formatDistance(double distanceKm) {
    if (distanceKm < 1) {
      return '${(distanceKm * 1000).round()} m';
    }
    return '${distanceKm.toStringAsFixed(1)} km';
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/garages_pro/models/garage.dart';
import 'package:carhabti/garages_pro/screens/garage_detail_screen.dart';
import 'package:carhabti/garages_pro/screens/garage_itinerary_screen.dart';
import 'package:carhabti/garages_pro/screens/rdv_screen.dart';
import 'package:carhabti/garages_pro/services/garage_service.dart';
import 'package:carhabti/garages_pro/services/location_service.dart';

class GarageMapScreen extends StatefulWidget {
  final List<Garage> garages;
  final Position? userPosition;
  final Garage? initialGarage;
  final String immatriculation;

  const GarageMapScreen({
    super.key,
    required this.garages,
    this.userPosition,
    this.initialGarage,
    required this.immatriculation,
  });

  @override
  State<GarageMapScreen> createState() => _GarageMapScreenState();
}

class _GarageMapScreenState extends State<GarageMapScreen>
    with SingleTickerProviderStateMixin {
  final MapController _mapController = MapController();
  Garage? _selected;
  LatLng? _userLatLng;
  bool _showUserPulse = true;

  static const _kBlue1 = Color(0xFF0D5C8A);
  static const _kBlue2 = Color(0xFF127BBC);

  @override
  void initState() {
    super.initState();
    _selected = widget.initialGarage;
    if (widget.userPosition != null) {
      _userLatLng =
          LatLng(widget.userPosition!.latitude, widget.userPosition!.longitude);
    }
    // Animation de pulsation pour le marqueur utilisateur
    _startPulseAnimation();
  }

  void _startPulseAnimation() {
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => _showUserPulse = !_showUserPulse);
        _startPulseAnimation();
      }
    });
  }

  void _centerOnUser() {
    if (_userLatLng != null) {
      _mapController.move(_userLatLng!, 14);
    }
  }

  void _fitAllMarkers() {
    if (widget.garages.isEmpty) return;
    final bounds = LatLngBounds.fromPoints(
      widget.garages.map((g) => g.latLng).toList(),
    );
    if (_userLatLng != null) {
      bounds.extend(_userLatLng!);
    }
    _mapController.fitCamera(
      CameraFit.bounds(bounds: bounds, padding: const EdgeInsets.all(60)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // ─── CARTE ──────────────────────────────────────────────────────
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _getInitialCenter(),
              initialZoom: 13,
              onTap: (_, __) {
                setState(() => _selected = null);
              },
            ),
            children: [
              TileLayer(
                urlTemplate:
                    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                subdomains: const ['a', 'b', 'c'],
                userAgentPackageName: 'com.carhabti.app',
              ),
              // ─── Polyline entre utilisateur et garage sélectionné ──────
              if (_selected != null && _userLatLng != null)
                PolylineLayer(polylines: [
                  Polyline(
                    points: [_userLatLng!, _selected!.latLng],
                    color: _kBlue2.withOpacity(0.5),
                    strokeWidth: 3,
                    pattern: const StrokePattern.dotted(),
                  ),
                ]),
              // ─── Marqueurs des garages ─────────────────────────────────
              MarkerLayer(
                markers: _buildMarkers(),
              ),
            ],
          ),

          // ─── BOUTON RECENTRER ──────────────────────────────────────────
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            right: 16,
            child: Column(
              children: [
                FloatingActionButton.small(
                  heroTag: 'backBtn',
                  backgroundColor: Colors.white,
                  onPressed: () => Navigator.pop(context),
                  child: const Icon(Icons.arrow_back, color: Colors.black87),
                ),
                const SizedBox(height: 8),
                FloatingActionButton.small(
                  heroTag: 'userLocBtn',
                  backgroundColor: Colors.white,
                  onPressed: _centerOnUser,
                  child: const Icon(Icons.gps_fixed, color: _kBlue1),
                ),
                const SizedBox(height: 8),
                FloatingActionButton.small(
                  heroTag: 'fitAllBtn',
                  backgroundColor: Colors.white,
                  onPressed: _fitAllMarkers,
                  child: const Icon(Icons.zoom_out_map, color: _kBlue1),
                ),
              ],
            ),
          ),

          // ─── COMPTEUR DE GARAGES ──────────────────────────────────────
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2)),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.car_repair, size: 16, color: _kBlue1),
                  const SizedBox(width: 6),
                  Text(
                    '${widget.garages.length} garage${widget.garages.length > 1 ? 's' : ''}',
                    style: GoogleFonts.poppins(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: _kBlue1),
                  ),
                ],
              ),
            ),
          ),

          // ─── BOTTOM SHEET DRAGGABLE ────────────────────────────────────
          if (_selected != null)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: _buildDraggableSheet(_selected!),
            ),
        ],
      ),
    );
  }

  // ─── INITIAL CENTER ────────────────────────────────────────────────────────

  LatLng _getInitialCenter() {
    if (_selected != null) return _selected!.latLng;
    if (_userLatLng != null) return _userLatLng!;
    if (widget.garages.isNotEmpty) return widget.garages.first.latLng;
    return const LatLng(36.8, 10.18); // Tunisie par défaut
  }

  // ─── MARKERS ────────────────────────────────────────────────────────────────

  List<Marker> _buildMarkers() {
    final markers = <Marker>[];

    // Marqueur utilisateur avec animation pulsante
    if (_userLatLng != null) {
      markers.add(Marker(
        point: _userLatLng!,
        width: 24,
        height: 24,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Cercle de précision pulsant
            AnimatedContainer(
              duration: const Duration(seconds: 2),
              curve: Curves.easeInOut,
              width: _showUserPulse ? 40 : 24,
              height: _showUserPulse ? 40 : 24,
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
            ),
            // Point central
            Container(
              width: 16,
              height: 16,
              decoration: BoxDecoration(
                color: Colors.blue,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 3),
              ),
            ),
          ],
        ),
      ));
    }

    // Marqueurs des garages
    for (final g in widget.garages) {
      final isSelected = _selected?.id == g.id;
      markers.add(Marker(
        point: g.latLng,
        width: isSelected ? 52 : 42,
        height: isSelected ? 52 : 42,
        child: GestureDetector(
          onTap: () {
            setState(() => _selected = g);
            _mapController.move(g.latLng, 15);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: isSelected ? _kBlue2 : _kBlue1,
              shape: BoxShape.circle,
              border: isSelected
                  ? Border.all(color: Colors.white, width: 3)
                  : Border.all(color: Colors.white, width: 2),
              boxShadow: isSelected
                  ? [
                      BoxShadow(
                          color: _kBlue1.withOpacity(0.4),
                          blurRadius: 8,
                          offset: const Offset(0, 3))
                    ]
                  : null,
            ),
            child: Icon(
              Icons.build,
              color: Colors.white,
              size: isSelected ? 24 : 18,
            ),
          ),
        ),
      ));
    }

    return markers;
  }

  // ─── DRAGGABLE BOTTOM SHEET ─────────────────────────────────────────────────

  Widget _buildDraggableSheet(Garage g) {
    final dist = widget.userPosition == null
        ? null
        : GarageService.calculateDistance(widget.userPosition!.latitude,
            widget.userPosition!.longitude, g.latitude, g.longitude);

    return DraggableScrollableSheet(
      initialChildSize: 0.35,
      minChildSize: 0.2,
      maxChildSize: 0.55,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            boxShadow: [
              BoxShadow(
                  color: Colors.black12, blurRadius: 10, offset: Offset(0, -2))
            ],
          ),
          child: SingleChildScrollView(
            controller: scrollController,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Handle de drag
                Center(
                  child: Container(
                    margin: const EdgeInsets.only(top: 10, bottom: 6),
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Nom + vérifié
                      Row(children: [
                        Expanded(
                          child: Text(g.nom,
                              style: GoogleFonts.poppins(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: const Color(0xFF1A2340))),
                        ),
                        if (g.estVerifie)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFF43A047).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.verified,
                                    size: 12, color: Color(0xFF43A047)),
                                const SizedBox(width: 4),
                                Text('Vérifié',
                                    style: GoogleFonts.poppins(
                                        fontSize: 10,
                                        color: const Color(0xFF43A047),
                                        fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ),
                      ]),
                      const SizedBox(height: 4),
                      Text('${g.ville} • ${g.adresse}',
                          style: GoogleFonts.poppins(
                              fontSize: 13, color: const Color(0xFF8A94A6))),
                      const SizedBox(height: 8),
                      // Note + distance
                      Row(
                        children: [
                          _buildStars(g.noteMoyenne),
                          const SizedBox(width: 6),
                          Text(
                              '${g.noteMoyenne.toStringAsFixed(1)} (${g.nombreAvis})',
                              style: GoogleFonts.poppins(
                                  fontSize: 12,
                                  color: const Color(0xFF8A94A6))),
                          const Spacer(),
                          if (dist != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _kBlue2.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.navigation_outlined,
                                      size: 14, color: _kBlue2),
                                  const SizedBox(width: 4),
                                  Text(LocationService.formatDistance(dist),
                                      style: GoogleFonts.poppins(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: _kBlue2)),
                                ],
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      // Spécialités
                      Wrap(
                        spacing: 6,
                        children: g.specialites
                            .take(3)
                            .map((s) => Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: _kBlue2.withOpacity(0.08),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(s,
                                      style: GoogleFonts.poppins(
                                          fontSize: 10,
                                          color: _kBlue2,
                                          fontWeight: FontWeight.w500)),
                                ))
                            .toList(),
                      ),
                      const SizedBox(height: 16),
                      // Boutons d'action
                      Row(children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => GarageItineraryScreen(
                                        garage: g,
                                        userPosition: widget.userPosition))),
                            icon: const Icon(Icons.directions,
                                size: 18, color: Colors.white),
                            label: Text('Itinéraire',
                                style: GoogleFonts.poppins(
                                    fontSize: 12,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _kBlue1,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => BookingScreen(
                                        garage: g,
                                        immatriculation:
                                            widget.immatriculation))),
                            icon: const Icon(Icons.calendar_today,
                                size: 18, color: Colors.white),
                            label: Text('Prendre RDV',
                                style: GoogleFonts.poppins(
                                    fontSize: 12,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _kBlue2,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 8),
                      // Bouton voir les détails
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => GarageDetailScreen(
                                      garage: g,
                                      userPosition: widget.userPosition,
                                      immatriculation:
                                          widget.immatriculation))),
                          icon: const Icon(Icons.info_outline, size: 16),
                          label: Text('Voir la fiche complète',
                              style: GoogleFonts.poppins(fontSize: 13)),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _kBlue1,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── ÉTOLES DE NOTATION ─────────────────────────────────────────────────────

  Widget _buildStars(double rating) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (i) {
        final filled = i < rating.floor();
        final half = i == rating.floor() && rating % 1 >= 0.5;
        return Icon(
          half ? Icons.star_half : (filled ? Icons.star : Icons.star_border),
          size: 14,
          color: const Color(0xFFFFB300),
        );
      }),
    );
  }
}
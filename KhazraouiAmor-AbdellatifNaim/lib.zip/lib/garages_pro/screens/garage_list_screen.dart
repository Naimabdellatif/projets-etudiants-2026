// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/garages_pro/models/garage.dart';
import 'package:carhabti/garages_pro/services/garage_service.dart';
import 'package:carhabti/garages_pro/services/location_service.dart';
import 'package:carhabti/garages_pro/widgets/garage_card.dart';
import 'package:carhabti/garages_pro/screens/garage_map_screen.dart';
import 'package:carhabti/garages_pro/screens/garage_detail_screen.dart';
import 'package:carhabti/garages_pro/screens/rdv_screen.dart';
import 'package:geolocator/geolocator.dart';

class GarageListScreen extends StatefulWidget {
  final String immatriculation;

  const GarageListScreen({super.key, required this.immatriculation});

  @override
  State<GarageListScreen> createState() => _GarageListScreenState();
}

class _GarageListScreenState extends State<GarageListScreen>
    with SingleTickerProviderStateMixin {
  final GarageService _service = GarageService();
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<Garage> _garages = [];
  List<Garage> _filtered = [];
  bool _isLoading = true;
  Position? _userPos;
  String _sortBy = 'distance';
  String _selectedFilter = 'Tous';
  bool _isSearchExpanded = false;
  final FocusNode _searchFocusNode = FocusNode();

  static const _kBlue1 = Color(0xFF0D5C8A);
  static const _kBlue2 = Color(0xFF127BBC);
  static const _kBlue3 = Color(0xFF1AA3D8);

  final List<Map<String, dynamic>> _filters = [
    {'label': 'Tous', 'icon': Icons.apps},
    {'label': 'Près de moi', 'icon': Icons.near_me},
    {'label': 'Vidange', 'icon': Icons.opacity},
    {'label': 'Freins', 'icon': Icons.disc_full},
    {'label': 'Électronique', 'icon': Icons.electrical_services},
    {'label': 'Carrosserie', 'icon': Icons.directions_car},
    {'label': 'Climatisation', 'icon': Icons.ac_unit},
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      _userPos = await LocationService.getCurrentPosition();
      final garages = await _service.getGarages(
        lat: _userPos?.latitude,
        lng: _userPos?.longitude,
        sortBy: _sortBy,
      );
      setState(() {
        _garages = garages;
        _applyFilters();
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Erreur chargement garages: $e');
      setState(() => _isLoading = false);
    }
  }

  void _applyFilters() {
    var results = List<Garage>.from(_garages);
    final query = _searchController.text.trim().toLowerCase();

    if (query.isNotEmpty) {
      results = results
          .where((g) =>
              g.nom.toLowerCase().contains(query) ||
              g.ville.toLowerCase().contains(query) ||
              g.adresse.toLowerCase().contains(query) ||
              g.specialites.any((s) => s.toLowerCase().contains(query)))
          .toList();
    }

    if (_selectedFilter != 'Tous' && _selectedFilter != 'Près de moi') {
      results = results
          .where((g) => g.specialites.any(
              (s) => s.toLowerCase().contains(_selectedFilter.toLowerCase())))
          .toList();
    }

    if (_selectedFilter == 'Près de moi' && _userPos != null) {
      results = results.where((g) {
        final d = GarageService.calculateDistance(
            _userPos!.latitude, _userPos!.longitude, g.latitude, g.longitude);
        return d <= 20;
      }).toList();
    }

    if (_sortBy == 'distance' && _userPos != null) {
      results.sort((a, b) {
        final da = GarageService.calculateDistance(
            _userPos!.latitude, _userPos!.longitude, a.latitude, a.longitude);
        final db = GarageService.calculateDistance(
            _userPos!.latitude, _userPos!.longitude, b.latitude, b.longitude);
        return da.compareTo(db);
      });
    } else if (_sortBy == 'note') {
      results.sort((a, b) => b.noteMoyenne.compareTo(a.noteMoyenne));
    } else if (_sortBy == 'alpha') {
      results.sort((a, b) => a.nom.compareTo(b.nom));
    }

    setState(() => _filtered = results);
  }

  double? _getDistance(Garage g) => _userPos == null
      ? null
      : GarageService.calculateDistance(
          _userPos!.latitude, _userPos!.longitude, g.latitude, g.longitude);

  void _openMap() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => GarageMapScreen(
                  garages: _filtered,
                  userPosition: _userPos,
                  immatriculation: widget.immatriculation,
                )));
  }

  void _openDetail(Garage g) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => GarageDetailScreen(
                garage: g,
                userPosition: _userPos,
                immatriculation: widget.immatriculation)));
  }

  void _openBooking(Garage g) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => BookingScreen(
                garage: g, immatriculation: widget.immatriculation)));
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // BUILD — PAS DE Scaffold ici.
  // Le widget est rendu directement dans le body du Scaffold parent
  // (ClientDashboard). Le fond est transparent pour hériter du _kBg du parent.
  // ─────────────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    // CustomScrollView autonome — le Scaffold et l'AppBar sont fournis par
    // ClientDashboard via _buildGarageAppBar() / appBar: null.
    return CustomScrollView(
      controller: _scrollController,
      slivers: [
        // ── SliverAppBar propre à la section Garages PRO ─────────────────────
        _buildSliverAppBar(),

        // ── Barre de recherche (animée) ───────────────────────────────────────
        SliverToBoxAdapter(child: _buildSearchBar()),

        // ── Chips de filtres ──────────────────────────────────────────────────
        SliverToBoxAdapter(child: _buildFilterChips()),

        // ── Contenu principal ─────────────────────────────────────────────────
        _isLoading
            ? const SliverFillRemaining(
                child: Center(
                    child: CircularProgressIndicator(color: _kBlue2)))
            : _filtered.isEmpty
                ? SliverFillRemaining(child: _buildEmptyState())
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (ctx, i) {
                        final g = _filtered[i];
                        return GarageCard(
                          garage: g,
                          distance: _getDistance(g),
                          onTap: () => _openDetail(g),
                          onMapTap: _openMap,
                          onBookingTap: () => _openBooking(g),
                        );
                      },
                      childCount: _filtered.length,
                    ),
                  ),
      ],
    );
  }

  // ─── SLIVER APP BAR ──────────────────────────────────────────────────────────
  // automaticallyImplyLeading: false → pas de flèche retour indésirable
  // (le back est géré par la BottomNavBar du Dashboard)

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 80,
      floating: true,
      pinned: true,
      elevation: 0,
      title: Text(
        'Garages PRO',
        style: GoogleFonts.poppins(
            fontWeight: FontWeight.w700, color: Colors.white, fontSize: 18),
      ),
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [_kBlue1, _kBlue2, _kBlue3],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      ),
      actions: [
        // Recherche
        IconButton(
          icon: const Icon(Icons.search, color: Colors.white),
          onPressed: () {
            setState(() {
              _isSearchExpanded = !_isSearchExpanded;
              if (!_isSearchExpanded) {
                _searchController.clear();
                _applyFilters();
              } else {
                _searchFocusNode.requestFocus();
              }
            });
          },
        ),
        // Carte
        IconButton(
          icon: const Icon(Icons.map_outlined, color: Colors.white),
          onPressed: _openMap,
        ),
        // Tri
        PopupMenuButton<String>(
          icon: const Icon(Icons.sort, color: Colors.white),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          onSelected: (v) => setState(() {
            _sortBy = v;
            _applyFilters();
          }),
          itemBuilder: (_) => [
            _sortItem('distance', 'Par distance', Icons.near_me),
            _sortItem('note', 'Par note', Icons.star),
            _sortItem('alpha', 'Alphabétique', Icons.sort_by_alpha),
          ],
        ),
      ],
    );
  }

  PopupMenuItem<String> _sortItem(
      String value, String label, IconData icon) {
    final isActive = _sortBy == value;
    return PopupMenuItem(
      value: value,
      child: Row(children: [
        Icon(icon, size: 18, color: isActive ? _kBlue2 : Colors.grey),
        const SizedBox(width: 8),
        Text(label),
        if (isActive) ...[
          const Spacer(),
          const Icon(Icons.check, size: 16, color: _kBlue2),
        ],
      ]),
    );
  }

  // ─── SEARCH BAR ──────────────────────────────────────────────────────────────

  Widget _buildSearchBar() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      height: _isSearchExpanded ? 60 : 0,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: _isSearchExpanded
          ? TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              onChanged: (_) => _applyFilters(),
              style: GoogleFonts.poppins(fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Rechercher par nom, ville, spécialité...',
                hintStyle: GoogleFonts.poppins(
                    fontSize: 13, color: const Color(0xFF8A94A6)),
                prefixIcon:
                    const Icon(Icons.search, color: Color(0xFF8A94A6)),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear,
                            color: Color(0xFF8A94A6), size: 18),
                        onPressed: () {
                          _searchController.clear();
                          _applyFilters();
                        })
                    : null,
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 12),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(
                        color: _kBlue2.withOpacity(0.3), width: 1.5)),
              ),
            )
          : const SizedBox.shrink(),
    );
  }

  // ─── FILTER CHIPS ────────────────────────────────────────────────────────────

  Widget _buildFilterChips() {
    return SizedBox(
      height: 48,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: _filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (ctx, i) {
          final filter = _filters[i];
          final label = filter['label'] as String;
          final icon = filter['icon'] as IconData;
          final isSelected = _selectedFilter == label;
          return ChoiceChip(
            avatar: Icon(icon,
                size: 16,
                color:
                    isSelected ? _kBlue2 : const Color(0xFF8A94A6)),
            label:
                Text(label, style: GoogleFonts.poppins(fontSize: 12)),
            selected: isSelected,
            onSelected: (_) => setState(() {
              _selectedFilter = label;
              _applyFilters();
            }),
            selectedColor: _kBlue2.withOpacity(0.15),
            backgroundColor: Colors.white,
            labelStyle: TextStyle(
              color: isSelected ? _kBlue2 : const Color(0xFF8A94A6),
              fontWeight:
                  isSelected ? FontWeight.w600 : FontWeight.normal,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: BorderSide(
                color: isSelected
                    ? _kBlue2.withOpacity(0.4)
                    : const Color(0xFFEAEEF4),
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── EMPTY STATE ─────────────────────────────────────────────────────────────

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.build_outlined, size: 80, color: Colors.grey.shade300),
            const SizedBox(height: 20),
            Text(
              'Aucun garage trouvé',
              style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF8A94A6)),
            ),
            const SizedBox(height: 8),
            Text(
              'Essayez une autre recherche ou un autre filtre',
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                  fontSize: 14, color: Colors.grey.shade400),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  _selectedFilter = 'Tous';
                  _searchController.clear();
                  _sortBy = 'distance';
                });
                _loadData();
              },
              icon: const Icon(Icons.refresh, size: 18),
              label: Text('Réinitialiser les filtres',
                  style: GoogleFonts.poppins(fontSize: 14)),
              style: ElevatedButton.styleFrom(
                  backgroundColor: _kBlue2,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12)),
            ),
          ],
        ),
      ),
    );
  }
}
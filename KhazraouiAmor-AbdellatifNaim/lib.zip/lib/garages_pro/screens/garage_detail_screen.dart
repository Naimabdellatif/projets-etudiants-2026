// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:carhabti/garages_pro/models/garage.dart';
import 'package:carhabti/garages_pro/models/review.dart';
import 'package:carhabti/garages_pro/services/garage_service.dart';
import 'package:carhabti/supabase_connexion.dart';
import 'garage_itinerary_screen.dart';
import 'rdv_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class GarageDetailScreen extends StatefulWidget {
  final Garage garage;
  final Position? userPosition;
  final String immatriculation;

  const GarageDetailScreen({
    super.key,
    required this.garage,
    this.userPosition,
    required this.immatriculation,
  });

  @override
  State<GarageDetailScreen> createState() => _GarageDetailScreenState();
}

class _GarageDetailScreenState extends State<GarageDetailScreen> {
  static const _kBlue1 = Color(0xFF0D5C8A);
  static const _kBlue2 = Color(0xFF127BBC);

  final GarageService _service = GarageService();
  List<Review> _reviews = [];
  bool _loadingReviews = true;
  bool _canReview = false;
  bool _alreadyReviewed = false;

  @override
  void initState() {
    super.initState();
    _loadReviews();
    _checkReviewEligibility();
  }

  Future<void> _loadReviews() async {
    final reviews = await _service.getGarageReviews(widget.garage.id);
    if (mounted) {
      setState(() {
        _reviews = reviews;
        _loadingReviews = false;
      });
    }
  }

  Future<void> _checkReviewEligibility() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    final can =
        await _service.hasCompletedAppointment(user.id, widget.garage.id);
    final already =
        await _service.hasReviewForAppointment(
            user.id, widget.garage.id, widget.immatriculation);
    if (mounted) {
      setState(() {
        _canReview = can && !already;
        _alreadyReviewed = already;
      });
    }
  }

  void _openLeaveReview() {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    int selectedNote = 5;
    final commentCtrl = TextEditingController();
    bool submitting = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Laisser un avis',
                  style: GoogleFonts.poppins(
                      fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(widget.garage.nom,
                  style: GoogleFonts.poppins(
                      fontSize: 13, color: const Color(0xFF8A94A6))),
              const SizedBox(height: 16),
              Text('Note',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600, fontSize: 14)),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                    5,
                    (i) => GestureDetector(
                          onTap: () =>
                              setModalState(() => selectedNote = i + 1),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            child: Icon(
                              i < selectedNote ? Icons.star : Icons.star_border,
                              color: const Color(0xFFFFB300),
                              size: 36,
                            ),
                          ),
                        )),
              ),
              const SizedBox(height: 16),
              Text('Commentaire (optionnel)',
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600, fontSize: 14)),
              const SizedBox(height: 8),
              TextField(
                controller: commentCtrl,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'Partagez votre expérience…',
                  hintStyle: GoogleFonts.poppins(color: Colors.grey),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _kBlue1),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: submitting
                      ? null
                      : () async {
                          setModalState(() => submitting = true);
                          final ok = await _service.createReview(Review(
                            id: '',
                            userId: user.id,
                            garageId: widget.garage.id,
                            note: selectedNote,
                            commentaire: commentCtrl.text.trim().isEmpty
                                ? null
                                : commentCtrl.text.trim(),
                            createdAt: DateTime.now(),
                          ));
                          if (ctx.mounted) Navigator.pop(ctx);
                          if (ok && mounted) {
                            setState(() => _canReview = false);
                            _loadReviews();
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Merci pour votre avis !')),
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kBlue1,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: submitting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : Text('Publier l\'avis',
                          style:
                              GoogleFonts.poppins(fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final g = widget.garage;

    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 220,
          pinned: true,
          backgroundColor: _kBlue1,
          flexibleSpace: FlexibleSpaceBar(
            background: g.photoCouverture != null
                ? Hero(
                    tag: 'garage_${g.id}',
                    child: Image.network(g.photoCouverture!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _placeholder()))
                : _placeholder(),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Titre + badge vérifié
                Row(children: [
                  Expanded(
                    child: Text(g.nom,
                        style: GoogleFonts.poppins(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF1A2340))),
                  ),
                  if (g.estVerifie) _verifiedBadge(),
                ]),
                const SizedBox(height: 4),
                Text(g.ville,
                    style: GoogleFonts.poppins(
                        fontSize: 15, color: const Color(0xFF8A94A6))),
                const SizedBox(height: 4),
                _starsRow(g.noteMoyenne, g.nombreAvis),
                const SizedBox(height: 16),

                // Informations de contact
                _infoTile(Icons.location_on, g.adresse),
                if (g.telephone != null)
                  _infoTile(Icons.phone, g.telephone!, onTap: () async {
                    final u = Uri(scheme: 'tel', path: g.telephone);
                    if (await canLaunchUrl(u)) launchUrl(u);
                  }),
                if (g.email != null)
                  _infoTile(Icons.email, g.email!, onTap: () async {
                    final u = Uri(scheme: 'mailto', path: g.email);
                    if (await canLaunchUrl(u)) launchUrl(u);
                  }),

                const SizedBox(height: 24),

                // Spécialités
                _sectionTitle('Spécialités'),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: g.specialites
                      .map((s) => Chip(
                            label: Text(s,
                                style: GoogleFonts.poppins(fontSize: 12)),
                            backgroundColor: _kBlue2.withOpacity(0.08),
                            side: BorderSide.none,
                          ))
                      .toList(),
                ),

                const SizedBox(height: 24),

                // Horaires
                _sectionTitle('Horaires d\'ouverture'),
                const SizedBox(height: 10),
                ...[
                  'Lundi',
                  'Mardi',
                  'Mercredi',
                  'Jeudi',
                  'Vendredi',
                  'Samedi',
                  'Dimanche'
                ].map((j) {
                  final h = g.getHoraireJour(j);
                  final isClosed = h == 'Fermé';
                  return Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom:
                            BorderSide(color: Colors.grey.shade100, width: 0.5),
                      ),
                    ),
                    child: Row(children: [
                      SizedBox(
                        width: 100,
                        child:
                            Text(j, style: GoogleFonts.poppins(fontSize: 14)),
                      ),
                      const Spacer(),
                      Text(h,
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: isClosed
                                ? Colors.red.shade400
                                : const Color(0xFF1A2340),
                          )),
                    ]),
                  );
                }),

                const SizedBox(height: 24),

                // Localisation (mini carte)
                _sectionTitle('Localisation'),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: SizedBox(
                    height: 180,
                    child: FlutterMap(
                      options: MapOptions(
                        initialCenter: g.latLng,
                        initialZoom: 15,
                        interactionOptions: const InteractionOptions(
                            flags: InteractiveFlag.none),
                      ),
                      children: [
                        TileLayer(
                          urlTemplate:
                              'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                          subdomains: const ['a', 'b', 'c'],
                        ),
                        MarkerLayer(markers: [
                          Marker(
                            point: g.latLng,
                            width: 44,
                            height: 44,
                            child: Container(
                              decoration: const BoxDecoration(
                                color: _kBlue1,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.car_repair,
                                  color: Colors.white, size: 22),
                            ),
                          ),
                        ]),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => GarageItineraryScreen(
                                garage: g, userPosition: widget.userPosition))),
                    icon: const Icon(Icons.directions),
                    label: const Text('Obtenir l\'itinéraire'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _kBlue2,
                      side: BorderSide(color: _kBlue2.withOpacity(0.4)),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                // ─── AVIS CLIENTS ─────────────────────────────────────────
                Row(children: [
                  Expanded(child: _sectionTitle('Avis clients')),
                  if (_canReview)
                    TextButton.icon(
                      onPressed: _openLeaveReview,
                      icon: const Icon(Icons.rate_review_outlined, size: 16),
                      label: const Text('Laisser un avis'),
                      style: TextButton.styleFrom(foregroundColor: _kBlue1),
                    ),
                  if (_alreadyReviewed)
                    Text('Avis envoyé ✓',
                        style: GoogleFonts.poppins(
                            fontSize: 12, color: Colors.green.shade600)),
                ]),
                const SizedBox(height: 10),

                if (_loadingReviews)
                  const Center(child: CircularProgressIndicator(color: _kBlue2))
                else if (_reviews.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text('Aucun avis pour le moment.',
                          style: GoogleFonts.poppins(
                              color: Colors.grey, fontSize: 13)),
                    ),
                  )
                else
                  ...(_reviews.take(5).map((r) => _reviewCard(r))),

                if (_reviews.length > 5)
                  TextButton(
                    onPressed: () {},
                    child: Text('Voir tous les ${_reviews.length} avis',
                        style: GoogleFonts.poppins(color: _kBlue1)),
                  ),

                const SizedBox(height: 80), // espace pour le bottom bar
              ],
            ),
          ),
        ),
      ]),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0D5C8A), Color(0xFF5E35B1)],
            ),
          ),
          child: ElevatedButton.icon(
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => BookingScreen(
                        garage: g,
                        immatriculation: widget.immatriculation))),
            icon: const Icon(Icons.calendar_today, color: Colors.white),
            label: const Text('Prendre rendez-vous',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ),
    );
  }

  Widget _placeholder() => Container(
        color: Colors.grey.shade300,
        child: const Center(
            child: Icon(Icons.car_repair, size: 64, color: Colors.white)),
      );

  Widget _verifiedBadge() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: const Color(0xFF43A047).withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.verified, size: 14, color: Color(0xFF43A047)),
            const SizedBox(width: 4),
            Text('Vérifié',
                style: GoogleFonts.poppins(
                    fontSize: 11,
                    color: const Color(0xFF43A047),
                    fontWeight: FontWeight.w700)),
          ],
        ),
      );

  Widget _sectionTitle(String t) => Text(t,
      style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w700));

  Widget _starsRow(double note, int count) => Row(children: [
        ...List.generate(5, (i) {
          if (i < note.floor()) {
            return const Icon(Icons.star, size: 16, color: Color(0xFFFFB300));
          } else if (i == note.floor() && note % 1 >= 0.5) {
            return const Icon(Icons.star_half,
                size: 16, color: Color(0xFFFFB300));
          } else {
            return const Icon(Icons.star_border,
                size: 16, color: Color(0xFFFFB300));
          }
        }),
        const SizedBox(width: 6),
        Text('${note.toStringAsFixed(1)} ($count avis)',
            style: GoogleFonts.poppins(
                fontSize: 13, color: const Color(0xFF8A94A6))),
      ]);

  Widget _infoTile(IconData icon, String text, {VoidCallback? onTap}) =>
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(children: [
            Icon(icon, color: _kBlue1, size: 18),
            const SizedBox(width: 12),
            Expanded(
              child: Text(text,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    color: onTap != null ? _kBlue2 : const Color(0xFF1A2340),
                    decoration: onTap != null ? TextDecoration.underline : null,
                  )),
            ),
          ]),
        ),
      );

  Widget _reviewCard(Review r) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade100),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Row(
              children: List.generate(
                  5,
                  (i) => Icon(
                        i < r.note ? Icons.star : Icons.star_border,
                        size: 14,
                        color: const Color(0xFFFFB300),
                      )),
            ),
            const Spacer(),
            if (r.userName != null)
              Text(r.userName!,
                  style: GoogleFonts.poppins(
                      fontSize: 12, fontWeight: FontWeight.w600)),
            const SizedBox(width: 8),
            Text(
              '${r.createdAt.day.toString().padLeft(2, '0')}/'
              '${r.createdAt.month.toString().padLeft(2, '0')}/'
              '${r.createdAt.year}',
              style: GoogleFonts.poppins(
                  fontSize: 11, color: const Color(0xFF8A94A6)),
            ),
          ]),
          if (r.commentaire != null && r.commentaire!.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(r.commentaire!,
                style: GoogleFonts.poppins(
                    fontSize: 13, color: const Color(0xFF4A4A4A))),
          ],
        ]),
      );
}

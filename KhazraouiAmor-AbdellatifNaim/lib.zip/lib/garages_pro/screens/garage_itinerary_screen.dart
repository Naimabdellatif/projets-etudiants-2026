// ignore_for_file: deprecated_member_use

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:carhabti/garages_pro/models/garage.dart';
import 'package:carhabti/garages_pro/services/location_service.dart';
import 'package:carhabti/garages_pro/services/garage_service.dart';

class GarageItineraryScreen extends StatefulWidget {
  final Garage garage;
  final Position? userPosition;

  const GarageItineraryScreen({
    super.key,
    required this.garage,
    this.userPosition,
  });

  @override
  State<GarageItineraryScreen> createState() => _GarageItineraryScreenState();
}

class _GarageItineraryScreenState extends State<GarageItineraryScreen> {
  final MapController _mapController = MapController();
  LatLng? _userLoc;
  String _mode = 'driving'; // driving, walking, cycling
  List<LatLng> _routePoints = [];
  bool _isLoadingRoute = false;
  double _routeDistance = 0; // en km
  int _routeDuration = 0; // en minutes
  Stream<Position>? _positionStream;
  LatLng? _lastUserLoc;

  static const _kBlue1 = Color(0xFF0D5C8A);
  static const _kBlue2 = Color(0xFF127BBC);

  // Clé API OpenRouteService (gratuite, 2000 requêtes/jour)
  static const String _orsApiKey =
      '5b3ce3597851110001cf6248a00000000000000000000000000000000';

  @override
  void initState() {
    super.initState();
    _initLocation();
  }

  @override
  void dispose() {
    // Ne pas annuler le stream ici car Geolocator gère le cycle de vie
    super.dispose();
  }

  Future<void> _initLocation() async {
    if (widget.userPosition != null) {
      _userLoc =
          LatLng(widget.userPosition!.latitude, widget.userPosition!.longitude);
    } else {
      final pos = await LocationService.getCurrentPosition();
      if (pos != null) {
        _userLoc = LatLng(pos.latitude, pos.longitude);
      }
    }

    if (_userLoc != null) {
      _lastUserLoc = _userLoc;
      await _fetchRoute();
    }

    // Surveiller les déplacements pour recalcul si > 50m
    _positionStream = LocationService.getPositionStream(distanceFilter: 50);
    _positionStream!.listen((Position pos) {
      final newLoc = LatLng(pos.latitude, pos.longitude);
      if (_lastUserLoc != null) {
        final dist = GarageService.calculateDistance(
          _lastUserLoc!.latitude,
          _lastUserLoc!.longitude,
          newLoc.latitude,
          newLoc.longitude,
        );
        if (dist * 1000 > 50) {
          // Plus de 50m de déplacement
          setState(() {
            _userLoc = newLoc;
            _lastUserLoc = newLoc;
          });
          _fetchRoute();
        }
      } else {
        setState(() {
          _userLoc = newLoc;
          _lastUserLoc = newLoc;
        });
        _fetchRoute();
      }
    });

    setState(() {});
  }

  /// Récupère l'itinéraire via OpenRouteService API.
  Future<void> _fetchRoute() async {
    if (_userLoc == null) return;

    setState(() => _isLoadingRoute = true);

    try {
      final profile = _getORSProfile();
      final url = Uri.parse(
        'https://api.openrouteservice.org/v2/directions/$profile?api_key=$_orsApiKey&start=${_userLoc!.longitude},${_userLoc!.latitude}&end=${widget.garage.longitude},${widget.garage.latitude}',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final routes = data['routes'] as List?;
        if (routes != null && routes.isNotEmpty) {
          final route = routes[0];
          final segments = route['summary'] as Map<String, dynamic>?;

          if (segments != null) {
            setState(() {
              _routeDistance = (segments['distance'] as num?)?.toDouble() ?? 0;
              _routeDistance = _routeDistance / 1000; // Convertir en km
              _routeDuration =
                  ((segments['duration'] as num?)?.toDouble() ?? 0) ~/
                      60; // Convertir en minutes
            });
          }

          // Décoder la polyline encodée
          final geometry = route['geometry'] as String?;
          if (geometry != null) {
            final decoded = _decodePolyline(geometry);
            setState(() => _routePoints = decoded);
          }
        }
      } else {
        debugPrint('❌ Erreur API ORS: ${response.statusCode}');
        // Fallback : ligne droite
        setState(() {
          _routePoints = [_userLoc!, widget.garage.latLng];
          _routeDistance = GarageService.calculateDistance(
            _userLoc!.latitude,
            _userLoc!.longitude,
            widget.garage.latitude,
            widget.garage.longitude,
          );
          _routeDuration = _estimateDuration(_routeDistance);
        });
      }
    } catch (e) {
      debugPrint('❌ Erreur fetchRoute: $e');
      // Fallback : ligne droite avec estimation
      setState(() {
        _routePoints = _userLoc != null
            ? [_userLoc!, widget.garage.latLng]
            : [widget.garage.latLng];
        _routeDistance = _userLoc != null
            ? GarageService.calculateDistance(
                _userLoc!.latitude,
                _userLoc!.longitude,
                widget.garage.latitude,
                widget.garage.longitude)
            : 0;
        _routeDuration = _estimateDuration(_routeDistance);
      });
    }

    setState(() => _isLoadingRoute = false);

    // Zoom automatique pour englober tout l'itinéraire
    _fitRouteBounds();
  }

  String _getORSProfile() {
    switch (_mode) {
      case 'walking':
        return 'foot-walking';
      case 'cycling':
        return 'cycling-regular';
      default:
        return 'driving-car';
    }
  }

  int _estimateDuration(double distanceKm) {
    switch (_mode) {
      case 'walking':
        return (distanceKm / 5 * 60).round(); // 5 km/h
      case 'cycling':
        return (distanceKm / 15 * 60).round(); // 15 km/h
      default:
        return (distanceKm / 40 * 60).round(); // 40 km/h moyenne urbaine
    }
  }

  /// Décode une polyline encodée (format ORS/Google).
  List<LatLng> _decodePolyline(String encoded) {
    final points = <LatLng>[];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return points;
  }

  void _fitRouteBounds() {
    if (_routePoints.isEmpty) return;
    final bounds = LatLngBounds.fromPoints(_routePoints);
    if (_userLoc != null) bounds.extend(_userLoc!);
    bounds.extend(widget.garage.latLng);
    _mapController.fitCamera(
      CameraFit.bounds(bounds: bounds, padding: const EdgeInsets.all(60)),
    );
  }

  void _openExternalNav() async {
    final dest = '${widget.garage.latitude},${widget.garage.longitude}';
    final travelMode = _mode == 'walking'
        ? 'walking'
        : _mode == 'cycling'
            ? 'bicycling'
            : 'driving';
    final uri = Uri.parse(
        'https://www.google.com/maps/dir/?api=1&destination=$dest&travelmode=$travelMode');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _openWaze() async {
    final uri = Uri.parse(
        'https://waze.com/ul?ll=${widget.garage.latitude},${widget.garage.longitude}&navigate=yes');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final g = widget.garage;

    return Scaffold(
      appBar: AppBar(
        title: Text('Itinéraire vers ${g.nom}',
            style: GoogleFonts.poppins(fontSize: 16)),
        backgroundColor: _kBlue1,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          // ─── CARTE ────────────────────────────────────────────────────
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _userLoc ?? g.latLng,
              initialZoom: 13,
            ),
            children: [
              TileLayer(
                urlTemplate:
                    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                subdomains: const ['a', 'b', 'c'],
                userAgentPackageName: 'com.carhabti.app',
              ),
              // ─── Tracé de l'itinéraire ─────────────────────────────
              if (_routePoints.isNotEmpty)
                PolylineLayer(polylines: [
                  Polyline(
                    points: _routePoints,
                    color: _kBlue2,
                    strokeWidth: 5,
                    strokeJoin: StrokeJoin.round,
                  ),
                ]),
              // ─── Marqueurs ──────────────────────────────────────────
              MarkerLayer(
                markers: [
                  // Marqueur position utilisateur
                  if (_userLoc != null)
                    Marker(
                      point: _userLoc!,
                      width: 24,
                      height: 24,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                        ),
                        child: const Icon(Icons.person,
                            color: Colors.white, size: 12),
                      ),
                    ),
                  // Marqueur garage
                  Marker(
                    point: g.latLng,
                    width: 40,
                    height: 40,
                    child: Container(
                      decoration: BoxDecoration(
                        color: _kBlue1,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                      ),
                      child: const Icon(Icons.build,
                          color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ],
          ),

          // ─── INDICATEUR DE CHARGEMENT ──────────────────────────────
          if (_isLoadingRoute)
            Positioned(
              top: 16,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.1), blurRadius: 8),
                  ],
                ),
                child: Row(
                  children: [
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: _kBlue2),
                    ),
                    const SizedBox(width: 12),
                    Text('Calcul de l\'itinéraire...',
                        style: GoogleFonts.poppins(
                            fontSize: 13, color: const Color(0xFF8A94A6))),
                  ],
                ),
              ),
            ),

          // ─── PANNEAU RÉCAPITULATIF EN BAS ──────────────────────────
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      offset: Offset(0, -2)),
                ],
              ),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Nom du garage
                      Text(g.nom,
                          style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF1A2340))),
                      const SizedBox(height: 4),
                      Text(g.adresse,
                          style: GoogleFonts.poppins(
                              fontSize: 13, color: const Color(0xFF8A94A6))),
                      const SizedBox(height: 12),

                      // Distance et durée
                      Row(
                        children: [
                          _buildInfoChip(
                            Icons.straighten,
                            LocationService.formatDistance(_routeDistance),
                          ),
                          const SizedBox(width: 16),
                          _buildInfoChip(
                            Icons.schedule,
                            _formatDuration(_routeDuration),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Sélecteur de mode de transport
                      Row(children: [
                        Expanded(
                            child: _buildModeButton(
                                Icons.directions_car, 'driving', 'Voiture')),
                        const SizedBox(width: 8),
                        Expanded(
                            child: _buildModeButton(
                                Icons.directions_walk, 'walking', 'À pied')),
                        const SizedBox(width: 8),
                        Expanded(
                            child: _buildModeButton(
                                Icons.pedal_bike, 'cycling', 'Vélo')),
                      ]),
                      const SizedBox(height: 16),

                      // Boutons de navigation
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _openExternalNav,
                          icon:
                              const Icon(Icons.navigation, color: Colors.white),
                          label: Text('Ouvrir dans Google Maps',
                              style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBlue1,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: _openWaze,
                          icon: const Icon(Icons.navigation_outlined),
                          label: Text('Ouvrir dans Waze',
                              style: GoogleFonts.poppins(fontSize: 14)),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: _kBlue1,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── WIDGETS UTILITAIRES ────────────────────────────────────────────────────

  Widget _buildInfoChip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _kBlue2.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: _kBlue2),
          const SizedBox(width: 8),
          Text(text,
              style: GoogleFonts.poppins(
                  fontSize: 14, fontWeight: FontWeight.w600, color: _kBlue2)),
        ],
      ),
    );
  }

  Widget _buildModeButton(IconData icon, String mode, String label) {
    final isSelected = _mode == mode;
    return ChoiceChip(
      avatar: Icon(icon,
          size: 18, color: isSelected ? _kBlue2 : const Color(0xFF8A94A6)),
      label: Text(label, style: GoogleFonts.poppins(fontSize: 12)),
      selected: isSelected,
      onSelected: (_) {
        setState(() => _mode = mode);
        _fetchRoute();
      },
      selectedColor: _kBlue2.withOpacity(0.15),
      backgroundColor: Colors.grey.shade100,
      labelStyle: TextStyle(
        color: isSelected ? _kBlue2 : const Color(0xFF8A94A6),
        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isSelected ? _kBlue2.withOpacity(0.4) : Colors.grey.shade300,
        ),
      ),
    );
  }

  String _formatDuration(int minutes) {
    if (minutes < 60) return '$minutes min';
    final h = minutes ~/ 60;
    final m = minutes % 60;
    return '${h}h${m.toString().padLeft(2, '0')}';
  }
}
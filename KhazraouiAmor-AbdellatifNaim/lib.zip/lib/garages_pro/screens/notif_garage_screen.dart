// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/garages_pro/models/appointment.dart';
import 'package:carhabti/garages_pro/models/review.dart';
import 'package:carhabti/garages_pro/services/garage_service.dart';
import 'package:carhabti/garages_pro/screens/garage_detail_screen.dart';
import 'package:carhabti/supabase_connexion.dart';

// ─── Palette partagée ────────────────────────────────────────────────────────
class _C {
  static const Color primary = Color(0xFF1A73E8);
  static const Color primaryLight = Color(0xFFE8F0FE);
  static const Color surface = Color(0xFFF8FAFF);
  static const Color card = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF1C1E2E);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textHint = Color(0xFFB0BAC9);
  static const Color border = Color(0xFFE5EAF2);
  static const Color star = Color(0xFFFFB300);
}

class MyAppointmentsScreen extends StatefulWidget {
  const MyAppointmentsScreen({super.key});

  @override
  State<MyAppointmentsScreen> createState() => _MyAppointmentsScreenState();
}

class _MyAppointmentsScreenState extends State<MyAppointmentsScreen>
    with SingleTickerProviderStateMixin {
  final GarageService _service = GarageService();
  late TabController _tabCtrl;
  List<Appointment> _appointments = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    _load();
    _subscribeRealtime();
  }

  @override
  void dispose() {
    _service.unsubscribeFromAppointments();
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final user = supabase.auth.currentUser;
    if (user != null) {
      final a = await _service.getUserAppointments(user.id);
      if (mounted) {
        setState(() {
          _appointments = a;
          _loading = false;
        });
      }
    } else {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _subscribeRealtime() {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    _service.subscribeToAppointmentChanges(user.id, (data) {
      debugPrint('🔄 Changement détecté, rechargement des rendez-vous...');
      _load();
    });
  }

  List<Appointment> _filterByStatus(AppointmentStatus status) {
    if (status == AppointmentStatus.enAttente) {
      return _appointments
          .where((a) =>
              a.statut == AppointmentStatus.enAttente ||
              a.statut == AppointmentStatus.confirme)
          .toList();
    }
    if (status == AppointmentStatus.termine) {
      return _appointments
          .where((a) => a.statut == AppointmentStatus.termine)
          .toList();
    }
    return _appointments
        .where((a) => a.statut == AppointmentStatus.annule)
        .toList();
  }

  Future<void> _cancelAppointment(Appointment a) async {
    final ok = await _service.cancelAppointment(a.id);
    if (!mounted) return;
    _showFeedbackSnackbar(
      ok ? 'Rendez-vous annulé avec succès' : 'Erreur lors de l\'annulation',
      ok ? const Color(0xFF34C759) : const Color(0xFFE74C3C),
      ok ? Icons.check_circle_rounded : Icons.error_rounded,
    );
    if (ok) _load();
  }

  void _showFeedbackSnackbar(String msg, Color bg, IconData icon) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 10),
          Text(msg, style: GoogleFonts.nunito(fontSize: 13)),
        ]),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        backgroundColor: bg,
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  // ─── Dialogue d'annulation ───────────────────────────────────────────────
  void _showCancelDialog(Appointment a) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFDEDED),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.event_busy_rounded,
                      color: Color(0xFFE74C3C), size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    'Annuler le rendez-vous ?',
                    style: GoogleFonts.nunito(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        color: _C.textPrimary),
                  ),
                ),
              ]),
              const SizedBox(height: 16),
              Text(
                'Cette action est irréversible. Êtes-vous sûr de vouloir annuler ?',
                style: GoogleFonts.nunito(
                    fontSize: 13, color: _C.textSecondary, height: 1.5),
              ),
              const SizedBox(height: 16),
              _MiniInfoCard(appointment: a),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: _C.border),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text('Garder',
                        style: GoogleFonts.nunito(
                            fontWeight: FontWeight.w700,
                            color: _C.textSecondary)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _cancelAppointment(a);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE74C3C),
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text('Annuler',
                        style: GoogleFonts.nunito(fontWeight: FontWeight.w800)),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Dialogue d'avis ─────────────────────────────────────────────────────
  void _openReviewDialog(Appointment a) {
    int selectedRating = 5;
    final commentController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF9E6),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.star_rounded,
                        color: _C.star, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Text(
                    'Laisser un avis',
                    style: GoogleFonts.nunito(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        color: _C.textPrimary),
                  ),
                ]),
                const SizedBox(height: 12),
                Text(
                  'Comment s\'est passé votre rendez-vous chez ${a.garageInfo?.nom ?? 'le garage'} ?',
                  style: GoogleFonts.nunito(
                      fontSize: 13, color: _C.textSecondary, height: 1.5),
                ),
                const SizedBox(height: 20),

                // Étoiles interactives
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (i) {
                    final filled = i < selectedRating;
                    return GestureDetector(
                      onTap: () {
                        HapticFeedback.selectionClick();
                        setDialogState(() => selectedRating = i + 1);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 120),
                        padding: const EdgeInsets.all(4),
                        child: Icon(
                          filled
                              ? Icons.star_rounded
                              : Icons.star_border_rounded,
                          color: filled ? _C.star : _C.textHint,
                          size: 38,
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 6),
                Center(
                  child: Text(
                    _ratingLabel(selectedRating),
                    style: GoogleFonts.nunito(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: _C.star),
                  ),
                ),
                const SizedBox(height: 16),

                // Zone de commentaire
                TextField(
                  controller: commentController,
                  maxLines: 3,
                  style:
                      GoogleFonts.nunito(fontSize: 13, color: _C.textPrimary),
                  decoration: InputDecoration(
                    hintText: 'Commentaire (optionnel)...',
                    hintStyle:
                        GoogleFonts.nunito(color: _C.textHint, fontSize: 13),
                    filled: true,
                    fillColor: _C.surface,
                    contentPadding: const EdgeInsets.all(14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide:
                          const BorderSide(color: _C.primary, width: 1.5),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                Row(children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _C.border),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text('Annuler',
                          style: GoogleFonts.nunito(
                              fontWeight: FontWeight.w700,
                              color: _C.textSecondary)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        final user = supabase.auth.currentUser;
                        if (user == null) return;
                        final ok = await _service.createReview(
                          Review(
                            id: '',
                            userId: user.id,
                            garageId: a.garageId,
                            rendezVousId: a.id,
                            note: selectedRating,
                            commentaire: commentController.text.trim().isEmpty
                                ? null
                                : commentController.text.trim(),
                            createdAt: DateTime.now(),
                          ),
                        );
                        if (ok && mounted) {
                          Navigator.pop(ctx);
                          _showFeedbackSnackbar(
                            'Avis publié avec succès !',
                            const Color(0xFF34C759),
                            Icons.star_rounded,
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _C.primary,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text('Envoyer',
                          style:
                              GoogleFonts.nunito(fontWeight: FontWeight.w800)),
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _ratingLabel(int r) {
    switch (r) {
      case 1:
        return 'Très décevant';
      case 2:
        return 'Décevant';
      case 3:
        return 'Correct';
      case 4:
        return 'Bien';
      case 5:
        return 'Excellent !';
      default:
        return '';
    }
  }

  // ─── BUILD PRINCIPAL ──────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.surface,
      appBar: AppBar(
        title: Text(
          'Mes rendez-vous',
          style: GoogleFonts.nunito(
              fontWeight: FontWeight.w900, fontSize: 18, color: _C.textPrimary),
        ),
        backgroundColor: _C.card,
        foregroundColor: _C.textPrimary,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(49),
          child: Column(
            children: [
              Container(height: 1, color: _C.border),
              TabBar(
                controller: _tabCtrl,
                labelStyle: GoogleFonts.nunito(
                    fontWeight: FontWeight.w800, fontSize: 13),
                unselectedLabelStyle: GoogleFonts.nunito(
                    fontWeight: FontWeight.w600, fontSize: 13),
                labelColor: _C.primary,
                unselectedLabelColor: _C.textSecondary,
                indicatorColor: _C.primary,
                indicatorWeight: 3,
                indicatorSize: TabBarIndicatorSize.label,
                tabs: const [
                  Tab(text: 'À venir'),
                  Tab(text: 'Passés'),
                  Tab(text: 'Annulés'),
                ],
              ),
            ],
          ),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _C.primary))
          : TabBarView(
              controller: _tabCtrl,
              children: [
                _buildTab(
                    _filterByStatus(AppointmentStatus.enAttente), 'à venir'),
                _buildTab(_filterByStatus(AppointmentStatus.termine), 'passés'),
                _buildTab(_filterByStatus(AppointmentStatus.annule), 'annulés'),
              ],
            ),
    );
  }

  Widget _buildTab(List<Appointment> list, String emptyLabel) {
    if (list.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: _C.primaryLight,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.event_busy_rounded,
                  size: 44, color: _C.primary),
            ),
            const SizedBox(height: 20),
            Text(
              'Aucun rendez-vous $emptyLabel',
              style: GoogleFonts.nunito(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: _C.textPrimary),
            ),
            const SizedBox(height: 6),
            Text(
              'Vos rendez-vous apparaîtront ici',
              style: GoogleFonts.nunito(fontSize: 13, color: _C.textSecondary),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      color: _C.primary,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        itemCount: list.length,
        itemBuilder: (_, i) => _AppointmentCard(
          appointment: list[i],
          onCancelTap: () => _showCancelDialog(list[i]),
          onReviewTap: () => _openReviewDialog(list[i]),
          onCardTap: () => _navigateToGarageDetail(
              list[i].garageId, list[i].immatriculation),
        ),
      ),
    );
  }

  void _navigateToGarageDetail(String garageId, String immatriculation) async {
    final garage = await _service.getGarageById(garageId);
    if (garage != null && mounted) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => GarageDetailScreen(
            garage: garage,
            immatriculation: immatriculation,
          ),
        ),
      );
    }
  }
}

// ─── Card de rendez-vous ─────────────────────────────────────────────────────
class _AppointmentCard extends StatelessWidget {
  final Appointment appointment;
  final VoidCallback onCancelTap;
  final VoidCallback onReviewTap;
  final VoidCallback onCardTap;

  const _AppointmentCard({
    required this.appointment,
    required this.onCancelTap,
    required this.onReviewTap,
    required this.onCardTap,
  });

  @override
  Widget build(BuildContext context) {
    final a = appointment;
    final garageName = a.garageInfo?.nom ?? 'Garage';
    final garagePhoto = a.garageInfo?.photoCouverture;
    final garageVille = a.garageInfo?.ville;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onCardTap,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Statut + date ──────────────────────────────────
                Row(children: [
                  _StatusBadge(status: a.statut),
                  const Spacer(),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.calendar_today_rounded,
                          size: 12, color: _C.textSecondary),
                      const SizedBox(width: 5),
                      Text(
                        a.dateFormatted,
                        style: GoogleFonts.nunito(
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                            color: _C.textPrimary),
                      ),
                    ]),
                  ),
                ]),
                const SizedBox(height: 14),

                // ── Garage info ────────────────────────────────────
                Row(children: [
                  _GarageAvatar(photo: garagePhoto),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          garageName,
                          style: GoogleFonts.nunito(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: _C.textPrimary),
                        ),
                        if (garageVille != null) ...[
                          const SizedBox(height: 2),
                          Row(children: [
                            const Icon(Icons.location_on_rounded,
                                size: 12, color: _C.textHint),
                            const SizedBox(width: 3),
                            Text(
                              garageVille,
                              style: GoogleFonts.nunito(
                                  fontSize: 12, color: _C.textSecondary),
                            ),
                          ]),
                        ],
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded,
                      color: _C.textHint, size: 20),
                ]),
                const SizedBox(height: 14),

                // ── Détails du RDV ────────────────────────────────
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            a.prestationLabel,
                            style: GoogleFonts.nunito(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: _C.textPrimary),
                          ),
                          const SizedBox(height: 6),
                          Row(children: [
                            _DetailPill(
                                icon: Icons.access_time_rounded,
                                label: a.heureFormatted),
                            const SizedBox(width: 8),
                            _DetailPill(
                                icon: Icons.directions_car_rounded,
                                label: a.immatriculation),
                          ]),
                        ],
                      ),
                    ),
                  ]),
                ),

                // ── Boutons d'action ──────────────────────────────
                if (a.canCancel || a.canReview) ...[
                  const SizedBox(height: 14),
                  if (a.canCancel)
                    _ActionButton(
                      label: 'Annuler le rendez-vous',
                      icon: Icons.event_busy_rounded,
                      color: const Color(0xFFE74C3C),
                      backgroundColor: const Color(0xFFFDEDED),
                      onTap: onCancelTap,
                    ),
                  if (a.canReview) ...[
                    if (a.canCancel) const SizedBox(height: 8),
                    _ActionButton(
                      label: 'Laisser un avis',
                      icon: Icons.star_rounded,
                      color: Colors.white,
                      backgroundColor: _C.primary,
                      onTap: onReviewTap,
                      filled: true,
                    ),
                  ],
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Sous-composants de la card ───────────────────────────────────────────────

class _StatusBadge extends StatelessWidget {
  final AppointmentStatus status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: status.backgroundColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: status.borderColor),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(status.icon, size: 12, color: status.color),
        const SizedBox(width: 5),
        Text(
          status.label,
          style: GoogleFonts.nunito(
              fontSize: 11,
              color: status.color,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.2),
        ),
      ]),
    );
  }
}

class _GarageAvatar extends StatelessWidget {
  final String? photo;
  const _GarageAvatar({this.photo});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: _C.primaryLight,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: photo != null
            ? Image.network(
                photo!,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                    Icons.car_repair_rounded,
                    color: _C.primary,
                    size: 24),
              )
            : const Icon(Icons.car_repair_rounded, color: _C.primary, size: 24),
      ),
    );
  }
}

class _DetailPill extends StatelessWidget {
  final IconData icon;
  final String label;
  const _DetailPill({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, size: 13, color: _C.textSecondary),
      const SizedBox(width: 4),
      Text(
        label,
        style: GoogleFonts.nunito(
            fontSize: 12, color: _C.textSecondary, fontWeight: FontWeight.w600),
      ),
    ]);
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final Color backgroundColor;
  final VoidCallback onTap;
  final bool filled;

  const _ActionButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.backgroundColor,
    required this.onTap,
    this.filled = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 44,
      child: Material(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            HapticFeedback.lightImpact();
            onTap();
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 8),
              Text(
                label,
                style: GoogleFonts.nunito(
                    color: color, fontSize: 13, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Mini card récap (dialogue d'annulation) ─────────────────────────────────
class _MiniInfoCard extends StatelessWidget {
  final Appointment appointment;
  const _MiniInfoCard({required this.appointment});

  @override
  Widget build(BuildContext context) {
    final a = appointment;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            a.garageInfo?.nom ?? 'Garage',
            style: GoogleFonts.nunito(
                fontWeight: FontWeight.w800,
                fontSize: 13,
                color: _C.textPrimary),
          ),
          const SizedBox(height: 6),
          Row(children: [
            const Icon(Icons.build_rounded, size: 12, color: _C.textHint),
            const SizedBox(width: 5),
            Text(
              '${a.prestationLabel} • ${a.heureFormatted}',
              style: GoogleFonts.nunito(fontSize: 12, color: _C.textSecondary),
            ),
          ]),
          const SizedBox(height: 3),
          Row(children: [
            const Icon(Icons.calendar_today_rounded,
                size: 12, color: _C.textHint),
            const SizedBox(width: 5),
            Text(
              a.dateFormatted,
              style: GoogleFonts.nunito(fontSize: 12, color: _C.textSecondary),
            ),
          ]),
        ],
      ),
    );
  }
}

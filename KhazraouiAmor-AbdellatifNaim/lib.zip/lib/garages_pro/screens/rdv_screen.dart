// ignore_for_file: deprecated_member_use, unused_field

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/garages_pro/screens/garage_list_screen.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:carhabti/garages_pro/models/garage.dart';
import 'package:carhabti/garages_pro/models/appointment.dart';
import 'package:carhabti/garages_pro/services/garage_service.dart';
import 'package:carhabti/supabase_connexion.dart';

// ─── Palette de design ──────────────────────────────────────────────────────
class _AppColors {
  static const Color primary = Color(0xFF1A73E8); // Bleu vif principal
  static const Color primaryLight = Color(0xFFE8F0FE); // Fond bleu très pâle
  static const Color primarySoft = Color(0xFF4A90E2); // Bleu doux interactif
  static const Color accent = Color(0xFF00BCD4); // Cyan frais
  static const Color success = Color(0xFF34C759); // Vert succès iOS
  static const Color successLight = Color(0xFFEAF8ED);
  static const Color surface = Color(0xFFF8FAFF); // Fond général
  static const Color card = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF1C1E2E);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textHint = Color(0xFFB0BAC9);
  static const Color border = Color(0xFFE5EAF2);
  static const Color borderFocus = Color(0xFF1A73E8);
  static const Color taken = Color(0xFFF1F5F9);
  static const Color takenText = Color(0xFFCBD5E1);
  static const Color warning = Color(0xFFFF9500);
  static const Color warningLight = Color(0xFFFFF4E5);
}

class BookingScreen extends StatefulWidget {
  final Garage garage;
  final String immatriculation;
  const BookingScreen(
      {super.key, required this.garage, required this.immatriculation});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen>
    with TickerProviderStateMixin {
  final GarageService _service = GarageService();

  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  String? _selectedVehicle;
  String? _selectedPrestation;
  String _autrePrestation = '';
  String? _selectedHeure;
  String _commentaire = '';
  bool _submitting = false;
  bool _success = false;

  List<String> _vehicles = [];
  List<Appointment> _takenSlots = [];
  bool _loadingSlots = false;
  bool _loadingVehicles = true;

  // Animations
  late AnimationController _successController;
  late AnimationController _fadeController;
  late Animation<double> _successScale;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  final List<String> _prestations = [
    'Vidange moteur',
    'Révision complète',
    'Contrôle freins',
    'Changement pneus',
    'Diagnostic électronique',
    'Remplacement batterie',
    'Contrôle courroie',
    'Climatisation',
    'Autre',
  ];

  final List<String> _creneaux = [
    '08:00',
    '09:00',
    '10:00',
    '11:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
  ];

  // Icônes associées aux prestations
  final Map<String, IconData> _prestationIcons = {
    'Vidange moteur': Icons.oil_barrel_rounded,
    'Révision complète': Icons.settings_rounded,
    'Contrôle freins': Icons.brightness_1_rounded,
    'Changement pneus': Icons.tire_repair_rounded,
    'Diagnostic électronique': Icons.electrical_services_rounded,
    'Remplacement batterie': Icons.battery_charging_full_rounded,
    'Contrôle courroie': Icons.rotate_right_rounded,
    'Climatisation': Icons.ac_unit_rounded,
    'Autre': Icons.build_circle_rounded,
  };

  @override
  void initState() {
    super.initState();
    _selectedDay = DateTime.now();

    _successController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _successScale =
        CurvedAnimation(parent: _successController, curve: Curves.elasticOut);

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.05),
      end: Offset.zero,
    ).animate(_fadeAnim);

    _fadeController.forward();
    _loadVehicles();
    _fetchSlots();
  }

  @override
  void dispose() {
    _successController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  /// Même source que [ClientDashboard._fetchUserVehicles] : vue `user_vehicles`.
  Future<void> _loadVehicles() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loadingVehicles = false);
      return;
    }
    if (mounted) setState(() => _loadingVehicles = true);
    try {
      final response = await supabase
          .from('user_vehicles')
          .select('immatriculation')
          .eq('user_id', user.id);

      final raw = (response as List)
          .map((e) => e['immatriculation'])
          .where((v) => v != null && v.toString().trim().isNotEmpty)
          .map((v) => v.toString().trim())
          .toList();

      final list = <String>[];
      for (final s in raw) {
        if (!list.contains(s)) list.add(s);
      }

      const storage = FlutterSecureStorage();
      final stored = await storage.read(key: 'last_active_immatriculation');
      String? targetImmat;
      if (stored != null && stored.isNotEmpty && list.contains(stored)) {
        targetImmat = stored;
      }
      final fromRoute = widget.immatriculation.trim();
      if (targetImmat == null &&
          fromRoute.isNotEmpty &&
          list.contains(fromRoute)) {
        targetImmat = fromRoute;
      }

      if (mounted) {
        final chosen = list.isNotEmpty ? (targetImmat ?? list.first) : null;
        setState(() {
          _vehicles = list;
          _loadingVehicles = false;
          _selectedVehicle = chosen;
        });
        if (chosen != null && chosen.isNotEmpty) {
          await const FlutterSecureStorage().write(
            key: 'last_active_immatriculation',
            value: chosen,
          );
        }
      }
    } catch (e) {
      debugPrint('vehicles err $e');
      if (mounted) {
        setState(() {
          _vehicles = [];
          _selectedVehicle = null;
          _loadingVehicles = false;
        });
      }
    }
  }

  Future<void> _onVehicleSelected(String plate) async {
    setState(() => _selectedVehicle = plate);
    await const FlutterSecureStorage().write(
      key: 'last_active_immatriculation',
      value: plate,
    );
  }

  Future<void> _fetchSlots() async {
    if (_selectedDay == null) return;
    setState(() => _loadingSlots = true);
    final slots =
        await _service.getAppointmentsByGarage(widget.garage.id, _selectedDay!);
    if (mounted) {
      setState(() {
        _takenSlots = slots;
        _loadingSlots = false;
      });
    }
  }

  bool _isTaken(String h) {
    final parts = h.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1]);
    return _takenSlots.any((a) =>
        a.heureRendezVous.hour == hour && a.heureRendezVous.minute == minute);
  }
  /// Retourne true si le créneau [h] est déjà passé pour le jour sélectionné.
/// Pour un jour futur, retourne toujours false.
bool _isPast(String h) {
  if (_selectedDay == null) return false;
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final selected = DateTime(
      _selectedDay!.year, _selectedDay!.month, _selectedDay!.day);
  if (selected.isAfter(today)) return false;

  final parts = h.split(':');
  final slotHour = int.parse(parts[0]);
  final slotMinute = int.parse(parts[1]);

  // Le créneau est passé si son heure de début est ≤ à l'heure courante.
  return slotHour < now.hour ||
      (slotHour == now.hour && slotMinute <= now.minute);
}

  bool get _isFormValid =>
      _selectedVehicle != null &&
      _selectedPrestation != null &&
      _selectedHeure != null &&
      _selectedDay != null &&
      (_selectedPrestation != 'Autre' || _autrePrestation.trim().isNotEmpty);

  Future<void> _submit() async {
    if (!_isFormValid) {
      HapticFeedback.mediumImpact();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(children: [
            const Icon(Icons.info_outline_rounded,
                color: Colors.white, size: 18),
            const SizedBox(width: 10),
            Text('Veuillez remplir tous les champs obligatoires',
                style: GoogleFonts.nunito(fontSize: 13)),
          ]),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          backgroundColor: const Color(0xFF1C1E2E),
          margin: const EdgeInsets.all(16),
        ),
      );
      return;
    }

    final user = supabase.auth.currentUser;
    if (user == null) return;

    setState(() => _submitting = true);
    HapticFeedback.lightImpact();

    final hParts = _selectedHeure!.split(':');
    final ok = await _service.createAppointment(Appointment(
      id: '',
      userId: user.id,
      garageId: widget.garage.id,
      immatriculation: _selectedVehicle!,
      typePrestation: _selectedPrestation!,
      prestationAutre:
          _selectedPrestation == 'Autre' ? _autrePrestation.trim() : null,
      dateRendezVous: _selectedDay!,
      heureRendezVous:
          TimeOfDay(hour: int.parse(hParts[0]), minute: int.parse(hParts[1])),
      commentaire: _commentaire.trim().isEmpty ? null : _commentaire.trim(),
      statut: AppointmentStatus.enAttente,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ));

    if (mounted) {
      setState(() {
        _submitting = false;
        if (ok) _success = true;
      });
      if (ok) {
        HapticFeedback.heavyImpact();
        _successController.forward();
      } else {
        HapticFeedback.vibrate();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(children: [
              const Icon(Icons.error_outline_rounded,
                  color: Colors.white, size: 18),
              const SizedBox(width: 10),
              Text('Une erreur est survenue. Réessayez.',
                  style: GoogleFonts.nunito(fontSize: 13)),
            ]),
            behavior: SnackBarBehavior.floating,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            backgroundColor: const Color(0xFFE74C3C),
            margin: const EdgeInsets.all(16),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_success) return _buildSuccess();

    final g = widget.garage;

    return Scaffold(
      backgroundColor: _AppColors.surface,
      appBar: AppBar(
        title: Text(
          'Prendre rendez-vous',
          style: GoogleFonts.nunito(
              fontWeight: FontWeight.w800,
              fontSize: 18,
              color: _AppColors.textPrimary),
        ),
        backgroundColor: _AppColors.card,
        foregroundColor: _AppColors.textPrimary,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _AppColors.border),
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SlideTransition(
          position: _slideAnim,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── En-tête garage ───────────────────────────────────
                _GarageHeaderCard(garage: g),
                const SizedBox(height: 24),

                // ── Véhicule (liste alignée sur le tableau de bord client) ──
                _SectionLabel(label: 'Véhicule', required: true),
                const SizedBox(height: 12),
                _loadingVehicles
                    ? const Padding(
                        padding: EdgeInsets.symmetric(vertical: 24),
                        child: Center(
                          child: SizedBox(
                            width: 28,
                            height: 28,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: _AppColors.primary,
                            ),
                          ),
                        ),
                      )
                    : _vehicles.isEmpty
                        ? _WarningBanner(
                            message:
                                'Aucun véhicule enregistré. Ajoutez-en un depuis le tableau de bord ou votre profil.')
                        : Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _vehicles
                                .map((v) => _VehicleChip(
                                      plate: v,
                                      selected: _selectedVehicle == v,
                                      onTap: () => _onVehicleSelected(v),
                                    ))
                                .toList(),
                          ),
                const SizedBox(height: 24),

                // ── Prestation ───────────────────────────────────────
                _SectionLabel(label: 'Type de prestation', required: true),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _prestations
                      .map((p) => _PrestationChip(
                            label: p,
                            icon: _prestationIcons[p] ?? Icons.build_rounded,
                            selected: _selectedPrestation == p,
                            onTap: () =>
                                setState(() => _selectedPrestation = p),
                          ))
                      .toList(),
                ),
                if (_selectedPrestation == 'Autre') ...[
                  const SizedBox(height: 12),
                  _StyledTextField(
                    hint: 'Décrivez la prestation…',
                    onChanged: (v) => setState(() => _autrePrestation = v),
                  ),
                ],
                const SizedBox(height: 24),

                // ── Calendrier ───────────────────────────────────────
                _SectionLabel(label: 'Date', required: true),
                const SizedBox(height: 12),
                _CalendarCard(
                  focusedDay: _focusedDay,
                  selectedDay: _selectedDay,
                  onDaySelected: (s, f) {
                    setState(() {
                      _selectedDay = s;
                      _focusedDay = f;
                      _selectedHeure = null;
                    });
                    _fetchSlots();
                  },
                ),
                const SizedBox(height: 24),

                // ── Créneaux ─────────────────────────────────────────
                Row(
                  children: [
                    _SectionLabel(label: 'Créneau horaire', required: true),
                    const Spacer(),
                    if (_loadingSlots)
                      const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _AppColors.primary,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                _TimeSlotGrid(
                  creneaux: _creneaux,
                  selectedHeure: _selectedHeure,
                  isTaken: _isTaken,
                  isPast: _isPast,
                  onSelect: (h) => setState(() => _selectedHeure = h),
                ),
                const SizedBox(height: 24),

                // ── Commentaire ──────────────────────────────────────
                _SectionLabel(label: 'Commentaire', required: false),
                const SizedBox(height: 12),
                _StyledTextField(
                  hint: 'Décrivez le problème ou la demande…',
                  maxLines: 3,
                  onChanged: (v) => _commentaire = v,
                ),
                const SizedBox(height: 24),

                // ── Récapitulatif ────────────────────────────────────
                if (_isFormValid) ...[
                  _RecapCard(
                    garageName: widget.garage.nom,
                    vehicle: _selectedVehicle ?? '',
                    prestation: _selectedPrestation == 'Autre'
                        ? _autrePrestation
                        : _selectedPrestation ?? '',
                    date: _selectedDay != null
                        ? '${_selectedDay!.day.toString().padLeft(2, '0')}/'
                            '${_selectedDay!.month.toString().padLeft(2, '0')}/'
                            '${_selectedDay!.year}'
                        : '',
                    heure: _selectedHeure ?? '',
                  ),
                  const SizedBox(height: 24),
                ],

                // ── Bouton confirmer ─────────────────────────────────
                _ConfirmButton(
                  enabled: _isFormValid,
                  submitting: _submitting,
                  onPressed: _submit,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── Écran de succès ──────────────────────────────────────────────────────
  Widget _buildSuccess() {
    return Scaffold(
      backgroundColor: _AppColors.surface,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ScaleTransition(
                  scale: _successScale,
                  child: Container(
                    width: 110,
                    height: 110,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF34C759), Color(0xFF30D158)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF34C759).withOpacity(0.35),
                          blurRadius: 24,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: const Icon(Icons.check_rounded,
                        color: Colors.white, size: 56),
                  ),
                ),
                const SizedBox(height: 28),
                Text(
                  'Rendez-vous envoyé !',
                  style: GoogleFonts.nunito(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: _AppColors.textPrimary),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                Text(
                  'Votre demande a été transmise à ${widget.garage.nom}. '
                  'Vous recevrez une confirmation dès validation du créneau.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.nunito(
                      fontSize: 14,
                      height: 1.6,
                      color: _AppColors.textSecondary),
                ),
                const SizedBox(height: 32),
                _RecapCard(
                  garageName: widget.garage.nom,
                  vehicle: _selectedVehicle ?? '',
                  prestation: _selectedPrestation == 'Autre'
                      ? _autrePrestation
                      : _selectedPrestation ?? '',
                  date: _selectedDay != null
                      ? '${_selectedDay!.day.toString().padLeft(2, '0')}/'
                          '${_selectedDay!.month.toString().padLeft(2, '0')}/'
                          '${_selectedDay!.year}'
                      : '',
                  heure: _selectedHeure ?? '',
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (_) => const Scaffold(
                            body: GarageListScreen(
                              immatriculation: '',
                            ),
                          ),
                        ),
                        (route) => false,
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _AppColors.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                      elevation: 0,
                    ),
                    child: Text(
                      'Retour à l\'accueil',
                      style: GoogleFonts.nunito(
                          fontWeight: FontWeight.w800, fontSize: 15),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Composants UI réutilisables ─────────────────────────────────────────────

class _GarageHeaderCard extends StatelessWidget {
  final Garage garage;
  const _GarageHeaderCard({required this.garage});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _AppColors.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _AppColors.border),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1A73E8).withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: garage.photoCouverture != null
              ? Image.network(
                  garage.photoCouverture!,
                  width: 58,
                  height: 58,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _GarageIconPlaceholder(),
                )
              : _GarageIconPlaceholder(),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                garage.nom,
                style: GoogleFonts.nunito(
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                    color: _AppColors.textPrimary),
              ),
              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.location_on_rounded,
                    size: 13, color: _AppColors.textHint),
                const SizedBox(width: 3),
                Text(
                  garage.ville,
                  style: GoogleFonts.nunito(
                      fontSize: 12, color: _AppColors.textSecondary),
                ),
                const SizedBox(width: 10),
                const Icon(Icons.star_rounded,
                    size: 13, color: Color(0xFFFFB300)),
                const SizedBox(width: 2),
                Text(
                  garage.noteMoyenne.toStringAsFixed(1),
                  style: GoogleFonts.nunito(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: _AppColors.textPrimary),
                ),
              ]),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: _AppColors.primaryLight,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            'Disponible',
            style: GoogleFonts.nunito(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: _AppColors.primary),
          ),
        ),
      ]),
    );
  }
}

class _GarageIconPlaceholder extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        color: _AppColors.primaryLight,
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Icon(Icons.car_repair_rounded,
          color: _AppColors.primary, size: 28),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  final bool required;
  const _SectionLabel({required this.label, required this.required});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          label,
          style: GoogleFonts.nunito(
              fontWeight: FontWeight.w800,
              fontSize: 15,
              color: _AppColors.textPrimary),
        ),
        if (required) ...[
          const SizedBox(width: 4),
          const Text('*',
              style: TextStyle(
                  color: Color(0xFFE74C3C),
                  fontSize: 15,
                  fontWeight: FontWeight.w700)),
        ],
      ],
    );
  }
}

class _VehicleChip extends StatelessWidget {
  final String plate;
  final bool selected;
  final VoidCallback onTap;
  const _VehicleChip(
      {required this.plate, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? _AppColors.primary : _AppColors.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _AppColors.primary : _AppColors.border,
            width: selected ? 2 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: _AppColors.primary.withOpacity(0.2),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  )
                ]
              : [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.directions_car_rounded,
              size: 14,
              color: selected ? Colors.white : _AppColors.textSecondary,
            ),
            const SizedBox(width: 6),
            Text(
              plate,
              style: GoogleFonts.nunito(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: selected ? Colors.white : _AppColors.textPrimary),
            ),
          ],
        ),
      ),
    );
  }
}

class _PrestationChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _PrestationChip({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? _AppColors.primaryLight : _AppColors.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? _AppColors.primary : _AppColors.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon,
                size: 14,
                color:
                    selected ? _AppColors.primary : _AppColors.textSecondary),
            const SizedBox(width: 6),
            Text(
              label,
              style: GoogleFonts.nunito(
                  fontSize: 12,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  color:
                      selected ? _AppColors.primary : _AppColors.textPrimary),
            ),
          ],
        ),
      ),
    );
  }
}

class _CalendarCard extends StatelessWidget {
  final DateTime focusedDay;
  final DateTime? selectedDay;
  final Function(DateTime, DateTime) onDaySelected;

  const _CalendarCard({
    required this.focusedDay,
    required this.selectedDay,
    required this.onDaySelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _AppColors.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _AppColors.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: TableCalendar(
          firstDay: DateTime.now(),
          lastDay: DateTime.now().add(const Duration(days: 90)),
          focusedDay: focusedDay,
          selectedDayPredicate: (d) => isSameDay(selectedDay, d),
          onDaySelected: onDaySelected,
          enabledDayPredicate: (d) =>
              d.weekday != DateTime.sunday &&
              !d.isBefore(DateTime.now().subtract(const Duration(days: 1))),
          calendarStyle: CalendarStyle(
            selectedDecoration: const BoxDecoration(
              color: _AppColors.primary,
              shape: BoxShape.circle,
            ),
            todayDecoration: BoxDecoration(
              color: _AppColors.primaryLight,
              shape: BoxShape.circle,
              border: Border.all(color: _AppColors.primary, width: 1.5),
            ),
            todayTextStyle: GoogleFonts.nunito(
                color: _AppColors.primary, fontWeight: FontWeight.w700),
            selectedTextStyle: GoogleFonts.nunito(
                color: Colors.white, fontWeight: FontWeight.w800),
            defaultTextStyle: GoogleFonts.nunito(color: _AppColors.textPrimary),
            weekendTextStyle: GoogleFonts.nunito(color: _AppColors.textHint),
            disabledTextStyle: GoogleFonts.nunito(color: _AppColors.textHint),
            outsideTextStyle: GoogleFonts.nunito(color: _AppColors.textHint),
            cellMargin: const EdgeInsets.all(5),
          ),
          daysOfWeekStyle: DaysOfWeekStyle(
            weekdayStyle: GoogleFonts.nunito(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: _AppColors.textSecondary),
            weekendStyle: GoogleFonts.nunito(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: _AppColors.textHint),
          ),
          headerStyle: HeaderStyle(
            formatButtonVisible: false,
            titleCentered: true,
            titleTextStyle: GoogleFonts.nunito(
                fontWeight: FontWeight.w800,
                fontSize: 15,
                color: _AppColors.textPrimary),
            leftChevronIcon: const Icon(Icons.chevron_left_rounded,
                color: _AppColors.primary),
            rightChevronIcon: const Icon(Icons.chevron_right_rounded,
                color: _AppColors.primary),
          ),
        ),
      ),
    );
  }
}

class _TimeSlotGrid extends StatelessWidget {
  final List<String> creneaux;
  final String? selectedHeure;
  final bool Function(String) isTaken;
  final bool Function(String) isPast;
  final void Function(String) onSelect;

  const _TimeSlotGrid({
    required this.creneaux,
    required this.selectedHeure,
    required this.isTaken,
    required this.isPast,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 4,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      childAspectRatio: 2.2,
      children: creneaux.map((h) {
        final taken = isTaken(h);
        final past = isPast(h);
        final disabled = taken || past;
        final selected = selectedHeure == h;
        return GestureDetector(
          onTap: disabled
              ? null
              : () {
                  HapticFeedback.selectionClick();
                  onSelect(h);
                },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
            decoration: BoxDecoration(
              color: disabled
                  ? _AppColors.taken
                  : selected
                      ? _AppColors.primary
                      : _AppColors.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: disabled
                    ? _AppColors.border
                    : selected
                        ? _AppColors.primary
                        : _AppColors.border,
                width: selected ? 2 : 1,
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: _AppColors.primary.withOpacity(0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ]
                  : [],
            ),
            child: Center(
              child: Text(
                h,
                style: GoogleFonts.nunito(
                  fontSize: 12,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  color: taken
                      ? _AppColors.takenText
                      : selected
                          ? Colors.white
                          : _AppColors.textPrimary,
                  decoration: disabled ? TextDecoration.lineThrough : null,
                  decorationColor: _AppColors.takenText,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _RecapCard extends StatelessWidget {
  final String garageName;
  final String vehicle;
  final String prestation;
  final String date;
  final String heure;

  const _RecapCard({
    required this.garageName,
    required this.vehicle,
    required this.prestation,
    required this.date,
    required this.heure,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _AppColors.primaryLight,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _AppColors.primary.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.receipt_long_rounded,
                color: _AppColors.primary, size: 16),
            const SizedBox(width: 6),
            Text(
              'Récapitulatif',
              style: GoogleFonts.nunito(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: _AppColors.primary),
            ),
          ]),
          const SizedBox(height: 14),
          _RecapRow(
              icon: Icons.car_repair_rounded,
              label: 'Garage',
              value: garageName),
          _RecapRow(
              icon: Icons.directions_car_rounded,
              label: 'Véhicule',
              value: vehicle),
          _RecapRow(
              icon: Icons.build_rounded,
              label: 'Prestation',
              value: prestation),
          if (date.isNotEmpty)
            _RecapRow(
                icon: Icons.calendar_today_rounded, label: 'Date', value: date),
          if (heure.isNotEmpty)
            _RecapRow(
                icon: Icons.access_time_rounded, label: 'Heure', value: heure),
        ],
      ),
    );
  }
}

class _RecapRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _RecapRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        Icon(icon, size: 14, color: _AppColors.primary.withOpacity(0.7)),
        const SizedBox(width: 8),
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: GoogleFonts.nunito(
                fontSize: 12, color: _AppColors.textSecondary),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: GoogleFonts.nunito(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: _AppColors.textPrimary),
          ),
        ),
      ]),
    );
  }
}

class _ConfirmButton extends StatelessWidget {
  final bool enabled;
  final bool submitting;
  final VoidCallback onPressed;

  const _ConfirmButton({
    required this.enabled,
    required this.submitting,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          gradient: enabled
              ? const LinearGradient(
                  colors: [Color(0xFF1A73E8), Color(0xFF4A90E2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: enabled ? null : _AppColors.border,
          borderRadius: BorderRadius.circular(16),
          boxShadow: enabled
              ? [
                  BoxShadow(
                    color: _AppColors.primary.withOpacity(0.3),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: ElevatedButton(
          onPressed: enabled && !submitting ? onPressed : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            foregroundColor: Colors.white,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            padding: EdgeInsets.zero,
          ),
          child: submitting
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                      strokeWidth: 2.5, color: Colors.white),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.check_circle_rounded,
                      size: 20,
                      color: enabled ? Colors.white : _AppColors.textHint,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Confirmer le rendez-vous',
                      style: GoogleFonts.nunito(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: enabled ? Colors.white : _AppColors.textHint,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _StyledTextField extends StatelessWidget {
  final String hint;
  final int maxLines;
  final ValueChanged<String>? onChanged;

  const _StyledTextField({
    required this.hint,
    this.maxLines = 1,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      maxLines: maxLines,
      onChanged: onChanged,
      style: GoogleFonts.nunito(fontSize: 14, color: _AppColors.textPrimary),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: GoogleFonts.nunito(color: _AppColors.textHint, fontSize: 13),
        filled: true,
        fillColor: _AppColors.card,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide:
              const BorderSide(color: _AppColors.borderFocus, width: 1.5),
        ),
      ),
    );
  }
}

class _WarningBanner extends StatelessWidget {
  final String message;
  const _WarningBanner({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _AppColors.warningLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _AppColors.warning.withOpacity(0.3)),
      ),
      child: Row(children: [
        Icon(Icons.info_outline_rounded, color: _AppColors.warning, size: 18),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            message,
            style: GoogleFonts.nunito(
                fontSize: 13, color: const Color(0xFF92400E)),
          ),
        ),
      ]),
    );
  }
}

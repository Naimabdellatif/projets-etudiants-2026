class Review {
  final String id;
  final String userId;
  final String garageId;
  final String? rendezVousId;
  final int note;
  final String? commentaire;
  final DateTime createdAt;

  /// Nom de l'utilisateur (alimenté optionnellement par une jointure).
  final String? userName;

  Review({
    required this.id,
    required this.userId,
    required this.garageId,
    this.rendezVousId,
    required this.note,
    this.commentaire,
    required this.createdAt,
    this.userName,
  });

  factory Review.fromMap(Map<String, dynamic> map) {
    // Extraire le nom d'utilisateur si jointure présente
    String? uName;
    if (map['users'] != null && map['users'] is Map<String, dynamic>) {
      final userData = map['users'] as Map<String, dynamic>;
      uName = userData['full_name'] ??
          userData['nom'] ??
          userData['email']?.split('@').first;
    }

    return Review(
      id: map['id'] ?? '',
      userId: map['user_id'] ?? '',
      garageId: map['garage_id'] ?? '',
      rendezVousId: map['rendez_vous_id'],
      note: map['note'] ?? 1,
      commentaire: map['commentaire'],
      createdAt: DateTime.tryParse(map['created_at'] ?? '') ?? DateTime.now(),
      userName: uName,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'garage_id': garageId,
      'rendez_vous_id': rendezVousId,
      'note': note,
      'commentaire': commentaire,
    };
  }

  /// Date formatée pour l'affichage.
  String get dateFormatted {
    const months = [
      '',
      'janv.',
      'févr.',
      'mars',
      'avr.',
      'mai',
      'juin',
      'juil.',
      'août',
      'sept.',
      'oct.',
      'nov.',
      'déc.'
    ];
    return '${createdAt.day} ${months[createdAt.month]} ${createdAt.year}';
  }

  /// Nom affichable de l'auteur.
  String get displayName => userName ?? 'Utilisateur';
}

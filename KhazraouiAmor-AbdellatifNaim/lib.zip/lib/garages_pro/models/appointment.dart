import 'package:flutter/material.dart';

enum AppointmentStatus {
  enAttente,
  confirme,
  annule,
  termine,
}

extension AppointmentStatusExtension on AppointmentStatus {
  String get value {
    switch (this) {
      case AppointmentStatus.enAttente:
        return 'en_attente';
      case AppointmentStatus.confirme:
        return 'confirme';
      case AppointmentStatus.annule:
        return 'annule';
      case AppointmentStatus.termine:
        return 'termine';
    }
  }

  String get label {
    switch (this) {
      case AppointmentStatus.enAttente:
        return 'En attente';
      case AppointmentStatus.confirme:
        return 'Confirmé';
      case AppointmentStatus.annule:
        return 'Annulé';
      case AppointmentStatus.termine:
        return 'Terminé';
    }
  }

  /// Couleur principale du statut (texte / icône).
  Color get color {
    switch (this) {
      case AppointmentStatus.enAttente:
        return const Color(0xFFE67E22); // Orange chaleureux
      case AppointmentStatus.confirme:
        return const Color(0xFF27AE60); // Vert confiant
      case AppointmentStatus.annule:
        return const Color(0xFFE74C3C); // Rouge doux
      case AppointmentStatus.termine:
        return const Color(0xFF7F8C8D); // Gris sobre
    }
  }

  /// Fond pastelle associé au statut.
  Color get backgroundColor {
    switch (this) {
      case AppointmentStatus.enAttente:
        return const Color(0xFFFFF3E0);
      case AppointmentStatus.confirme:
        return const Color(0xFFE8F8EF);
      case AppointmentStatus.annule:
        return const Color(0xFFFDEDED);
      case AppointmentStatus.termine:
        return const Color(0xFFF2F3F4);
    }
  }

  /// Couleur de bordure associée au statut.
  Color get borderColor {
    switch (this) {
      case AppointmentStatus.enAttente:
        return const Color(0xFFFFCC80);
      case AppointmentStatus.confirme:
        return const Color(0xFF81C784);
      case AppointmentStatus.annule:
        return const Color(0xFFEF9A9A);
      case AppointmentStatus.termine:
        return const Color(0xFFB0BEC5);
    }
  }

  IconData get icon {
    switch (this) {
      case AppointmentStatus.enAttente:
        return Icons.hourglass_top_rounded;
      case AppointmentStatus.confirme:
        return Icons.check_circle_rounded;
      case AppointmentStatus.annule:
        return Icons.cancel_rounded;
      case AppointmentStatus.termine:
        return Icons.task_alt_rounded;
    }
  }

  static AppointmentStatus fromString(String? status) {
    switch (status) {
      case 'confirme':
        return AppointmentStatus.confirme;
      case 'annule':
        return AppointmentStatus.annule;
      case 'termine':
        return AppointmentStatus.termine;
      default:
        return AppointmentStatus.enAttente;
    }
  }
}

/// Informations sommaires du garage jointes au rendez-vous (depuis Supabase join).
class GarageInfo {
  final String nom;
  final String? photoCouverture;
  final String? ville;
  final String? telephone;

  GarageInfo({
    required this.nom,
    this.photoCouverture,
    this.ville,
    this.telephone,
  });

  factory GarageInfo.fromMap(Map<String, dynamic> map) {
    return GarageInfo(
      nom: map['nom'] ?? 'Garage inconnu',
      photoCouverture: map['photo_couverture'],
      ville: map['ville'],
      telephone: map['telephone'],
    );
  }
}

class Appointment {
  final String id;
  final String userId;
  final String garageId;
  final String immatriculation;
  final String typePrestation;
  final String? prestationAutre;
  final DateTime dateRendezVous;
  final TimeOfDay heureRendezVous;
  final String? commentaire;
  final AppointmentStatus statut;
  final DateTime createdAt;
  final DateTime updatedAt;

  /// Informations du garage jointes (optionnel, alimenté par la requête Supabase).
  GarageInfo? garageInfo;

  Appointment({
    required this.id,
    required this.userId,
    required this.garageId,
    required this.immatriculation,
    required this.typePrestation,
    this.prestationAutre,
    required this.dateRendezVous,
    required this.heureRendezVous,
    this.commentaire,
    required this.statut,
    required this.createdAt,
    required this.updatedAt,
    this.garageInfo,
  });

  factory Appointment.fromMap(Map<String, dynamic> map) {
    final heureStr = map['heure_rendez_vous']?.toString() ?? '08:00:00';
    final parts = heureStr.split(':');
    final hour = int.tryParse(parts[0]) ?? 8;
    final minute = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;

    GarageInfo? gInfo;
    if (map['garages'] != null && map['garages'] is Map<String, dynamic>) {
      gInfo = GarageInfo.fromMap(map['garages'] as Map<String, dynamic>);
    }

    return Appointment(
      id: map['id'] ?? '',
      userId: map['user_id'] ?? '',
      garageId: map['garage_id'] ?? '',
      immatriculation: map['immatriculation'] ?? '',
      typePrestation: map['type_prestation'] ?? '',
      prestationAutre: map['prestation_autre'],
      dateRendezVous:
          DateTime.tryParse(map['date_rendez_vous']?.toString() ?? '') ??
              DateTime.now(),
      heureRendezVous: TimeOfDay(hour: hour, minute: minute),
      commentaire: map['commentaire'],
      statut: AppointmentStatusExtension.fromString(map['statut']),
      createdAt: DateTime.tryParse(map['created_at'] ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(map['updated_at'] ?? '') ?? DateTime.now(),
      garageInfo: gInfo,
    );
  }

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'user_id': userId,
      'garage_id': garageId,
      'immatriculation': immatriculation,
      'type_prestation': typePrestation,
      'prestation_autre': prestationAutre,
      'date_rendez_vous': dateRendezVous.toIso8601String().split('T')[0],
      'heure_rendez_vous':
          '${heureRendezVous.hour.toString().padLeft(2, '0')}:${heureRendezVous.minute.toString().padLeft(2, '0')}:00',
      'commentaire': commentaire,
      'statut': statut.value,
    };
    // Ne pas envoyer d'id vide : la colonne est UUID et DEFAULT gen_random_uuid().
    if (id.isNotEmpty) {
      map['id'] = id;
    }
    return map;
  }

  /// Heure formatée pour l'affichage (ex: "09:00").
  String get heureFormatted =>
      '${heureRendezVous.hour.toString().padLeft(2, '0')}:${heureRendezVous.minute.toString().padLeft(2, '0')}';

  /// Date formatée pour l'affichage (ex: "15 mars 2025").
  String get dateFormatted {
    const months = [
      '',
      'janvier',
      'février',
      'mars',
      'avril',
      'mai',
      'juin',
      'juillet',
      'août',
      'septembre',
      'octobre',
      'novembre',
      'décembre',
    ];
    return '${dateRendezVous.day} ${months[dateRendezVous.month]} ${dateRendezVous.year}';
  }

  /// Date courte formatée (ex: "15/03/2025").
  String get dateShort =>
      '${dateRendezVous.day.toString().padLeft(2, '0')}/'
      '${dateRendezVous.month.toString().padLeft(2, '0')}/'
      '${dateRendezVous.year}';

  /// Indique si le rendez-vous est à venir (en attente ou confirmé).
  bool get isUpcoming =>
      statut == AppointmentStatus.enAttente ||
      statut == AppointmentStatus.confirme;

  /// Indique si le rendez-vous peut être annulé.
  bool get canCancel =>
      statut == AppointmentStatus.enAttente ||
      statut == AppointmentStatus.confirme;

  /// Indique si l'utilisateur peut laisser un avis.
  bool get canReview => statut == AppointmentStatus.termine;

  /// Libellé de prestation affiché (gère le cas "Autre").
  String get prestationLabel =>
      typePrestation == 'Autre' && (prestationAutre?.isNotEmpty ?? false)
          ? prestationAutre!
          : typePrestation;
}
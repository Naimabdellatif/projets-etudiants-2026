import 'package:latlong2/latlong.dart';

class Garage {
  final String id;
  final String nom;
  final String adresse;
  final String ville;
  final String? codePostal;
  final String? telephone;
  final String? email;
  final double latitude;
  final double longitude;
  final bool estVerifie;
  final double noteMoyenne;
  final int nombreAvis;
  final List<String> specialites;
  final List<String> photos;
  final String? photoCouverture;
  final Map<String, dynamic> horaires;
  final String? description;
  final DateTime createdAt;

  Garage({
    required this.id,
    required this.nom,
    required this.adresse,
    required this.ville,
    this.codePostal,
    this.telephone,
    this.email,
    required this.latitude,
    required this.longitude,
    required this.estVerifie,
    required this.noteMoyenne,
    required this.nombreAvis,
    required this.specialites,
    required this.photos,
    this.photoCouverture,
    required this.horaires,
    this.description,
    required this.createdAt,
  });

  LatLng get latLng => LatLng(latitude, longitude);

  factory Garage.fromMap(Map<String, dynamic> map) {
    return Garage(
      id: map['id'] ?? '',
      nom: map['nom'] ?? '',
      adresse: map['adresse'] ?? '',
      ville: map['ville'] ?? '',
      codePostal: map['code_postal'],
      telephone: map['telephone'],
      email: map['email'],
      latitude: (map['latitude'] ?? 0.0).toDouble(),
      longitude: (map['longitude'] ?? 0.0).toDouble(),
      estVerifie: map['est_verifie'] ?? false,
      noteMoyenne: (map['note_moyenne'] ?? 0.0).toDouble(),
      nombreAvis: map['nombre_avis'] ?? 0,
      specialites: List<String>.from(map['specialites'] ?? []),
      photos: List<String>.from(map['photos'] ?? []),
      photoCouverture: map['photo_couverture'],
      horaires: Map<String, dynamic>.from(map['horaires'] ?? {}),
      description: map['description'],
      createdAt: DateTime.tryParse(map['created_at'] ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nom': nom,
      'adresse': adresse,
      'ville': ville,
      'code_postal': codePostal,
      'telephone': telephone,
      'email': email,
      'latitude': latitude,
      'longitude': longitude,
      'est_verifie': estVerifie,
      'note_moyenne': noteMoyenne,
      'nombre_avis': nombreAvis,
      'specialites': specialites,
      'photos': photos,
      'photo_couverture': photoCouverture,
      'horaires': horaires,
      'description': description,
      'created_at': createdAt.toIso8601String(),
    };
  }

  String getHoraireJour(String jour) {
    final h = horaires[jour.toLowerCase()];
    if (h == null || h['ouvert'] == false) return 'Fermé';
    return '${h['debut'] ?? '--:--'} - ${h['fin'] ?? '--:--'}';
  }

  bool isOuvertAujourdhui() {
    final jours = [
      'dimanche',
      'lundi',
      'mardi',
      'mercredi',
      'jeudi',
      'vendredi',
      'samedi'
    ];
    final jour = jours[DateTime.now().weekday % 7];
    final h = horaires[jour];
    return h != null && h['ouvert'] == true;
  }
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/garages_pro/models/garage.dart';
import 'package:carhabti/garages_pro/services/location_service.dart';

class GarageCard extends StatelessWidget {
  final Garage garage;
  final double? distance;
  final VoidCallback? onTap;
  final VoidCallback? onMapTap;
  final VoidCallback? onBookingTap;

  const GarageCard({
    super.key,
    required this.garage,
    this.distance,
    this.onTap,
    this.onMapTap,
    this.onBookingTap,
  });

  static const _kBlue1 = Color(0xFF0D5C8A);
  static const _kBlue2 = Color(0xFF127BBC);
  static const _kTextPrimary = Color(0xFF1A2340);
  static const _kTextSecondary = Color(0xFF8A94A6);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          garage.nom,
                          style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: _kTextPrimary,
                          ),
                        ),
                      ),
                      if (garage.estVerifie)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFF43A047).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.verified,
                                  size: 12, color: Color(0xFF43A047)),
                              const SizedBox(width: 4),
                              Text('Vérifié',
                                  style: GoogleFonts.poppins(
                                      fontSize: 10,
                                      color: const Color(0xFF43A047),
                                      fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on_outlined,
                          size: 14, color: _kTextSecondary),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text('${garage.ville} • ${garage.adresse}',
                            style: GoogleFonts.poppins(
                                fontSize: 12, color: _kTextSecondary),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _buildStars(garage.noteMoyenne),
                      const SizedBox(width: 6),
                      Text(
                          '${garage.noteMoyenne.toStringAsFixed(1)} (${garage.nombreAvis})',
                          style: GoogleFonts.poppins(
                              fontSize: 11, color: _kTextSecondary)),
                      const Spacer(),
                      if (distance != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _kBlue2.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.navigation_outlined,
                                  size: 14, color: _kBlue2),
                              const SizedBox(width: 4),
                              Text(LocationService.formatDistance(distance!),
                                  style: GoogleFonts.poppins(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: _kBlue2)),
                            ],
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: garage.specialites
                        .take(3)
                        .map((s) => _buildChip(s))
                        .toList()
                      ..addAll(garage.specialites.length > 3
                          ? [_buildChip('+${garage.specialites.length - 3}')]
                          : []),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: onMapTap,
                          icon: const Icon(Icons.map_outlined,
                              size: 16, color: _kBlue2),
                          label: Text('Voir sur la carte',
                              style: GoogleFonts.poppins(
                                  fontSize: 12, color: _kBlue2)),
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: _kBlue2.withOpacity(0.3)),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: onBookingTap,
                          icon: const Icon(Icons.calendar_today,
                              size: 16, color: Colors.white),
                          label: Text('Prendre RDV',
                              style: GoogleFonts.poppins(
                                  fontSize: 12,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kBlue1,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      child: Hero(
        tag: 'garage_cover_${garage.id}',
        child: Container(
          height: 120,
          width: double.infinity,
          color: Colors.grey.shade200,
          child: garage.photoCouverture != null &&
                  garage.photoCouverture!.isNotEmpty
              ? Image.network(garage.photoCouverture!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _buildPlaceholder())
              : _buildPlaceholder(),
        ),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      color: const Color(0xFF0D5C8A).withOpacity(0.08),
      child: const Center(
        child: Icon(Icons.car_repair, size: 48, color: Color(0xFF0D5C8A)),
      ),
    );
  }

  Widget _buildStars(double rating) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (i) {
        final filled = i < rating.floor();
        final half = i == rating.floor() && rating % 1 >= 0.5;
        return Icon(
          half ? Icons.star_half : (filled ? Icons.star : Icons.star_border),
          size: 14,
          color: const Color(0xFFFFB300),
        );
      }),
    );
  }

  Widget _buildChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: _kBlue2.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label,
          style: GoogleFonts.poppins(
              fontSize: 10, color: _kBlue2, fontWeight: FontWeight.w500)),
    );
  }
}

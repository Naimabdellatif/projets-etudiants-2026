"""
Module d'initialisation pour les services.
"""

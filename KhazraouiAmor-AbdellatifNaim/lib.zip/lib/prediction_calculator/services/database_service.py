"""
Service d'accès à la base de données pour le calculateur de prédiction.
Ce module gère les interactions avec Supabase.
"""

import os
import logging
from typing import Dict, Any, Optional, List
import datetime
import json

# Importation conditionnelle de supabase-py
try:
    from supabase import create_client, Client
except ImportError:
    logging.warning("Supabase client not installed. Run 'pip install supabase' to enable database functionality.")

class DatabaseService:
    """
    Service pour gérer les interactions avec la base de données Supabase.
    """
    
    def __init__(self, url: Optional[str] = None, key: Optional[str] = None):
        """
        Initialise le service de base de données.
        
        Args:
            url (str, optional): URL de l'API Supabase.
            key (str, optional): Clé d'API Supabase.
        """
        self.url = url or os.environ.get("SUPABASE_URL")
        self.key = key or os.environ.get("SUPABASE_KEY")
        self.client = None
        
        # Initialiser le client Supabase si les identifiants sont disponibles
        if self.url and self.key:
            try:
                self.client = create_client(self.url, self.key)
                logging.info("Supabase client initialized successfully")
            except Exception as e:
                logging.error(f"Failed to initialize Supabase client: {e}")
        else:
            logging.warning("Supabase credentials not provided. Database functionality will be limited.")
    
    async def get_vehicle_data(self, immatriculation: str) -> Dict[str, Any]:
        """
        Récupère les données d'un véhicule à partir de son immatriculation.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            
        Returns:
            Dict[str, Any]: Données du véhicule.
            
        Raises:
            Exception: Si la récupération échoue.
        """
        if not self.client:
            logging.error("Supabase client not initialized")
            return {}
        
        try:
            response = await self.client.table('voiture').select('*').eq('immatriculation', immatriculation).maybe_single().execute()
            return response.data or {}
        except Exception as e:
            logging.error(f"Error fetching vehicle data: {e}")
            raise
    
    async def get_vehicle_age(self, immatriculation: str) -> int:
        """
        Calcule l'âge du véhicule à partir de son année de fabrication.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            
        Returns:
            int: Âge du véhicule en années.
        """
        if not self.client:
            logging.warning("Supabase client not initialized, returning default age (5 years)")
            return 5
        
        try:
            response = await self.client.table('voiture').select('annee').eq('immatriculation', immatriculation).maybe_single().execute()
            
            if not response.data or 'annee' not in response.data:
                logging.warning(f"Could not retrieve vehicle year for {immatriculation}, using default (5 years)")
                return 5
            
            year = response.data['annee']
            current_year = datetime.datetime.now().year
            age = current_year - year
            
            logging.info(f"Calculated vehicle age: {age} years (manufacturing year: {year})")
            return max(1, age)  # Au moins 1 an pour éviter des calculs incorrects
            
        except Exception as e:
            logging.error(f"Error calculating vehicle age: {e}")
            return 5  # Valeur par défaut en cas d'erreur
    
    async def save_predictions(self, immatriculation: str, predictions: Dict[str, float]) -> bool:
        """
        Sauvegarde les prédictions dans la base de données.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            predictions (Dict[str, float]): Prédictions à sauvegarder.
            
        Returns:
            bool: True si la sauvegarde a réussi, False sinon.
        """
        if not self.client:
            logging.error("Supabase client not initialized")
            return False
        
        try:
            data = {
                'fk_immatriculation': immatriculation,
                **predictions,
                'updated_at': datetime.datetime.now().isoformat()
            }
            
            await self.client.table('predictions').upsert(data).execute()
            logging.info(f"Predictions saved successfully for vehicle {immatriculation}")
            return True
            
        except Exception as e:
            logging.error(f"Error saving predictions: {e}")
            return False
    
    def close(self):
        """
        Ferme la connexion à la base de données.
        """
        # Pas nécessaire avec le client Supabase Python actuel,
        # mais inclus pour la compatibilité future
        self.client = None
        logging.info("Database connection closed")


class MockDatabaseService:
    """
    Service de base de données simulé pour les tests ou lorsque Supabase n'est pas disponible.
    """
    
    def __init__(self):
        """
        Initialise le service de base de données simulé.
        """
        self.vehicles = {}
        self.predictions = {}
        logging.info("Mock database service initialized")
    
    async def get_vehicle_data(self, immatriculation: str) -> Dict[str, Any]:
        """
        Récupère les données simulées d'un véhicule.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            
        Returns:
            Dict[str, Any]: Données simulées du véhicule.
        """
        return self.vehicles.get(immatriculation, {})
    
    async def get_vehicle_age(self, immatriculation: str) -> int:
        """
        Retourne un âge simulé pour le véhicule.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            
        Returns:
            int: Âge simulé du véhicule (5 ans par défaut).
        """
        vehicle = self.vehicles.get(immatriculation, {})
        if 'annee' in vehicle:
            current_year = datetime.datetime.now().year
            return max(1, current_year - vehicle['annee'])
        return 5  # Âge par défaut
    
    async def save_predictions(self, immatriculation: str, predictions: Dict[str, float]) -> bool:
        """
        Sauvegarde les prédictions dans la mémoire.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            predictions (Dict[str, float]): Prédictions à sauvegarder.
            
        Returns:
            bool: True (toujours réussi).
        """
        self.predictions[immatriculation] = {
            **predictions,
            'updated_at': datetime.datetime.now().isoformat()
        }
        logging.info(f"Mock predictions saved for vehicle {immatriculation}")
        return True
    
    def set_vehicle_data(self, immatriculation: str, data: Dict[str, Any]):
        """
        Définit les données d'un véhicule pour les tests.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            data (Dict[str, Any]): Données du véhicule.
        """
        self.vehicles[immatriculation] = data
    
    def get_saved_predictions(self, immatriculation: str) -> Dict[str, Any]:
        """
        Récupère les prédictions sauvegardées pour un véhicule.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            
        Returns:
            Dict[str, Any]: Prédictions sauvegardées.
        """
        return self.predictions.get(immatriculation, {})
    
    def close(self):
        """
        Simule la fermeture de la connexion.
        """
        self.vehicles = {}
        self.predictions = {}
        logging.info("Mock database connection closed")

"""
Contrôleur principal pour le calculateur de prédiction.
Ce module contient la logique de calcul des prédictions d'usure.
"""

import logging
import datetime
import math
from typing import Dict, Any, Optional, List, Tuple

# Importation des modules du projet
from ..models.constants import (
    REFERENCE_DUREE_VIE_OPTIMALE, ROAD_FACTORS_EXPERT, DAILY_KM_FACTORS_EXPERT,
    TEMPERATURE_FACTORS_BATTERY_EXPERT, LOCATION_FACTORS_BATTERY_EXPERT,
    TIME_CONDUITE_FACTORS_BATTERY_EXPERT, DAILY_KM_FACTORS_BATTERY_EXPERT,
    WEATHER_FACTORS_BATTERY_EXPERT, ROAD_FACTORS, ENGINE_TYPE_FACTORS,
    USAGE_FACTORS, DRIVING_STYLE_FACTORS, WEATHER_FACTORS,
    TIME_CONDUITE_FACTORS, TEMPERATURE_FACTORS,
    BASE_KM_INTERVAL_PETROL, BASE_KM_INTERVAL_DIESEL,
    BASE_TIME_INTERVAL_DAYS_OIL_EXPERT
)
from ..models.data_model import VehicleData, PredictionResult
from ..controllers.utils import (
    parse_double, parse_road_usage, calculate_composite_road_factor,
    calculate_driving_severity, parse_temperature, get_temp_range,
    calculate_days_since_installation, validate_date
)
from ..services.database_service import DatabaseService, MockDatabaseService

# Configuration du logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PredictionCalculator:
    """
    Calculateur de prédiction pour l'usure des pièces automobiles.
    """
    
    def __init__(self, immatriculation: str, raw_facteur_data: Dict[str, Any], 
                 db_service: Optional[Any] = None):
        """
        Initialise le calculateur de prédiction.
        
        Args:
            immatriculation (str): Immatriculation du véhicule.
            raw_facteur_data (Dict[str, Any]): Données brutes des facteurs.
            db_service (Optional[Any]): Service de base de données (DatabaseService ou MockDatabaseService).
        """
        self.immatriculation = immatriculation
        self.raw_facteur_data = raw_facteur_data or {}
        
        # Initialiser le service de base de données
        if db_service:
            self.db_service = db_service
        else:
            try:
                self.db_service = DatabaseService()
                if not self.db_service.client:
                    logger.warning("Supabase client not initialized, using mock database")
                    self.db_service = MockDatabaseService()
            except Exception as e:
                logger.error(f"Error initializing database service: {e}")
                self.db_service = MockDatabaseService()
    
    async def _calculate_vehicle_age(self) -> int:
        """
        Calcule l'âge du véhicule automatiquement.
        
        Returns:
            int: Âge du véhicule en années.
        """
        try:
            return await self.db_service.get_vehicle_age(self.immatriculation)
        except Exception as e:
            logger.error(f"Error calculating vehicle age: {e}")
            return 5  # Valeur par défaut en cas d'erreur
    
    async def _fetch_vehicle_factors(self) -> Dict[str, Any]:
        """
        Récupère les facteurs du véhicule.
        
        Returns:
            Dict[str, Any]: Facteurs du véhicule.
            
        Raises:
            Exception: Si aucune donnée facteur n'est disponible.
        """
        if not self.raw_facteur_data:
            raise Exception("Aucune donnée facteur disponible")
        
        # Combinaison des clés requises pour toutes les vérifications
        required_keys_combined = {
            'total_km',
            'date_installation_pneus',
            'daily_km',
            'date_dernier_vidange',
            'type_de_moteur',
            'condition_de_utilisation',
            'type_de_route',
        }
        
        # Vérification des clés
        missing_keys = [key for key in required_keys_combined if key not in self.raw_facteur_data]
        
        if missing_keys:
            raise Exception(f"Données incomplètes pour le calcul expert. Clés manquantes : {', '.join(missing_keys)}")
        
        # Récupérer les données avec l'âge du véhicule calculé automatiquement
        data = dict(self.raw_facteur_data)
        vehicle_age = await self._calculate_vehicle_age()
        
        # Remplacer age_de_vehicule s'il existait déjà ou l'ajouter
        data['age_de_vehicule'] = vehicle_age
        
        return data
    
    async def save_predictions(self, predictions: Dict[str, float]) -> bool:
        """
        Sauvegarde les prédictions dans la base de données.
        
        Args:
            predictions (Dict[str, float]): Prédictions à sauvegarder.
            
        Returns:
            bool: True si la sauvegarde a réussi, False sinon.
        """
        try:
            return await self.db_service.save_predictions(self.immatriculation, predictions)
        except Exception as e:
            logger.error(f"Error saving predictions: {e}")
            return False
    
    async def calculate_all_predictions(self) -> Dict[str, float]:
        """
        Calcule toutes les prédictions d'usure.
        
        Returns:
            Dict[str, float]: Résultats des prédictions.
        """
        try:
            data = await self._fetch_vehicle_factors()
            
            # Afficher l'âge du véhicule dans les logs pour vérification
            logger.info(f"Calcul des prédictions avec âge du véhicule: {data['age_de_vehicule']} ans")
            
            results = {
                'tire_wear': self._calculate_tire_wear(data),
                'brake_wear': self._calculate_brake_wear(data),
            }
            
            # Si les méthodes manquantes sont définies, les utiliser également
            # Sinon, utiliser des valeurs par défaut
            try:
                results['battery_health'] = self._calculate_battery_health(data)
            except Exception as e:
                logger.error(f"Error calculating battery health: {e}")
                results['battery_health'] = 50.0
                
            try:
                results['clutch_wear'] = self._calculate_clutch_wear(data)
            except Exception as e:
                logger.error(f"Error calculating clutch wear: {e}")
                results['clutch_wear'] = 30.0
                
            try:
                results['ShockAbsorber_Wear'] = self._calculate_shock_absorber_wear(data)
            except Exception as e:
                logger.error(f"Error calculating shock absorber wear: {e}")
                results['ShockAbsorber_Wear'] = 40.0
                
            try:
                results['oil_change'] = self._calculate_oil_change(data)
            except Exception as e:
                logger.error(f"Error calculating oil change: {e}")
                results['oil_change'] = 45.0
                
            try:
                results['belt_risk'] = self._calculate_belt_risk(data)
            except Exception as e:
                logger.error(f"Error calculating belt risk: {e}")
                results['belt_risk'] = 35.0
            
            # Assurez-vous que toutes les valeurs sont des doubles valides
            for key, value in results.items():
                if math.isnan(value):
                    results[key] = 0.0
            
            # Sauvegarde des prédictions
            await self.save_predictions(results)
            return results
            
        except Exception as e:
            logger.error(f"Error in calculateAllPredictions: {e}")
            # Valeurs par défaut en cas d'erreur
            return {
                'tire_wear': 50.0,
                'oil_change': 45.0,
                'belt_risk': 35.0,
                'battery_health': 50.0,
                'brake_wear': 40.0,
                'clutch_wear': 30.0,
                'ShockAbsorber_Wear': 40.0,
            }
    
    def _calculate_brake_wear(self, data: Dict[str, Any]) -> float:
        """
        Calcule l'usure des freins.
        
        Args:
            data (Dict[str, Any]): Données du véhicule.
            
        Returns:
            float: Pourcentage d'usure des freins.
        """
        try:
            logger.info("Début du calcul optimisé de l'usure des freins")
            
            # 1. Extraction et validation des données
            installation_date_str = data.get('date_installation_frein')
            if not installation_date_str:
                return 50.0  # Usure moyenne si date inconnue
            
            installation_date = datetime.datetime.fromisoformat(installation_date_str)
            now = datetime.datetime.now()
            age_in_days = (now - installation_date).days
            
            daily_km = parse_double(data.get('daily_km', 30.0))
            location = data.get('localisation') or data.get('place_de_conduite') or 'Centre-ville'
            driving_style = data.get('style_de_conduite') or 'Normal'
            vehicle_weight = parse_double(data.get('poids_vehicule') or data.get('vehicle_weight') or 1500.0)
            road_type = data.get('type_de_route') or 'Urbain'
            usage_type = data.get('condition_de_utilisation') or 'Quotidienne'
            
            # Vérifier si c'est un usage intensif/louage
            is_intensive_use = usage_type in ['Louage', 'Transport de charges lourdes', 'Usage intensif']
            
            # 2. Récupération des valeurs de référence optimales
            # Utilisation des valeurs médianes pour une meilleure précision
            ref_km = (REFERENCE_DUREE_VIE_OPTIMALE['freins']['km_intensif_median'] 
                     if is_intensive_use 
                     else REFERENCE_DUREE_VIE_OPTIMALE['freins']['km_median'])
            
            # 3. Calcul des facteurs d'impact
            # Facteur de localisation (10% d'impact)
            location_factor = 1.0
            if location == 'Centre-ville':
                location_factor = 1.75  # Augmenté
            elif location == 'Urbain':
                location_factor = 1.55  # Augmenté
            elif location == 'Entre-région':
                location_factor = 0.80  # Légèrement ajusté
            elif location == 'Autoroute':
                location_factor = 0.70  # Légèrement ajusté
            
            # Facteur de style de conduite (impact majeur sur les freins - 40%)
            driving_style_factor = 1.2
            if driving_style == 'Sportif':
                driving_style_factor = 2.0  # Augmenté pour plus d'impact
            elif driving_style == 'Calme':
                driving_style_factor = 0.7  # Conduite douce préserve les freins
            elif driving_style == 'Normal':
                driving_style_factor = 1.1
            
            # Facteur de type de route (30% d'impact)
            road_factor = 1.0
            if 'Montagne' in road_type:
                road_factor = 1.85  # Freinage fréquent en descente - augmenté
            elif 'Urbain' in road_type or 'Centre-ville' in road_type:
                road_factor = 1.65  # Arrêts fréquents - augmenté
            elif 'Autoroute' in road_type:
                road_factor = 0.60  # Peu de freinage - diminué
            
            # Facteur de poids (20% d'impact)
            weight_factor = min(1.6, max(0.85, vehicle_weight / 1500.0))
            
            # 4. Conversion entre kilométrage et temps
            # Durée de vie en kilomètres ajustée selon les facteurs de sévérité
            total_severity_factor = (
                driving_style_factor * 0.4 +  # Style de conduite: 40%
                road_factor * 0.3 +  # Type de route: 30%
                weight_factor * 0.2 +  # Poids du véhicule: 20%
                location_factor * 0.1  # Localisation: 10%
            )
            
            # Durée de vie ajustée en kilomètres
            adjusted_life_km = ref_km / total_severity_factor
            
            # 5. Kilométrage estimé depuis l'installation
            estimated_km = age_in_days * daily_km
            
            # 6. Calcul de l'usure basé sur le kilométrage (plus précis que le temps)
            # Utilisation d'un modèle non-linéaire amélioré avec seuils adaptés
            km_ratio = estimated_km / adjusted_life_km
            
            if km_ratio < 0.55:
                # Première phase: usure linéaire lente
                wear_percentage = km_ratio * 70.0  # Progression plus lente au début
            elif km_ratio < 0.85:
                # Deuxième phase: usure modérément accélérée
                wear_percentage = 38.5 + ((km_ratio - 0.55) / 0.3) * 36.5
            else:
                # Phase finale: usure très rapide (courbe exponentielle)
                excess_wear = km_ratio - 0.85
                wear_percentage = 75.0 + excess_wear * (125.0 + excess_wear * 50.0)
            
            # 7. Ajustement final et validation
            clamped_wear_percentage = max(0.0, min(100.0, wear_percentage))
            
            logger.info(f"Calcul optimisé usure freins: {clamped_wear_percentage}% (Km estimés: {estimated_km}, Durée ajustée: {adjusted_life_km} km)")
            return clamped_wear_percentage
            
        except Exception as e:
            logger.error(f"Erreur dans calcul usure freins: {e}")
            return 45.0  # Valeur moyenne en cas d'erreur
    
    def _calculate_tire_wear(self, data: Dict[str, Any]) -> float:
        """
        Calcule l'usure des pneus.
        
        Args:
            data (Dict[str, Any]): Données du véhicule.
            
        Returns:
            float: Pourcentage d'usure des pneus.
        """
        try:
            logger.info("Début du calcul avancé de l'usure des pneus")
            
            # 1. Extraction et validation des données d'entrée
            marque = data.get('marque_pneus') or '1e choix'
            daily_km = parse_double(data.get('daily_km')) or 50.0
            vehicle_weight = parse_double(data.get('vehicle_weight') or data.get('poids_vehicule')) or 1500.0
            road_usage = parse_road_usage(data.get('type_de_route'))
            engine_type = data.get('type_de_moteur') or 'Essence'
            temperature = data.get('temperature') or '20C°-35C°'
            driving_style = data.get('style_de_conduite') or 'Normal'
            usage_type = data.get('condition_de_utilisation') or 'Quotidienne'
            weather = data.get('meteo') or 'Tempéré'
            
            logger.info(f"Données d'entrée récupérées: marque={marque}, dailyKm={daily_km}, style={driving_style}, moteur={engine_type}, usage={usage_type}")
            
            # 2. Calcul des durées de vie de référence basées sur la qualité des pneus
            # Durée de vie ajustée pour un pourcentage d'usure plus réaliste
            tire_lifespans = {
                'Original': {'km': 90000.0, 'years': 5.0},  # Haut de gamme - ajusté
                '1e choix': {'km': 85000.0, 'years': 4.5},  # Moyenne gamme - ajusté
                '2e choix': {'km': 75000.0, 'years': 4.0},  # Entrée de gamme - ajusté
            }
            
            # Récupérer les références de durée de vie selon la marque
            tire_lifespan = tire_lifespans.get(marque) or tire_lifespans['1e choix']
            max_km = tire_lifespan['km']
            max_years = tire_lifespan['years']
            
            logger.info(f"Durée de vie de référence: {max_km} km sur {max_years} ans")
            
            # 3. Calcul des facteurs de modification
            # a) Facteur composite de route - moyenne pondérée des types de routes
            composite_road_factor = calculate_composite_road_factor(road_usage, ROAD_FACTORS)
            
            # b) Facteur de style de conduite
            driving_factor = DRIVING_STYLE_FACTORS.get(driving_style, 1.3)
            
            # c) Impact météorologique - température et conditions climatiques (réduit)
            temp_value = parse_temperature(temperature)
            weather_impact = (WEATHER_FACTORS.get(weather, 1.0) * 
                             (1.2 if temp_value > 35 else 
                              1.0 if temp_value > 20 else 
                              1.15 if temp_value < 0 else 0.9))
            
            # d) Impact du poids et type d'utilisation
            load_factor = (vehicle_weight / 1500) * USAGE_FACTORS.get(usage_type, 1.1)
            
            # e) Catégorie de kilométrage quotidien
            daily_km_category = 'very_short'
            if daily_km > 100:
                daily_km_category = 'très_long'
            elif daily_km > 50:
                daily_km_category = 'long'
            elif daily_km > 25:
                daily_km_category = 'medium'
            elif daily_km > 10:
                daily_km_category = 'short'
            
            daily_distance_factor = DAILY_KM_FACTORS_EXPERT.get(daily_km_category, 1.0)
            
            # 4. Âge des pneus et kilométrage estimé
            age_days = calculate_days_since_installation(data.get('date_installation_pneus'))
            if age_days < 7:
                return 0.0  # Installation très récente
            
            age_years = age_days / 365.0
            estimated_total_km = daily_km * age_days
            
            logger.info(f"Âge des pneus: {age_years} ans ({age_days} jours), km estimés: {estimated_total_km}")
            
            # 5. Calcul du taux d'usure combiné
            # Combinaison du pourcentage d'usure par rapport au temps et au kilométrage
            km_wear_ratio = estimated_total_km / (max_km / (
                composite_road_factor * 
                driving_factor * 
                weather_impact * 
                load_factor * 
                daily_distance_factor
            ))
            
            time_wear_ratio = age_years / max_years
            
            # Le taux d'usure est déterminé par le facteur le plus avancé
            # avec une pondération de 65% pour le kilométrage et 35% pour le temps
            # Facteur d'atténuation ajusté selon la qualité des pneus
            attenuation_factor = 1.2 if marque in ['Original', '1e choix'] else 0.9
            wear_ratio = ((km_wear_ratio * 0.65) + (time_wear_ratio * 0.35)) * attenuation_factor
            
            # 6. Modèle d'usure non-linéaire - coefficients ajustés selon la qualité des pneus
            # Les pneus s'usent plus rapidement vers la fin de leur cycle de vie
            
            # Coefficients d'usure différents selon la qualité des pneus
            if marque in ['Original', '1e choix']:
                # Pour les pneus de qualité originale ou 1e choix - usure initiale augmentée
                if wear_ratio < 0.3:
                    # Phase initiale - usure augmentée pour atteindre 25-30%
                    wear_percentage = wear_ratio * 100.0  # Augmenté de 75 à 100
                elif wear_ratio < 0.7:
                    # Phase intermédiaire - usure normale
                    wear_percentage = 30.0 + ((wear_ratio - 0.3) * 85.0)
                else:
                    # Phase finale - usure accélérée
                    wear_percentage = 64.0 + ((wear_ratio - 0.7) * 100.0)
            else:
                # Pour les pneus de qualité inférieure - valeurs originales légèrement ajustées
                if wear_ratio < 0.3:
                    wear_percentage = wear_ratio * 80.0  # Légèrement augmenté de 75 à 80
                elif wear_ratio < 0.7:
                    wear_percentage = 24.0 + ((wear_ratio - 0.3) * 85.0)
                else:
                    wear_percentage = 58.0 + ((wear_ratio - 0.7) * 100.0)
            
            # 7. Ajustement final et validation
            clamped_wear_percentage = max(0.0, min(100.0, wear_percentage))
            
            # 8. Calcul de la vie résiduelle estimée (en km et en temps)
            remaining_percentage = 100.0 - clamped_wear_percentage
            remaining_km = round(max_km * remaining_percentage / 100.0)
            remaining_days = round(max_years * 365.0 * remaining_percentage / 100.0)
            
            logger.info(f"Calcul de l'usure des pneus: {clamped_wear_percentage}%")
            logger.info(f"Durée de vie restante estimée: {remaining_km} km ou {remaining_days} jours")
            
            return clamped_wear_percentage
            
        except Exception as e:
            logger.error(f"Erreur calcul avancé usure pneus: {e}")
            return 50.0  # Valeur moyenne en cas d'erreur
    
    def _calculate_battery_health(self, data: Dict[str, Any]) -> float:
        """
        Calcule l'état de santé de la batterie.
        
        Args:
            data (Dict[str, Any]): Données du véhicule.
            
        Returns:
            float: Pourcentage d'usure de la batterie.
        """
        try:
            logger.info("Début du calcul optimisé de la santé de la batterie")
            
            # 1. Extraction et validation des données
            installation_date_str = data.get('date_installation_batterie')
            installation_date = (datetime.datetime.fromisoformat(installation_date_str) 
                               if installation_date_str 
                               else datetime.datetime.now() - datetime.timedelta(days=365))
            
            # Type de moteur - essentiel pour la durée de vie de référence
            engine_type = data.get('type_de_moteur') or 'Essence'
            is_diesel = 'diesel' in engine_type.lower()
            
            # Autres données importantes
            usage_type = data.get('condition_de_utilisation') or 'Quotidienne'
            driving_location = (data.get('place_de_conduite') or 
                               data.get('localisation') or 
                               'Entre-région')
            temperature_value = data.get('temperature')
            driving_style = data.get('style_de_conduite') or 'Normal'
            daily_km = parse_double(data.get('daily_km', 30.0))
            vehicle_age_years = parse_double(data.get('age_de_vehicule', 5.0))
            
            # Vérifier si c'est un usage intensif/louage
            is_intensive_use = usage_type in ['Louage', 'Transport de charges lourdes', 'Usage intensif']
            
            # 2. Calcul de l'âge de la batterie
            now = datetime.datetime.now()
            battery_age_days = max(0, (now - installation_date).days)
            battery_age_years = battery_age_days / 365.0
            
            logger.info(f"Âge de la batterie: {battery_age_years} ans ({battery_age_days} jours)")
            
            # 3. Récupération des valeurs de référence optimales
            # Durée de vie différente selon le type de moteur
            ref_max_years = (REFERENCE_DUREE_VIE_OPTIMALE['batterie']['ans_diesel'] 
                           if is_diesel 
                           else REFERENCE_DUREE_VIE_OPTIMALE['batterie']['ans_essence'])
            
            # 4. Déterminer la qualité de la batterie (influence la durée de vie)
            battery_quality = data.get('qualite_batterie') or 'Standard'
            
            # Facteur de qualité qui influence la durée de vie
            quality_factor = 1.2  # Standard
            if battery_quality == 'Premium':
                quality_factor = 1.15  # Batterie haut de gamme +15%
            elif battery_quality == 'Economy':
                quality_factor = 0.85  # Batterie économique -15%
            
            # Durée de vie de référence en années, ajustée selon la qualité
            base_life_years = ref_max_years * quality_factor
            
            logger.info(f"Durée de vie de référence: {base_life_years} ans (type: {engine_type}, qualité: {battery_quality})")
            
            # 5. Calcul des facteurs de dégradation individuels
            # a) Température - impact sur les réactions chimiques (25%)
            temp_factor = 1.0
            temp = parse_double(temperature_value or 25.0)
            if temp > 35:
                temp_factor = 1.35  # Chaleur extrême - forte dégradation
            elif temp < 0:
                temp_factor = 1.25  # Froid extrême - dégradation importante
            elif temp < 20:
                temp_factor = 1.1  # Froid modéré - légère dégradation
            
            # b) Localisation - impact sur les cycles thermiques et vibrations (20%)
            location_factor = 1.05
            if driving_location in ['Centre-ville', 'Urbain']:
                location_factor = 1.3  # Arrêts/démarrages fréquents
            elif driving_location == 'Désert':
                location_factor = 1.15  # Conditions extrêmes
            elif driving_location == 'Campagne':
                location_factor = 1.1  # Vibrations, chemins inégaux
            elif driving_location in ['Autoroute', 'Entre-région']:
                location_factor = 0.95  # Usage régulier, optimal
            
            # c) Style de conduite - impact sur les cycles de charge/décharge (15%)
            driving_style_factor = 1.05
            if driving_style == 'Sportif':
                driving_style_factor = 1.2  # Décharges rapides
            elif driving_style == 'Calme':
                driving_style_factor = 0.9  # Utilisation douce
            
            # d) Condition d'utilisation - impact sur la charge (20%)
            usage_factor = 1.0
            if usage_type == 'Transport de charges lourdes':
                usage_factor = 1.25  # Demande électrique élevée
            elif usage_type == 'Louage':
                usage_factor = 1.3  # Usage intensif
            elif usage_type == 'Voyage':
                usage_factor = 1.1  # Utilisation prolongée
            
            # e) Kilométrage quotidien - impact sur les cycles de charge (10%)
            daily_km_factor = 0.95
            if daily_km < 15:
                daily_km_factor = 1.25  # Trajets courts - charges incomplètes
            elif daily_km < 30:
                daily_km_factor = 1.1  # Trajets moyens
            
            # f) Âge du véhicule - impact sur le système électrique (10%)
            age_vehicle_factor = min(1.3, 1.0 + (vehicle_age_years / 20.0))
            
            # g) Type de moteur - impact supplémentaire pour diesel
            engine_type_factor = 1.2 if is_diesel else 1.0
            
            # 6. Calcul du multiplicateur de dégradation combiné avec pondération optimisée
            degradation_multiplier = (
                temp_factor * 0.25 +  # Température: 25%
                location_factor * 0.20 +  # Localisation: 20%
                driving_style_factor * 0.15 +  # Style de conduite: 15%
                usage_factor * 0.20 +  # Utilisation: 20%
                daily_km_factor * 0.10 +  # Kilométrage quotidien: 10%
                age_vehicle_factor * 0.10  # Âge du véhicule: 10%
            ) * engine_type_factor
            
            # 7. Calcul de la durée de vie ajustée en jours
            adjusted_life_days = base_life_years * 365.0 / degradation_multiplier
            
            # 8. Calcul du pourcentage d'usure
            # Modèle non-linéaire pour la dégradation de la batterie
            wear_ratio = battery_age_days / adjusted_life_days
            
            # Modèle de dégradation non-linéaire amélioré
            # Les batteries se dégradent plus rapidement au début et à la fin
            double_wear_percentage = 0.0
            if wear_ratio < 0.2:
                # Phase initiale - dégradation rapide
                double_wear_percentage = wear_ratio * 250.0  # 0-50% pour les premiers 20%
            elif wear_ratio < 0.7:
                # Phase intermédiaire - dégradation plus lente
                double_wear_percentage = 50.0 + ((wear_ratio - 0.2) / 0.5) * 30.0  # 50-80% pour 20-70%
            else:
                # Phase finale - dégradation très rapide
                double_wear_percentage = 80.0 + ((wear_ratio - 0.7) / 0.3) * 20.0  # 80-100% pour 70-100%
            
            # 9. Ajustement final et validation
            clamped_wear_percentage = max(0.0, min(100.0, double_wear_percentage))
            
            # 10. Calcul de la santé restante (inverse de l'usure)
            battery_health = 100.0 - clamped_wear_percentage
            
            logger.info(f"Calcul de la santé de la batterie: {battery_health}%")
            logger.info(f"Âge: {battery_age_days} jours, Durée de vie ajustée: {adjusted_life_days} jours")
            
            return battery_health
            
        except Exception as e:
            logger.error(f"Erreur dans le calcul de la santé de la batterie: {e}")
            return 50.0  # Valeur moyenne en cas d'erreur
    
    def _calculate_clutch_wear(self, data: Dict[str, Any]) -> float:
        """
        Calcule l'usure de l'embrayage.
        
        Args:
            data (Dict[str, Any]): Données du véhicule.
            
        Returns:
            float: Pourcentage d'usure de l'embrayage.
        """
        try:
            logger.info("Début du calcul de l'usure de l'embrayage")
            
            # 1. Extraction et validation des données
            # Pour l'embrayage, nous avons besoin de données spécifiques
            engine_type = data.get('type_de_moteur') or 'Essence'
            
            # Si c'est un véhicule électrique, pas d'embrayage
            if 'electrique' in engine_type.lower():
                logger.info("Véhicule électrique détecté, pas d'embrayage")
                return 0.0
            
            # Récupération des données importantes
            installation_date_str = data.get('date_installation_embrayage')
            daily_km = parse_double(data.get('daily_km', 30.0))
            driving_style = data.get('style_de_conduite') or 'Normal'
            road_type = data.get('type_de_route') or 'Urbain'
            usage_type = data.get('condition_de_utilisation') or 'Quotidienne'
            vehicle_age_years = parse_double(data.get('age_de_vehicule', 5.0))
            
            # 2. Calcul de l'âge de l'embrayage
            age_days = 0
            if installation_date_str:
                installation_date = datetime.datetime.fromisoformat(installation_date_str)
                age_days = (datetime.datetime.now() - installation_date).days
            else:
                # Si pas de date d'installation, estimation basée sur l'âge du véhicule
                # L'embrayage d'origine dure généralement 60% de la vie du véhicule
                age_days = int(vehicle_age_years * 365 * 0.6)
            
            # 3. Récupération des valeurs de référence
            ref_km = REFERENCE_DUREE_VIE_OPTIMALE['embrayage']['km_median']
            
            # 4. Calcul des facteurs d'impact
            # a) Style de conduite (impact majeur - 50%)
            driving_style_factor = 1.0
            if driving_style == 'Sportif':
                driving_style_factor = 1.8  # Forte usure
            elif driving_style == 'Calme':
                driving_style_factor = 0.8  # Usure réduite
            
            # b) Type de route (30%)
            road_factor = 1.0
            if 'Urbain' in road_type or 'Centre-ville' in road_type:
                road_factor = 1.5  # Embouteillages, arrêts/démarrages fréquents
            elif 'Montagne' in road_type:
                road_factor = 1.3  # Utilisation fréquente
            elif 'Autoroute' in road_type:
                road_factor = 0.8  # Peu de changements de vitesse
            
            # c) Type d'utilisation (20%)
            usage_factor = 1.0
            if usage_type in ['Louage', 'Taxi']:
                usage_factor = 1.6  # Usage intensif
            elif usage_type == 'Transport de charges lourdes':
                usage_factor = 1.7  # Forte charge
            
            # 5. Calcul du facteur de sévérité total
            severity_factor = (
                driving_style_factor * 0.5 +  # Style de conduite: 50%
                road_factor * 0.3 +  # Type de route: 30%
                usage_factor * 0.2  # Type d'utilisation: 20%
            )
            
            # 6. Calcul de la durée de vie ajustée
            adjusted_life_km = ref_km / severity_factor
            
            # 7. Kilométrage estimé
            estimated_km = daily_km * age_days
            
            # 8. Calcul de l'usure
            wear_ratio = estimated_km / adjusted_life_km
            
            # Modèle d'usure non-linéaire pour l'embrayage
            wear_percentage = 0.0
            if wear_ratio < 0.4:
                # Première phase: usure lente
                wear_percentage = wear_ratio * 40.0
            elif wear_ratio < 0.8:
                # Deuxième phase: usure modérée
                wear_percentage = 16.0 + ((wear_ratio - 0.4) / 0.4) * 44.0
            else:
                # Phase finale: usure rapide
                wear_percentage = 60.0 + ((wear_ratio - 0.8) / 0.2) * 40.0
            
            # 9. Ajustement final
            clamped_wear_percentage = max(0.0, min(100.0, wear_percentage))
            
            logger.info(f"Calcul de l'usure de l'embrayage: {clamped_wear_percentage}%")
            logger.info(f"Âge: {age_days} jours, Km estimés: {estimated_km}, Durée ajustée: {adjusted_life_km} km")
            
            return clamped_wear_percentage
            
        except Exception as e:
            logger.error(f"Erreur dans le calcul de l'usure de l'embrayage: {e}")
            return 30.0  # Valeur par défaut en cas d'erreur
    
    def _calculate_shock_absorber_wear(self, data: Dict[str, Any]) -> float:
        """
        Calcule l'usure des amortisseurs.
        
        Args:
            data (Dict[str, Any]): Données du véhicule.
            
        Returns:
            float: Pourcentage d'usure des amortisseurs.
        """
        try:
            logger.info("Début du calcul de l'usure des amortisseurs")
            
            # 1. Extraction et validation des données
            installation_date_str = data.get('date_installation_amortisseurs')
            daily_km = parse_double(data.get('daily_km', 30.0))
            road_usage = parse_road_usage(data.get('type_de_route'))
            usage_type = data.get('condition_de_utilisation') or 'Quotidienne'
            vehicle_age_years = parse_double(data.get('age_de_vehicule', 5.0))
            vehicle_weight = parse_double(data.get('poids_vehicule') or data.get('vehicle_weight') or 1500.0)
            
            # 2. Calcul de l'âge des amortisseurs
            age_days = 0
            if installation_date_str:
                installation_date = datetime.datetime.fromisoformat(installation_date_str)
                age_days = (datetime.datetime.now() - installation_date).days
            else:
                # Si pas de date d'installation, estimation basée sur l'âge du véhicule
                # Les amortisseurs d'origine durent généralement 50% de la vie du véhicule
                age_days = int(vehicle_age_years * 365 * 0.5)
            
            age_years = age_days / 365.0
            
            # 3. Récupération des valeurs de référence
            ref_km = REFERENCE_DUREE_VIE_OPTIMALE['amortisseurs']['km_median']
            ref_years = REFERENCE_DUREE_VIE_OPTIMALE['amortisseurs']['ans_median']
            
            # Vérifier si c'est un usage intensif
            is_intensive_use = usage_type in ['Louage', 'Transport de charges lourdes', 'Usage intensif']
            if is_intensive_use:
                ref_years = REFERENCE_DUREE_VIE_OPTIMALE['amortisseurs']['ans_intensif']
            
            # 4. Calcul des facteurs d'impact
            # a) Type de route (impact majeur - 50%)
            composite_road_factor = calculate_composite_road_factor(road_usage, ROAD_FACTORS)
            
            # b) Poids du véhicule (25%)
            weight_factor = min(1.5, max(0.9, vehicle_weight / 1500.0))
            
            # c) Type d'utilisation (25%)
            usage_factor = USAGE_FACTORS.get(usage_type, 1.1)
            
            # 5. Calcul du facteur de sévérité total
            severity_factor = (
                composite_road_factor * 0.5 +  # Type de route: 50%
                weight_factor * 0.25 +  # Poids du véhicule: 25%
                usage_factor * 0.25  # Type d'utilisation: 25%
            )
            
            # 6. Calcul des durées de vie ajustées
            adjusted_life_km = ref_km / severity_factor
            adjusted_life_years = ref_years / severity_factor
            
            # 7. Kilométrage estimé
            estimated_km = daily_km * age_days
            
            # 8. Calcul des ratios d'usure
            km_wear_ratio = estimated_km / adjusted_life_km
            time_wear_ratio = age_years / adjusted_life_years
            
            # Utiliser le ratio le plus élevé (le facteur limitant)
            wear_ratio = max(km_wear_ratio, time_wear_ratio)
            
            # 9. Modèle d'usure non-linéaire pour les amortisseurs
            wear_percentage = 0.0
            if wear_ratio < 0.3:
                # Première phase: usure lente
                wear_percentage = wear_ratio * 30.0
            elif wear_ratio < 0.7:
                # Deuxième phase: usure modérée
                wear_percentage = 9.0 + ((wear_ratio - 0.3) / 0.4) * 51.0
            else:
                # Phase finale: usure rapide
                wear_percentage = 60.0 + ((wear_ratio - 0.7) / 0.3) * 40.0
            
            # 10. Ajustement final
            clamped_wear_percentage = max(0.0, min(100.0, wear_percentage))
            
            logger.info(f"Calcul de l'usure des amortisseurs: {clamped_wear_percentage}%")
            logger.info(f"Âge: {age_days} jours, Km estimés: {estimated_km}, Durée ajustée: {adjusted_life_km} km")
            
            return clamped_wear_percentage
            
        except Exception as e:
            logger.error(f"Erreur dans le calcul de l'usure des amortisseurs: {e}")
            return 40.0  # Valeur par défaut en cas d'erreur
    
    def _calculate_oil_change(self, data: Dict[str, Any]) -> float:
        """
        Calcule le besoin de vidange d'huile.
        
        Args:
            data (Dict[str, Any]): Données du véhicule.
            
        Returns:
            float: Pourcentage d'usure de l'huile.
        """
        try:
            logger.info("Début du calcul du besoin de vidange d'huile")
            
            # 1. Extraction et validation des données
            engine_type = data.get('type_de_moteur') or 'Essence'
            
            # Si c'est un véhicule électrique, pas de vidange d'huile
            if 'electrique' in engine_type.lower():
                logger.info("Véhicule électrique détecté, pas de vidange d'huile nécessaire")
                return 0.0
            
            last_oil_change_date_str = data.get('date_dernier_vidange')
            if not last_oil_change_date_str:
                return 75.0  # Valeur élevée si date inconnue
            
            last_oil_change_date = datetime.datetime.fromisoformat(last_oil_change_date_str)
            daily_km = parse_double(data.get('daily_km', 30.0))
            driving_style = data.get('style_de_conduite') or 'Normal'
            usage_type = data.get('condition_de_utilisation') or 'Quotidienne'
            
            # 2. Calcul du temps écoulé depuis la dernière vidange
            days_since_change = (datetime.datetime.now() - last_oil_change_date).days
            
            # 3. Détermination des intervalles de référence
            # Intervalle en kilomètres selon le type de moteur
            base_km_interval = BASE_KM_INTERVAL_DIESEL if 'diesel' in engine_type.lower() else BASE_KM_INTERVAL_PETROL
            
            # Intervalle en jours (strict cap)
            base_time_interval_days = BASE_TIME_INTERVAL_DAYS_OIL_EXPERT
            
            # 4. Calcul des facteurs d'ajustement
            # a) Style de conduite
            driving_style_factor = 1.0
            if driving_style == 'Sportif':
                driving_style_factor = 0.8  # Réduction de l'intervalle
            elif driving_style == 'Calme':
                driving_style_factor = 1.1  # Augmentation de l'intervalle
            
            # b) Type d'utilisation
            usage_factor = 1.0
            if usage_type in ['Louage', 'Taxi']:
                usage_factor = 0.7  # Réduction significative de l'intervalle
            elif usage_type == 'Transport de charges lourdes':
                usage_factor = 0.8  # Réduction de l'intervalle
            
            # 5. Calcul des intervalles ajustés
            adjusted_km_interval = base_km_interval * driving_style_factor * usage_factor
            adjusted_time_interval_days = base_time_interval_days * driving_style_factor * usage_factor
            
            # 6. Calcul du kilométrage estimé depuis la dernière vidange
            estimated_km_since_change = daily_km * days_since_change
            
            # 7. Calcul des pourcentages d'usure
            km_percentage = (estimated_km_since_change / adjusted_km_interval) * 100.0
            time_percentage = (days_since_change / adjusted_time_interval_days) * 100.0
            
            # Utiliser le pourcentage le plus élevé (le facteur limitant)
            oil_wear_percentage = max(km_percentage, time_percentage)
            
            # 8. Ajustement final
            clamped_oil_wear_percentage = max(0.0, min(100.0, oil_wear_percentage))
            
            logger.info(f"Calcul du besoin de vidange d'huile: {clamped_oil_wear_percentage}%")
            logger.info(f"Jours depuis dernière vidange: {days_since_change}, Km estimés: {estimated_km_since_change}")
            
            return clamped_oil_wear_percentage
            
        except Exception as e:
            logger.error(f"Erreur dans le calcul du besoin de vidange d'huile: {e}")
            return 45.0  # Valeur par défaut en cas d'erreur
    
    def _calculate_belt_risk(self, data: Dict[str, Any]) -> float:
        """
        Calcule le risque lié à la courroie.
        
        Args:
            data (Dict[str, Any]): Données du véhicule.
            
        Returns:
            float: Pourcentage de risque pour la courroie.
        """
        try:
            logger.info("Début du calcul du risque lié à la courroie")
            
            # 1. Extraction et validation des données
            engine_type = data.get('type_de_moteur') or 'Essence'
            
            # Si c'est un véhicule électrique, pas de courroie
            if 'electrique' in engine_type.lower():
                logger.info("Véhicule électrique détecté, pas de courroie")
                return 0.0
            
            installation_date_str = data.get('date_installation_courroie')
            daily_km = parse_double(data.get('daily_km', 30.0))
            usage_type = data.get('condition_de_utilisation') or 'Quotidienne'
            vehicle_age_years = parse_double(data.get('age_de_vehicule', 5.0))
            
            # 2. Calcul de l'âge de la courroie
            age_days = 0
            if installation_date_str:
                installation_date = datetime.datetime.fromisoformat(installation_date_str)
                age_days = (datetime.datetime.now() - installation_date).days
            else:
                # Si pas de date d'installation, estimation basée sur l'âge du véhicule
                # La courroie d'origine dure généralement 70% de la vie du véhicule
                age_days = int(vehicle_age_years * 365 * 0.7)
            
            # 3. Récupération des valeurs de référence
            # Vérifier si c'est un usage intensif
            is_intensive_use = usage_type in ['Louage', 'Transport de charges lourdes', 'Usage intensif']
            
            ref_km = (REFERENCE_DUREE_VIE_OPTIMALE['courroie']['km_intensif'] 
                     if is_intensive_use 
                     else REFERENCE_DUREE_VIE_OPTIMALE['courroie']['km_max'])
            
            # 4. Calcul du facteur d'utilisation
            usage_factor = USAGE_FACTORS.get(usage_type, 1.1)
            
            # 5. Calcul de la durée de vie ajustée
            adjusted_life_km = ref_km / usage_factor
            
            # 6. Kilométrage estimé
            estimated_km = daily_km * age_days
            
            # 7. Calcul du ratio d'usure
            wear_ratio = estimated_km / adjusted_life_km
            
            # 8. Modèle de risque non-linéaire pour la courroie
            risk_percentage = 0.0
            if wear_ratio < 0.5:
                # Première phase: risque faible
                risk_percentage = wear_ratio * 20.0
            elif wear_ratio < 0.8:
                # Deuxième phase: risque modéré
                risk_percentage = 10.0 + ((wear_ratio - 0.5) / 0.3) * 40.0
            else:
                # Phase finale: risque élevé
                risk_percentage = 50.0 + ((wear_ratio - 0.8) / 0.2) * 50.0
            
            # 9. Ajustement final
            clamped_risk_percentage = max(0.0, min(100.0, risk_percentage))
            
            logger.info(f"Calcul du risque lié à la courroie: {clamped_risk_percentage}%")
            logger.info(f"Âge: {age_days} jours, Km estimés: {estimated_km}, Durée ajustée: {adjusted_life_km} km")
            
            return clamped_risk_percentage
            
        except Exception as e:
            logger.error(f"Erreur dans le calcul du risque lié à la courroie: {e}")
            return 35.0  # Valeur par défaut en cas d'erreur

"""
Module d'initialisation pour les contrôleurs.
"""

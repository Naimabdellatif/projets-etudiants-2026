"""
Fonctions utilitaires pour le calculateur de prédiction.
Ce module contient des fonctions d'aide pour les calculs et le traitement des données.
"""

import datetime
import re
import logging
from typing import Dict, Any, Optional, Union, List, Tuple

# Configuration du logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def parse_double(value: Any) -> float:
    """
    Méthode utilitaire pour parser les doubles depuis différents formats.
    
    Args:
        value: Valeur à convertir en float.
        
    Returns:
        float: Valeur convertie ou 0.0 si la conversion échoue.
    """
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    
    # Extraction des caractères numériques et du point décimal
    numeric_string = re.sub(r'[^0-9.]', '', str(value))
    try:
        return float(numeric_string)
    except (ValueError, TypeError):
        return 0.0

def parse_road_usage(input_data: Any) -> Dict[str, float]:
    """
    Méthode pour analyser l'utilisation des routes.
    
    Args:
        input_data: Données d'entrée (dictionnaire ou chaîne de caractères).
        
    Returns:
        Dict[str, float]: Dictionnaire des types de routes avec leur proportion d'utilisation.
    """
    if isinstance(input_data, dict):
        return {k: parse_double(v) for k, v in input_data.items()}
    elif isinstance(input_data, str):
        types = [s.strip() for s in input_data.split(',') if s.strip()]
        if not types:
            return {'Autoroute': 1.0}
        
        factor_per_type = 1.0 / len(types)  # Répartition égale
        return {road_type: factor_per_type for road_type in types}
    
    return {'Autoroute': 1.0}  # Valeur par défaut

def calculate_composite_road_factor(road_usage: Dict[str, float], road_factors: Dict[str, float]) -> float:
    """
    Calcul du facteur composite de route.
    
    Args:
        road_usage: Dictionnaire des types de routes avec leur proportion d'utilisation.
        road_factors: Dictionnaire des facteurs d'impact pour chaque type de route.
        
    Returns:
        float: Facteur composite de route.
    """
    if not road_usage:
        return 1.0
    
    total_factor = 0.0
    total_weight = 0.0
    
    for key, value in road_usage.items():
        total_factor += (road_factors.get(key, 1.0) * value)
        total_weight += value
    
    return total_factor / total_weight if total_weight > 0 else 1.0

def calculate_driving_severity(driving_style: str, engine_type: str, 
                              driving_style_factors: Dict[str, float], 
                              engine_type_factors: Dict[str, float]) -> float:
    """
    Calcul de la sévérité de conduite.
    
    Args:
        driving_style: Style de conduite.
        engine_type: Type de moteur.
        driving_style_factors: Facteurs d'impact pour chaque style de conduite.
        engine_type_factors: Facteurs d'impact pour chaque type de moteur.
        
    Returns:
        float: Facteur de sévérité de conduite.
    """
    return (driving_style_factors.get(driving_style, 1.15) * 
            engine_type_factors.get(engine_type, 1.0))

def parse_temperature(temp_range: str) -> float:
    """
    Parsing de température.
    
    Args:
        temp_range: Plage de température sous forme de chaîne.
        
    Returns:
        float: Valeur de température estimée.
    """
    if temp_range == "< 0C°":
        return -5.0
    elif temp_range == "0C°-20C°":
        return 10.0
    elif temp_range == "20C°-35C°":
        return 27.5
    elif temp_range == "> 35C°":
        return 40.0
    else:
        # Extraction des valeurs numériques
        numeric_pattern = re.compile(r'(\d+)')
        matches = numeric_pattern.findall(temp_range)
        if matches:
            try:
                return float(matches[0])
            except (ValueError, IndexError):
                return 25.0
        return 25.0

def get_temp_range(temp: str) -> str:
    """
    Récupération de la plage de température.
    
    Args:
        temp: Température sous forme de chaîne ou valeur numérique.
        
    Returns:
        str: Plage de température correspondante.
    """
    value = parse_temperature(temp)
    if value < 0:
        return "< 0C°"
    elif 0 <= value < 20:
        return "0C°-20C°"
    elif 20 <= value <= 35:
        return "20C°-35C°"
    else:
        return "> 35C°"

def calculate_days_since_installation(date_str: Optional[str]) -> int:
    """
    Calcul du nombre de jours depuis l'installation.
    
    Args:
        date_str: Date d'installation au format ISO.
        
    Returns:
        int: Nombre de jours écoulés depuis l'installation.
    """
    try:
        if date_str:
            installation_date = datetime.datetime.fromisoformat(date_str)
            return (datetime.datetime.now() - installation_date).days
        return 30  # Valeur par défaut
    except (ValueError, TypeError):
        return 30  # Valeur par défaut en cas d'erreur

def validate_date(date_value: Any, default_subtract_days: int = 365) -> datetime.datetime:
    """
    Validation des dates.
    
    Args:
        date_value: Valeur de date à valider.
        default_subtract_days: Nombre de jours à soustraire par défaut.
        
    Returns:
        datetime.datetime: Date validée.
    """
    if date_value is None:
        return datetime.datetime.now() - datetime.timedelta(days=default_subtract_days)
    
    try:
        return datetime.datetime.fromisoformat(str(date_value))
    except (ValueError, TypeError) as e:
        logger.error(f"Error parsing date: {date_value}, defaulting. Error: {e}")
        return datetime.datetime.now() - datetime.timedelta(days=default_subtract_days)

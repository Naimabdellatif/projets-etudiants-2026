"""
Module de modèle de données pour le calculateur de prédiction.
Ce module contient les classes représentant les structures de données utilisées.
"""

class VehicleData:
    """
    Classe représentant les données d'un véhicule.
    Utilisée pour stocker et accéder aux données nécessaires aux calculs de prédiction.
    """
    
    def __init__(self, raw_data=None):
        """
        Initialise les données du véhicule à partir des données brutes.
        
        Args:
            raw_data (dict, optional): Dictionnaire contenant les données brutes du véhicule.
        """
        self.raw_data = raw_data or {}
        
    def get(self, key, default=None):
        """
        Récupère une valeur à partir de la clé spécifiée.
        
        Args:
            key (str): Clé de la donnée à récupérer.
            default: Valeur par défaut si la clé n'existe pas.
            
        Returns:
            La valeur associée à la clé ou la valeur par défaut.
        """
        return self.raw_data.get(key, default)
    
    def set(self, key, value):
        """
        Définit une valeur pour la clé spécifiée.
        
        Args:
            key (str): Clé de la donnée à définir.
            value: Valeur à associer à la clé.
        """
        self.raw_data[key] = value
        
    def to_dict(self):
        """
        Convertit les données en dictionnaire.
        
        Returns:
            dict: Dictionnaire contenant les données du véhicule.
        """
        return self.raw_data


class PredictionResult:
    """
    Classe représentant les résultats des prédictions d'usure.
    """
    
    def __init__(self):
        """
        Initialise un objet de résultat de prédiction vide.
        """
        self.results = {
            'tire_wear': 0.0,
            'brake_wear': 0.0,
            'battery_health': 0.0,
            'clutch_wear': 0.0,
            'ShockAbsorber_Wear': 0.0,
            'oil_change': 0.0,
            'belt_risk': 0.0,
        }
        
    def set_result(self, component, value):
        """
        Définit le résultat pour un composant spécifique.
        
        Args:
            component (str): Nom du composant.
            value (float): Valeur de l'usure ou du risque.
        """
        if component in self.results:
            self.results[component] = float(value)
            
    def get_result(self, component):
        """
        Récupère le résultat pour un composant spécifique.
        
        Args:
            component (str): Nom du composant.
            
        Returns:
            float: Valeur de l'usure ou du risque.
        """
        return self.results.get(component, 0.0)
        
    def to_dict(self):
        """
        Convertit les résultats en dictionnaire.
        
        Returns:
            dict: Dictionnaire contenant les résultats des prédictions.
        """
        return self.results

"""
Module d'initialisation pour les modèles.
"""

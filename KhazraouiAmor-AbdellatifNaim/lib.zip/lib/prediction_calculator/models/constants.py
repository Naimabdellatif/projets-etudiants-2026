"""
Constantes et valeurs de référence pour le calculateur de prédiction.
Ce module contient toutes les constantes et mappings utilisés dans les calculs d'usure.
"""

# SECTION: RÉFÉRENCES DE DURÉE DE VIE OPTIMALE DES PIÈCES
# Ces valeurs servent de point central pour les algorithmes prédictifs
# Basées sur des sources réelles et fiables des constructeurs automobiles

# Durée de vie optimale des pièces en conditions normales (conduite et usage normaux)
REFERENCE_DUREE_VIE_OPTIMALE = {
    'freins': {
        'km_min': 90000.0,  # Valeur minimale: 90 000 km
        'km_max': 100000.0,  # Valeur maximale: 100 000 km
        'km_intensif': 50000.0,  # Usage intensif/louage: 50 000 km
        'km_intensif_max': 60000.0,  # Usage intensif max: 60 000 km
        'km_median': 95000.0,  # Valeur médiane pour calculs
        'km_intensif_median': 55000.0,  # Valeur médiane usage intensif
        'ans': None,  # Pas de référence en années pour les freins
    },
    'pneus': {
        'km_min': 60000.0,  # Valeur minimale: 60 000 km
        'km_max': 80000.0,  # Valeur maximale: 80 000 km
        'km_median': 70000.0,  # Valeur médiane pour calculs
        'ans_min': 3,  # Durée minimale: 3 ans
        'ans_max': 5,  # Durée maximale: 4 ans
        'ans_median': 3.5,  # Valeur médiane pour calculs
    },
    'batterie': {
        'ans_essence': 2,  # Véhicules à essence: 2 ans max
        'ans_diesel': 1,  # Véhicules diesel: 1 an max
    },
    'embrayage': {
        'km_min': 150000.0,  # Valeur minimale: 150 000 km
        'km_max': 180000.0,  # Valeur maximale: 180 000 km
        'km_median': 165000.0,  # Valeur médiane pour calculs
        'ans': None,  # Pas de référence en années pour l'embrayage
    },
    'amortisseurs': {
        'km_min': 65000.0,  # Valeur minimale: 65 000 km
        'km_max': 80000.0,  # Valeur maximale: 80 000 km
        'km_median': 72500.0,  # Valeur médiane pour calculs
        'ans_min': 3,  # Durée minimale: 3 ans
        'ans_max': 6,  # Durée maximale: 4 ans
        'ans_median': 3.5,  # Valeur médiane pour calculs
        'ans_intensif': 1,  # 1 an pour usage intensif/louage
    },
    'courroie': {
        'km_max': 80000.0,  # Valeur maximale: 80 000 km
        'km_intensif': 50000.0,  # Usage intensif/louage: 50 000 km
        'ans': None,  # Pas de référence en années pour la courroie
    },
}

# SECTION: FACTEURS D'USURE AMÉLIORÉS BASÉS SUR DES DONNÉES RÉELLES

# Facteurs de route - impact sur l'usure des pièces
ROAD_FACTORS_EXPERT = {
    'Autoroute': 0.75,  # Usure plus faible due à une vitesse constante
    'Entre les pays': 0.78,  # Similaire à l'autoroute
    'Campagne': 0.95,  # Routes à vitesse modérée
    'Entre-région': 0.92,  # Routes nationales/régionales
    'Asphelte': 0.90,  # Surface standard
    'Beton': 0.93,  # Surface plus dure
    'Urbain': 1.45,  # Trafic dense, arrêts/démarrages fréquents
    'Centre-ville': 1.55,  # Encore plus d'arrêts/démarrages
    'Montagne': 1.35,  # Impact sur les freins et transmissions
    'Gravier': 1.70,  # Surface non-pavée
    'Terre': 1.75,  # Impact sur la suspension et le chassis
    'Piste': 1.80,  # Impact maximal
    'default': 1.0,  # Valeur standard
}

DAILY_KM_FACTORS_EXPERT = {
    # Severity multiplier based on daily kilometers
    'long': 0.85,  # > 50 km
    'medium': 1.0,  # 25-50 km
    'short': 1.3,  # 10-25 km
    'very_short': 1.6,  # < 10 km
}

TEMPERATURE_FACTORS_BATTERY_EXPERT = {
    # Degradation multiplier based on ambient temperature
    "> 35C°": 1.8,
    "< 0C°": 1.4,
    "0C°-20C°": 1.15,
    "20C°-35C°": 1.0,
    "default": 1.0,
}

LOCATION_FACTORS_BATTERY_EXPERT = {
    # Degradation multiplier based on driving location
    'Centre-ville': 1.6,
    'Urbain': 1.6,
    'Désert': 1.3,
    'Campagne': 1.1,
    'Entre-région': 1.0,
    'Autoroute': 1.0,
    'Entre les pays': 1.0,
    'default': 1.1,
}

TIME_CONDUITE_FACTORS_BATTERY_EXPERT = {
    # Degradation multiplier based on driving time
    'Nocturne': 1.3,
    'Journalière': 1.0,
    'default': 1.0,
}

DAILY_KM_FACTORS_BATTERY_EXPERT = {
    # Degradation multiplier based on daily kilometers
    'very_short': 1.7,  # < 15 km
    'short': 1.2,  # 15-30 km
    'medium_long': 1.0,  # > 30 km
}

WEATHER_FACTORS_BATTERY_EXPERT = {
    # Minor degradation multiplier based on general weather
    'Aride': 1.05,
    'Chaude': 1.05,
    'Humide': 1.05,
    'Pluies': 1.05,
    'Froid': 1.05,
    'default': 1.0,
}

ROAD_FACTORS = {
    'Autoroute': 0.8,
    'Urbain': 1.0,
    'Terre': 2.5,
    'Asphelte': 1.1,
    'Fourage': 1.8,
    'Beton': 1.3,
    'Gravier': 1.7,
    'Piste': 2.5,
    "Montagne": 2.0,
}

ENGINE_TYPE_FACTORS = {
    'Essence': 1.0,
    'Diesel': 1.2,
    'Electrique': 0.8,
    'Hybride': 1.1,
}

USAGE_FACTORS = {
    'Quotidienne': 0.8,
    'Charges lourdes': 1.8,
    'Transport de livraison': 1.8,
    'Voyage': 1.0,
    'Louage': 1.5,
    'Taxi': 1.1,
    'Autre': 1.3,
    'default': 1.1,
}

DRIVING_STYLE_FACTORS = {
    'Calme': 1.0,
    'Normal': 1.3,
    'Sportif': 1.8,
}

WEATHER_FACTORS = {
    'Sub-Humide': 1.1,
    'Semi-Aride': 1.2,
    'Aride': 1.3,
    'Froid': 1.2,
    'Tempéré': 1.0,
    'Humide': 1.1,
    'Chaude': 1.3,
    'Pluies': 1.1,
}

TIME_CONDUITE_FACTORS = {
    'Journalière': 1.0, 
    'Nocturne': 1.1
}

TEMPERATURE_FACTORS = {
    "0C°-20C°": 0.8,
    "20C°-40C°": 1.1,
    "> 40C°": 1.5,
}

# --- Base Intervals (Values based on industry standards) ---
BASE_KM_INTERVAL_PETROL = 8000.0
BASE_KM_INTERVAL_DIESEL = 11000.0
# 1 year
# Average lifespan
BASE_TIME_INTERVAL_DAYS_OIL_EXPERT = 137  # Strict Cap: ~4.5 months

import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Gestionnaire centralisé pour toutes les notifications dans l'application
class NotificationManager {
  // Singleton pattern
  static final NotificationManager _instance = NotificationManager._internal();
  factory NotificationManager() => _instance;
  NotificationManager._internal();

  // Instances des services
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  final SupabaseClient _supabase = Supabase.instance.client;
  RealtimeChannel? _appNotificationsChannel;

  // Canal de notification principal pour Android
  static const AndroidNotificationChannel _maintenanceChannel =
      AndroidNotificationChannel(
    'maintenance_alerts',
    'Alertes d\'entretien',
    description: 'Notifications pour les rappels d\'entretien de véhicule',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
  );

  // Debug mode pour plus de logs
  bool _isDebugMode = true;

  // Statut d'initialisation
  bool _isInitialized = false;
  StreamSubscription<AuthState>? _authSubscription;

  /// Initialise le gestionnaire de notifications
  Future<void> initialize() async {
    if (_isInitialized) return;

    _debugLog('Initialisation du gestionnaire de notifications...');

    try {
      // 1. Demander les permissions
      final settings = await _firebaseMessaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );

      _debugLog(
          'Statut d\'autorisation des notifications: ${settings.authorizationStatus}');

      // 2. Configurer les notifications locales
      const androidSettings =
          AndroidInitializationSettings('@mipmap/ic_launcher');
      const iosSettings = DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      );

      await _localNotifications.initialize(
        const InitializationSettings(
            android: androidSettings, iOS: iosSettings),
        onDidReceiveNotificationResponse: _handleNotificationTap,
      );

      // 3. Créer le canal de notification pour Android
      await _localNotifications
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(_maintenanceChannel);

      // 4. Configurer les gestionnaires de messages Firebase
      FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
      FirebaseMessaging.onBackgroundMessage(
          _firebaseMessagingBackgroundHandler);
      FirebaseMessaging.onMessageOpenedApp.listen(_handleMessageOpenedApp);

      // 5. Vérifier les tokens FCM
      _updateFcmToken();

      await _authSubscription?.cancel();
      _authSubscription =
          _supabase.auth.onAuthStateChange.listen((AuthState data) {
        switch (data.event) {
          case AuthChangeEvent.signedIn:
            subscribeToAppNotificationInserts();
            break;
          case AuthChangeEvent.signedOut:
            unsubscribeFromAppNotificationInserts();
            break;
          default:
            break;
        }
      });

      if (_supabase.auth.currentUser != null) {
        await subscribeToAppNotificationInserts();
      }

      _isInitialized = true;
      _debugLog('Gestionnaire de notifications initialisé avec succès');
    } catch (e) {
      _debugLog('Erreur lors de l\'initialisation des notifications: $e');
    }
  }

  /// Met à jour le token FCM dans Supabase
  Future<void> _updateFcmToken() async {
    try {
      final fcmToken = await _firebaseMessaging.getToken();
      final user = _supabase.auth.currentUser;

      if (fcmToken != null && user != null) {
        await _supabase
            .from('client')
            .update({'fcm_token': fcmToken}).eq('id', user.id);

        _debugLog('Token FCM mis à jour: $fcmToken');
      }
    } catch (e) {
      _debugLog('Erreur lors de la mise à jour du token FCM: $e');
    }
  }

  /// Gestionnaire pour les messages en premier plan (app ouverte)
  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    _debugLog('Message reçu en premier plan: ${message.notification?.title}');
    _showLocalNotification(message.notification?.title ?? 'Notification',
        message.notification?.body ?? '', message.data);
  }

  /// Gestionnaire pour les messages en arrière-plan
  static Future<void> _firebaseMessagingBackgroundHandler(
      RemoteMessage message) async {
    if (kDebugMode) {
      print('Message reçu en arrière-plan: ${message.notification?.title}');
    }
  }

  /// Gestionnaire pour l'ouverture de l'application via une notification
  void _handleMessageOpenedApp(RemoteMessage message) {
    _debugLog(
        'App ouverte depuis une notification: ${message.notification?.title}');
    // La navigation sera gérée par _handleNotificationTap
  }

  /// Gestionnaire pour le tap sur une notification locale
  void _handleNotificationTap(NotificationResponse response) {
    _debugLog('Notification tappée: ${response.payload}');

    if (response.payload == null) return;

    try {
      final Map<String, dynamic> payload = {};

      response.payload!.split(',').forEach((item) {
        final parts = item.split(':');
        if (parts.length == 2) {
          payload[parts[0].trim()] = parts[1].trim();
        }
      });

      _debugLog('Payload décodé: $payload');

      // Marquer comme lue dans Supabase si un ID est présent
      final notificationId = payload['notification_id'];
      if (notificationId != null) {
        _markNotificationAsRead(notificationId);
      }

      // La navigation sera gérée via une callback enregistrée ailleurs dans l'app
    } catch (e) {
      _debugLog('Erreur lors du traitement du tap sur notification: $e');
    }
  }

  /// Affiche une notification locale
  Future<void> _showLocalNotification(
      String title, String body, Map<String, dynamic> data) async {
    final androidDetails = AndroidNotificationDetails(
      _maintenanceChannel.id,
      _maintenanceChannel.name,
      channelDescription: _maintenanceChannel.description,
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    // Créer un payload simple pour la notification
    final payload = data.entries.map((e) => '${e.key}:${e.value}').join(',');

    // Générer un ID unique pour éviter d'écraser les notifications
    final notificationId = DateTime.now().millisecondsSinceEpoch % 10000;

    await _localNotifications.show(
      notificationId,
      title,
      body,
      notificationDetails,
      payload: payload,
    );

    _debugLog('Notification locale affichée: $title');
  }

  /// Vérifie les pièces nécessitant un entretien et envoie des notifications
  Future<int> checkMaintenanceNeeds({bool forceCheck = false}) async {
    _debugLog(
        'Vérification des besoins de maintenance ${forceCheck ? "(forcée)" : ""}');

    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        _debugLog('Aucun utilisateur connecté, vérification annulée');
        return 0;
      }

      // On suppose que les notifications sont activées par défaut
      // puisque la colonne notifications_enabled n'existe pas
      bool notificationsEnabled = true;

      try {
        final userProfile = await _supabase
            .from('client')
            .select('*')
            .eq('id', user.id)
            .single();

        // Si la colonne existe, on l'utilise; sinon on garde true
        notificationsEnabled = userProfile['notifications_enabled'] ?? true;
      } catch (e) {
        // Si erreur, on suppose que les notifications sont activées
        _debugLog('Impossible de vérifier le statut des notifications: $e');
      }

      if (!notificationsEnabled && !forceCheck) {
        _debugLog(
            'Notifications désactivées par l\'utilisateur, vérification annulée');
        return 0;
      }

      // Récupérer tous les véhicules de l'utilisateur en joignant les tables
      final vehiculesResponse = await _supabase
          .from('user_vehicles')
          .select('voiture!inner(immatriculation, marque, modele)')
          .eq('user_id', user.id);

      final List<Map<String, dynamic>> vehicules =
          List<Map<String, dynamic>>.from(vehiculesResponse);
      _debugLog('Nombre de véhicules trouvés: ${vehicules.length}');

      if (vehicules.isEmpty) {
        _debugLog('Aucun véhicule trouvé, vérification annulée');
        return 0;
      }

      int notificationCount = 0;

// Nouvelle fonction utilitaire pour éviter les doublons et centraliser la création
Future<void> createMaintenanceNotification({
  required String userId,
  required Map<String, dynamic> vehicule,
  required String pieceName,
  required String title,
  required String body,
  required String type,
}) async {
  final existingNotifs = await _supabase
      .from('app_notifications')
      .select()
      .eq('user_id', userId)
      .eq('type', 'maintenance')
      .eq('vehicule_id', vehicule['id'])
      .ilike('title', '%$pieceName%')
      .order('created_at', ascending: false)
      .limit(1);

  if (existingNotifs.isNotEmpty) {
    _debugLog('Notification déjà existante pour ce cas ($type/$pieceName)');
    return;
  }

  final notifResponse = await _supabase
      .from('app_notifications')
      .insert({
        'user_id': userId,
        'title': title,
        'body': body,
        'type': 'maintenance',
        'read': false,
        'piece_id': null,
        'vehicule_id': vehicule['id'],
        'created_at': DateTime.now().toIso8601String(),
      })
      .select('id')
      .single();

  final int notificationId = notifResponse['id'];
  final Map<String, dynamic> notificationData = {
    'notification_id': notificationId.toString(),
    'type': 'maintenance',
    'vehicule_id': vehicule['id'].toString(),
  };
  _showLocalNotification(title, body, notificationData);
}

      final DateTime now = DateTime.now();
      final DateTime twoWeeksLater = now.add(const Duration(days: 14));

      // Pour chaque véhicule, vérifier les dates de maintenance
      for (final vehicule in vehicules) {
        try {
          // Récupérer les données du véhicule depuis la structure imbriquée
          final voitureData = vehicule['voiture'] as Map<String, dynamic>;
          final immatriculation = voitureData['immatriculation'];
          
          // Récupérer les dates de maintenance du véhicule
          final maintenanceDatesResponse = await _supabase
              .from('maintenance_dates')
              .select('*')
              .eq('fk_immatriculation', immatriculation)
              .single();

          // Vérifier chaque type de maintenance
          final maintenanceTypes = [
            {'nom': 'Batterie', 'date_field': 'changement_batterie'},
            {'nom': 'Amortisseurs', 'date_field': 'changement_amortisseurs'},
            {'nom': 'Embrayage', 'date_field': 'changement_embrayage'},
            {'nom': 'Freins', 'date_field': 'changement_freins'},
            {'nom': 'Courroie', 'date_field': 'changement_courroie'},
            {'nom': 'Vidange', 'date_field': 'changement_vidange'},
            {'nom': 'Pneus', 'date_field': 'changement_pneus'},
          ];

          for (final maintenance in maintenanceTypes) {
            final dateField = maintenance['date_field'];
            final String? dateStr = maintenanceDatesResponse[dateField];
            if (dateStr == null || dateStr.isEmpty) continue;

            final DateTime maintenanceDate = DateTime.parse(dateStr);
            final String pieceName = maintenance['nom'] ?? 'Inconnu';
            final String formattedDate = DateFormat('dd/MM/yyyy').format(maintenanceDate);

            // --- 1. Rappel 2 semaines avant ---
            if (maintenanceDate.isAfter(now) && maintenanceDate.isBefore(twoWeeksLater)) {
              await createMaintenanceNotification(
                userId: user.id,
                vehicule: vehicule,
                pieceName: pieceName,
                title: 'Maintenance $pieceName à planifier',
                body: 'Votre véhicule ${vehicule['immatriculation']} nécessite une maintenance $pieceName le $formattedDate.',
                type: 'reminder',
              );
              notificationCount++;
            }

            // --- 2. Le jour même ---
            if (maintenanceDate.year == now.year && maintenanceDate.month == now.month && maintenanceDate.day == now.day) {
              await createMaintenanceNotification(
                userId: user.id,
                vehicule: vehicule,
                pieceName: pieceName,
                title: 'Maintenance $pieceName à effectuer aujourd\'hui',
                body: 'La maintenance $pieceName de votre véhicule ${vehicule['immatriculation']} doit être effectuée aujourd\'hui ($formattedDate).',
                type: 'due_today',
              );
              notificationCount++;
            }

            // --- 3. En retard ---
            if (maintenanceDate.isBefore(now)) {
              await createMaintenanceNotification(
                userId: user.id,
                vehicule: vehicule,
                pieceName: pieceName,
                title: 'Maintenance $pieceName en retard !',
                body: 'La maintenance $pieceName de votre véhicule ${vehicule['immatriculation']} aurait dû être effectuée le $formattedDate.',
                type: 'overdue',
              );
              notificationCount++;
            }

            // --- 4. Usure à 100% (si champ trouvé) ---
            final wearField = 'usure_${pieceName.toLowerCase()}';
            if (maintenanceDatesResponse.containsKey(wearField)) {
              final wear = double.tryParse(maintenanceDatesResponse[wearField]?.toString() ?? '0') ?? 0;
              if (wear >= 100) {
                await createMaintenanceNotification(
                  userId: user.id,
                  vehicule: vehicule,
                  pieceName: pieceName,
                  title: 'Alerte: $pieceName usé à 100%',
                  body: 'La pièce $pieceName de votre véhicule ${vehicule['immatriculation']} est usée à 100% et doit être remplacée immédiatement.',
                  type: 'wear_100',
                );
                notificationCount++;
              }
            }
          }
        } catch (e) {
          _debugLog(
              'Erreur lors de la vérification des dates de maintenance pour ${vehicule['immatriculation']}: $e');
        }
      }

      _debugLog('$notificationCount notification(s) générée(s)');
      return notificationCount;
    } catch (e) {
      _debugLog(
          'Erreur lors de la vérification des besoins de maintenance: $e');
      return 0;
    }
  }

  /// Temps réel : nouvelles lignes [app_notifications] (ex. décision admin sur un RDV).
  /// Affiche une notification locale — complète la chaîne FCM lorsque l’app est active.
  Future<void> subscribeToAppNotificationInserts() async {
    await unsubscribeFromAppNotificationInserts();
    final user = _supabase.auth.currentUser;
    if (user == null) return;

    _appNotificationsChannel =
        _supabase.channel('public:app_notifications:${user.id}');
    _appNotificationsChannel!.onPostgresChanges(
      event: PostgresChangeEvent.insert,
      schema: 'public',
      table: 'app_notifications',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'user_id',
        value: user.id,
      ),
      callback: (PostgresChangePayload payload) {
        final row = payload.newRecord;
        final type = row['type']?.toString() ?? '';
        if (!type.startsWith('rendez_vous')) return;
        final title = row['title']?.toString() ?? 'Rendez-vous';
        final body = row['body']?.toString() ?? '';
        final id = row['id']?.toString() ?? '';
        _showLocalNotification(title, body, {
          'notification_id': id,
          'type': type,
        });
      },
    );
    _appNotificationsChannel!.subscribe();
    _debugLog('Realtime app_notifications (insert) actif');
  }

  Future<void> unsubscribeFromAppNotificationInserts() async {
    if (_appNotificationsChannel != null) {
      await _supabase.removeChannel(_appNotificationsChannel!);
      _appNotificationsChannel = null;
      _debugLog('Realtime app_notifications désactivé');
    }
  }

  /// Marque une notification comme lue dans Supabase
  Future<void> _markNotificationAsRead(String notificationId) async {
    try {
      await _supabase
          .from('app_notifications')
          .update({'read': true}).eq('id', notificationId);

      _debugLog('Notification $notificationId marquée comme lue');
    } catch (e) {
      _debugLog(
          'Erreur lors du marquage de la notification $notificationId comme lue: $e');
    }
  }

  /// Récupère toutes les notifications de l'utilisateur courant
  Future<List<Map<String, dynamic>>> fetchUserNotifications() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return [];

      final response = await _supabase
          .from('app_notifications')
          .select(
              'id, title, body, created_at, read, type, piece_id, vehicule_id')
          .eq('user_id', user.id)
          .order('created_at', ascending: false);

      final notifications = List<Map<String, dynamic>>.from(response);
      _debugLog('${notifications.length} notifications récupérées');

      return notifications;
    } catch (e) {
      _debugLog('Erreur lors de la récupération des notifications: $e');
      return [];
    }
  }

  /// Récupère les notifications non lues de l'utilisateur
  Future<int> getUnreadNotificationsCount() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return 0;

      final response = await _supabase
          .from('app_notifications')
          .select()
          .eq('user_id', user.id)
          .eq('read', false);

      final count = response.length;
      return count;
    } catch (e) {
      _debugLog('Erreur lors du comptage des notifications non lues: $e');
      return 0;
    }
  }

  /// Marque toutes les notifications comme lues
  Future<void> markAllNotificationsAsRead() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return;

      await _supabase
          .from('app_notifications')
          .update({'read': true})
          .eq('user_id', user.id)
          .eq('read', false);

      _debugLog('Toutes les notifications marquées comme lues');
    } catch (e) {
      _debugLog(
          'Erreur lors du marquage de toutes les notifications comme lues: $e');
    }
  }

  /// Active ou désactive les notifications pour l'utilisateur
  Future<bool> setNotificationsEnabled(bool enabled) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return false;

      try {
        // Vérifier si la table client existe
        await _supabase.from('client').select('id').limit(1);

        _debugLog(
            'Notifications ${enabled ? "activées" : "désactivées"} pour l\'utilisateur. Note: La colonne notifications_enabled n\'existe pas dans la table client.');
        return true;
      } catch (e) {
        _debugLog(
            'Erreur lors de la modification du statut des notifications: $e');
        return false;
      }
    } catch (e) {
      _debugLog(
          'Erreur lors de la modification du statut des notifications: $e');
      return false;
    }
  }

  /// Vérifie si les notifications sont activées pour l'utilisateur
  Future<bool> areNotificationsEnabled() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return false;

      try {
        final response = await _supabase
            .from('client')
            .select('*')
            .eq('id', user.id)
            .single();

        // Si la colonne existe, on l'utilise; sinon on suppose activé par défaut
        return response['notifications_enabled'] ?? true;
      } catch (e) {
        // En cas d'erreur, on suppose que les notifications sont activées
        _debugLog(
            'Erreur lors de la vérification du statut des notifications: $e');
        return true;
      }
    } catch (e) {
      _debugLog(
          'Erreur lors de la vérification du statut des notifications: $e');
      return false;
    }
  }

  /// Supprime une notification
  Future<bool> deleteNotification(int notificationId) async {
    try {
      await _supabase
          .from('app_notifications')
          .delete()
          .eq('id', notificationId);

      _debugLog('Notification $notificationId supprimée');
      return true;
    } catch (e) {
      _debugLog(
          'Erreur lors de la suppression de la notification $notificationId: $e');
      return false;
    }
  }

  /// Log conditionnelle pour le debug
  void _debugLog(String message) {
    if (_isDebugMode) {
      if (kDebugMode) {
        print('NotificationManager: $message');
      }
    }
  }

  /// Pour activer/désactiver les logs
  set debugMode(bool value) => _isDebugMode = value;
}

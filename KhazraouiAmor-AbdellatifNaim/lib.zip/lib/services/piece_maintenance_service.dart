import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/prediction_dossier_dart/date.dart';
import 'package:intl/intl.dart';

class PieceMaintenanceService {
  // Singleton pattern
  static final PieceMaintenanceService _instance =
      PieceMaintenanceService._internal();

  factory PieceMaintenanceService() {
    return _instance;
  }

  PieceMaintenanceService._internal();

  // Services
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  final SupabaseClient _supabase = Supabase.instance.client;

  // Notification channel ID and name
  static const String _channelId = 'maintenance_alerts';
  static const String _channelName = 'Alertes d\'entretien';
  static const String _channelDescription =
      'Notifications pour les rappels d\'entretien de véhicule';

  // Seuils de notification (jours)
  static const int _criticalThreshold = 3; // Alerte rouge
  static const int _warningThreshold = 7; // Alerte orange
  static const int _upcomingThreshold = 14; // Alerte jaune

  // État des notifications
  bool _notificationsInitialized = false;

  /// Initialise le service de notifications
  Future<void> initialize() async {
    if (_notificationsInitialized) return;

    // Demander la permission pour les notifications
    NotificationSettings settings = await _firebaseMessaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      if (kDebugMode) {
        print('✅ Notifications autorisées par l\'utilisateur');
      }
    } else {
      if (kDebugMode) {
        print('⚠️ Notifications non autorisées par l\'utilisateur');
      }
    }

    // Initialiser les notifications locales
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings();
    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTap,
    );

    // Configurer les canaux de notification pour Android
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDescription,
      importance: Importance.high,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    // Configurer les gestionnaires de messages Firebase
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessageOpenedApp);

    // Enregistrer le token FCM pour les notifications push
    _registerDeviceToken();

    _notificationsInitialized = true;
    if (kDebugMode) {
      print('✅ Service de notifications initialisé');
    }
  }

  /// Enregistre le token de l'appareil pour les notifications push
  Future<void> _registerDeviceToken() async {
    try {
      final token = await _firebaseMessaging.getToken();
      final user = _supabase.auth.currentUser;

      if (token != null && user != null) {
        await _supabase.from('device_tokens').upsert({
          'user_id': user.id,
          'token': token,
          'platform':
              Theme.of(navigatorKey.currentContext!).platform.toString(),
          'last_updated': DateTime.now().toIso8601String(),
        });
        if (kDebugMode) {
          print('✅ Token FCM enregistré: ${token.substring(0, 10)}...');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de l\'enregistrement du token: $e');
      }
    }
  }

  // GlobalKey pour accéder au contexte depuis n'importe où
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  /// Gère les messages reçus en premier plan
  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    if (kDebugMode) {
      print('📬 Message reçu en premier plan: ${message.notification?.title}');
    }
    _showLocalNotification(message);
  }

  /// Gère les messages lorsque l'application est ouverte depuis une notification
  void _handleMessageOpenedApp(RemoteMessage message) {
    if (kDebugMode) {
      print(
          '🔔 App ouverte depuis une notification: ${message.notification?.title}');
    }
    _navigateToNotificationDetails(message.data);
  }

  /// Affiche une notification locale
  Future<void> _showLocalNotification(RemoteMessage message) async {
    final RemoteNotification? notification = message.notification;
    final AndroidNotification? android = message.notification?.android;

    if (notification != null) {
      await _localNotifications.show(
        notification.hashCode,
        notification.title,
        notification.body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _channelId,
            _channelName,
            channelDescription: _channelDescription,
            icon: android?.smallIcon,
            importance: Importance.max,
            priority: Priority.high,
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        payload: message.data.toString(),
      );
    }
  }

  /// Gère l'action lorsqu'une notification est tapée
  void _onNotificationTap(NotificationResponse response) {
    if (response.payload != null) {
      try {
        final Map<String, dynamic> data = _parsePayload(response.payload!);
        _navigateToNotificationDetails(data);
      } catch (e) {
        if (kDebugMode) {
          print('❌ Erreur lors du parsing du payload: $e');
        }
      }
    }
  }

  /// Parse le payload de notification
  Map<String, dynamic> _parsePayload(String payload) {
    // Transforme la string "key1: value1, key2: value2" en Map
    final Map<String, dynamic> result = {};

    try {
      // Essayer d'analyser le format JSON entre accolades
      final cleanPayload = payload.trim();

      if (cleanPayload.startsWith('{') && cleanPayload.endsWith('}')) {
        // Extraire le contenu entre les accolades
        final content = cleanPayload.substring(1, cleanPayload.length - 1);

        // Diviser par les virgules
        final pairs = content.split(',');

        for (final pair in pairs) {
          final parts = pair.split(':');
          if (parts.length == 2) {
            // Nettoyer la clé et la valeur
            String key = parts[0].trim();
            String value = parts[1].trim();

            // Supprimer les guillemets si présents
            key = key.replaceAll('"', '').replaceAll("'", '');
            value = value.replaceAll('"', '').replaceAll("'", '');

            result[key] = value;
          }
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors du parsing du payload: $e');
      }
    }

    return result;
  }

  /// Navigation vers les détails de la notification
  void _navigateToNotificationDetails(Map<String, dynamic> data) {
    try {
      final context = navigatorKey.currentContext;

      if (context != null) {
        // Exemple: rediriger vers l'écran correspondant selon les données
        final immatriculation = data['immatriculation'];

        if (immatriculation != null) {
          // Naviguer vers le dashboard du véhicule
          // ou vers la page de détails du composant spécifique
          if (kDebugMode) {
            print('🧭 Navigation vers les détails du véhicule: $immatriculation');
          }
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la navigation: $e');
      }
    }
  }

  /// Analyse les dates de maintenance et génère des notifications si nécessaire
  /// Retourne le nombre de notifications générées
  Future<int> checkMaintenanceDates(String immatriculation) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        if (kDebugMode) {
          print('❌ Utilisateur non connecté');
        }
        return 0;
      }

      // Vérifier si les notifications sont initialisées
      if (!_notificationsInitialized) {
        await initialize();
      }

      if (kDebugMode) {
        print('🔍 Vérification des dates de maintenance pour $immatriculation');
      }
      int notificationsCount = 0;

      // Vérifier d'abord si le véhicule existe
      final vehicleExists = await _supabase
          .from('voiture')
          .select('immatriculation')
          .eq('immatriculation', immatriculation)
          .maybeSingle();

      if (vehicleExists == null) {
        if (kDebugMode) {
          print(
              '❌ Aucun véhicule trouvé pour l’immatriculation $immatriculation');
        }
        return 0;
      }

      // Synchroniser les dates avec les prédictions d'usure pour cette immatriculation spécifique
      await _syncMaintenanceDatesWithPredictions(immatriculation);

      // Récupérer les données de maintenance depuis la table facteur
      final facteurData = await _supabase
          .from('facteur')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (facteurData == null) {
        if (kDebugMode) {
          print('ℹ️ Aucune donnée facteur trouvée pour $immatriculation');
        }
        return 0;
      }

      // Récupérer les dates de maintenance mises à jour
      final maintenanceDatesData = await _supabase
          .from('maintenance_dates')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (maintenanceDatesData == null) {
        if (kDebugMode) {
          print('ℹ️ Aucune date de maintenance trouvée pour $immatriculation');
        }
        // Créer un enregistrement si nécessaire
        await _createMaintenanceDatesRecord(immatriculation);
        return 0;
      }

      final Map<String, dynamic> maintenanceDates = maintenanceDatesData;
      final DateTime now = DateTime.now();

      // Composants à vérifier
      final components = {
        'changement_batterie': 'Batterie',
        'changement_vidange': 'Vidange',
        'changement_freins': 'Freins',
        'changement_pneus': 'Pneus',
        'changement_amortisseurs': 'Amortisseurs',
        'changement_courroie': 'Courroie',
        'changement_embrayage': 'Embrayage',
      };

      // Vérifier chaque composant
      for (final entry in components.entries) {
        final String dbField = entry.key;
        final String componentName = entry.value;

        // Vérifier si la date existe
        if (maintenanceDates[dbField] == null) continue;

        final DateTime maintenanceDate =
            DateTime.parse(maintenanceDates[dbField]);
        final Duration difference = maintenanceDate.difference(now);
        final int daysRemaining = difference.inDays;

        // Déterminer le niveau de priorité
        NotificationPriority priority = NotificationPriority.none;
        String title = '';
        String body = '';

        if (difference.isNegative) {
          // La date est dépassée
          priority = NotificationPriority.critical;
          title = '🚨 Entretien en retard!';
          body =
              'Le remplacement de $componentName est en retard de ${-daysRemaining} jours';
        } else if (daysRemaining <= _criticalThreshold) {
          // Seuil critique
          priority = NotificationPriority.critical;
          title = '🚨 Entretien imminent!';
          body =
              'Le remplacement de $componentName est prévu dans $daysRemaining jours';
        } else if (daysRemaining <= _warningThreshold) {
          // Seuil d'avertissement
          priority = NotificationPriority.warning;
          title = '⚠️ Entretien à prévoir!';
          body =
              'Le remplacement de $componentName est prévu dans $daysRemaining jours';
        } else if (daysRemaining <= _upcomingThreshold) {
          // Seuil à venir
          priority = NotificationPriority.info;
          title = 'ℹ️ Entretien à planifier';
          body =
              'Le remplacement de $componentName est prévu dans $daysRemaining jours';
        }

        // Si une notification doit être envoyée
        if (priority != NotificationPriority.none) {
          // Créer un ID unique pour cette notification
          final int notificationId =
              '${immatriculation}_${dbField}_${now.day}'.hashCode;

          // Vérifier si une notification similaire a déjà été envoyée aujourd'hui
          final existingNotifications = await _supabase
              .from('maintenance_notifications')
              .select('id')
              .eq('immatriculation', immatriculation)
              .eq('component', dbField)
              .gte('created_at', DateFormat('yyyy-MM-dd').format(now));

          if (existingNotifications.isEmpty) {
            // Enregistrer la notification dans la base de données
            await _supabase.from('maintenance_notifications').insert({
              'user_id': user.id,
              'immatriculation': immatriculation,
              'component': dbField,
              'component_name': componentName,
              'maintenance_date': maintenanceDate.toIso8601String(),
              'days_remaining': daysRemaining,
              'priority': priority.name,
              'title': title,
              'body': body,
              'read': false,
              'created_at': now.toIso8601String(),
            });

            // Envoyer la notification locale
            await _localNotifications.show(
              notificationId,
              title,
              body,
              NotificationDetails(
                android: AndroidNotificationDetails(
                  _channelId,
                  _channelName,
                  channelDescription: _channelDescription,
                  importance: Importance.max,
                  priority: Priority.high,
                  color: _getPriorityColor(priority),
                ),
                iOS: const DarwinNotificationDetails(
                  presentAlert: true,
                  presentBadge: true,
                  presentSound: true,
                ),
              ),
              payload:
                  '{immatriculation: $immatriculation, component: $dbField}',
            );

            notificationsCount++;
            if (kDebugMode) {
              print('✅ Notification créée pour $componentName: $title');
            }
          } else {
            if (kDebugMode) {
              print(
                  'ℹ️ Notification déjà envoyée aujourd\'hui pour $componentName');
            }
          }
        }
      }

      return notificationsCount;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la vérification des dates de maintenance: $e');
      }
      return 0;
    }
  }

  /// Récupère les notifications non lues pour un véhicule
  Future<List<Map<String, dynamic>>> getUnreadNotifications(
      String immatriculation) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return [];

      final response = await _supabase
          .from('maintenance_notifications')
          .select('*')
          .eq('user_id', user.id)
          .eq('immatriculation', immatriculation)
          .eq('read', false)
          .order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la récupération des notifications: $e');
      }
      return [];
    }
  }

  /// Récupère toutes les notifications pour un véhicule
  Future<List<Map<String, dynamic>>> getAllNotifications(
      String immatriculation) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return [];

      final response = await _supabase
          .from('maintenance_notifications')
          .select('*')
          .eq('user_id', user.id)
          .eq('immatriculation', immatriculation)
          .order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la récupération des notifications: $e');
      }
      return [];
    }
  }

  /// Marque une notification comme lue
  Future<bool> markNotificationAsRead(int notificationId) async {
    try {
      await _supabase
          .from('maintenance_notifications')
          .update({'read': true}).eq('id', notificationId);

      return true;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors du marquage de la notification: $e');
      }
      return false;
    }
  }

  /// Récupère les alertes de maintenance pour affichage dans le dashboard
  Future<Map<String, MaintenanceAlert>> getMaintenanceAlerts(
      String immatriculation) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return {};

      // Vérifier si le véhicule existe
      final vehicleExists = await _supabase
          .from('voiture')
          .select('immatriculation')
          .eq('immatriculation', immatriculation)
          .maybeSingle();

      if (vehicleExists == null) {
        if (kDebugMode) {
          print(
              '❌ Aucun véhicule trouvé pour l’immatriculation $immatriculation');
        }
        return {};
      }

      // Récupérer les dates de maintenance
      final response = await _supabase
          .from('maintenance_dates')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      // Si aucune donnée n'est trouvée, retourner une map vide
      if (response == null) {
        if (kDebugMode) {
          print('ℹ️ Aucune date de maintenance trouvée pour $immatriculation');
        }
        // Créer un enregistrement vide
        await _createMaintenanceDatesRecord(immatriculation);
        return {};
      }

      final Map<String, dynamic> maintenanceDates = response;
      final Map<String, MaintenanceAlert> alerts = {};
      final DateTime now = DateTime.now();

      // Composants à vérifier
      final components = {
        'changement_batterie': 'Batterie',
        'changement_vidange': 'Vidange',
        'changement_freins': 'Freins',
        'changement_pneus': 'Pneus',
        'changement_amortisseurs': 'Amortisseurs',
        'changement_courroie': 'Courroie',
        'changement_embrayage': 'Embrayage',
      };

      // Vérifier chaque composant
      for (final entry in components.entries) {
        final String dbField = entry.key;
        final String componentName = entry.value;

        // Vérifier si la date existe
        if (maintenanceDates[dbField] == null) continue;

        final DateTime maintenanceDate =
            DateTime.parse(maintenanceDates[dbField]);
        final Duration difference = maintenanceDate.difference(now);
        final int daysRemaining = difference.inDays;

        // Déterminer le niveau de priorité
        NotificationPriority priority = NotificationPriority.none;

        if (difference.isNegative) {
          priority = NotificationPriority.critical;
        } else if (daysRemaining <= _criticalThreshold) {
          priority = NotificationPriority.critical;
        } else if (daysRemaining <= _warningThreshold) {
          priority = NotificationPriority.warning;
        } else if (daysRemaining <= _upcomingThreshold) {
          priority = NotificationPriority.info;
        } else {
          priority = NotificationPriority.normal;
        }

        // Créer l'alerte
        alerts[dbField] = MaintenanceAlert(
          component: dbField,
          componentName: componentName,
          daysRemaining: daysRemaining,
          maintenanceDate: maintenanceDate,
          priority: priority,
        );
      }

      return alerts;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la récupération des alertes: $e');
      }
      return {};
    }
  }

  /// Obtenir la couleur associée à une priorité
  Color _getPriorityColor(NotificationPriority priority) {
    switch (priority) {
      case NotificationPriority.critical:
        return Colors.red;
      case NotificationPriority.warning:
        return Colors.orange;
      case NotificationPriority.info:
        return Colors.blue;
      case NotificationPriority.normal:
        return Colors.green;
      case NotificationPriority.none:
        return Colors.grey;
    }
  }

  /// Crée un nouvel enregistrement de dates de maintenance pour un véhicule
  Future<void> _createMaintenanceDatesRecord(String immatriculation) async {
    try {
      if (kDebugMode) {
        print(
            'ℹ️ Création d\'un nouvel enregistrement de dates de maintenance pour $immatriculation');
      }

      // Vérifier si un enregistrement existe déjà
      final existingRecord = await _supabase
          .from('maintenance_dates')
          .select('id')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (existingRecord != null) {
        if (kDebugMode) {
          print('ℹ️ Un enregistrement existe déjà pour $immatriculation');
        }
        return;
      }

      // Obtenir les données du facteur pour estimer les dates
      final facteurData = await _supabase
          .from('facteur')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      final now = DateTime.now();

      // Utiliser les données du facteur pour estimer les dates si disponibles
      int kmParAn = 15000; // Valeur par défaut
      if (facteurData != null && facteurData['km_par_an'] != null) {
        kmParAn = facteurData['km_par_an'];
      }

      // Dates estimées basées sur le kilométrage annuel
      final defaultBatteryDate = now
          .add(Duration(days: (365 * 3)))
          .toIso8601String(); // 3 ans pour batterie
      final defaultVidangeDate = now
          .add(Duration(days: (365 * kmParAn / 15000).round()))
          .toIso8601String(); // ~1 an
      final defaultFreinsDate = now
          .add(Duration(days: (365 * kmParAn / 10000).round()))
          .toIso8601String(); // ~1.5 ans
      final defaultPneusDate = now
          .add(Duration(days: (365 * 2)))
          .toIso8601String(); // 2 ans pour pneus
      final defaultAmortisseursDate =
          now.add(Duration(days: (365 * 4))).toIso8601String(); // 4 ans
      final defaultCourroieDate =
          now.add(Duration(days: (365 * 5))).toIso8601String(); // 5 ans
      final defaultEmbrayageDate =
          now.add(Duration(days: (365 * 4))).toIso8601String(); // 4 ans

      // Créer un nouvel enregistrement avec les dates estimées
      await _supabase.from('maintenance_dates').insert({
        'fk_immatriculation': immatriculation,
        'changement_batterie': defaultBatteryDate,
        'changement_vidange': defaultVidangeDate,
        'changement_freins': defaultFreinsDate,
        'changement_pneus': defaultPneusDate,
        'changement_amortisseurs': defaultAmortisseursDate,
        'changement_courroie': defaultCourroieDate,
        'changement_embrayage': defaultEmbrayageDate,
        'created_at': now.toIso8601String(),
      });

      if (kDebugMode) {
        print(
            '✅ Enregistrement de dates de maintenance créé pour $immatriculation');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la création des dates de maintenance: $e');
      }
    }
  }

  /// Synchronise les dates de maintenance avec les prédictions d'usure pour l'immatriculation spécifiée
  Future<void> _syncMaintenanceDatesWithPredictions(
      String immatriculation) async {
    try {
      if (kDebugMode) {
        print(
            '🔄 Synchronisation des dates de maintenance avec les prédictions pour $immatriculation');
      }

      // Utiliser la méthode statique de DateManager pour mettre à jour les dates
      await DateManager.updateMaintenanceDatesFromPredictions(immatriculation);

      if (kDebugMode) {
        print(
            '✅ Synchronisation réussie des dates avec les prédictions pour $immatriculation');
      }
    } catch (e) {
      if (kDebugMode) {
        print(
            '❌ Erreur lors de la synchronisation des dates avec les prédictions: $e');
      }
      // Si erreur, créer un enregistrement avec les valeurs par défaut
      await _createMaintenanceDatesRecord(immatriculation);
    }
  }

  /// Récupère les dates de maintenance pour un véhicule
  Future<Map<String, dynamic>> getMaintenanceDates(
      String immatriculation) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return {};

      // Vérifier si le véhicule existe
      final vehicleExists = await _supabase
          .from('voiture')
          .select('immatriculation')
          .eq('immatriculation', immatriculation)
          .maybeSingle();

      if (vehicleExists == null) {
        if (kDebugMode) {
          print('❌ Aucun véhicule trouvé pour $immatriculation');
        }
        return {};
      }

      // Récupérer les dates de maintenance
      final response = await _supabase
          .from('maintenance_dates')
          .select('*')
          .eq('fk_immatriculation', immatriculation)
          .maybeSingle();

      if (response == null) {
        if (kDebugMode) {
          print('ℹ️ Aucune date de maintenance trouvée pour $immatriculation');
        }
        // Créer un enregistrement si nécessaire
        await _createMaintenanceDatesRecord(immatriculation);

        // Refaire la requête pour obtenir les nouvelles dates
        final newResponse = await _supabase
            .from('maintenance_dates')
            .select('*')
            .eq('fk_immatriculation', immatriculation)
            .maybeSingle();

        return newResponse ?? {};
      }

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la récupération des dates de maintenance: $e');
      }
      return {};
    }
  }
}

/// Niveaux de priorité des notifications
enum NotificationPriority {
  critical, // Urgent, action immédiate nécessaire
  warning, // Important, action nécessaire bientôt
  info, // Informatif, planification à prévoir
  normal, // Normal, aucune action urgente
  none // Pas de notification nécessaire
}

/// Classe pour les alertes de maintenance
class MaintenanceAlert {
  final String component;
  final String componentName;
  final int daysRemaining;
  final DateTime maintenanceDate;
  final NotificationPriority priority;

  MaintenanceAlert({
    required this.component,
    required this.componentName,
    required this.daysRemaining,
    required this.maintenanceDate,
    required this.priority,
  });

  /// Obtenir la couleur associée à la priorité
  Color get color {
    switch (priority) {
      case NotificationPriority.critical:
        return Colors.red;
      case NotificationPriority.warning:
        return Colors.orange;
      case NotificationPriority.info:
        return Colors.blue;
      case NotificationPriority.normal:
        return Colors.green;
      case NotificationPriority.none:
        return Colors.grey;
    }
  }

  /// Obtenir l'icône associée au composant
  IconData get icon {
    switch (component) {
      case 'changement_batterie':
        return Icons.battery_alert;
      case 'changement_vidange':
        return Icons.oil_barrel;
      case 'changement_freins':
        return Icons
            .warning_amber_rounded; // Remplacer brake_alert qui n'existe pas
      case 'changement_pneus':
        return Icons.cyclone; // Remplacer tire_repair qui n'existe pas
      case 'changement_amortisseurs':
        return Icons.alt_route;
      case 'changement_courroie':
        return Icons.linear_scale;
      case 'changement_embrayage':
        return Icons.settings;
      default:
        return Icons.build;
    }
  }

  /// Message à afficher à l'utilisateur
  String get message {
    if (daysRemaining < 0) {
      return 'Remplacement en retard de ${-daysRemaining} jours';
    } else if (daysRemaining == 0) {
      return 'Remplacement prévu aujourd\'hui';
    } else if (daysRemaining == 1) {
      return 'Remplacement prévu demain';
    } else {
      return 'Remplacement prévu dans $daysRemaining jours';
    }
  }

  /// Date formatée pour l'affichage
  String get formattedDate {
    return DateFormat('dd/MM/yyyy').format(maintenanceDate);
  }
}

/// Fonction globale pour le traitement des messages en arrière-plan
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  if (kDebugMode) {
    print('🔄 Traitement d\'un message en arrière-plan: ${message.messageId}');
  }
}

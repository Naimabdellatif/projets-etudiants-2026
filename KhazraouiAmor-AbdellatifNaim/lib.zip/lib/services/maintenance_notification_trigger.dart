import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'maintenance_notification_service.dart';

/// Cette classe permet de déclencher manuellement les vérifications de maintenance
/// depuis n'importe quel écran de l'application
class MaintenanceNotificationTrigger {
  // Singleton pattern
  static final MaintenanceNotificationTrigger _instance = MaintenanceNotificationTrigger._internal();
  final MaintenanceNotificationService _service = MaintenanceNotificationService();
  
  factory MaintenanceNotificationTrigger() {
    return _instance;
  }
  
  MaintenanceNotificationTrigger._internal();
  
  /// Force une vérification immédiate des notifications de maintenance pour aujourd'hui
  Future<void> forceMaintenanceCheck() async {
    if (kDebugMode) {
      print('Forçage manuel de la vérification des entretiens pour aujourd\'hui');
    }
    await _service.forceCheckMaintenanceForToday();
  }
  
  /// À appeler dans le initState() de votre écran de calendrier de maintenance
  static Future<void> checkOnMaintenanceScreenLoad(BuildContext context) async {
    if (kDebugMode) {
      print('Écran de maintenance chargé, vérification des notifications');
    }
    await MaintenanceNotificationTrigger().forceMaintenanceCheck();
  }
  
  /// À appeler lors de l'affichage du Tableau de bord
  static Future<void> checkOnDashboardLoad(BuildContext context) async {
    if (kDebugMode) {
      print('Tableau de bord chargé, vérification des notifications');
    }
    await MaintenanceNotificationTrigger().forceMaintenanceCheck();
  }
  
  /// À appeler au démarrage de l'application pour s'assurer que le service est initialisé
  static Future<void> ensureServiceInitialized() async {
    if (kDebugMode) {
      print('Initialisation du service de notification de maintenance...');
    }
    final service = MaintenanceNotificationService();
    await service.initialize();
    service.startDailyMaintenanceCheck();
    if (kDebugMode) {
      print('Service de notification de maintenance initialisé avec succès');
    }
  }
}

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/prediction_dossier_dart/date.dart';
import 'package:intl/intl.dart';

/// Service spécialisé pour les notifications contextuelles liées au véhicule actif
/// Déclenche des notifications lors de l'ouverture de l'app et l'accès au dashboard
class ContextualNotificationService {
  // Singleton
  static final ContextualNotificationService _instance = ContextualNotificationService._internal();
  factory ContextualNotificationService() => _instance;
  ContextualNotificationService._internal();
  
  // Services
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();
  final SupabaseClient _supabase = Supabase.instance.client;
  
  // Configuration
  static const String _channelId = 'contextual_maintenance_alerts';
  static const String _channelName = 'Alertes d\'entretien contextuelles';
  static const String _channelDescription = 'Notifications contextuelles pour le véhicule actif';
  
  // État du service
  bool _isInitialized = false;
  String? _lastCheckedImmatriculation;
  DateTime? _lastCheckTime;
  
  /// Initialise le service de notifications contextuelles
  Future<void> initialize() async {
    if (_isInitialized) return;
    
    // Initialiser les notifications locales
    const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings();
    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );
    
    await _localNotifications.initialize(initSettings);
    
    // Configurer le canal de notification Android
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDescription,
      importance: Importance.high,
    );
    
    await _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    
    _isInitialized = true;
    if (kDebugMode) {
      print('✅ Service de notifications contextuelles initialisé');
    }
  }
  
  /// MÉTHODE PRINCIPALE: Vérifie les dates de maintenance pour le véhicule sélectionné
  /// et envoie des notifications contextuelles si nécessaire
  /// 
  /// Cette méthode sera appelée:
  /// 1. À l'ouverture de l'application (main.dart)
  /// 2. Lors de l'accès au ClientDashboard
  /// 3. Lors de la sélection d'un véhicule
  /// 
  /// Paramètres:
  /// - immatriculation: L'immatriculation du véhicule actif
  /// - context: BuildContext pour afficher des SnackBars (facultatif)
  /// - forceCheck: Force une vérification même si déjà vérifiée récemment
  /// 
  /// Retourne le nombre de notifications envoyées
  Future<int> checkMaintenanceForActiveVehicle({
    required String immatriculation,
    BuildContext? context,
    bool forceCheck = false,
  }) async {
    if (!_isInitialized) await initialize();
    
    // Éviter les vérifications trop fréquentes pour la même immatriculation
    if (!forceCheck && 
        _lastCheckedImmatriculation == immatriculation && 
        _lastCheckTime != null &&
        DateTime.now().difference(_lastCheckTime!).inMinutes < 10) {
      if (kDebugMode) {
        print('⏭️ Vérification ignorée pour $immatriculation (déjà vérifiée récemment)');
      }
      return 0;
    }
    
    if (kDebugMode) {
      print('🔍 Vérification des alertes contextuelles pour $immatriculation');
    }
    _lastCheckedImmatriculation = immatriculation;
    _lastCheckTime = DateTime.now();
    
    try {
      // 1. Vérifier si des dates de maintenance existent pour ce véhicule
      // et les initialiser si nécessaire (comme dans le sélecteur de véhicules)
      final datesInitialized = await DateManager.verifyAndInitMaintenanceDates(immatriculation);
      if (!datesInitialized) {
        if (kDebugMode) {
          print('⚠️ Impossible d\'initialiser les dates de maintenance pour $immatriculation');
        }
        return 0;
      }
      
      // 2. Récupérer les dates de maintenance formatées
      final maintenanceDates = await DateManager.getFormattedMaintenanceDates(immatriculation);
      if (maintenanceDates.isEmpty) {
        if (kDebugMode) {
          print('ℹ️ Aucune date de maintenance trouvée pour $immatriculation');
        }
        return 0;
      }
      
      // 3. Vérifier les dates imminentes (dans les prochains jours)
      final now = DateTime.now();
      int notificationCount = 0;
      
      maintenanceDates.forEach((componentKey, date) {
        if (date == null) return;
        
        // Calculer le nombre de jours restants
        final daysRemaining = date.difference(now).inDays;
        
        // Définir le niveau de priorité en fonction des seuils
        // Ces seuils sont synchronisés avec DateManager
        String priority = 'normal';
        if (daysRemaining < 0) {
          priority = 'critical'; // En retard
        } else if (daysRemaining <= DateManager.criticalThreshold) {
          priority = 'critical'; // Très urgent (3 jours ou moins)
        } else if (daysRemaining <= DateManager.warningThreshold) {
          priority = 'warning'; // Urgent (7 jours ou moins)
        } else if (daysRemaining <= DateManager.upcomingThreshold) {
          priority = 'info'; // À venir (14 jours ou moins)
        } else {
          return; // Ignorer les dates trop lointaines
        }
        
        // Générer le message de notification
        final componentName = _getComponentDisplayName(componentKey);
        final formattedDate = DateFormat('dd/MM/yyyy').format(date);
        String title, body;
        
        if (daysRemaining < 0) {
          title = '🚨 Maintenance en retard!';
          body = 'Remplacement $componentName en retard de ${-daysRemaining} jour(s) pour $immatriculation';
        } else if (daysRemaining == 0) {
          title = '🔔 Maintenance aujourd\'hui!';
          body = 'Remplacement $componentName prévu aujourd\'hui pour $immatriculation';
        } else if (daysRemaining == 1) {
          title = '⚠️ Maintenance demain!';
          body = 'Remplacement $componentName prévu demain pour $immatriculation';
        } else {
          title = 'ℹ️ Maintenance à prévoir';
          body = 'Remplacement $componentName prévu dans $daysRemaining jours ($formattedDate) pour $immatriculation';
        }
        
        // Générer un ID unique pour cette notification basé sur l'immatriculation et le composant
        final notificationId = '${immatriculation}_$componentKey'.hashCode;
        
        // Sauvegarder les infos de la notification en base de données si haute priorité
        if (priority == 'critical' || priority == 'warning') {
          _saveNotificationToDatabase(
            immatriculation: immatriculation,
            componentKey: componentKey,
            title: title,
            body: body,
            priority: priority,
            daysRemaining: daysRemaining,
          );
        }
        
        // Envoyer la notification si elle est urgente ou critique
        if (priority == 'critical' || priority == 'warning') {
          _showNotification(
            id: notificationId,
            title: title,
            body: body,
            priority: priority,
          );
          notificationCount++;
        }
      });
      
      if (notificationCount > 0 && context != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$notificationCount alerte(s) de maintenance pour $immatriculation'),
            duration: Duration(seconds: 3),
          ),
        );
      }
      
      return notificationCount;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de la vérification des alertes contextuelles: $e');
      }
      return 0;
    }
  }
  
  /// Affiche une notification locale
  Future<void> _showNotification({
    required int id,
    required String title,
    required String body,
    required String priority,
  }) async {
    // Définir l'importance et la priorité en fonction du niveau d'urgence
    Importance importance = Importance.high;
    Priority notificationPriority = Priority.high;
    
    if (priority == 'critical') {
      importance = Importance.max;
      notificationPriority = Priority.max;
    } else if (priority == 'warning') {
      importance = Importance.high;
      notificationPriority = Priority.high;
    } else {
      importance = Importance.defaultImportance;
      notificationPriority = Priority.defaultPriority;
    }
    
    await _localNotifications.show(
      id,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDescription,
          importance: importance,
          priority: notificationPriority,
        ),
        iOS: const DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
    );
    
    if (kDebugMode) {
      print('🔔 Notification envoyée: $title');
    }
  }
  
  /// Sauvegarde une notification en base de données
  Future<void> _saveNotificationToDatabase({
    required String immatriculation,
    required String componentKey,
    required String title,
    required String body,
    required String priority,
    required int daysRemaining,
  }) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return;
      
      // Vérifier si une notification similaire existe déjà aujourd'hui
      final today = DateTime.now();
      final todayStr = DateFormat('yyyy-MM-dd').format(today);
      
      final existingNotifications = await _supabase
          .from('maintenance_notifications')
          .select('id')
          .eq('immatriculation', immatriculation)
          .eq('component_key', componentKey)
          .gte('created_at', '${todayStr}T00:00:00')
          .lte('created_at', '${todayStr}T23:59:59');
      
      if (existingNotifications.isNotEmpty) {
        if (kDebugMode) {
          print('ℹ️ Notification déjà existante pour $componentKey de $immatriculation aujourd\'hui');
        }
        return;
      }
      
      // Enregistrer la nouvelle notification
      await _supabase.from('maintenance_notifications').insert({
        'user_id': user.id,
        'immatriculation': immatriculation,
        'component_key': componentKey,
        'title': title,
        'body': body,
        'priority': priority,
        'days_remaining': daysRemaining,
        'read': false,
        'created_at': today.toIso8601String(),
      });
      
      if (kDebugMode) {
        print('💾 Notification enregistrée en base de données');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Erreur lors de l\'enregistrement de la notification: $e');
      }
    }
  }
  
  /// Obtient le nom d'affichage d'un composant à partir de sa clé
  String _getComponentDisplayName(String componentKey) {
    switch (componentKey) {
      case 'changement_batterie': return 'de la batterie';
      case 'changement_vidange': return 'de l\'huile';
      case 'changement_freins': return 'des freins';
      case 'changement_pneus': return 'des pneus';
      case 'changement_amortisseurs': return 'des amortisseurs';
      case 'changement_courroie': return 'de la courroie';
      case 'changement_embrayage': return 'de l\'embrayage';
      default: return 'de la pièce';
    }
  }
}

import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';

class MaintenanceNotificationService {
  static final MaintenanceNotificationService _instance =
      MaintenanceNotificationService._internal();
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  final SupabaseClient _supabase = Supabase.instance.client;

  // Singleton pattern
  factory MaintenanceNotificationService() {
    return _instance;
  }

  MaintenanceNotificationService._internal();

  Future<void> initialize() async {
    // Demander la permission pour les notifications
    NotificationSettings settings = await _firebaseMessaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      if (kDebugMode) {
        print('Notifications autorisées par l\'utilisateur');
      }
    }

    // Initialiser les notifications locales
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings();
    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(initSettings);

    // Configurer les canaux de notification pour Android
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'maintenance_alerts',
      'Alertes d\'entretien',
      description: 'Notifications pour les rappels d\'entretien de véhicule',
      importance: Importance.high,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    // Configurer les gestionnaires de messages Firebase
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    FirebaseMessaging.onBackgroundMessage(_handleBackgroundMessage);
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessageOpenedApp);
  }

  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    if (kDebugMode) {
      print('Message reçu en premier plan: ${message.notification?.title}');
    }
    _showLocalNotification(message);
  }

  static Future<void> _handleBackgroundMessage(RemoteMessage message) async {
    if (kDebugMode) {
      print('Message reçu en arrière-plan: ${message.notification?.title}');
    }
    // Le traitement en arrière-plan est simplifié car on ne peut pas accéder à beaucoup de services ici
  }

  void _handleMessageOpenedApp(RemoteMessage message) {
    if (kDebugMode) {
      print(
        'App ouverte depuis une notification: ${message.notification?.title}');
    }
    // Naviguer vers l'écran approprié quand l'utilisateur appuie sur la notification
  }

  Future<void> _showLocalNotification(RemoteMessage message) async {
    final RemoteNotification? notification = message.notification;
    final AndroidNotification? android = message.notification?.android;

    if (notification != null) {
      await _localNotifications.show(
        notification.hashCode,
        notification.title,
        notification.body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            'maintenance_alerts',
            'Alertes d\'entretien',
            channelDescription:
                'Notifications pour les rappels d\'entretien de véhicule',
            icon: android?.smallIcon,
            importance: Importance.max,
            priority: Priority.high,
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
      );
    }
  }

  // Vérifier les pièces qui nécessitent un remplacement et envoyer des notifications
  Future<void> checkMaintenanceNeeds({bool forceCheck = false}) async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return;

      // On suppose que les notifications sont activées par défaut
      // puisque la colonne notifications_enabled n'existe pas
      bool notificationsEnabled = true;

      try {
        final userProfile = await _supabase
            .from('client')
            .select('*')
            .eq('id', user.id)
            .single();

        // Si la colonne existe, on l'utilise; sinon on garde true
        notificationsEnabled = userProfile['notifications_enabled'] ?? true;
      } catch (e) {
        // Si erreur, on suppose que les notifications sont activées
        if (kDebugMode) {
          print('Impossible de vérifier le statut des notifications: $e');
        }
      }

      if (!notificationsEnabled && !forceCheck) {
        if (kDebugMode) {
          print(
              'Notifications désactivées par l\'utilisateur, vérification annulée');
        }
        return;
      }

      // Récupérer la date actuelle
      final DateTime now = DateTime.now();
      final DateTime twoWeeksLater = now.add(const Duration(days: 14));
      final String todayDate = DateFormat('yyyy-MM-dd').format(now);
      if (kDebugMode) {
        print('Vérification des entretiens pour le $todayDate');
      }

      final vehiculesResponse = await _supabase
          .from('user_vehicles')
          .select('id, immatriculation')
          .eq('user_id', user.id);

      final List<Map<String, dynamic>> vehicules =
          List<Map<String, dynamic>>.from(vehiculesResponse);
      if (kDebugMode) {
        print('Nombre de véhicules trouvés: ${vehicules.length}');
      }

      for (final vehicule in vehicules) {
        try {
          // Récupérer les dates de maintenance du véhicule
          final maintenanceDatesResponse = await _supabase
              .from('maintenance_dates')
              .select('*')
              .eq('fk_immatriculation', vehicule['immatriculation'])
              .single();

          // Vérifier chaque type de maintenance
          final maintenanceTypes = [
            {'nom': 'Batterie', 'date_field': 'changement_batterie'},
            {'nom': 'Amortisseurs', 'date_field': 'changement_amortisseurs'},
            {'nom': 'Embrayage', 'date_field': 'changement_embrayage'},
            {'nom': 'Freins', 'date_field': 'changement_freins'},
            {'nom': 'Courroie', 'date_field': 'changement_courroie'},
            {'nom': 'Vidange', 'date_field': 'changement_vidange'},
            {'nom': 'Pneus', 'date_field': 'changement_pneus'},
          ];

          for (final maintenance in maintenanceTypes) {
            final dateField = maintenance['date_field'];
            final String? dateStr = maintenanceDatesResponse[dateField];

            if (dateStr == null || dateStr.isEmpty) continue;

            final DateTime maintenanceDate = DateTime.parse(dateStr);

            // Si la date de maintenance est dans les 2 semaines à venir ou déjà passée
            if ((maintenanceDate.isAfter(now) &&
                    maintenanceDate.isBefore(twoWeeksLater)) ||
                maintenanceDate.isBefore(now)) {
              final bool isOverdue = maintenanceDate.isBefore(now);
              final String formattedDate =
                  DateFormat('dd/MM/yyyy').format(maintenanceDate);

              // Préparer le titre et le corps de la notification
              String title;
              String body;

              if (isOverdue) {
                title = 'Maintenance ${maintenance['nom']} en retard';
                body =
                    'Votre véhicule ${vehicule['immatriculation']} a une maintenance ${maintenance['nom']} en retard depuis le $formattedDate.';
              } else {
                title = 'Maintenance ${maintenance['nom']} à planifier';
                body =
                    'Votre véhicule ${vehicule['immatriculation']} nécessite une maintenance ${maintenance['nom']} le $formattedDate.';
              }

              if (kDebugMode) {
                print('$title: $body');
              }

              // Vérifier si une notification similaire existe déjà
              final existingNotifs = await _supabase
                  .from('notifications')
                  .select()
                  .eq('user_id', user.id)
                  .eq('type', 'maintenance')
                  .eq('vehicule_id', vehicule['id'])
                  .ilike('title', '%${maintenance['nom']}%');

              if (existingNotifs.isNotEmpty && !forceCheck) {
                if (kDebugMode) {
                  print('Une notification similaire existe déjà');
                }
                continue;
              }

              // Créer une notification dans la base de données
              await _supabase.from('app_notifications').insert({
                'user_id': user.id,
                'title': title,
                'body': body,
                'type': 'maintenance',
                'read': false,
                'vehicule_id': vehicule['id'],
                'piece_id': null, // On ne connaît pas l'id de la pièce ici, sauf si tu veux le mapper
                'created_at': DateTime.now().toIso8601String(),
              });
            }
          }
        } catch (e) {
          if (kDebugMode) {
            print(
                'Erreur lors de la vérification des dates de maintenance pour ${vehicule['immatriculation']}: $e');
          }
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors de la vérification des entretiens: $e');
      }
    }
  }

  // Forcer la création de notifications pour les pièces qui nécessitent un entretien
  Future<void> forceCheckMaintenanceForToday() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) return;

      // On suppose que les notifications sont activées par défaut
      // puisque la colonne notifications_enabled n'existe pas
      bool notificationsEnabled = true;

      try {
        final userProfile = await _supabase
            .from('client')
            .select('*')
            .eq('id', user.id)
            .single();

        // Si la colonne existe, on l'utilise; sinon on garde true
        notificationsEnabled = userProfile['notifications_enabled'] ?? true;
      } catch (e) {
        // Si erreur, on suppose que les notifications sont activées
        if (kDebugMode) {
          print('Impossible de vérifier le statut des notifications: $e');
        }
      }

      if (!notificationsEnabled) {
        if (kDebugMode) {
          print(
              'Notifications désactivées par l\'utilisateur, vérification annulée');
        }
        return;
      }

      // Récupérer la date actuelle et son format
      final DateTime now = DateTime.now();
      final String todayStr = DateFormat('yyyy-MM-dd').format(now);

      if (kDebugMode) {
        print('Vérification force de maintenance pour aujourd\'hui: $todayStr');
      }

      // Récupérer tous les véhicules de l'utilisateur
      final vehiculesResponse = await _supabase
          .from('user_vehicles')
          .select('id, immatriculation')
          .eq('user_id', user.id);

      final List<Map<String, dynamic>> vehicules =
          List<Map<String, dynamic>>.from(vehiculesResponse);
      if (kDebugMode) {
        print('Nombre de véhicules trouvés: ${vehicules.length}');
      }

      int notificationCount = 0;

      for (final vehicule in vehicules) {
        // Recherche de pièces qui doivent être remplacées aujourd'hui ou qui sont en retard
        final piecesResponse = await _supabase
            .from('pieces_vehicule')
            .select('id, nom, prochaine_maintenance')
            .eq('vehicule_id', vehicule['id'])
            // Recherche les pièces avec date d'aujourd'hui ou antérieure (retard)
            .lte('prochaine_maintenance', '${todayStr}T23:59:59');

        final List<Map<String, dynamic>> pieces =
            List<Map<String, dynamic>>.from(piecesResponse);
        if (kDebugMode) {
          print(
              'Pièces pour ${vehicule['immatriculation']} au $todayStr: ${pieces.length}');
        }

        for (final piece in pieces) {
          final DateTime maintenanceDate =
              DateTime.parse(piece['prochaine_maintenance']);
          final bool isOverdue = maintenanceDate.isBefore(now);
          final String formattedDate =
              DateFormat('dd/MM/yyyy').format(maintenanceDate);

          // Créer un message selon si la date est dépassée ou à aujourd'hui
          final String title = isOverdue
              ? 'Entretien en retard!'
              : 'Entretien à prévoir aujourd\'hui';

          final String body = isOverdue
              ? 'La pièce ${piece['nom']} du véhicule ${vehicule['immatriculation']} aurait dû être remplacée le $formattedDate.'
              : 'La pièce ${piece['nom']} du véhicule ${vehicule['immatriculation']} doit être remplacée aujourd\'hui.';

          if (kDebugMode) {
            print('Création de notification: $title - $body');
          }

          // Générer une notification unique avec un ID basé sur la pièce et la date
          final int notificationId =
              '${piece['id']}_${DateFormat('yyyyMMdd').format(now)}'.hashCode;

          // Envoyer la notification locale
          await _localNotifications.show(
            notificationId,
            title,
            body,
            NotificationDetails(
              android: const AndroidNotificationDetails(
                'maintenance_alerts',
                'Alertes d\'entretien',
                channelDescription:
                    'Notifications pour les rappels d\'entretien de véhicule',
                importance: Importance.max,
                priority: Priority.high,
              ),
              iOS: const DarwinNotificationDetails(),
            ),
          );

          // Enregistrer la notification dans Supabase s'il n'en existe pas déjà une pour cette pièce aujourd'hui
          final existingNotifications = await _supabase
              .from('app_notifications')
              .select('id')
              .eq('piece_id', piece['id'])
              .gte('created_at', '${todayStr}T00:00:00')
              .lte('created_at', '${todayStr}T23:59:59');

          if (existingNotifications.isEmpty) {
            await _supabase.from('app_notifications').insert({
              'user_id': user.id,
              'title': title,
              'body': body,
              'type': 'maintenance',
              'read': false,
              'piece_id': piece['id'],
              'vehicule_id': vehicule['id'],
              'created_at': DateTime.now().toIso8601String(),
            });
            notificationCount++;
          } else {
            if (kDebugMode) {
              print('Notification déjà existante pour cette pièce aujourd\'hui');
            }
          }
        }
      }

      if (kDebugMode) {
        print(
            'Vérification force terminée, $notificationCount nouvelles notifications créées');
      }
    } catch (e) {
      if (kDebugMode) {
        print(
            'Erreur lors de la vérification forcée des besoins de maintenance: $e');
      }
    }
  }

  // Méthode pour vérifier quotidiennement les besoins de maintenance
  void startDailyMaintenanceCheck() {
    // Vérifier immédiatement au démarrage
    if (kDebugMode) {
      print('Démarrage de la vérification de maintenance');
    }
    checkMaintenanceNeeds();

    // Vérification toutes les heures au lieu de juste à 8h
    Timer.periodic(const Duration(hours: 1), (timer) {
      if (kDebugMode) {
        print('Vérification périodique des entretiens');
      }
      checkMaintenanceNeeds();
    });
  }
}

// Fonction globale pour le traitement des messages en arrière-plan
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Nécessaire pour traiter les notifications en arrière-plan
  // Cette fonction doit être enregistrée dans main.dart
  if (kDebugMode) {
    print('Handling a background message: ${message.messageId}');
  }
}

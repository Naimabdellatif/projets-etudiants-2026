// MechanicChatService simplifié — redirige vers GeminiAiService.
// Conservé pour compatibilité des appels existants éventuels.

import '../ai_assistant/services/gemini_ai_service.dart';

/// @Deprecated — Utiliser GeminiAiService directement.
class MechanicChatService {
  static final GeminiAiService _ai = GeminiAiService();

  static void init(String serviceAccountJson) {}
  static void initWithDefaultAccount() {
    _ai.initialize();
  }

  static Future<String> getResponse(
      String message, String lang, String vehicleInfo) async {
    final response = await _ai.sendMessage(message, vehicleId: vehicleInfo);
    return response.text;
  }
}

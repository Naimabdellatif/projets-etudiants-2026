// ChatService simplifié — redirige vers GeminiAiService.

import '../ai_assistant/services/gemini_ai_service.dart';

class ChatService {
  static final GeminiAiService _ai = GeminiAiService();

  static void init(String serviceAccountJson) {}
  static void initWithDefaultAccount() {
    _ai.initialize();
  }
  static void resetSession() {}

  static Future<String> getResponse(String message, String lang) async {
    final response = await _ai.sendMessage(message, vehicleId: 'UNKNOWN');
    return response.text;
  }
}

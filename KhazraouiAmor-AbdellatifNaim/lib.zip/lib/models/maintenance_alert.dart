import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// Types de priorité pour les alertes de maintenance
enum NotificationPriority {
  critical,  // Rouge - Urgent (0-3 jours)
  warning,   // Orange - Important (4-7 jours)
  info,      // Jaune - À prévoir (8-14 jours)
  none       // Pas d'alerte
}

/// Classe pour gérer les alertes de maintenance
class MaintenanceAlert {
  final int id;
  final String componentKey;
  final String componentName;
  final DateTime maintenanceDate;
  final int daysRemaining;
  final NotificationPriority priority;
  final String title;
  final String message;
  final bool read;
  final Color color;
  final String formattedDate;

  MaintenanceAlert({
    required this.id,
    required this.componentKey,
    required this.componentName,
    required this.maintenanceDate,
    required this.daysRemaining,
    required this.priority,
    required this.title,
    required this.message,
    required this.read,
    Color? color,
    String? formattedDate,
  }) : 
    color = color ?? _getPriorityColor(priority),
    formattedDate = formattedDate ?? DateFormat('dd/MM/yyyy').format(maintenanceDate);

  /// Obtenir la couleur associée à la priorité
  static Color _getPriorityColor(NotificationPriority priority) {
    switch (priority) {
      case NotificationPriority.critical:
        return Colors.red;
      case NotificationPriority.warning:
        return Colors.orange;
      case NotificationPriority.info:
        return Colors.amber;
      case NotificationPriority.none:
        return Colors.grey;
    }
  }
}

// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:Carhabti/notif_details.dart';
import 'package:Carhabti/services/notification_manager.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  final Color _primaryColor = const Color(0xFF2E5D7E);
  final Color _accentColor = const Color(0xFF6A11CB);
  bool _notificationsEnabled = false;
  List<Map<String, dynamic>> _notifications = [];
  bool _isLoading = true;
  final NotificationManager _notificationManager = NotificationManager();

  @override
  void initState() {
    super.initState();
    _loadNotificationSettings();
    _fetchNotifications();
  }

  Future<void> _loadNotificationSettings() async {
    try {
      final enabled = await _notificationManager.areNotificationsEnabled();
      setState(() {
        _notificationsEnabled = enabled;
      });
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors du chargement des paramètres de notification: $e");
      }
      // Valeur par défaut en cas d'erreur
      setState(() {
        _notificationsEnabled = false;
      });
    }
  }

  Future<void> _updateNotificationSettings(bool value) async {
    try {
      final success = await _notificationManager.setNotificationsEnabled(value);
      if (success) {
        setState(() {
          _notificationsEnabled = value;
        });

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(value
                ? 'Notifications activées'
                : 'Notifications désactivées')));

        // Si on active les notifications, vérifier immédiatement les maintenances
        if (value) {
          _checkMaintenanceNow();
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors de la mise à jour des paramètres de notification: $e");
      }
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Erreur lors de la mise à jour des paramètres')));
    }
  }

  Future<void> _checkMaintenanceNow() async {
    try {
      setState(() => _isLoading = true);

      final count =
          await _notificationManager.checkMaintenanceNeeds(forceCheck: true);

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(count > 0
              ? '$count nouvelles notifications d\'entretien créées'
              : 'Aucun entretien requis pour le moment')));

      // Actualiser la liste des notifications
      await _fetchNotifications();
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors de la vérification des maintenances: $e");
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchNotifications() async {
    try {
      setState(() => _isLoading = true);

      final notifications = await _notificationManager.fetchUserNotifications();

      setState(() {
        _notifications = notifications;
        _isLoading = false;
      });
    } catch (e) {
      if (kDebugMode) {
        print("Erreur de récupération des notifications: $e");
      }
      setState(() => _isLoading = false);
    }
  }

  Future<void> _markAllAsRead() async {
    try {
      await _notificationManager.markAllNotificationsAsRead();
      await _fetchNotifications(); // Actualiser pour montrer les changements

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content:
              Text('Toutes les notifications ont été marquées comme lues')));
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors du marquage des notifications comme lues: $e");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, designSize: const Size(375, 812));

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 4,
        title: Text('Notifications',
            style: GoogleFonts.poppins(
                color: _primaryColor,
                fontWeight: FontWeight.w600,
                fontSize: 20.sp)),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: _primaryColor),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          // Bouton pour vérifier les notifications maintenant
          IconButton(
            icon: Icon(Icons.refresh, color: _primaryColor),
            onPressed: _checkMaintenanceNow,
            tooltip: 'Vérifier les entretiens maintenant',
          ),
          // Bouton pour marquer toutes les notifications comme lues
          if (_notifications.isNotEmpty)
            IconButton(
              icon: Icon(Icons.done_all, color: _primaryColor),
              onPressed: _markAllAsRead,
              tooltip: 'Marquer tout comme lu',
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _fetchNotifications,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.all(16.w),
                child: Column(
                  children: [
                    _buildSettingsCard(),
                    SizedBox(height: 20.h),
                    _buildNotificationsList(),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildSettingsCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text('Activer les notifications',
                      style: GoogleFonts.poppins(
                          fontSize: 16.sp, fontWeight: FontWeight.w500)),
                ),
                Switch(
                  value: _notificationsEnabled,
                  activeThumbColor: _accentColor,
                  onChanged: (value) => _updateNotificationSettings(value),
                ),
              ],
            ),
            if (_notificationsEnabled) ...[
              Divider(height: 24.h),
              ElevatedButton.icon(
                onPressed: _checkMaintenanceNow,
                icon: const Icon(Icons.sync),
                label: const Text('Vérifier les entretiens maintenant'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accentColor,
                  foregroundColor: Colors.white,
                  minimumSize: Size(double.infinity, 40.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationsList() {
    if (_notifications.isEmpty) {
      return SizedBox(
        height: 200.h,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.notifications_off,
                  size: 48.sp, color: Colors.grey[400]),
              SizedBox(height: 16.h),
              Text('Aucune notification disponible',
                  style: GoogleFonts.poppins(
                      color: Colors.grey[600], fontSize: 16.sp)),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Historique des notifications',
                style: GoogleFonts.poppins(
                    fontSize: 18.sp, fontWeight: FontWeight.w600)),
            if (_notifications.isNotEmpty)
              TextButton.icon(
                onPressed: _markAllAsRead,
                icon: Icon(Icons.done_all, size: 16.sp, color: _accentColor),
                label: Text('Tout marquer comme lu',
                    style: GoogleFonts.poppins(
                        fontSize: 12.sp, color: _accentColor)),
              ),
          ],
        ),
        SizedBox(height: 10.h),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _notifications.length,
          separatorBuilder: (context, index) => Divider(),
          itemBuilder: (context, index) {
            final notification = _notifications[index];
            // Ajouter des vérifications de nullité pour éviter les erreurs
            final String title =
                notification['title']?.toString() ?? 'Notification';
            final String body = notification['body']?.toString() ?? '';
            final String createdAt = notification['created_at']?.toString() ??
                DateTime.now().toIso8601String();
            final String type = notification['type']?.toString() ?? 'default';
            final bool isRead = notification['read'] ?? false;

            return Card(
              elevation: isRead ? 1 : 3,
              margin: EdgeInsets.symmetric(vertical: 4.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.r),
                side: isRead
                    ? BorderSide.none
                    : BorderSide(
                        color: _accentColor.withOpacity(0.3), width: 1),
              ),
              child: ListTile(
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                leading: CircleAvatar(
                  backgroundColor:
                      isRead ? Colors.grey[200] : _accentColor.withOpacity(0.2),
                  child: Icon(_getNotificationIcon(type),
                      color: isRead ? Colors.grey[600] : _accentColor),
                ),
                title: Text(title,
                    style: GoogleFonts.poppins(
                      fontSize: 14.sp,
                      fontWeight: isRead ? FontWeight.normal : FontWeight.w600,
                    )),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 4.h),
                    Text(body,
                        style: GoogleFonts.poppins(fontSize: 12.sp),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    SizedBox(height: 4.h),
                    Text(
                        DateFormat('dd/MM/yyyy à HH:mm')
                            .format(DateTime.parse(createdAt)),
                        style: GoogleFonts.poppins(
                            fontSize: 11.sp,
                            color: Colors.grey[600],
                            fontStyle: FontStyle.italic)),
                  ],
                ),
                trailing: Icon(Icons.chevron_right, color: _primaryColor),
                onTap: () => _handleNotificationTap(notification),
              ),
            );
          },
        ),
      ],
    );
  }

  IconData _getNotificationIcon(String type) {
    switch (type) {
      case 'alert':
        return Icons.warning;
      case 'maintenance':
        return Icons.build;
      case 'rendez_vous_confirme':
        return Icons.event_available_rounded;
      case 'rendez_vous_annule':
        return Icons.event_busy_rounded;
      case 'info':
        return Icons.info;
      default:
        return Icons.notifications;
    }
  }

  void _handleNotificationTap(Map<String, dynamic> notification) async {
    try {
      // Naviguer vers l'écran de détails de la notification
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => NotificationDetailsScreen(
            notification: notification,
          ),
        ),
      );

      // Si la notification a été marquée comme lue, actualiser la liste
      if (result == true) {
        _fetchNotifications();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors de la navigation vers les détails: $e');
      }
    }
  }
}

// ignore_for_file: use_build_context_synchronously

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// u00c9cran de du00e9tails d'une notification
class NotificationDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> notification;

  const NotificationDetailsScreen({super.key, required this.notification});

  @override
  State<NotificationDetailsScreen> createState() =>
      _NotificationDetailsScreenState();
}

class _NotificationDetailsScreenState extends State<NotificationDetailsScreen> {
  final Color _primaryColor = const Color(0xFF2E5D7E);
  final Color _accentColor = const Color(0xFF6A11CB);

  bool _isLoading = true;
  Map<String, dynamic>? _pieceDetails;
  Map<String, dynamic>? _vehiculeDetails;

  @override
  void initState() {
    super.initState();
    _loadAdditionalData();
  }

  /// Charge les du00e9tails supplu00e9mentaires de la piu00e8ce et du vu00e9hicule
  Future<void> _loadAdditionalData() async {
    try {
      setState(() => _isLoading = true);

      final supabase = Supabase.instance.client;
      final pieceId = widget.notification['piece_id'];
      final vehiculeId = widget.notification['vehicule_id'];

      // Ru00e9cupu00e9rer les du00e9tails de la piu00e8ce
      if (pieceId != null) {
        final pieceResponse = await supabase
            .from('pieces_vehicule')
            .select('*')
            .eq('id', pieceId)
            .single();

        setState(() => _pieceDetails = pieceResponse);
      }

      // Ru00e9cupu00e9rer les du00e9tails du vu00e9hicule
      if (vehiculeId != null) {
        final vehiculeResponse = await supabase
            .from('voiture')
            .select('*')
            .eq('id', vehiculeId)
            .single();

        setState(() => _vehiculeDetails = vehiculeResponse);
      }
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors du chargement des du00e9tails: $e');
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, designSize: const Size(375, 812));

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 4,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: _primaryColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Du00e9tails de la notification',
          style: GoogleFonts.poppins(
            color: _primaryColor,
            fontWeight: FontWeight.w600,
            fontSize: 20.sp,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Carte d'information principale
          _buildNotificationCard(),
          SizedBox(height: 24.h),

          // Du00e9tails de la piu00e8ce si disponible
          if (_pieceDetails != null) _buildPieceDetails(),

          // Du00e9tails du vu00e9hicule si disponible
          if (_vehiculeDetails != null) ...[
            SizedBox(height: 24.h),
            _buildVehiculeDetails()
          ],

          // Actions
          SizedBox(height: 40.h),
          _buildActionButtons(),
        ],
      ),
    );
  }

  Widget _buildNotificationCard() {
    final DateTime createdAt =
        DateTime.parse(widget.notification['created_at']);
    final String formattedDate =
        DateFormat('dd MMMM yyyy u00e0 HH:mm', 'fr_FR').format(createdAt);

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                    _getNotificationIcon(
                        widget.notification['type'] ?? 'default'),
                    size: 32.w,
                    color: _accentColor),
                SizedBox(width: 12.w),
                Expanded(
                  child: Text(
                    widget.notification['title'] ?? 'Notification',
                    style: GoogleFonts.poppins(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w600,
                      color: _primaryColor,
                    ),
                  ),
                ),
              ],
            ),
            Divider(height: 24.h),
            Text(
              widget.notification['body'] ?? '',
              style: GoogleFonts.poppins(fontSize: 16.sp),
            ),
            SizedBox(height: 16.h),
            Text(
              'Reu00e7u le $formattedDate',
              style: GoogleFonts.poppins(
                fontSize: 13.sp,
                color: Colors.grey[600],
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPieceDetails() {
    if (_pieceDetails == null) return const SizedBox.shrink();

    // Extraire les du00e9tails pertinents
    final String nom = _pieceDetails?['nom'] ?? 'Inconnue';
    final DateTime? derniereDate =
        _pieceDetails?['derniere_maintenance'] != null
            ? DateTime.parse(_pieceDetails!['derniere_maintenance'])
            : null;
    final DateTime? prochaineDate =
        _pieceDetails?['prochaine_maintenance'] != null
            ? DateTime.parse(_pieceDetails!['prochaine_maintenance'])
            : null;

    // Calculer l'urgence
    final bool isUrgent = prochaineDate != null &&
        (prochaineDate.isBefore(DateTime.now().add(const Duration(days: 7))) ||
            prochaineDate.isBefore(DateTime.now()));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Du00e9tails de la piu00e8ce',
          style: GoogleFonts.poppins(
            fontSize: 20.sp,
            fontWeight: FontWeight.w600,
            color: _primaryColor,
          ),
        ),
        SizedBox(height: 12.h),
        Card(
          elevation: 3,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
          child: Padding(
            padding: EdgeInsets.all(16.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailRow('Nom de la piu00e8ce', nom),
                SizedBox(height: 8.h),
                if (derniereDate != null)
                  _buildDetailRow(
                    'Dernier entretien',
                    DateFormat('dd/MM/yyyy').format(derniereDate),
                  ),
                SizedBox(height: 8.h),
                if (prochaineDate != null)
                  _buildDetailRow(
                    'Prochain entretien',
                    DateFormat('dd/MM/yyyy').format(prochaineDate),
                    isHighlighted: isUrgent,
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildVehiculeDetails() {
    if (_vehiculeDetails == null) return const SizedBox.shrink();

    // Extraire les du00e9tails pertinents
    final String immatriculation = _vehiculeDetails?['immatriculation'] ?? '';
    final String marque = _vehiculeDetails?['marque'] ?? 'Inconnue';
    final String modele = _vehiculeDetails?['modele'] ?? 'Inconnu';
    final int? annee = _vehiculeDetails?['annee'];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Du00e9tails du vu00e9hicule',
          style: GoogleFonts.poppins(
            fontSize: 20.sp,
            fontWeight: FontWeight.w600,
            color: _primaryColor,
          ),
        ),
        SizedBox(height: 12.h),
        Card(
          elevation: 3,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
          child: Padding(
            padding: EdgeInsets.all(16.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailRow('Immatriculation', immatriculation),
                SizedBox(height: 8.h),
                _buildDetailRow('Marque', marque),
                SizedBox(height: 8.h),
                _buildDetailRow('Modu00e8le', modele),
                if (annee != null) ...[
                  SizedBox(height: 8.h),
                  _buildDetailRow('Annu00e9e', annee.toString())
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDetailRow(String label, String value,
      {bool isHighlighted = false}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
            width: 120.w,
            child: Text(label,
                style: GoogleFonts.poppins(fontWeight: FontWeight.w500))),
        Expanded(
          child: Text(
            value,
            style: GoogleFonts.poppins(
              fontWeight: isHighlighted ? FontWeight.w600 : FontWeight.w400,
              color: isHighlighted ? Colors.red : null,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (_pieceDetails != null && _vehiculeDetails != null)
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _navigateToPieceDetails(),
              icon: const Icon(Icons.build),
              label: const Text('Gu00e9rer cette piu00e8ce'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _accentColor,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 12.h),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.r)),
              ),
            ),
          ),
        SizedBox(width: 12.w),
        IconButton(
          onPressed: () => _markAsRead(),
          icon: const Icon(Icons.check_circle_outline),
          tooltip: 'Marquer comme lu',
          color: Colors.green,
        ),
      ],
    );
  }

  void _navigateToPieceDetails() {
    // Navigation vers l'u00e9cran de gestion de la piu00e8ce spu00e9cifique
    final String? pieceNom = _pieceDetails?['nom']?.toString().toLowerCase();
    final String? immatriculation = _vehiculeDetails?['immatriculation'];

    if (pieceNom == null || immatriculation == null) return;

    String route = '';

    // Du00e9terminer la route en fonction du type de piu00e8ce
    if (pieceNom.contains('pneu')) {
      route = '/pneus';
    } else if (pieceNom.contains('vidange') || pieceNom.contains('huile')) {
      route = '/vidange';
    } else if (pieceNom.contains('batterie')) {
      route = '/batterie';
    } else if (pieceNom.contains('amortisseur')) {
      route = '/amortisseurs';
    } else if (pieceNom.contains('frein')) {
      route = '/freins';
    } else if (pieceNom.contains('courroie')) {
      route = '/courroie';
    } else if (pieceNom.contains('embrayage')) {
      route = '/embrayage';
    } else {
      // Route gu00e9nu00e9rique vers le dashboard du vu00e9hicule
      route = '/dashboard';
    }

    Navigator.pushNamed(
      context,
      route,
      arguments: immatriculation,
    );
  }

  void _markAsRead() async {
    try {
      final supabase = Supabase.instance.client;
      final notificationId = widget.notification['id'];

      if (notificationId != null) {
        await supabase
            .from('notifications')
            .update({'read': true}).eq('id', notificationId);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Notification marquée comme lue')),
        );

        Navigator.pop(context,
            true); // Retourner avec résultat pour rafraîchir la liste
      }
    } catch (e) {
      if (kDebugMode) {
        print('Erreur lors du marquage de la notification comme lue: $e');
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur lors du marquage comme lu')),
      );
    }
  }

  IconData _getNotificationIcon(String type) {
    switch (type) {
      case 'maintenance':
        return Icons.build;
      case 'alert':
        return Icons.warning;
      case 'info':
        return Icons.info;
      default:
        return Icons.notifications;
    }
  }
}

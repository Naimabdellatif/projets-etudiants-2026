import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Notifications")),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text("Notifications push"),
            value: true,
            onChanged: (val) {},
          ),
          SwitchListTile(
            title: const Text("Mises à jour par email"),
            value: false,
            onChanged: (val) {},
          ),
        ],
      ),
    );
  }
}

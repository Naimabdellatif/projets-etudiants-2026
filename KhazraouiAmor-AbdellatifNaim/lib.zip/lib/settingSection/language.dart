// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';

class LanguageScreen extends StatefulWidget {
  const LanguageScreen({super.key});

  @override
  State<LanguageScreen> createState() => _LanguageScreenState();
}

class _LanguageScreenState extends State<LanguageScreen> {
  String _selectedLanguage = 'fr';

  final Map<String, String> _languages = {
    'fr': 'Français',
    'en': 'English',
    'es': 'Español',
  };

  void _changeLanguage(String? code) {
    if (code == null) return;
    setState(() {
      _selectedLanguage = code;
    });

    // Exemple avec easy_localization :
    // context.setLocale(Locale(code));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Langue')),
      body: ListView(
        children: _languages.entries.map((entry) {
          final code = entry.key;
          final name = entry.value;
          return RadioListTile<String>(
            title: Text(name),
            value: code,
            groupValue: _selectedLanguage,
            onChanged: _changeLanguage,
          );
        }).toList(),
      ),
    );
  }
}

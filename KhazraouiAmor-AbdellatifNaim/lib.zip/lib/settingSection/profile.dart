import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:Carhabti_web/interfaces/GetStarted.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mon Profil"),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(
                radius: 50, backgroundImage: AssetImage('assets/user.png')),
            const SizedBox(height: 20),
            Text("Nom d'utilisateur",
                style: GoogleFonts.poppins(
                    fontSize: 22, fontWeight: FontWeight.w600)),
            Text("email@exemple.com",
                style: GoogleFonts.poppins(color: Colors.grey)),
            const SizedBox(height: 30),
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text("Modifier le profil"),
              onTap: () {},
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text("Déconnexion"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Getstarted()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

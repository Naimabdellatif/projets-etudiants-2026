import 'package:flutter/material.dart';

class SecurityScreen extends StatelessWidget {
  const SecurityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Sécurité")),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const ListTile(
            leading: Icon(Icons.lock_outline),
            title: Text("Changer le mot de passe"),
          ),
          const Divider(),
          SwitchListTile(
            title: const Text("Authentification à deux facteurs"),
            value: true,
            onChanged: (bool value) {},
          ),
        ],
      ),
    );
  }
}

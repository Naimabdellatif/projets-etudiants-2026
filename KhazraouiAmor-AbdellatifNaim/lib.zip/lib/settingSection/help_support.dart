import 'package:flutter/material.dart';

class HelpSupportScreen extends StatelessWidget {
  const HelpSupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Aide & Support")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("FAQ", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const ListTile(
              title: Text("Comment réinitialiser mon mot de passe ?"),
              subtitle: Text("Allez dans les paramètres de sécurité pour le faire."),
            ),
            const Divider(),
            const Text("Contact", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const ListTile(
              leading: Icon(Icons.email_outlined),
              title: Text("Envoyer un email"),
              subtitle: Text("support@tonapp.com"),
            ),
          ],
        ),
      ),
    );
  }
}

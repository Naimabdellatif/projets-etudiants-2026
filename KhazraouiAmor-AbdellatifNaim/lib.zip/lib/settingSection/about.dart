import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Future<String> _getAppVersion() async {
    final info = await PackageInfo.fromPlatform();
    return "${info.version} (${info.buildNumber})";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("À propos")),
      body: FutureBuilder<String>(
        future: _getAppVersion(),
        builder: (context, snapshot) {
          final version = snapshot.data ?? '...';
          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Assistant Virtuel",
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Text("Version: $version"),
                const SizedBox(height: 20),
                const Text(
                    "Cette application vous aide à gérer votre véhicule efficacement."),
                const Spacer(),
                const Center(
                    child: Text("© 2026 CARHABTI. Tous droits réservés.")),
              ],
            ),
          );
        },
      ),
    );
  }
}

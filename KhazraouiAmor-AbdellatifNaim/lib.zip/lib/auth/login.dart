// ignore_for_file: deprecated_member_use, unused_field

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/interfaces/ClientDashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:carhabti/magasin_model/carhabti_theme.dart';

class LoginScreen extends StatefulWidget {
  final String? immatriculation;

  const LoginScreen({super.key, this.immatriculation});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  // "Se souvenir de moi" : toujours activé
  final bool _rememberMe = true;

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  late AnimationController _logoController;
  late AnimationController _contentController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final _emailController    = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  bool _isLoading       = false;

  final FocusNode _emailFocus    = FocusNode();
  final FocusNode _passwordFocus = FocusNode();
  bool _emailFocused    = false;
  bool _passwordFocused = false;

  // ── Connexion ──────────────────────────────────────────────────────────────
  Future<void> _login() async {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      _showSnackBar(
        "Veuillez remplir tous les champs",
        Icons.error_outline,
        KTheme.danger,
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final AuthResponse response =
          await Supabase.instance.client.auth.signInWithPassword(
        email:    _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      if (response.user != null) {
        // Se souvenir de moi est toujours actif
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('saved_email', _emailController.text.trim());
        await _secureStorage.write(
          key:      'password',
          value:    _passwordController.text.trim(),
          aOptions: AndroidOptions(encryptedSharedPreferences: true),
        );

        final targetImmatriculation = widget.immatriculation;

        if (targetImmatriculation != null) {
          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  ClientDashboard(immatriculation: targetImmatriculation),
            ),
          );
        } else {
          final clientResponse = await Supabase.instance.client
              .from('user_vehicles')
              .select('immatriculation')
              .eq('user_id', response.user!.id);

          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => ClientDashboard(
                immatriculation: clientResponse.isNotEmpty
                    ? clientResponse[0]['immatriculation'] as String
                    : 'default',
              ),
            ),
          );
        }
      }
    } on AuthException catch (e) {
      if (!mounted) return;
      _showSnackBar('Erreur: ${e.message}', Icons.warning_amber_rounded,
          KTheme.danger);
    } catch (e) {
      if (!mounted) return;
      _showSnackBar(
          'Erreur de connexion: $e', Icons.info_outline, KTheme.turquoise);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnackBar(String msg, IconData icon, Color bg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: GoogleFonts.poppins(fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
        backgroundColor: bg,
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ── Cycle de vie ────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _loadSavedCredentials();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    );
    _contentController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _scaleAnimation = CurvedAnimation(
      parent: _logoController,
      curve: Curves.elasticOut,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _contentController,
      curve: Curves.easeIn,
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.25),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _contentController,
      curve: Curves.easeOutCubic,
    ));

    _logoController.forward();
    Future.delayed(const Duration(milliseconds: 250),
        () => _contentController.forward());

    _emailFocus.addListener(
        () => setState(() => _emailFocused = _emailFocus.hasFocus));
    _passwordFocus.addListener(
        () => setState(() => _passwordFocused = _passwordFocus.hasFocus));
  }

  Future<void> _loadSavedCredentials() async {
    final prefs   = await SharedPreferences.getInstance();
    final email   = prefs.getString('saved_email');
    final password = await _secureStorage.read(
      key:      'password',
      aOptions: AndroidOptions(encryptedSharedPreferences: true),
    );
    if (email != null)    _emailController.text    = email;
    if (password != null) _passwordController.text = password;
  }

  @override
  void dispose() {
    _logoController.dispose();
    _contentController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    super.dispose();
  }

  // ── UI ──────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KTheme.surface,
      body: Stack(
        children: [
          // Blob décoratif en haut
          Positioned(
            top: -80,
            left: -60,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: KTheme.turquoise.withOpacity(0.18),
              ),
            ),
          ),
          Positioned(
            top: 40,
            right: -40,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: KTheme.cyan.withOpacity(0.12),
              ),
            ),
          ),
          // Petit accent navy en bas
          Positioned(
            bottom: -60,
            left: -30,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: KTheme.navy.withOpacity(0.06),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24.0, vertical: 12),
                child: Column(
                  children: [
                    const SizedBox(height: 16),

                    // ── Logo (Hero cohérent avec GetStarted & SignUp) ─────────
                    ScaleTransition(
                      scale: _scaleAnimation,
                      child: SizedBox(
                        height: 190,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            // Cercle pulsant extérieur
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0.9, end: 1.05),
                              duration: const Duration(seconds: 2),
                              curve: Curves.easeInOut,
                              builder: (_, v, __) => Container(
                                width: 170 * v,
                                height: 170 * v,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: KTheme.turquoise.withOpacity(0.08),
                                ),
                              ),
                            ),
                            // Cercle intérieur — Hero tag
                            Hero(
                              tag: 'background-circle',
                              child: Container(
                                width: 140,
                                height: 140,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      KTheme.cyan.withOpacity(0.22),
                                      KTheme.turquoise.withOpacity(0.16),
                                    ],
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: KTheme.turquoise.withOpacity(0.15),
                                      blurRadius: 24,
                                      spreadRadius: 4,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            // Logo — Hero tag
                            Hero(
                              tag: 'bike-image',
                              child: Image.asset(
                                'assets/LOGO_CARHABTI.png',
                                width: 160,
                                fit: BoxFit.contain,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 8),

                    // Nom de la marque
                    FadeTransition(
                      opacity: _fadeAnimation,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'CARHABTI',
                            style: GoogleFonts.poppins(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: KTheme.textPrimary,
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Container(
                            width: 7,
                            height: 7,
                            decoration: const BoxDecoration(
                              color: KTheme.yellow,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 28),

                    // ── Carte de connexion ────────────────────────────────────
                    FadeTransition(
                      opacity: _fadeAnimation,
                      child: SlideTransition(
                        position: _slideAnimation,
                        child: Container(
                          padding: const EdgeInsets.all(28),
                          decoration: BoxDecoration(
                            color: KTheme.card,
                            borderRadius: BorderRadius.circular(KTheme.radiusXL),
                            boxShadow: [
                              BoxShadow(
                                color: KTheme.turquoise.withOpacity(0.10),
                                blurRadius: 40,
                                spreadRadius: 0,
                                offset: const Offset(0, 16),
                              ),
                              BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 20,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Titre
                              Text(
                                "Bon retour 👋",
                                style: KTheme.headingXL.copyWith(
                                  fontSize: 26,
                                  height: 1.2,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                "Connectez-vous pour continuer",
                                style: KTheme.bodyMD,
                              ),

                              const SizedBox(height: 28),

                              // Champ e-mail
                              KInputField(
                                controller: _emailController,
                                focusNode:  _emailFocus,
                                prefixIcon: Icons.mail_outline_rounded,
                                hint: "Adresse e-mail",
                                isFocused: _emailFocused,
                                keyboardType: TextInputType.emailAddress,
                              ),
                              const SizedBox(height: 14),

                              // Champ mot de passe
                              KInputField(
                                controller: _passwordController,
                                focusNode:  _passwordFocus,
                                prefixIcon: Icons.lock_outline_rounded,
                                hint: "Mot de passe",
                                obscureText: _obscurePassword,
                                isFocused: _passwordFocused,
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    _obscurePassword
                                        ? Icons.visibility_off_outlined
                                        : Icons.visibility_outlined,
                                    color: _passwordFocused
                                        ? KTheme.turquoise
                                        : KTheme.textLight,
                                    size: 22,
                                  ),
                                  onPressed: () => setState(
                                      () => _obscurePassword = !_obscurePassword),
                                ),
                              ),
                              const SizedBox(height: 14),

                              // Rangée : Se souvenir de moi + Mot de passe oublié
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  _buildRememberMe(),
                                  TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                    ),
                                    child: Text(
                                      "Mot de passe oublié ?",
                                      style: GoogleFonts.poppins(
                                        color: KTheme.turquoise,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 24),

                              // Bouton Se connecter
                              KGradientButton(
                                label: "Se connecter",
                                icon: Icons.arrow_forward_rounded,
                                isLoading: _isLoading,
                                onTap: _login,
                              ),

                              const SizedBox(height: 26),

                              // Séparateur "Ou continuer avec"
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(colors: [
                                          Colors.transparent,
                                          KTheme.border,
                                        ]),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 14),
                                    child: Text(
                                      "Ou continuer avec",
                                      style: KTheme.labelSM,
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(colors: [
                                          KTheme.border,
                                          Colors.transparent,
                                        ]),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 22),

                              // Boutons sociaux
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  _buildSocialButton(
                                      'assets/google.svg',
                                      const Color(0xFFDB4437)),
                                  const SizedBox(width: 14),
                                  _buildSocialButton(
                                      'assets/facebook.svg',
                                      const Color(0xFF4267B2)),
                                  const SizedBox(width: 14),
                                  _buildSocialButton(
                                      'assets/apple.svg',
                                      const Color(0xFF000000)),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 28),

                    // Lien vers inscription
                    FadeTransition(
                      opacity: _fadeAnimation,
                      child: TextButton(
                        onPressed: () =>
                            Navigator.pushNamed(context, '/signup'),
                        style: TextButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          backgroundColor: KTheme.turquoise.withOpacity(0.12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: RichText(
                          text: TextSpan(
                            text: "Nouveau ici ?  ",
                            style: GoogleFonts.poppins(
                              color: KTheme.textSecondary,
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                            ),
                            children: [
                              TextSpan(
                                text: "Créer un compte",
                                style: GoogleFonts.poppins(
                                  color: KTheme.turquoise,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Widgets helpers ─────────────────────────────────────────────────────────

  /// "Se souvenir de moi" — toujours coché, non interactif
  Widget _buildRememberMe() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            gradient: KTheme.ctaGradient,
          ),
          child: const Icon(Icons.check, size: 14, color: Colors.white),
        ),
        const SizedBox(width: 8),
        Text(
          "Se souvenir de moi",
          style: GoogleFonts.poppins(
            fontSize: 13,
            color: KTheme.textSecondary,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildSocialButton(String asset, Color accent) {
    return Container(
      width: 54,
      height: 54,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: KTheme.borderLight, width: 1.5),
        boxShadow: KTheme.elevationLow,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {},
          borderRadius: BorderRadius.circular(14),
          splashColor: accent.withOpacity(0.08),
          child: Center(
            child: SvgPicture.asset(asset, height: 24, width: 24),
          ),
        ),
      ),
    );
  }
}
// Fichier: auth/SignUp.dart
// ignore_for_file: use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:carhabti/pieces_form/vehicule_form.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:carhabti/magasin_model/carhabti_theme.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> with SingleTickerProviderStateMixin {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _phoneController = TextEditingController();
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  String _clientType = 'propriétaire';
  String _phoneNumber = '';
  late AnimationController _animationController;
  final _formKey = GlobalKey<FormState>();
  bool _isProcessing = false;

  final List<String> _clientTypes = ['propriétaire', 'professionnel'];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _phoneController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: KTheme.surface,
      body: Stack(
        children: [
          // Fond avec gradient subtil
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [
                  Colors.white,
                  KTheme.surface,
                  KTheme.turquoise.withOpacity(0.05),
                ],
              ),
            ),
          ),

          // Bulles décoratives
          Positioned(
            top: -screenSize.height * 0.1,
            right: -screenSize.width * 0.2,
            child: _buildAnimatedBubble(
              size: screenSize.width * 0.4,
              color: KTheme.turquoise.withOpacity(0.08),
              delay: 0.1,
            ),
          ),
          Positioned(
            bottom: screenSize.height * 0.3,
            left: -screenSize.width * 0.15,
            child: _buildAnimatedBubble(
              size: screenSize.width * 0.3,
              color: KTheme.cyan.withOpacity(0.06),
              delay: 0.3,
            ),
          ),
          Positioned(
            bottom: -40,
            right: -30,
            child: _buildAnimatedBubble(
              size: screenSize.width * 0.35,
              color: KTheme.navy.withOpacity(0.04),
              delay: 0.2,
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),

                      // Bouton retour
                      _buildAnimatedFormField(
                        delay: 0.0,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(KTheme.radiusSM),
                            boxShadow: KTheme.elevationLow,
                          ),
                          child: IconButton(
                            icon: Icon(Icons.arrow_back_ios_new_rounded,
                                color: KTheme.textPrimary.withOpacity(0.7),
                                size: 20),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                        ),
                      ),

                      // Section logo
                      Container(
                        height: 180,
                        alignment: Alignment.center,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            // Cercle pulsant
                            _buildPulsingCircle(
                              color: KTheme.turquoise.withOpacity(0.08),
                              size: 160,
                              delay: 0.2,
                            ),
                            // Cercle intérieur
                            Hero(
                              tag: 'background-circle',
                              child: Container(
                                width: 140,
                                height: 140,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      KTheme.cyan.withOpacity(0.2),
                                      KTheme.turquoise.withOpacity(0.15),
                                    ],
                                  ),
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: KTheme.turquoise.withOpacity(0.1),
                                      blurRadius: 20,
                                      spreadRadius: 5,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            // Logo
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0.95, end: 1.0),
                              duration: const Duration(seconds: 2),
                              curve: Curves.elasticOut,
                              builder: (context, value, child) {
                                return Transform.scale(
                                  scale: value,
                                  child: Hero(
                                    tag: 'bike-image',
                                    child: Image.asset(
                                'assets/LOGO_CARHABTI.png',
                                      width: 160,
                                      fit: BoxFit.contain,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),

                      // Titre
                      FadeTransition(
                        opacity: Tween<double>(begin: 0.0, end: 1.0).animate(
                          CurvedAnimation(
                            parent: _animationController,
                            curve: const Interval(0.3, 0.7,
                                curve: Curves.easeOut),
                          ),
                        ),
                        child: SlideTransition(
                          position: Tween<Offset>(
                            begin: const Offset(0, 0.3),
                            end: Offset.zero,
                          ).animate(CurvedAnimation(
                            parent: _animationController,
                            curve: const Interval(0.3, 0.7,
                                curve: Curves.easeOut),
                          )),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ShaderMask(
                                shaderCallback: (bounds) =>
                                    KTheme.ctaGradient.createShader(bounds),
                                child: Text(
                                  'Créer un compte',
                                  style: GoogleFonts.poppins(
                                    fontSize: 32,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "S'inscrire pour commencer !",
                                style: KTheme.bodyMD.copyWith(
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 32),

                      // ── Formulaire ──────────────────────────────────────────

                      // Nom complet
                      _buildAnimatedFormField(
                        delay: 0.4,
                        child: TextFormField(
                          controller: _nameController,
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            color: KTheme.textPrimary,
                          ),
                          decoration: _getInputDecoration(
                            'Nom complet',
                            Icons.person_outline_rounded,
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Veuillez entrer votre nom';
                            }
                            return null;
                          },
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Type de client
                      _buildAnimatedFormField(
                        delay: 0.45,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius:
                                BorderRadius.circular(KTheme.radiusMD),
                            border: Border.all(color: KTheme.border),
                            boxShadow: KTheme.elevationLow,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 2),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                isExpanded: true,
                                icon: const Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    color: KTheme.turquoise),
                                value: _clientType,
                                items: _clientTypes.map((String type) {
                                  return DropdownMenuItem<String>(
                                    value: type,
                                    child: Row(
                                      children: [
                                        Icon(
                                          type == 'propriétaire'
                                              ? Icons.person_rounded
                                              : Icons.business_rounded,
                                          color: KTheme.turquoise
                                              .withOpacity(0.7),
                                          size: 20,
                                        ),
                                        const SizedBox(width: 12),
                                        Text(
                                          type,
                                          style: GoogleFonts.poppins(
                                            color: KTheme.textPrimary,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                                onChanged: (String? newValue) {
                                  if (newValue != null) {
                                    setState(() => _clientType = newValue);
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Numéro de téléphone
                      _buildAnimatedFormField(
                        delay: 0.5,
                        child: IntlPhoneField(
                          controller: _phoneController,
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            color: KTheme.textPrimary,
                          ),
                          decoration: _getInputDecoration(
                            'Numéro de téléphone',
                            Icons.phone_outlined,
                          ),
                          initialCountryCode: 'TN',
                          onChanged: (phone) {
                            setState(
                                () => _phoneNumber = phone.completeNumber);
                          },
                          disableLengthCheck: false,
                          keyboardType: TextInputType.phone,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          dropdownTextStyle: GoogleFonts.poppins(
                            fontSize: 15,
                            color: KTheme.textPrimary,
                          ),
                          flagsButtonMargin:
                              const EdgeInsets.only(left: 8),
                          showDropdownIcon: false,
                          dropdownIconPosition: IconPosition.trailing,
                          invalidNumberMessage: 'Numéro invalide',
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Email
                      _buildAnimatedFormField(
                        delay: 0.55,
                        child: TextFormField(
                          controller: _emailController,
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            color: KTheme.textPrimary,
                          ),
                          decoration: _getInputDecoration(
                            'Adresse Email',
                            Icons.email_outlined,
                          ),
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Veuillez entrer votre email';
                            }
                            if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                .hasMatch(value)) {
                              return 'Veuillez entrer un email valide';
                            }
                            return null;
                          },
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Mot de passe
                      _buildAnimatedFormField(
                        delay: 0.6,
                        child: TextFormField(
                          controller: _passwordController,
                          obscureText: _obscurePassword,
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            color: KTheme.textPrimary,
                          ),
                          decoration: _getInputDecoration(
                            'Mot de passe',
                            Icons.lock_outline_rounded,
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscurePassword
                                    ? Icons.visibility_off_outlined
                                    : Icons.visibility_outlined,
                                color:
                                    KTheme.textPrimary.withOpacity(0.5),
                                size: 20,
                              ),
                              onPressed: () => setState(
                                  () => _obscurePassword = !_obscurePassword),
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Veuillez entrer un mot de passe';
                            }
                            if (value.length < 6) {
                              return 'Le mot de passe doit contenir au moins 6 caractères';
                            }
                            return null;
                          },
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Confirmer mot de passe
                      _buildAnimatedFormField(
                        delay: 0.65,
                        child: TextFormField(
                          controller: _confirmPasswordController,
                          obscureText: _obscureConfirmPassword,
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            color: KTheme.textPrimary,
                          ),
                          decoration: _getInputDecoration(
                            'Confirmer le mot de passe',
                            Icons.lock_outline_rounded,
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscureConfirmPassword
                                    ? Icons.visibility_off_outlined
                                    : Icons.visibility_outlined,
                                color:
                                    KTheme.textPrimary.withOpacity(0.5),
                                size: 20,
                              ),
                              onPressed: () => setState(() =>
                                  _obscureConfirmPassword =
                                      !_obscureConfirmPassword),
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Veuillez confirmer votre mot de passe';
                            }
                            if (value != _passwordController.text) {
                              return 'Les mots de passe ne correspondent pas';
                            }
                            return null;
                          },
                        ),
                      ),

                      const SizedBox(height: 36),

                      // Bouton d'inscription
                      _buildAnimatedFormField(
                        delay: 0.7,
                        child: KGradientButton(
                          label: 'Créer un compte',
                          icon: Icons.arrow_forward_rounded,
                          isLoading: _isProcessing,
                          onTap: _handleSignUp,
                        ),
                      ),

                      const SizedBox(height: 28),

                      // Lien pour se connecter
                      _buildAnimatedFormField(
                        delay: 0.75,
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Vous avez déjà un compte? ',
                                style: KTheme.bodyMD.copyWith(fontSize: 14),
                              ),
                              GestureDetector(
                                onTap: () => Navigator.pop(context),
                                child: Text(
                                  'Se connecter',
                                  style: GoogleFonts.poppins(
                                    color: KTheme.turquoise,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Politique de confidentialité
                      _buildAnimatedFormField(
                        delay: 0.8,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 24),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: KTheme.surfaceAlt.withOpacity(0.5),
                            borderRadius:
                                BorderRadius.circular(KTheme.radiusSM),
                            border: Border.all(color: KTheme.border),
                          ),
                          child: Text(
                            'En créant un compte, vous acceptez nos Conditions d\'utilisation et Politique de confidentialité',
                            style: KTheme.bodySM.copyWith(
                              color: KTheme.textLight,
                              height: 1.5,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Handlers ───────────────────────────────────────────────────────────────

  Future<void> _handleSignUp() async {
    if (!_formKey.currentState!.validate()) return;

    if (_phoneNumber.isEmpty) {
      _showErrorSnackBar('Veuillez entrer un numéro de téléphone valide');
      return;
    }

    setState(() => _isProcessing = true);

    try {
      final authResponse = await Supabase.instance.client.auth.signUp(
        email: _emailController.text,
        password: _passwordController.text,
      );

      if (authResponse.user == null) {
        throw "User not authenticated";
      }

      await Supabase.instance.client.from('client').insert({
        'id': authResponse.user!.id,
        'nom_client': _nameController.text,
        'type_client': _clientType,
        'telephone': _phoneNumber,
      });

      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation, secondaryAnimation) =>
              VehiculeInfoForm(),
          transitionsBuilder:
              (context, animation, secondaryAnimation, child) {
            return SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(1.0, 0.0),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: animation,
                curve: Curves.easeInOutQuart,
              )),
              child: child,
            );
          },
          transitionDuration: const Duration(milliseconds: 500),
        ),
      );
    } catch (e) {
      setState(() => _isProcessing = false);
      _showErrorSnackBar('Erreur: $e');
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.white),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: GoogleFonts.poppins(fontSize: 14),
              ),
            ),
          ],
        ),
        backgroundColor: KTheme.danger,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(KTheme.radiusSM),
        ),
        margin: const EdgeInsets.all(16),
        elevation: 4,
        duration: const Duration(seconds: 4),
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () =>
              ScaffoldMessenger.of(context).hideCurrentSnackBar(),
        ),
      ),
    );
  }

  // ── Widget helpers ─────────────────────────────────────────────────────────

  Widget _buildPulsingCircle(
      {required Color color, required double size, required double delay}) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.9, end: 1.1),
      duration: const Duration(seconds: 2),
      curve: Curves.easeInOut,
      builder: (context, value, child) {
        return AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return Transform.scale(
              scale: value * _animationController.value,
              child: Container(
                width: size * value,
                height: size * value,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAnimatedBubble({
    required double size,
    required Color color,
    required double delay,
  }) {
    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        final delayedAnim = CurvedAnimation(
          parent: _animationController,
          curve: Interval(delay, 1.0, curve: Curves.easeOut),
        );
        return Transform.scale(
          scale: delayedAnim.value,
          child: Opacity(
            opacity: delayedAnim.value * 0.8,
            child: Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAnimatedFormField({
    required double delay,
    required Widget child,
  }) {
    return SlideTransition(
      position: Tween<Offset>(
        begin: const Offset(0.2, 0),
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: _animationController,
        curve: Interval(delay, delay + 0.2, curve: Curves.easeOutQuint),
      )),
      child: FadeTransition(
        opacity: Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(
          parent: _animationController,
          curve: Interval(delay, delay + 0.2, curve: Curves.easeOut),
        )),
        child: child,
      ),
    );
  }

  InputDecoration _getInputDecoration(String hint, IconData icon,
      {Widget? suffixIcon}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: GoogleFonts.poppins(
        color: KTheme.textLight,
        fontSize: 14,
      ),
      prefixIcon: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Icon(icon, color: KTheme.turquoise.withOpacity(0.7), size: 20),
      ),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(vertical: 18),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        borderSide: BorderSide(color: KTheme.border, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        borderSide: BorderSide(color: KTheme.border, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        borderSide: const BorderSide(color: KTheme.turquoise, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        borderSide: const BorderSide(color: KTheme.danger, width: 1),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        borderSide: const BorderSide(color: KTheme.danger, width: 1.5),
      ),
      errorStyle: GoogleFonts.poppins(
        color: KTheme.danger,
        fontSize: 12,
      ),
      isDense: true,
      floatingLabelBehavior: FloatingLabelBehavior.never,
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(KTheme.radiusMD),
        borderSide: BorderSide(color: KTheme.border.withOpacity(0.5), width: 1),
      ),
    );
  }
}

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config/supabase_config.dart';
import '../models/piece_recommendation_model.dart';
import '../models/recommendation_history_model.dart';

/// Service for admin-side recommendation management.
class RecommendationAdminService {
  final SupabaseClient _client = SupabaseConfig.client;

  // ─────────────────────────────────────────────
  //  Fetch all recommendations (admin view)
  // ─────────────────────────────────────────────

  /// Get all recommendations with optional filtering, pagination, and sorting.
  /// Joins with responsables_techniciens for the responsable name.
  Future<List<PieceRecommendation>> getAllRecommendations({
    String? statut,
    String? priorite,
    String? typeAction,
    String? immatriculation,
    String? responsableId,
    String orderBy = 'updated_at',
    bool ascending = false,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      dynamic query = _client
          .from('piece_recommendations')
          .select('*, responsables_techniciens(nom_complet)');

      if (statut != null && statut.isNotEmpty) {
        query = query.eq('statut', statut);
      }
      if (priorite != null && priorite.isNotEmpty) {
        query = query.eq('priorite', priorite);
      }
      if (typeAction != null && typeAction.isNotEmpty) {
        query = query.eq('type_action', typeAction);
      }
      if (immatriculation != null && immatriculation.isNotEmpty) {
        query = query.ilike('immatriculation', '%$immatriculation%');
      }
      if (responsableId != null && responsableId.isNotEmpty) {
        query = query.eq('responsable_id', responsableId);
      }

      query = query.order(orderBy, ascending: ascending);
      query = query.range(offset, offset + limit - 1);

      final rows = await query;
      return List<Map<String, dynamic>>.from(rows)
          .map<PieceRecommendation>(PieceRecommendation.fromJson)
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error fetching recommendations: $e');
      }
      return [];
    }
  }

  /// Get a single recommendation by ID with joined responsable name.
  Future<PieceRecommendation?> getRecommendationById(String id) async {
    try {
      final row = await _client
          .from('piece_recommendations')
          .select('*, responsables_techniciens(nom_complet)')
          .eq('id', id)
          .maybeSingle();
      if (row == null) return null;
      return PieceRecommendation.fromJson(row);
    } catch (e) {
      if (kDebugMode) {
        print('Error fetching recommendation by ID: $e');
      }
      return null;
    }
  }

  // ─────────────────────────────────────────────
  //  Statistics
  // ─────────────────────────────────────────────

  /// Get counts by status for the stats cards.
  Future<Map<String, int>> getRecommendationStats() async {
    try {
      final all = await _client
          .from('piece_recommendations')
          .select('statut');
      final rows = List<Map<String, dynamic>>.from(all);
      final stats = <String, int>{
        'total': rows.length,
        'en_attente': 0,
        'en_cours': 0,
        'approuvee': 0,
        'rejetee': 0,
      };
      for (final row in rows) {
        final s = row['statut'] as String? ?? 'en_attente';
        stats[s] = (stats[s] ?? 0) + 1;
      }
      return stats;
    } catch (e) {
      if (kDebugMode) {
        print('Error fetching recommendation stats: $e');
      }
      return {'total': 0, 'en_attente': 0, 'en_cours': 0, 'approuvee': 0, 'rejetee': 0};
    }
  }

  // ─────────────────────────────────────────────
  //  Treatment actions
  // ─────────────────────────────────────────────

  /// Treat a recommendation: change status, add admin response, tags.
  Future<bool> traiterRecommendation({
    required String id,
    required String nouveauStatut,
    String? adminResponse,
    List<String>? exploitationTags,
  }) async {
    try {
      final adminId = _client.auth.currentUser?.id;
      if (adminId == null) return false;

      // Get current recommendation for history
      final current = await getRecommendationById(id);
      if (current == null) return false;
      final ancienStatut = current.statut;

      // Update the recommendation
      final updateData = <String, dynamic>{
        'statut': nouveauStatut,
        'treated_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      };
      if (adminResponse != null) {
        updateData['admin_response'] = adminResponse;
      }
      if (exploitationTags != null) {
        updateData['exploitation_tags'] = exploitationTags;
      }

      await _client
          .from('piece_recommendations')
          .update(updateData)
          .eq('id', id);

      // Create history entry
      try {
        await _client.from('recommendation_history').insert({
          'recommendation_id': id,
          'ancien_statut': ancienStatut,
          'nouveau_statut': nouveauStatut,
          'modifie_par': adminId,
          'role_modificateur': 'admin',
          'commentaire': adminResponse,
        });
      } catch (_) {
        // Silently ignore if table doesn't exist yet
      }

      return true;
    } catch (e) {
      if (kDebugMode) {
        print('Error treating recommendation: $e');
      }
      return false;
    }
  }

  // ─────────────────────────────────────────────
  //  History
  // ─────────────────────────────────────────────

  /// Get the full audit history for a recommendation.
  Future<List<RecommendationHistory>> getHistory(String recommendationId) async {
    try {
      final rows = await _client
          .from('recommendation_history')
          .select()
          .eq('recommendation_id', recommendationId)
          .order('created_at', ascending: false);
      return List<Map<String, dynamic>>.from(rows)
          .map<RecommendationHistory>(RecommendationHistory.fromJson)
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error fetching recommendation history: $e');
      }
      return [];
    }
  }

  // ─────────────────────────────────────────────
  //  Notifications (admin side)
  // ─────────────────────────────────────────────

  /// Get count of unread recommendation notifications.
  Future<int> getUnreadNotificationCount() async {
    try {
      final rows = await _client
          .from('admin_notifications')
          .select('id')
          .eq('type', 'nouvelle_recommandation')
          .eq('is_read', false);
      return (rows as List).length;
    } catch (_) {
      return 0;
    }
  }

  /// Mark all recommendation notifications as read.
  Future<void> markAllNotificationsRead() async {
    try {
      await _client
          .from('admin_notifications')
          .update({'is_read': true})
          .eq('type', 'nouvelle_recommandation')
          .eq('is_read', false);
    } catch (_) {
      // Ignore
    }
  }
}

import 'package:intl/intl.dart';

/// Notification model for admin alerts (new recommendations, etc.).
class AdminNotification {
  final String id;
  final String type;
  final String titre;
  final String? message;
  final String? referenceId;
  final String? referenceTable;
  final bool isRead;
  final DateTime createdAt;

  const AdminNotification({
    required this.id,
    required this.type,
    required this.titre,
    this.message,
    this.referenceId,
    this.referenceTable,
    this.isRead = false,
    required this.createdAt,
  });

  factory AdminNotification.fromJson(Map<String, dynamic> json) {
    return AdminNotification(
      id: json['id'] as String,
      type: json['type'] as String? ?? '',
      titre: json['titre'] as String? ?? '',
      message: json['message'] as String?,
      referenceId: json['reference_id'] as String?,
      referenceTable: json['reference_table'] as String?,
      isRead: json['is_read'] as bool? ?? false,
      createdAt: DateTime.parse(
        json['created_at'] as String? ?? DateTime.now().toIso8601String(),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'type': type,
      'titre': titre,
      'message': message,
      'reference_id': referenceId,
      'reference_table': referenceTable,
      'is_read': isRead,
    };
  }

  String get formattedDate {
    final formatter = DateFormat('dd/MM/yyyy HH:mm', 'fr_FR');
    return formatter.format(createdAt);
  }

  AdminNotification markAsRead() {
    return AdminNotification(
      id: id,
      type: type,
      titre: titre,
      message: message,
      referenceId: referenceId,
      referenceTable: referenceTable,
      isRead: true,
      createdAt: createdAt,
    );
  }
}

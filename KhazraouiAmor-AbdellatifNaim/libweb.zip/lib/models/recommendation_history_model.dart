import 'package:intl/intl.dart';

/// Audit trail entry for recommendation status changes.
class RecommendationHistory {
  final String id;
  final String recommendationId;
  final String? ancienStatut;
  final String nouveauStatut;
  final String modifiePar;
  final String roleModificateur; // 'responsable' or 'admin'
  final String? commentaire;
  final DateTime createdAt;

  const RecommendationHistory({
    required this.id,
    required this.recommendationId,
    this.ancienStatut,
    required this.nouveauStatut,
    required this.modifiePar,
    required this.roleModificateur,
    this.commentaire,
    required this.createdAt,
  });

  factory RecommendationHistory.fromJson(Map<String, dynamic> json) {
    return RecommendationHistory(
      id: json['id'] as String,
      recommendationId: json['recommendation_id'] as String,
      ancienStatut: json['ancien_statut'] as String?,
      nouveauStatut: json['nouveau_statut'] as String,
      modifiePar: json['modifie_par'] as String,
      roleModificateur: json['role_modificateur'] as String? ?? 'admin',
      commentaire: json['commentaire'] as String?,
      createdAt: DateTime.parse(
        json['created_at'] as String? ?? DateTime.now().toIso8601String(),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'recommendation_id': recommendationId,
      'ancien_statut': ancienStatut,
      'nouveau_statut': nouveauStatut,
      'modifie_par': modifiePar,
      'role_modificateur': roleModificateur,
      'commentaire': commentaire,
    };
  }

  String get formattedDate {
    final formatter = DateFormat('dd/MM/yyyy HH:mm', 'fr_FR');
    return formatter.format(createdAt);
  }

  String get statutLabel => switch (nouveauStatut) {
    'en_attente' => 'En attente',
    'en_cours' => 'En cours de traitement',
    'approuvee' => 'Approuvée',
    'rejetee' => 'Rejetée',
    _ => nouveauStatut,
  };

  String get roleLabel => switch (roleModificateur) {
    'responsable' => 'Responsable',
    'admin' => 'Administrateur',
    _ => roleModificateur,
  };
}

class PieceRecommendation {
  final String id;
  final String responsableId;
  final String? responsableNom; // Joined from responsables_techniciens
  final String immatriculation;
  final String pieceType;
  final int? pieceId;
  final String recommendation;
  final String statut; // en_attente, en_cours, approuvee, rejetee
  final String? typeAction; // correction_erreur, ajustement_modele, cas_usage, autre
  final String priorite; // haute, moyenne, basse
  final double? valeurPredite;
  final double? valeurSuggeree;
  final String? adminResponse;
  final List<String> exploitationTags;
  final String? treatedBy;
  final DateTime? treatedAt;
  final DateTime createdAt;
  final DateTime updatedAt;

  const PieceRecommendation({
    required this.id,
    required this.responsableId,
    this.responsableNom,
    required this.immatriculation,
    required this.pieceType,
    this.pieceId,
    required this.recommendation,
    this.statut = 'en_attente',
    this.typeAction,
    this.priorite = 'moyenne',
    this.valeurPredite,
    this.valeurSuggeree,
    this.adminResponse,
    this.exploitationTags = const [],
    this.treatedBy,
    this.treatedAt,
    required this.createdAt,
    required this.updatedAt,
  });

  factory PieceRecommendation.fromJson(Map<String, dynamic> json) {
    // Parse exploitation_tags from JSONB
    List<String> tags = [];
    if (json['exploitation_tags'] != null) {
      if (json['exploitation_tags'] is List) {
        tags = (json['exploitation_tags'] as List)
            .map((e) => e.toString())
            .toList();
      }
    }

    // Handle joined responsable name
    String? responsableNom;
    if (json['responsables_techniciens'] is Map) {
      responsableNom = json['responsables_techniciens']['nom_complet'] as String?;
    } else {
      responsableNom = json['responsable_nom'] as String?;
    }

    return PieceRecommendation(
      id: json['id'] as String,
      responsableId: json['responsable_id'] as String? ?? '',
      responsableNom: responsableNom,
      immatriculation: json['immatriculation'] as String? ?? '',
      pieceType: json['piece_type'] as String? ?? '',
      pieceId: json['piece_id'] as int?,
      recommendation: json['recommendation'] as String? ?? '',
      statut: json['statut'] as String? ?? 'en_attente',
      typeAction: json['type_action'] as String?,
      priorite: json['priorite'] as String? ?? 'moyenne',
      valeurPredite: (json['valeur_predite'] as num?)?.toDouble(),
      valeurSuggeree: (json['valeur_suggeree'] as num?)?.toDouble(),
      adminResponse: json['admin_response'] as String?,
      exploitationTags: tags,
      treatedAt: json['treated_at'] != null
          ? DateTime.parse(json['treated_at'] as String)
          : null,
      createdAt: DateTime.parse(
        json['created_at'] as String? ?? DateTime.now().toIso8601String(),
      ),
      updatedAt: DateTime.parse(
        json['updated_at'] as String? ?? DateTime.now().toIso8601String(),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'responsable_id': responsableId,
      'immatriculation': immatriculation,
      'piece_type': pieceType,
      'piece_id': pieceId,
      'recommendation': recommendation,
      'statut': statut,
      'type_action': typeAction,
      'priorite': priorite,
      'valeur_predite': valeurPredite,
      'valeur_suggeree': valeurSuggeree,
      'admin_response': adminResponse,
      'exploitation_tags': exploitationTags,
      'treated_at': treatedAt?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  PieceRecommendation copyWith({
    String? id,
    String? responsableId,
    String? responsableNom,
    String? immatriculation,
    String? pieceType,
    int? pieceId,
    String? recommendation,
    String? statut,
    String? typeAction,
    String? priorite,
    double? valeurPredite,
    double? valeurSuggeree,
    String? adminResponse,
    List<String>? exploitationTags,
    String? treatedBy,
    DateTime? treatedAt,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return PieceRecommendation(
      id: id ?? this.id,
      responsableId: responsableId ?? this.responsableId,
      responsableNom: responsableNom ?? this.responsableNom,
      immatriculation: immatriculation ?? this.immatriculation,
      pieceType: pieceType ?? this.pieceType,
      pieceId: pieceId ?? this.pieceId,
      recommendation: recommendation ?? this.recommendation,
      statut: statut ?? this.statut,
      typeAction: typeAction ?? this.typeAction,
      priorite: priorite ?? this.priorite,
      valeurPredite: valeurPredite ?? this.valeurPredite,
      valeurSuggeree: valeurSuggeree ?? this.valeurSuggeree,
      adminResponse: adminResponse ?? this.adminResponse,
      exploitationTags: exploitationTags ?? this.exploitationTags,
      treatedBy: treatedBy ?? this.treatedBy,
      treatedAt: treatedAt ?? this.treatedAt,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  /// Whether the responsable can still edit this recommendation
  bool get isEditable => statut == 'en_attente';

  /// Human-readable label for statut
  String get statutLabel => switch (statut) {
    'en_attente' => 'En attente',
    'en_cours' => 'En cours',
    'approuvee' => 'Approuvée',
    'rejetee' => 'Rejetée',
    _ => statut,
  };

  /// Human-readable label for typeAction
  String get typeActionLabel => switch (typeAction) {
    'correction_erreur' => 'Correction d\'erreur',
    'ajustement_modele' => 'Ajustement du modèle',
    'cas_usage' => 'Cas d\'usage / Limite',
    'autre' => 'Autre observation',
    _ => typeAction ?? '—',
  };

  /// Human-readable label for priorite
  String get prioriteLabel => switch (priorite) {
    'haute' => 'Haute',
    'moyenne' => 'Moyenne',
    'basse' => 'Basse',
    _ => priorite,
  };
}

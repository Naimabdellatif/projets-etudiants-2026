// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/piece_recommendation_model.dart';
import '../../models/recommendation_history_model.dart';
import '../../services/recommendation_admin_service.dart';
import '../../theme/Carhabti_tokens.dart';

// ─── Design Tokens (dark admin theme) ────────────────────────────────────────
class _T {
  static const Color bg         = Color.fromARGB(255, 254, 255, 255);
  static const Color surface    = Color.fromARGB(255, 246, 248, 255);
  static const Color surfaceAlt = Color.fromARGB(255, 215, 220, 233);
  static const Color border     = CarhabtiTokens.border;
  static const Color gold       = CarhabtiTokens.gold;
  static const Color success    = CarhabtiTokens.success;
  static const Color danger     = CarhabtiTokens.danger;
  static const Color warning    = CarhabtiTokens.warning;
  static const Color info       = CarhabtiTokens.info;
  static const Color textPri    = Color.fromARGB(255, 0, 2, 6);
  static const Color textSec    = Color.fromARGB(255, 0, 72, 254);
  static const Color textMuted  = CarhabtiTokens.textMuted;

  static const double radiusSm = 8;
  static const double radiusMd = 14;
}

class RecommendationsScreen extends StatefulWidget {
  const RecommendationsScreen({super.key});

  @override
  State<RecommendationsScreen> createState() => _RecommendationsScreenState();
}

class _RecommendationsScreenState extends State<RecommendationsScreen> {
  final _service = RecommendationAdminService();
  final _dateFmt = DateFormat('dd/MM/yyyy HH:mm', 'fr_FR');

  bool _loading = true;
  List<PieceRecommendation> _recommendations = [];
  Map<String, int> _stats = {};
  PieceRecommendation? _selected;
  List<RecommendationHistory> _selectedHistory = [];

  // Filters
  String _filterStatut = '';
  String _filterPriorite = '';
  String _filterTypeAction = '';
  String _searchQuery = '';

  // Treatment form
  final _responseCtrl = TextEditingController();
  String _treatmentStatut = '';
  final Set<String> _treatmentTags = {};
  bool _treating = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _responseCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final stats = await _service.getRecommendationStats();
    final recs = await _service.getAllRecommendations(
      statut: _filterStatut.isEmpty ? null : _filterStatut,
      priorite: _filterPriorite.isEmpty ? null : _filterPriorite,
      typeAction: _filterTypeAction.isEmpty ? null : _filterTypeAction,
      immatriculation: _searchQuery.isEmpty ? null : _searchQuery,
    );
    if (mounted) {
      setState(() {
        _stats = stats;
        _recommendations = recs;
        _loading = false;
      });
      // Mark notifications as read when the screen is opened
      _service.markAllNotificationsRead();
    }
  }

  Future<void> _selectRecommendation(PieceRecommendation rec) async {
    final history = await _service.getHistory(rec.id);
    if (mounted) {
      setState(() {
        _selected = rec;
        _selectedHistory = history;
        _responseCtrl.text = '';
        _treatmentStatut = '';
        _treatmentTags.clear();
      });
    }
  }

  Future<void> _treat() async {
    if (_treatmentStatut.isEmpty) return;
    if (_treatmentStatut == 'rejetee' && _responseCtrl.text.trim().length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Le motif de rejet doit contenir au moins 10 caractères.'),
        backgroundColor: _T.danger,
      ));
      return;
    }
    setState(() => _treating = true);
    final ok = await _service.traiterRecommendation(
      id: _selected!.id,
      nouveauStatut: _treatmentStatut,
      adminResponse: _responseCtrl.text.trim().isEmpty ? null : _responseCtrl.text.trim(),
      exploitationTags: _treatmentTags.toList(),
    );
    setState(() => _treating = false);
    if (ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Recommandation ${_treatmentStatut == 'approuvee' ? 'approuvée' : _treatmentStatut == 'rejetee' ? 'rejetée' : 'mise en cours'}.'),
        backgroundColor: _T.success,
      ));
      setState(() => _selected = null);
      _load();
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _T.bg,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          const SizedBox(height: 16),
          _buildStatCards(),
          const SizedBox(height: 16),
          _buildFilters(),
          const SizedBox(height: 8),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: _T.gold))
                : Row(
                    children: [
                      // Left: Table
                      Expanded(
                        flex: _selected != null ? 5 : 1,
                        child: _buildTable(),
                      ),
                      // Right: Detail panel
                      if (_selected != null) ...[
                        Container(width: 1, color: _T.border),
                        Expanded(flex: 4, child: _buildDetailPanel()),
                      ],
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  // ─── Header ───────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_T.gold.withOpacity(0.2), _T.gold.withOpacity(0.08)],
              ),
              borderRadius: BorderRadius.circular(_T.radiusMd),
            ),
            child: const Icon(Icons.recommend_rounded, color: _T.gold, size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Recommandations prédictives',
                    style: TextStyle(color: _T.textPri, fontSize: 22,
                        fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                const SizedBox(height: 4),
                Text('Analysez et traitez les retours des responsables sur les prédictions d\'usure.',
                    style: TextStyle(color: _T.textSec, fontSize: 13,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          // Refresh button
          _buildIconButton(Icons.refresh_rounded, 'Actualiser', _load),
        ],
      ),
    );
  }

  // ─── Stat Cards ───────────────────────────────────────────────────────────
  Widget _buildStatCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          _statCard('Total', _stats['total'] ?? 0, Icons.assignment_rounded,
              _T.info, ''),
          const SizedBox(width: 12),
          _statCard('En attente', _stats['en_attente'] ?? 0,
              Icons.hourglass_top_rounded, _T.warning, 'en_attente'),
          const SizedBox(width: 12),
          _statCard('En cours', _stats['en_cours'] ?? 0,
              Icons.sync_rounded, _T.info, 'en_cours'),
          const SizedBox(width: 12),
          _statCard('Approuvées', _stats['approuvee'] ?? 0,
              Icons.check_circle_rounded, _T.success, 'approuvee'),
          const SizedBox(width: 12),
          _statCard('Rejetées', _stats['rejetee'] ?? 0,
              Icons.cancel_rounded, _T.danger, 'rejetee'),
        ],
      ),
    );
  }

  Widget _statCard(String label, int count, IconData icon, Color color, String filterVal) {
    final isActive = _filterStatut == filterVal;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() => _filterStatut = isActive ? '' : filterVal);
          _load();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isActive ? color.withOpacity(0.12) : _T.surface,
            borderRadius: BorderRadius.circular(_T.radiusMd),
            border: Border.all(
              color: isActive ? color.withOpacity(0.5) : _T.border,
              width: isActive ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$count',
                        style: TextStyle(color: _T.textPri, fontSize: 20,
                            fontWeight: FontWeight.w800)),
                    Text(label,
                        style: TextStyle(color: _T.textSec, fontSize: 11,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Filters ──────────────────────────────────────────────────────────────
  Widget _buildFilters() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          // Search
          SizedBox(
            width: 260,
            child: TextField(
              style: const TextStyle(color: _T.textPri, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Rechercher par immatriculation…',
                hintStyle: const TextStyle(color: _T.textMuted, fontSize: 12),
                prefixIcon: const Icon(Icons.search_rounded, color: _T.textMuted, size: 18),
                filled: true,
                fillColor: _T.surface,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(_T.radiusSm),
                  borderSide: BorderSide(color: _T.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(_T.radiusSm),
                  borderSide: BorderSide(color: _T.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(_T.radiusSm),
                  borderSide: BorderSide(color: _T.gold, width: 1.5),
                ),
              ),
              onChanged: (v) {
                _searchQuery = v;
                _load();
              },
            ),
          ),
          const SizedBox(width: 12),
          _filterDropdown(
            label: 'Priorité',
            value: _filterPriorite,
            items: const {'': 'Toutes', 'haute': 'Haute', 'moyenne': 'Moyenne', 'basse': 'Basse'},
            onChanged: (v) { setState(() => _filterPriorite = v ?? ''); _load(); },
          ),
          const SizedBox(width: 12),
          _filterDropdown(
            label: 'Type',
            value: _filterTypeAction,
            items: const {
              '': 'Tous',
              'correction_erreur': 'Correction',
              'ajustement_modele': 'Ajustement',
              'cas_usage': 'Cas d\'usage',
              'autre': 'Autre',
            },
            onChanged: (v) { setState(() => _filterTypeAction = v ?? ''); _load(); },
          ),
          const Spacer(),
          Text('${_recommendations.length} résultat(s)',
              style: const TextStyle(color: _T.textSec, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _filterDropdown({
    required String label,
    required String value,
    required Map<String, String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: _T.surface,
        borderRadius: BorderRadius.circular(_T.radiusSm),
        border: Border.all(color: _T.border),
      ),
      child: DropdownButton<String>(
        value: value,
        underline: const SizedBox(),
        dropdownColor: _T.surface,
        style: const TextStyle(color: _T.textPri, fontSize: 12),
        icon: const Icon(Icons.keyboard_arrow_down_rounded, color: _T.textSec, size: 18),
        items: items.entries.map((e) => DropdownMenuItem(
          value: e.key,
          child: Text(e.value),
        )).toList(),
        onChanged: onChanged,
      ),
    );
  }

  // ─── Table ────────────────────────────────────────────────────────────────
  Widget _buildTable() {
    if (_recommendations.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.inbox_rounded, color: _T.textMuted, size: 48),
          const SizedBox(height: 12),
          Text('Aucune recommandation trouvée.',
              style: TextStyle(color: _T.textSec, fontSize: 14)),
        ]),
      );
    }

    return Container(
      margin: EdgeInsets.fromLTRB(24, 0, _selected != null ? 0 : 24, 24),
      decoration: BoxDecoration(
        color: _T.surface,
        borderRadius: BorderRadius.circular(_T.radiusMd),
        border: Border.all(color: _T.border),
      ),
      child: Column(
        children: [
          // Table header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: _T.surfaceAlt,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(_T.radiusMd)),
            ),
            child: Row(children: [
              _headerCell('Date', flex: 2),
              _headerCell('Responsable', flex: 2),
              _headerCell('Véhicule', flex: 2),
              _headerCell('Pièce', flex: 2),
              _headerCell('Type', flex: 2),
              _headerCell('Priorité', flex: 1),
              _headerCell('Statut', flex: 2),
            ]),
          ),
          Divider(height: 1, color: _T.border),
          // Table body
          Expanded(
            child: ListView.separated(
              itemCount: _recommendations.length,
              separatorBuilder: (_, __) => Divider(height: 1, color: _T.border),
              itemBuilder: (context, index) {
                final rec = _recommendations[index];
                final isSelected = _selected?.id == rec.id;
                // Highlight high priority items pending > 48h
                final isUrgent = rec.priorite == 'haute'
                    && rec.statut == 'en_attente'
                    && DateTime.now().difference(rec.updatedAt).inHours > 48;

                return GestureDetector(
                  onTap: () => _selectRecommendation(rec),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    color: isSelected
                        ? _T.gold.withOpacity(0.08)
                        : isUrgent
                            ? _T.danger.withOpacity(0.06)
                            : Colors.transparent,
                    child: Row(children: [
                      _bodyCell(_formatDate(rec.updatedAt), flex: 2),
                      _bodyCell(rec.responsableNom ?? '—', flex: 2),
                      _bodyCell(rec.immatriculation, flex: 2, bold: true),
                      _bodyCell(_pieceLabel(rec.pieceType), flex: 2),
                      _bodyCell(rec.typeActionLabel, flex: 2),
                      Expanded(flex: 1, child: _prioriteBadge(rec.priorite)),
                      Expanded(flex: 2, child: _statutBadge(rec.statut, rec.statutLabel)),
                    ]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _headerCell(String text, {int flex = 1}) {
    return Expanded(
      flex: flex,
      child: Text(text, style: const TextStyle(color: _T.textSec, fontSize: 11,
          fontWeight: FontWeight.w700, letterSpacing: 0.3)),
    );
  }

  Widget _bodyCell(String text, {int flex = 1, bool bold = false}) {
    return Expanded(
      flex: flex,
      child: Text(text,
          style: TextStyle(color: _T.textPri, fontSize: 12,
              fontWeight: bold ? FontWeight.w700 : FontWeight.w500),
          maxLines: 1, overflow: TextOverflow.ellipsis),
    );
  }

  Widget _prioriteBadge(String p) {
    final (color, label) = switch (p) {
      'haute'   => (_T.danger, '●'),
      'moyenne' => (_T.warning, '●'),
      'basse'   => (_T.success, '●'),
      _         => (_T.textMuted, '●'),
    };
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 8, height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 5),
      Text(p[0].toUpperCase() + p.substring(1),
          style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)),
    ]);
  }

  Widget _statutBadge(String statut, String label) {
    final (color, icon) = switch (statut) {
      'en_attente' => (_T.warning, Icons.hourglass_top_rounded),
      'en_cours'   => (_T.info, Icons.sync_rounded),
      'approuvee'  => (_T.success, Icons.check_circle_rounded),
      'rejetee'    => (_T.danger, Icons.cancel_rounded),
      _            => (_T.textMuted, Icons.help_outline_rounded),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 12),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(color: color, fontSize: 10,
            fontWeight: FontWeight.w700)),
      ]),
    );
  }

  // ─── Detail Panel ─────────────────────────────────────────────────────────
  Widget _buildDetailPanel() {
    final rec = _selected!;
    return Container(
      color: _T.surface,
      child: Column(
        children: [
          // Panel header
          Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 12, 16),
            decoration: BoxDecoration(
              color: _T.surfaceAlt,
              border: Border(bottom: BorderSide(color: _T.border)),
            ),
            child: Row(children: [
              const Icon(Icons.description_rounded, color: _T.gold, size: 18),
              const SizedBox(width: 10),
              const Expanded(child: Text('Détail de la recommandation',
                  style: TextStyle(color: _T.textPri, fontSize: 14,
                      fontWeight: FontWeight.w700))),
              _buildIconButton(Icons.close_rounded, 'Fermer',
                  () => setState(() => _selected = null)),
            ]),
          ),
          // Panel body
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Info grid
                _infoRow(Icons.calendar_today_rounded, 'Date',
                    _dateFmt.format(rec.updatedAt)),
                _infoRow(Icons.person_rounded, 'Responsable',
                    rec.responsableNom ?? rec.responsableId),
                _infoRow(Icons.directions_car_rounded, 'Véhicule',
                    rec.immatriculation),
                _infoRow(Icons.build_rounded, 'Pièce',
                    _pieceLabel(rec.pieceType)),
                if (rec.valeurPredite != null)
                  _infoRow(Icons.insights_rounded, 'Prédiction actuelle',
                      '${rec.valeurPredite!.toStringAsFixed(0)} %'),
                if (rec.valeurSuggeree != null)
                  _infoRow(Icons.edit_rounded, 'Valeur suggérée',
                      '${rec.valeurSuggeree!.toStringAsFixed(0)} %'),
                _infoRow(Icons.category_rounded, 'Type', rec.typeActionLabel),
                const SizedBox(height: 8),
                Row(children: [
                  const Text('Priorité : ',
                      style: TextStyle(color: _T.textSec, fontSize: 12)),
                  _prioriteBadge(rec.priorite),
                  const SizedBox(width: 16),
                  const Text('Statut : ',
                      style: TextStyle(color: _T.textSec, fontSize: 12)),
                  _statutBadge(rec.statut, rec.statutLabel),
                ]),

                const SizedBox(height: 20),
                // Recommendation text
                _sectionTitle('Texte de la recommandation'),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _T.surfaceAlt,
                    borderRadius: BorderRadius.circular(_T.radiusSm),
                    border: Border.all(color: _T.border),
                  ),
                  child: Text(rec.recommendation,
                      style: const TextStyle(color: _T.textPri, fontSize: 13,
                          height: 1.5)),
                ),

                // Existing admin response
                if (rec.adminResponse != null && rec.adminResponse!.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  _sectionTitle('Réponse précédente'),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _T.info.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(_T.radiusSm),
                      border: Border.all(color: _T.info.withOpacity(0.2)),
                    ),
                    child: Text(rec.adminResponse!,
                        style: const TextStyle(color: _T.textPri, fontSize: 13,
                            height: 1.5)),
                  ),
                ],

                // Treatment section
                if (rec.statut == 'en_attente' || rec.statut == 'en_cours') ...[
                  const SizedBox(height: 24),
                  _sectionTitle('Traitement'),
                  const SizedBox(height: 12),

                  // Admin response
                  TextField(
                    controller: _responseCtrl,
                    maxLines: 3,
                    style: const TextStyle(color: _T.textPri, fontSize: 13),
                    decoration: InputDecoration(
                      hintText: 'Votre réponse / commentaire…',
                      hintStyle: const TextStyle(color: _T.textMuted, fontSize: 12),
                      filled: true,
                      fillColor: _T.surfaceAlt,
                      contentPadding: const EdgeInsets.all(14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(_T.radiusSm),
                        borderSide: BorderSide(color: _T.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(_T.radiusSm),
                        borderSide: BorderSide(color: _T.border),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(_T.radiusSm),
                        borderSide: BorderSide(color: _T.gold, width: 1.5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Action buttons
                  Text('Action :', style: TextStyle(color: _T.textSec,
                      fontSize: 12, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Row(children: [
                    _actionChip('approuvee', 'Approuver',
                        Icons.check_circle_rounded, _T.success),
                    const SizedBox(width: 8),
                    _actionChip('rejetee', 'Rejeter',
                        Icons.cancel_rounded, _T.danger),
                    const SizedBox(width: 8),
                    _actionChip('en_cours', 'En cours',
                        Icons.sync_rounded, _T.info),
                  ]),
                  const SizedBox(height: 14),

                  // Tags
                  Text('Tags d\'exploitation :', style: TextStyle(color: _T.textSec,
                      fontSize: 12, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    _tagChip('correction_integree', 'Correction intégrée'),
                    _tagChip('anomalie_documentee', 'Anomalie documentée'),
                    _tagChip('reentrainement', 'Nécessite réentraînement'),
                    _tagChip('derive_biais', 'Dérive/biais détecté'),
                  ]),
                  const SizedBox(height: 20),

                  // Submit button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _treatmentStatut.isEmpty || _treating ? null : _treat,
                      icon: _treating
                          ? const SizedBox(width: 16, height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                          : const Icon(Icons.save_rounded, size: 18),
                      label: Text(_treating ? 'Enregistrement…' : 'Enregistrer le traitement'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _T.gold,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(_T.radiusSm),
                        ),
                        textStyle: const TextStyle(fontWeight: FontWeight.w700,
                            fontSize: 13),
                      ),
                    ),
                  ),
                ],

                // History timeline
                if (_selectedHistory.isNotEmpty) ...[
                  const SizedBox(height: 28),
                  _sectionTitle('Historique'),
                  const SizedBox(height: 12),
                  ..._selectedHistory.map(_historyTile),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionChip(String value, String label, IconData icon, Color color) {
    final selected = _treatmentStatut == value;
    return GestureDetector(
      onTap: () => setState(() => _treatmentStatut = selected ? '' : value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.15) : _T.surfaceAlt,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? color : _T.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: selected ? color : _T.textMuted, size: 14),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(
            color: selected ? color : _T.textSec,
            fontSize: 11, fontWeight: FontWeight.w700,
          )),
        ]),
      ),
    );
  }

  Widget _tagChip(String value, String label) {
    final selected = _treatmentTags.contains(value);
    return GestureDetector(
      onTap: () => setState(() {
        if (selected) {
          _treatmentTags.remove(value);
        } else {
          _treatmentTags.add(value);
        }
      }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? _T.gold.withOpacity(0.12) : _T.surfaceAlt,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? _T.gold.withOpacity(0.5) : _T.border,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(selected ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded,
              color: selected ? _T.gold : _T.textMuted, size: 14),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(
            color: selected ? _T.gold : _T.textSec,
            fontSize: 11, fontWeight: FontWeight.w600,
          )),
        ]),
      ),
    );
  }

  Widget _historyTile(RecommendationHistory h) {
    final (color, icon) = switch (h.nouveauStatut) {
      'en_attente' => (_T.warning, Icons.hourglass_top_rounded),
      'en_cours'   => (_T.info, Icons.sync_rounded),
      'approuvee'  => (_T.success, Icons.check_circle_rounded),
      'rejetee'    => (_T.danger, Icons.cancel_rounded),
      _            => (_T.textMuted, Icons.history_rounded),
    };

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 14),
            ),
            Container(width: 2, height: 24, color: _T.border),
          ]),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Text(h.statutLabel,
                      style: TextStyle(color: color, fontSize: 12,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(width: 8),
                  Text('par ${h.roleLabel}',
                      style: const TextStyle(color: _T.textMuted, fontSize: 10)),
                ]),
                Text(h.formattedDate,
                    style: const TextStyle(color: _T.textMuted, fontSize: 10)),
                if (h.commentaire != null && h.commentaire!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(h.commentaire!,
                        style: const TextStyle(color: _T.textSec, fontSize: 11,
                            height: 1.4)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────
  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Icon(icon, color: _T.textMuted, size: 14),
        const SizedBox(width: 8),
        SizedBox(
          width: 120,
          child: Text(label,
              style: const TextStyle(color: _T.textSec, fontSize: 12,
                  fontWeight: FontWeight.w600)),
        ),
        Expanded(child: Text(value,
            style: const TextStyle(color: _T.textPri, fontSize: 12,
                fontWeight: FontWeight.w500))),
      ]),
    );
  }

  Widget _sectionTitle(String text) {
    return Row(children: [
      Container(width: 3, height: 16,
          decoration: BoxDecoration(
            color: _T.gold,
            borderRadius: BorderRadius.circular(2),
          )),
      const SizedBox(width: 8),
      Text(text, style: const TextStyle(color: _T.textPri, fontSize: 13,
          fontWeight: FontWeight.w700)),
    ]);
  }

  Widget _buildIconButton(IconData icon, String tooltip, VoidCallback onTap) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _T.surfaceAlt,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _T.border),
          ),
          child: Icon(icon, color: _T.textSec, size: 18),
        ),
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) {
      if (diff.inHours == 0) return 'Il y a ${diff.inMinutes} min';
      return 'Il y a ${diff.inHours}h';
    }
    if (diff.inDays == 1) return 'Hier';
    if (diff.inDays < 7) return 'Il y a ${diff.inDays}j';
    return _dateFmt.format(dt);
  }

  String _pieceLabel(String type) {
    final label = type.replaceAll('_', ' ');
    return label[0].toUpperCase() + label.substring(1);
  }
}

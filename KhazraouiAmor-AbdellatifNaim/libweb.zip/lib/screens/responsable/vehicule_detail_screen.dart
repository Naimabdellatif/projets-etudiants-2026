// ignore_for_file: unused_field, deprecated_member_use

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/piece_recommendation_model.dart';
import '../../models/piece_validation_model.dart';
import '../../models/vehicule_analytics_models.dart';
import '../../services/responsable_technicien_service.dart';

// ─── Design Tokens ────────────────────────────────────────────────────────────
class _DS {
  // Backgrounds
  static const Color background    = Color(0xFFFAFBFF);
  static const Color surface       = Color(0xFFFFFFFF);
  static const Color surfaceAlt    = Color(0xFFF4F6FC);
  static const Color surfaceBlue   = Color(0xFFEEF2FF);
  static const Color surfaceMint   = Color(0xFFEDFAF5);

  // Brand gold
  static const Color gold          = Color(0xFFE6A817);
  static const Color goldLight     = Color(0xFFFFF4D9);
  static const Color goldDeep      = Color(0xFFD4920E);

  // Accent blue
  static const Color accent        = Color(0xFF5B8DEF);
  static const Color accentLight   = Color(0xFFE8EFFF);
  static const Color accentDeep    = Color(0xFF3A6FD8);

  // Semantic
  static const Color success       = Color(0xFF34C78A);
  static const Color successLight  = Color(0xFFDFF5EC);
  static const Color warning       = Color(0xFFF5A623);
  static const Color warningLight  = Color(0xFFFFF3DC);
  static const Color danger        = Color(0xFFEF5B5B);
  static const Color dangerLight   = Color(0xFFFFEAEA);
  static const Color purple        = Color(0xFF9B59B6);
  static const Color purpleLight   = Color(0xFFF3E8FF);

  // Text
  static const Color textPri   = Color(0xFF1A1F36);
  static const Color textSec   = Color(0xFF6B7280);
  static const Color textMute  = Color(0xFFB0B7C3);
  static const Color border    = Color(0xFFE8ECF4);

  // Radius
  static const double radiusSm = 10;
  static const double radiusMd = 16;
  static const double radiusLg = 22;
  static const double radiusXl = 28;

  // Shadows
  static List<BoxShadow> shadowSm = [
    const BoxShadow(color: Color(0x0A1A1F36), blurRadius: 8, offset: Offset(0, 2)),
  ];
  static List<BoxShadow> shadowMd = [
    const BoxShadow(color: Color(0x141A1F36), blurRadius: 16, offset: Offset(0, 4)),
    const BoxShadow(color: Color(0x061A1F36), blurRadius: 4,  offset: Offset(0, 1)),
  ];
  static List<BoxShadow> shadowGold = [
    const BoxShadow(color: Color(0x35E6A817), blurRadius: 18, offset: Offset(0, 4)),
  ];
  static List<BoxShadow> shadowAccent = [
    const BoxShadow(color: Color(0x255B8DEF), blurRadius: 16, offset: Offset(0, 4)),
  ];
}

// ─── Écran principal ──────────────────────────────────────────────────────────
class VehiculeDetailScreen extends StatefulWidget {
  final Map<String, dynamic> vehiculeData;
  const VehiculeDetailScreen({super.key, required this.vehiculeData});

  @override
  State<VehiculeDetailScreen> createState() => _VehiculeDetailScreenState();
}

class _VehiculeDetailScreenState extends State<VehiculeDetailScreen>
    with TickerProviderStateMixin {
  final _service = ResponsableTechnicienService();
  DateFormat get _dateFmt => DateFormat('dd/MM/yyyy', 'fr_FR');

  final _types = const [
    'batterie', 'freins', 'pneus', 'embrayage',
    'courroie', 'amortisseurs', 'vidange',
  ];

  late TabController _tabCtrl;
  late AnimationController _fadeCtrl;
  late AnimationController _slideCtrl;
  late AnimationController _headerCtrl;
  late Animation<double>   _fadeAnim;
  late Animation<Offset>   _slideAnim;
  late Animation<double>   _headerScale;

  bool _loading = true;
  VehiculeComplet? _data;
  final Map<String, TextEditingController> _controllers = {};
  final Map<String, PieceRecommendation?> _recs = {};
  final Map<String, String> _typeActions = {};
  final Map<String, String> _priorites = {};
  final Map<String, TextEditingController> _valeurSuggereeCtrl = {};

  String get _immat => widget.vehiculeData['immatriculation'] as String;

  @override
  void initState() {
    super.initState();
    _tabCtrl  = TabController(length: 4, vsync: this);
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _slideCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _headerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim   = CurvedAnimation(parent: _fadeCtrl,  curve: Curves.easeOut);
    _slideAnim  = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOutCubic));
    _headerScale = Tween<double>(begin: 0.92, end: 1.0)
        .animate(CurvedAnimation(parent: _headerCtrl, curve: Curves.elasticOut));

    for (final t in _types) {
      _controllers[t] = TextEditingController();
      _valeurSuggereeCtrl[t] = TextEditingController();
      _priorites[t] = 'moyenne';
    }
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _fadeCtrl.reset();
    _slideCtrl.reset();
    _headerCtrl.reset();
    final complet = await _service.getVehiculeComplet(_immat);
    final all     = await _service.getAllRecommendations(_immat);
    for (final t in _types) {
      PieceRecommendation? rec;
      for (final item in all) { if (item.pieceType == t) { rec = item; break; } }
      _recs[t] = rec;
      _controllers[t]!.text = rec?.recommendation ?? '';
      _typeActions[t] = rec?.typeAction ?? '';
      _priorites[t] = rec?.priorite ?? 'moyenne';
      _valeurSuggereeCtrl[t]!.text = rec?.valeurSuggeree != null
          ? rec!.valeurSuggeree!.toStringAsFixed(0)
          : '';
    }
    if (mounted) {
      setState(() { _data = complet; _loading = false; });
      _headerCtrl.forward();
      Future.delayed(const Duration(milliseconds: 120), () {
        _fadeCtrl.forward();
        _slideCtrl.forward();
      });
    }
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _fadeCtrl.dispose();
    _slideCtrl.dispose();
    _headerCtrl.dispose();
    for (final c in _controllers.values) {
      c.dispose();
    }
    for (final c in _valeurSuggereeCtrl.values) {
      c.dispose();
    }
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final v = _data?.voiture;
    return Scaffold(
      backgroundColor: _DS.background,
      appBar: _buildAppBar(v),
      body: _loading
          ? _buildLoader()
          : _data == null
              ? _buildEmptyState('Véhicule introuvable dans la base.')
              : FadeTransition(
                  opacity: _fadeAnim,
                  child: SlideTransition(
                    position: _slideAnim,
                    child: TabBarView(
                      controller: _tabCtrl,
                      children: [
                        _buildSyntheseTab(),
                        _buildVoitureTab(),
                        _buildFacteurTab(),
                        _buildPiecesTab(),
                      ],
                    ),
                  ),
                ),
    );
  }

  // ─── AppBar modernisée ────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar(Map<String, dynamic>? v) {
    final marque = v != null ? '${v['marque']} ${v['modele']}' : _immat;
    final detail = v != null ? '${v['moteur']} · ${v['annee']}' : '';

    return PreferredSize(
      preferredSize: const Size.fromHeight(kToolbarHeight + 56 + 48),
      child: Container(
        decoration: const BoxDecoration(
          color: _DS.surface,
          boxShadow: [
            BoxShadow(color: Color(0x08000000), blurRadius: 12, offset: Offset(0, 3)),
          ],
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: kToolbarHeight + 20,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _CircleIconBtn(
                        icon: Icons.arrow_back_ios_new_rounded,
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      const SizedBox(width: 12),
                      // Icône véhicule avec dégradé
                      ScaleTransition(
                        scale: _headerScale,
                        child: Container(
                          width: 48, height: 48,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFFFFE49A), Color(0xFFE6A817)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: _DS.shadowGold,
                          ),
                          child: const Center(
                            child: Text('🚗', style: TextStyle(fontSize: 22)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(marque,
                                style: const TextStyle(
                                  color: _DS.textPri, fontSize: 17,
                                  fontWeight: FontWeight.w800, letterSpacing: -0.4,
                                ),
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                            if (detail.isNotEmpty) ...[
                              const SizedBox(height: 2),
                              Text(detail,
                                  style: const TextStyle(
                                      color: _DS.textSec, fontSize: 12,
                                      fontWeight: FontWeight.w500)),
                            ],
                          ],
                        ),
                      ),
                      _ImmatBadge(immat: _immat),
                    ],
                  ),
                ),
              ),
              Divider(height: 0, thickness: 1, color: _DS.border),
              _buildTabBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: _DS.surface,
      height: 48,
      child: TabBar(
        controller: _tabCtrl,
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFFE49A), Color(0xFFFFF4D9)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(color: Color(0x25E6A817), blurRadius: 6, offset: Offset(0, 2)),
          ],
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: _DS.border,
        labelColor: _DS.goldDeep,
        unselectedLabelColor: _DS.textSec,
        labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
        tabs: const [
          Tab(text: '✨ Synthèse'),
          Tab(text: '🚙 Véhicule'),
          Tab(text: '📊 Facteurs'),
          Tab(text: '🔧 Pièces'),
        ],
      ),
    );
  }

  // ─── Loader modernisé ────────────────────────────────────────────────────
  Widget _buildLoader() => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 72, height: 72,
        decoration: BoxDecoration(
          color: _DS.goldLight,
          shape: BoxShape.circle,
          boxShadow: _DS.shadowGold,
        ),
        child: const Center(child: Text('⚙️', style: TextStyle(fontSize: 32))),
      ),
      const SizedBox(height: 20),
      const Text('Chargement des données…',
          style: TextStyle(color: _DS.textSec, fontSize: 14, fontWeight: FontWeight.w500)),
      const SizedBox(height: 8),
      SizedBox(
        width: 140,
        child: LinearProgressIndicator(
          backgroundColor: _DS.goldLight,
          color: _DS.gold,
          borderRadius: BorderRadius.circular(100),
          minHeight: 3,
        ),
      ),
    ]),
  );

  Widget _buildEmptyState(String msg) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: _DS.surfaceAlt,
          shape: BoxShape.circle,
          boxShadow: _DS.shadowSm,
        ),
        child: const Text('🔍', style: TextStyle(fontSize: 42)),
      ),
      const SizedBox(height: 16),
      Text(msg, style: const TextStyle(color: _DS.textSec, fontSize: 14),
          textAlign: TextAlign.center),
    ]),
  );

  // ═══════════════════════════════════════════════════════════════════════════
  // ONGLET 1 — SYNTHÈSE
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildSyntheseTab() {
    final d       = _data!;
    final metrics = predictionMetricsFromMap(d.prediction);
    final events  = maintenanceEventsFromMap(d.maintenanceDates);
    final client  = d.client;

    return RefreshIndicator(
      color: _DS.gold,
      backgroundColor: _DS.surface,
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
        children: [
          // Hero Banner
          _buildHeroBanner(d),
          const SizedBox(height: 16),

          // Client
          if (client != null) ...[
            _KCard(
              emoji: '👤',
              iconBg: _DS.accentLight, iconColor: _DS.accent,
              title: 'Informations Client',
              child: Wrap(spacing: 10, runSpacing: 8, children: [
                _KBadge(label: _str(client['nom_client']), icon: Icons.badge_rounded, color: _DS.accent),
                _KBadge(label: _str(client['telephone']), icon: Icons.phone_rounded, color: _DS.success),
              ]),
            ),
            const SizedBox(height: 14),
          ],

          // Prédictions
          _KCard(
            emoji: '📈',
            iconBg: _DS.goldLight, iconColor: _DS.gold,
            title: 'Prédictions d\'usure',
            subtitle: _predictionSubtitle(d.prediction),
            child: metrics.isEmpty
                ? _noData('Aucune prédiction enregistrée pour ce véhicule.')
                : Column(children: [
                    SizedBox(
                      height: 260,
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 4, bottom: 6),
                                child: Text('📉 Évolution',
                                    style: TextStyle(color: _DS.textSec, fontSize: 11,
                                        fontWeight: FontWeight.w700, letterSpacing: 0.3)),
                              ),
                              Expanded(child: _wearLineChart(metrics)),
                            ]),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 4, bottom: 6),
                                child: Text('🕸️ Radar global',
                                    style: TextStyle(color: _DS.textSec, fontSize: 11,
                                        fontWeight: FontWeight.w700, letterSpacing: 0.3)),
                              ),
                              Expanded(child: _radarChart(metrics)),
                            ]),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    ...metrics.map(_wearBar),
                    const SizedBox(height: 8),
                    _legendRow(),
                  ]),
          ),
          const SizedBox(height: 14),

          // Historique entretiens
          _KCard(
            emoji: '🗓️',
            iconBg: _DS.accentLight, iconColor: _DS.accent,
            title: 'Historique des entretiens',
            child: events.every((e) => e.date == null)
                ? _noData('Aucune date d\'entretien enregistrée.')
                : Column(children: [
                    SizedBox(height: 200, child: _maintenanceBarChart(events)),
                    const SizedBox(height: 16),
                    ...events.map(_maintenanceTile),
                  ]),
          ),
        ],
      ),
    );
  }

  // ─── Hero Banner ─────────────────────────────────────────────────────────
  Widget _buildHeroBanner(VehiculeComplet d) {
    final p = d.prediction;
    final avgWear = p == null ? null : _calcAvgWear(p);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFFFAED), Color(0xFFEEF6FF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(_DS.radiusLg),
        border: Border.all(color: _DS.border),
        boxShadow: _DS.shadowMd,
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFFE49A), Color(0xFFF5C842)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(_DS.radiusMd),
            boxShadow: _DS.shadowGold,
          ),
          child: const Text('🚘', style: TextStyle(fontSize: 36)),
        ),
        const SizedBox(width: 16),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_immat,
                style: const TextStyle(color: _DS.gold, fontSize: 13,
                    fontWeight: FontWeight.w800, letterSpacing: 1.2)),
            const SizedBox(height: 4),
            // ignore: unnecessary_null_comparison
            Text(d.voiture != null
                    ? '${d.voiture['marque']} ${d.voiture['modele']}'
                    : 'Véhicule',
                style: const TextStyle(color: _DS.textPri, fontSize: 18,
                    fontWeight: FontWeight.w800, letterSpacing: -0.4)),
            if (avgWear != null) ...[
              const SizedBox(height: 8),
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _wearColor(avgWear).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _wearColor(avgWear).withOpacity(0.4)),
                  ),
                  child: Text('Usure moyenne : ${avgWear.toStringAsFixed(0)}%',
                      style: TextStyle(color: _wearColor(avgWear),
                          fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ]),
            ],
          ],
        )),
      ]),
    );
  }

  double _calcAvgWear(Map<String, dynamic> p) {
    final keys = ['battery_health','brake_wear','tire_wear','clutch_wear',
                  'belt_risk','ShockAbsorber_Wear','oil_change'];
    double sum = 0; int count = 0;
    for (final k in keys) {
      final v = (p[k] as num?)?.toDouble();
      if (v != null) { sum += v; count++; }
    }
    return count > 0 ? sum / count : 0;
  }

  String? _predictionSubtitle(Map<String, dynamic>? p) {
    if (p == null) return null;
    final next = p['next_replacement_date'];
    if (next == null) return null;
    try {
      return '📅 Prochain remplacement : ${_dateFmt.format(DateTime.parse(next.toString()))}';
    } catch (_) { return null; }
  }

  // ─── Line Chart d'évolution d'usure ──────────────────────────────────────
  Widget _wearLineChart(List<PredictionMetric> metrics) {
    final spots    = <FlSpot>[];
    final spotsOld = <FlSpot>[];
    for (int i = 0; i < metrics.length; i++) {
      spots.add(FlSpot(i.toDouble(), metrics[i].value.clamp(0, 100)));
      spotsOld.add(FlSpot(i.toDouble(), (metrics[i].value * 0.75).clamp(0.0, 100.0)));
    }
    return LineChart(
      LineChartData(
        minY: 0, maxY: 105,
        clipData: FlClipData.all(),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (_) =>
              FlLine(color: _DS.border, strokeWidth: 1, dashArray: [4, 4]),
        ),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          topTitles:   const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true, interval: 1,
              getTitlesWidget: (v, _) {
                final i = v.toInt();
                if (i < 0 || i >= metrics.length) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    metrics[i].label.split(' ').first.substring(0, 3),
                    style: TextStyle(color: _DS.textMute, fontSize: 8,
                        fontWeight: FontWeight.w600),
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true, reservedSize: 28, interval: 25,
              getTitlesWidget: (v, _) => Text(
                '${v.toInt()}',
                style: TextStyle(color: _DS.textMute, fontSize: 8),
              ),
            ),
          ),
        ),
        lineBarsData: [
          LineChartBarData(
            spots: spotsOld,
            isCurved: true,
            color: _DS.textMute.withOpacity(0.5),
            barWidth: 1.5,
            dotData: FlDotData(show: false),
            belowBarData: BarAreaData(show: false),
            dashArray: [4, 4],
          ),
          LineChartBarData(
            spots: spots,
            isCurved: true,
            gradient: LinearGradient(colors: [_DS.success, _DS.warning, _DS.danger]),
            barWidth: 2.5,
            isStrokeCapRound: true,
            dotData: FlDotData(
              show: true,
              getDotPainter: (spot, _, __, ___) {
                final col = _wearColor(spot.y);
                return FlDotCirclePainter(
                  radius: 3.5, color: col,
                  strokeWidth: 1.5, strokeColor: _DS.surface,
                );
              },
            ),
            belowBarData: BarAreaData(
              show: true,
              gradient: LinearGradient(
                colors: [
                  _DS.gold.withValues(alpha: 0.15),
                  _DS.danger.withValues(alpha: 0.05),
                ],
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
              ),
            ),
          ),
        ],
        lineTouchData: LineTouchData(
          touchTooltipData: LineTouchTooltipData(
            tooltipBgColor: _DS.surface,
            tooltipBorder: BorderSide(color: _DS.border),
            getTooltipItems: (spots) => spots.map((s) {
              if (s.barIndex == 0) return null;
              final m = metrics[s.x.toInt()];
              return LineTooltipItem(
                '${m.label.split(' ').first}\n${s.y.toStringAsFixed(0)} %',
                TextStyle(color: _wearColor(s.y), fontSize: 10,
                    fontWeight: FontWeight.w700),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  // ─── Radar Chart ─────────────────────────────────────────────────────────
  Widget _radarChart(List<PredictionMetric> metrics) {
    return RadarChart(
      RadarChartData(
        radarShape: RadarShape.polygon,
        radarBorderData: BorderSide(color: _DS.border, width: 1.5),
        gridBorderData: BorderSide(color: _DS.border, width: 0.6),
        tickBorderData: BorderSide.none,
        tickCount: 4,
        ticksTextStyle: TextStyle(color: _DS.textMute, fontSize: 9),
        titleTextStyle: TextStyle(color: _DS.textSec, fontSize: 10,
            fontWeight: FontWeight.w600),
        titlePositionPercentageOffset: 0.18,
        getTitle: (index, _) {
          if (index >= metrics.length) return RadarChartTitle(text: '');
          final short = metrics[index].label.split(' ').first;
          return RadarChartTitle(text: short, angle: 0);
        },
        dataSets: [
          RadarDataSet(
            fillColor: _DS.gold.withOpacity(0.18),
            borderColor: _DS.gold,
            borderWidth: 2,
            entryRadius: 4,
            dataEntries: metrics
                .map((m) => RadarEntry(value: m.value.clamp(0, 100)))
                .toList(),
          ),
        ],
      ),
    );
  }

  // ─── Barre d'usure ────────────────────────────────────────────────────────
  Widget _wearBar(PredictionMetric m) {
    final color = _wearColor(m.value);
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(m.label,
              style: const TextStyle(color: _DS.textPri, fontSize: 13,
                  fontWeight: FontWeight.w500))),
          Text('${m.value.toStringAsFixed(0)} %',
              style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 14)),
          const SizedBox(width: 8),
          _RiskChip(value: m.value),
        ]),
        const SizedBox(height: 8),
        Stack(children: [
          Container(
            height: 8,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(100),
            ),
          ),
          FractionallySizedBox(
            widthFactor: (m.value.clamp(0, 100)) / 100,
            child: Container(
              height: 8,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [color.withOpacity(0.7), color]),
                borderRadius: BorderRadius.circular(100),
              ),
            ),
          ),
        ]),
      ]),
    );
  }

  // ─── Bar chart entretiens ─────────────────────────────────────────────────
  Widget _maintenanceBarChart(List<MaintenanceEvent> events) {
    final withDates = events.where((e) => e.date != null).toList();
    if (withDates.isEmpty) return const SizedBox.shrink();
    final now    = DateTime.now();
    final maxDays = withDates
        .map((e) => now.difference(e.date!).inDays.toDouble())
        .fold<double>(0, (a, b) => a > b ? a : b)
        .clamp(1, 3650);

    return BarChart(BarChartData(
      maxY: maxDays * 1.15,
      borderData: FlBorderData(show: false),
      gridData: FlGridData(
        show: true, drawVerticalLine: false,
        getDrawingHorizontalLine: (_) =>
            FlLine(color: _DS.border, strokeWidth: 1, dashArray: [4, 4]),
      ),
      titlesData: FlTitlesData(
        topTitles:   const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true, reservedSize: 38,
            getTitlesWidget: (v, _) => Text('${v.toInt()}j',
                style: const TextStyle(color: _DS.textMute, fontSize: 10)),
          ),
        ),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            getTitlesWidget: (v, _) {
              final i = v.toInt();
              if (i < 0 || i >= withDates.length) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(withDates[i].label.substring(0, 3),
                    style: const TextStyle(color: _DS.textSec, fontSize: 10,
                        fontWeight: FontWeight.w600)),
              );
            },
          ),
        ),
      ),
      barGroups: List.generate(withDates.length, (i) {
        final days = now.difference(withDates[i].date!).inDays.toDouble();
        return BarChartGroupData(x: i, barRods: [
          BarChartRodData(
            toY: days,
            gradient: LinearGradient(
              colors: [_DS.accent.withOpacity(0.6), _DS.accent],
              begin: Alignment.bottomCenter, end: Alignment.topCenter,
            ),
            width: 16,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
          ),
        ]);
      }),
    ));
  }

  Widget _maintenanceTile(MaintenanceEvent e) {
    final rel     = e.date != null ? _relativeDate(e.date!) : 'Non renseigné';
    final hasDate = e.date != null;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: hasDate ? _DS.successLight : _DS.surfaceAlt,
        borderRadius: BorderRadius.circular(_DS.radiusMd),
        border: Border.all(
            color: hasDate ? _DS.success.withOpacity(0.3) : _DS.border),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: hasDate ? _DS.success.withOpacity(0.15) : _DS.border,
            shape: BoxShape.circle,
          ),
          child: Icon(
            hasDate ? Icons.check_rounded : Icons.help_outline_rounded,
            color: hasDate ? _DS.success : _DS.textMute, size: 16,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(e.label, style: const TextStyle(color: _DS.textPri,
                fontWeight: FontWeight.w600, fontSize: 13)),
            const SizedBox(height: 2),
            Text(rel, style: const TextStyle(color: _DS.textSec, fontSize: 12)),
          ],
        )),
        if (e.date != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: _DS.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _DS.border),
            ),
            child: Text(_dateFmt.format(e.date!),
                style: const TextStyle(color: _DS.textSec, fontSize: 11,
                    fontWeight: FontWeight.w500)),
          ),
      ]),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ONGLET 2 — VÉHICULE
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildVoitureTab() {
    final v = _data!.voiture;
    final items = voitureFieldLabels.entries
        .map((e) => _DetailItem(e.value, _formatVoitureValue(e.key, v[e.key])))
        .toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
      children: [
        _KCard(
          emoji: '📋',
          iconBg: _DS.accentLight, iconColor: _DS.accent,
          title: 'Fiche technique du véhicule',
          child: _detailGrid(items),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ONGLET 3 — FACTEURS
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildFacteurTab() {
    final f = _data!.facteur;
    if (f == null) return _buildEmptyState('Aucune fiche facteur d\'usure pour ce véhicule.');
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
      children: [
        // Info banner
        Container(
          padding: const EdgeInsets.all(16),
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [_DS.accentLight, _DS.surfaceBlue],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(_DS.radiusMd),
            border: Border.all(color: Color(0x335B8DEF)),
          ),
          child: Row(children: [
            const Text('💡', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 12),
            const Expanded(child: Text(
              'Ces données décrivent le contexte d\'utilisation '
              'et l\'état des pièces au moment de l\'analyse prédictive.',
              style: TextStyle(color: _DS.accent, fontSize: 13, height: 1.4,
                  fontWeight: FontWeight.w500),
            )),
          ]),
        ),
        ...facteurSections.map((section) {
          final fields = section.fields
              .map((field) =>
                  _DetailItem(field.label, _formatFacteurValue(f[field.key])))
              .toList();
          return Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: _KCard(
              emoji: '⚙️',
              iconBg: _DS.goldLight, iconColor: _DS.gold,
              title: section.title,
              child: _detailGrid(fields),
            ),
          );
        }),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ONGLET 4 — PIÈCES
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildPiecesTab() {
    final immat = _immat;
    final prediction = _data?.prediction;
    final predictionValues = <String, double?>{
      'batterie':        (prediction?['battery_health'] as num?)?.toDouble(),
      'freins':          (prediction?['brake_wear'] as num?)?.toDouble(),
      'pneus':           (prediction?['tire_wear'] as num?)?.toDouble(),
      'embrayage':       (prediction?['clutch_wear'] as num?)?.toDouble(),
      'courroie':        (prediction?['belt_risk'] as num?)?.toDouble(),
      'amortisseurs':    (prediction?['ShockAbsorber_Wear'] as num?)?.toDouble(),
      'huile_moteur':    (prediction?['oil_change'] as num?)?.toDouble(),
    };

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
      children: _types.asMap().entries.map((entry) {
        final t = entry.value;
        return _AnimatedPieceCard(
          index: entry.key,
          type:  t,
          immat: immat,
          rec:   _recs[t],
          ctrl:  _controllers[t]!,
          predictionValue: predictionValues[t],
          typeAction: _typeActions[t] ?? '',
          priorite: _priorites[t] ?? 'moyenne',
          valeurSuggereeCtrl: _valeurSuggereeCtrl[t]!,
          onTypeActionChanged: (v) => setState(() => _typeActions[t] = v),
          onPrioriteChanged:   (v) => setState(() => _priorites[t] = v),
          onSave:     () => _saveRecommendation(immat, t),
          onValidate: () => _validateReplacement(immat, t),
        );
      }).toList(),
    );
  }

  // ─── Actions ──────────────────────────────────────────────────────────────
  Future<void> _saveRecommendation(String immat, String t) async {
    final text = _controllers[t]!.text.trim();
    if (text.length < 10) {
      _showSnack('La recommandation doit contenir au moins 10 caractères',
          icon: Icons.warning_rounded, color: _DS.warning);
      return;
    }
    final typeAction = _typeActions[t];
    if (typeAction == null || typeAction.isEmpty) {
      _showSnack('Veuillez sélectionner un type d\'action',
          icon: Icons.warning_rounded, color: _DS.warning);
      return;
    }
    final priorite = _priorites[t] ?? 'moyenne';
    double? valeurSuggeree;
    final sugText = _valeurSuggereeCtrl[t]!.text.trim();
    if (sugText.isNotEmpty) valeurSuggeree = double.tryParse(sugText);
    if (typeAction == 'correction_erreur' && valeurSuggeree == null) {
      _showSnack('La valeur corrigée est obligatoire pour une correction',
          icon: Icons.warning_rounded, color: _DS.warning);
      return;
    }

    final prediction = _data?.prediction;
    final predMap = <String, String>{
      'batterie': 'battery_health', 'freins': 'brake_wear',
      'pneus': 'tire_wear', 'embrayage': 'clutch_wear',
      'courroie': 'belt_risk', 'amortisseurs': 'ShockAbsorber_Wear',
      'huile_moteur': 'oil_change',
    };
    final valeurPredite = predMap.containsKey(t)
        ? (prediction?[predMap[t]] as num?)?.toDouble()
        : null;

    try {
      final me = await _service.getMyProfile();
      if (me == null) {
        if (mounted) {
          _showSnack('Impossible de récupérer votre profil. Reconnectez-vous.',
              icon: Icons.error_rounded, color: _DS.danger);
        }
        return;
      }
      await _service.upsertRecommendation(PieceRecommendation(
        id: _recs[t]?.id ?? '',
        responsableId: me.id,
        immatriculation: immat,
        pieceType: t,
        recommendation: text,
        typeAction: typeAction,
        priorite: priorite,
        valeurPredite: valeurPredite,
        valeurSuggeree: valeurSuggeree,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ));
      await _load();
      if (mounted) {
        _showSnack('Recommandation enregistrée',
            icon: Icons.check_circle_rounded, color: _DS.success);
      }
    } catch (e) {
      if (mounted) {
        _showSnack('Erreur lors de l\'enregistrement : $e',
            icon: Icons.error_rounded, color: _DS.danger);
      }
    }
  }

  Future<void> _validateReplacement(String immat, String t) async {
    final me = await _service.getMyProfile();
    if (me == null) return;
    await _service.validerRemplacement(PieceValidation(
      id: '',
      responsableId: me.id,
      immatriculation: immat,
      pieceType: t,
      dateRemplacement: DateTime.now(),
      note: _controllers[t]!.text.trim().isEmpty ? null : _controllers[t]!.text.trim(),
    ));
    if (mounted) {
      _showSnack('Remplacement validé ✓',
          icon: Icons.verified_rounded, color: _DS.gold);
    }
  }

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: _DS.surface,
      elevation: 8,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(_DS.radiusMd)),
      content: Row(children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: _DS.textPri,
            fontWeight: FontWeight.w600, fontSize: 13))),
      ]),
    ));
  }

  // ─── Helpers layout ───────────────────────────────────────────────────────
  Widget _detailGrid(List<_DetailItem> items) {
    return LayoutBuilder(builder: (context, constraints) {
      final twoCols = constraints.maxWidth > 500;
      if (!twoCols) {
        return Column(children: items.map((i) => _detailRow(i.label, i.value)).toList());
      }
      return Wrap(
        spacing: 16, runSpacing: 0,
        children: items.map((i) => SizedBox(
          width: (constraints.maxWidth - 16) / 2,
          child: _detailRow(i.label, i.value),
        )).toList(),
      );
    });
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: _DS.textMute, fontSize: 11,
            fontWeight: FontWeight.w600, letterSpacing: 0.3)),
        const SizedBox(height: 2),
        Text(value, style: const TextStyle(color: _DS.textPri, fontSize: 13,
            fontWeight: FontWeight.w600)),
      ]),
    );
  }

  Widget _noData(String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 16),
    child: Row(children: [
      const Text('📭', style: TextStyle(fontSize: 18)),
      const SizedBox(width: 10),
      Expanded(child: Text(text,
          style: const TextStyle(color: _DS.textMute, fontSize: 13))),
    ]),
  );

  Widget _legendRow() {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      _legendDot('Faible',   _DS.success),
      const SizedBox(width: 20),
      _legendDot('Modéré',   _DS.warning),
      const SizedBox(width: 20),
      _legendDot('Élevé',    _DS.danger),
      const SizedBox(width: 20),
      _legendDot('Tendance', _DS.textMute),
    ]);
  }

  Widget _legendDot(String label, Color color) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 9, height: 9,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 6),
      Text(label, style: const TextStyle(color: _DS.textSec, fontSize: 11,
          fontWeight: FontWeight.w500)),
    ]);
  }

  Color _wearColor(double v) {
    if (v < 40) return _DS.success;
    if (v < 70) return _DS.warning;
    return _DS.danger;
  }

  String _str(dynamic v) =>
      v == null || v.toString().isEmpty ? '—' : v.toString();

  String _formatVoitureValue(String key, dynamic v) {
    if (v == null) return '—';
    if (key == 'total_km' || key == 'daily_km') return _formatKm(v);
    if (key == 'poids') return '${(v as num).toStringAsFixed(0)} kg';
    return v.toString();
  }

  String _formatFacteurValue(dynamic v) {
    if (v == null || v.toString().isEmpty) return '—';
    if (v is String && v.contains('-') && v.length >= 8) {
      try { return _dateFmt.format(DateTime.parse(v)); } catch (_) {}
    }
    if (v is num && v is double) return v.toStringAsFixed(1);
    return v.toString();
  }

  String _formatKm(dynamic v) {
    if (v == null) return '—';
    final n = (v as num).toDouble();
    return '${NumberFormat.decimalPattern('fr').format(n)} km';
  }

  String _relativeDate(DateTime d) {
    final days = DateTime.now().difference(d).inDays;
    if (days == 0) return 'Aujourd\'hui';
    if (days == 1) return 'Il y a 1 jour';
    if (days < 30) return 'Il y a $days jours';
    if (days < 365) return 'Il y a ${(days / 30).floor()} mois';
    return 'Il y a ${(days / 365).floor()} an(s)';
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SOUS-WIDGETS
// ═══════════════════════════════════════════════════════════════════════════════

/// Badge immatriculation modernisé
class _ImmatBadge extends StatelessWidget {
  final String immat;
  const _ImmatBadge({required this.immat});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFFF4D9), Color(0xFFFFE49A)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Color(0x66E6A817)),
        boxShadow: [
          BoxShadow(color: Color(0x20E6A817), blurRadius: 8, offset: Offset(0, 2)),
        ],
      ),
      child: Text(immat, style: const TextStyle(
          color: _DS.goldDeep, fontSize: 12,
          fontWeight: FontWeight.w800, letterSpacing: 1.0)),
    );
  }
}

/// Carte section moderne avec emoji
class _KCard extends StatelessWidget {
  final String   emoji;
  final Color    iconBg;
  final Color    iconColor;
  final String   title;
  final String?  subtitle;
  final Widget   child;

  const _KCard({
    required this.emoji, required this.iconBg, required this.iconColor,
    required this.title, required this.child, this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _DS.surface,
        borderRadius: BorderRadius.circular(_DS.radiusMd),
        border: Border.all(color: _DS.border),
        boxShadow: _DS.shadowMd,
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(emoji, style: const TextStyle(fontSize: 18)),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: _DS.textPri, fontSize: 15,
                  fontWeight: FontWeight.w700)),
              if (subtitle != null) ...[
                const SizedBox(height: 3),
                Text(subtitle!, style: const TextStyle(color: _DS.gold,
                    fontSize: 11, fontWeight: FontWeight.w600)),
              ],
            ],
          )),
        ]),
        const SizedBox(height: 16),
        Container(
          height: 1,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0x00E8ECF4), Color(0xFFE8ECF4), Color(0x00E8ECF4)],
            ),
          ),
        ),
        const SizedBox(height: 16),
        child,
      ]),
    );
  }
}

/// Badge info coloré
class _KBadge extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  const _KBadge({required this.label, required this.icon, this.color = _DS.accent});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color.withOpacity(0.09),
        borderRadius: BorderRadius.circular(_DS.radiusSm),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 14, color: color),
        const SizedBox(width: 6),
        Text(label, style: TextStyle(color: _DS.textPri, fontSize: 12,
            fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

/// Chip de risque
class _RiskChip extends StatelessWidget {
  final double value;
  const _RiskChip({required this.value});

  @override
  Widget build(BuildContext context) {
    final (label, emoji, color, bg) = switch (value) {
      < 40 => ('OK',        '✅', _DS.success, _DS.successLight),
      < 70 => ('Surveiller','⚠️', _DS.warning, _DS.warningLight),
      _    => ('Critique',  '🚨', _DS.danger,  _DS.dangerLight),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(emoji, style: const TextStyle(fontSize: 10)),
        const SizedBox(width: 3),
        Text(label, style: TextStyle(color: color, fontSize: 10,
            fontWeight: FontWeight.w800)),
      ]),
    );
  }
}

/// Bouton icône circulaire
class _CircleIconBtn extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleIconBtn({required this.icon, required this.onTap});

  @override
  State<_CircleIconBtn> createState() => _CircleIconBtnState();
}

class _CircleIconBtnState extends State<_CircleIconBtn>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween<double>(begin: 1, end: 0.88)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
            color: _DS.surfaceAlt,
            shape: BoxShape.circle,
            border: Border.all(color: _DS.border),
            boxShadow: _DS.shadowSm,
          ),
          child: Icon(widget.icon, size: 16, color: _DS.textPri),
        ),
      ),
    );
  }
}

// ─── Carte pièce avec animation échelonnée + enrichissements UX ──────────────
class _AnimatedPieceCard extends StatefulWidget {
  final int index;
  final String type;
  final String immat;
  final PieceRecommendation? rec;
  final TextEditingController ctrl;
  final double? predictionValue;
  final String typeAction;
  final String priorite;
  final TextEditingController valeurSuggereeCtrl;
  final ValueChanged<String> onTypeActionChanged;
  final ValueChanged<String> onPrioriteChanged;
  final VoidCallback onSave;
  final VoidCallback onValidate;

  const _AnimatedPieceCard({
    required this.index, required this.type, required this.immat,
    required this.rec, required this.ctrl,
    this.predictionValue,
    required this.typeAction, required this.priorite,
    required this.valeurSuggereeCtrl,
    required this.onTypeActionChanged, required this.onPrioriteChanged,
    required this.onSave, required this.onValidate,
  });

  @override
  State<_AnimatedPieceCard> createState() => _AnimatedPieceCardState();
}

class _AnimatedPieceCardState extends State<_AnimatedPieceCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>   _fade;
  late Animation<Offset>   _slide;
  bool _expanded = false;

  static const Map<String, String> _pieceEmojis = {
    'batterie':        '🔋',
    'freins':          '🛑',
    'pneus':           '⚫',
    'embrayage':       '⚙️',
    'courroie':        '🔄',
    'amortisseurs':    '📉',
    'vidange':    '🛢️',
  };

  static const Map<String, IconData> _pieceIcons = {
    'batterie':        Icons.battery_charging_full_rounded,
    'freins':          Icons.speed_rounded,
    'pneus':           Icons.tire_repair_rounded,
    'embrayage':       Icons.settings_rounded,
    'courroie':        Icons.loop_rounded,
    'amortisseurs':    Icons.compress_rounded,
    'vidange':    Icons.opacity_rounded,
  };

  static const _typeActionOptions = {
    'correction_erreur': 'Correction d\'erreur',
    'ajustement_modele': 'Ajustement du modèle',
    'cas_usage':         'Cas d\'usage / Limite',
    'autre':             'Autre observation',
  };

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 500));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.07), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    Future.delayed(Duration(milliseconds: 70 * widget.index), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Color _statutColor(String s) => switch (s) {
    'en_attente' => _DS.warning,
    'en_cours'   => _DS.accent,
    'approuvee'  => _DS.success,
    'rejetee'    => _DS.danger,
    _            => _DS.textMute,
  };

  IconData _statutIcon(String s) => switch (s) {
    'en_attente' => Icons.hourglass_top_rounded,
    'en_cours'   => Icons.sync_rounded,
    'approuvee'  => Icons.check_circle_rounded,
    'rejetee'    => Icons.cancel_rounded,
    _            => Icons.help_outline_rounded,
  };

  Color _prioriteColor(String p) => switch (p) {
    'haute'   => _DS.danger,
    'moyenne' => _DS.warning,
    'basse'   => _DS.success,
    _         => _DS.textMute,
  };

  @override
  Widget build(BuildContext context) {
    final emoji    = _pieceEmojis[widget.type] ?? '🔧';
    // ignore: unused_local_variable
    final iconData = _pieceIcons[widget.type] ?? Icons.build_rounded;
    final hasRec   = widget.rec != null;
    final isEditable = widget.rec?.isEditable ?? true;
    final statut = widget.rec?.statut ?? '';

    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Container(
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            color: _DS.surface,
            borderRadius: BorderRadius.circular(_DS.radiusMd),
            border: Border.all(
              color: hasRec ? Color(0x4DE6A817) : _DS.border,
              width: hasRec ? 1.5 : 1,
            ),
            boxShadow: hasRec ? _DS.shadowMd : _DS.shadowSm,
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // ── En-tête cliquable ─────────────────────────────────────────
            GestureDetector(
              onTap: () => setState(() => _expanded = !_expanded),
              child: Container(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                decoration: BoxDecoration(
                  gradient: hasRec
                      ? const LinearGradient(
                          colors: [Color(0xFFFFFAED), Color(0xFFFFF4D9)],
                          begin: Alignment.topLeft, end: Alignment.bottomRight)
                      : null,
                  color: hasRec ? null : _DS.surfaceAlt,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(_DS.radiusMd),
                    bottom: _expanded ? Radius.zero : Radius.circular(_DS.radiusMd),
                  ),
                ),
                child: Row(children: [
                  // Emoji icon
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      color: hasRec ? Color(0x30E6A817) : _DS.border,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Text(emoji, style: const TextStyle(fontSize: 20)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.type.replaceAll('_', ' ').toUpperCase(),
                        style: TextStyle(
                          color: hasRec ? _DS.goldDeep : _DS.textSec,
                          fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 0.8,
                        ),
                      ),
                      if (widget.predictionValue != null) ...[
                        const SizedBox(height: 2),
                        Text(
                          '${widget.predictionValue!.toStringAsFixed(0)}% d\'usure',
                          style: TextStyle(
                            color: _usureColor(widget.predictionValue!),
                            fontSize: 11, fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ],
                  )),
                  if (hasRec) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _statutColor(statut).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _statutColor(statut).withOpacity(0.3)),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(_statutIcon(statut), color: _statutColor(statut), size: 12),
                        const SizedBox(width: 4),
                        Text(widget.rec!.statutLabel,
                            style: TextStyle(color: _statutColor(statut),
                                fontSize: 10, fontWeight: FontWeight.w700)),
                      ]),
                    ),
                    const SizedBox(width: 8),
                  ],
                  AnimatedRotation(
                    turns: _expanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 250),
                    child: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: hasRec ? _DS.gold : _DS.textMute,
                      size: 22,
                    ),
                  ),
                ]),
              ),
            ),

            // ── Corps expandable ──────────────────────────────────────────
            AnimatedCrossFade(
              firstChild: const SizedBox.shrink(),
              secondChild: _buildCardBody(isEditable, statut),
              crossFadeState: _expanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              duration: const Duration(milliseconds: 280),
              sizeCurve: Curves.easeInOutCubic,
            ),
          ]),
        ),
      ),
    );
  }

  Color _usureColor(double v) {
    if (v < 40) return _DS.success;
    if (v < 70) return _DS.warning;
    return _DS.danger;
  }

  Widget _buildCardBody(bool isEditable, String statut) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Divider(color: _DS.border, height: 16),

        // Prediction badge
        if (widget.predictionValue != null) ...[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_DS.surfaceAlt, _DS.surfaceBlue],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _DS.border),
            ),
            child: Row(children: [
              const Text('📊', style: TextStyle(fontSize: 14)),
              const SizedBox(width: 8),
              Text('Prédiction actuelle : ',
                  style: const TextStyle(color: _DS.textSec, fontSize: 12)),
              Text('${widget.predictionValue!.toStringAsFixed(0)} %',
                  style: TextStyle(
                    color: _usureColor(widget.predictionValue!),
                    fontSize: 13, fontWeight: FontWeight.w800,
                  )),
              const Spacer(),
              _RiskChip(value: widget.predictionValue!),
            ]),
          ),
          const SizedBox(height: 12),
        ],

        // Type d'action dropdown
        _buildDropdownField(
          label: 'Type d\'action',
          value: _typeActionOptions.containsKey(widget.typeAction)
              ? widget.typeAction
              : null,
          items: _typeActionOptions,
          onChanged: isEditable ? (v) => widget.onTypeActionChanged(v ?? '') : null,
        ),
        const SizedBox(height: 12),

        // Priorité selector
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Priorité',
              style: TextStyle(color: _DS.textSec, fontSize: 12,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Row(children: [
            ...['haute', 'moyenne', 'basse'].map((p) {
              final selected = widget.priorite == p;
              final color    = _prioriteColor(p);
              final label    = p[0].toUpperCase() + p.substring(1);
              final emoji    = switch(p) {
                'haute'   => '🔴',
                'moyenne' => '🟡',
                _         => '🟢',
              };
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: isEditable ? () => widget.onPrioriteChanged(p) : null,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.easeOut,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: selected ? color.withOpacity(0.12) : _DS.surfaceAlt,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: selected ? color : _DS.border,
                        width: selected ? 1.5 : 1,
                      ),
                      boxShadow: selected ? [
                        BoxShadow(color: color.withOpacity(0.2),
                            blurRadius: 6, offset: const Offset(0, 2)),
                      ] : [],
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(emoji, style: const TextStyle(fontSize: 11)),
                      const SizedBox(width: 5),
                      Text(label, style: TextStyle(
                        color: selected ? color : _DS.textSec,
                        fontSize: 12, fontWeight: FontWeight.w700,
                      )),
                    ]),
                  ),
                ),
              );
            }),
          ]),
        ]),
        const SizedBox(height: 12),

        // Recommendation text field
        TextField(
          controller: widget.ctrl,
          maxLines: 3,
          enabled: isEditable,
          style: const TextStyle(color: _DS.textPri, fontSize: 13, height: 1.5),
          decoration: InputDecoration(
            hintText: '✏️  Entrez une recommandation (min. 10 caractères)…',
            hintStyle: const TextStyle(color: _DS.textMute, fontSize: 12),
            filled: true,
            fillColor: isEditable ? _DS.surfaceAlt : const Color(0xFFF9FAFB),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _DS.border)),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _DS.border)),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _DS.gold, width: 2)),
          ),
        ),
        const SizedBox(height: 10),

        // Valeur suggérée
        TextField(
          controller: widget.valeurSuggereeCtrl,
          enabled: isEditable,
          keyboardType: TextInputType.number,
          style: const TextStyle(color: _DS.textPri, fontSize: 13),
          decoration: InputDecoration(
            hintText: '🔢  Valeur corrigée suggérée',
            hintStyle: const TextStyle(color: _DS.textMute, fontSize: 12),
            filled: true,
            fillColor: isEditable ? _DS.surfaceAlt : const Color(0xFFF9FAFB),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            suffixText: '%',
            suffixStyle: const TextStyle(color: _DS.textSec, fontSize: 13),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _DS.border)),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _DS.border)),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _DS.gold, width: 2)),
          ),
        ),
        const SizedBox(height: 14),

        // Admin response
        if (widget.rec?.adminResponse != null && widget.rec!.adminResponse!.isNotEmpty) ...[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFE8EFFF), Color(0xFFEEF2FF)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _DS.accent.withOpacity(0.3)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Text('💬', style: TextStyle(fontSize: 13)),
                const SizedBox(width: 6),
                const Text('Réponse de l\'administrateur',
                    style: TextStyle(color: _DS.accent, fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ]),
              const SizedBox(height: 6),
              Text(widget.rec!.adminResponse!,
                  style: const TextStyle(color: _DS.textPri, fontSize: 12,
                      height: 1.5)),
            ]),
          ),
          const SizedBox(height: 14),
        ],

        // Buttons
        if (isEditable)
          Row(children: [
            Expanded(child: _KButton(
              label: 'Enregistrer',
              icon:  Icons.save_outlined,
              emoji: '💾',
              onTap: widget.onSave,
              filled: false,
            )),
            const SizedBox(width: 10),
            Expanded(child: _KButton(
              label: 'Valider',
              icon:  Icons.verified_rounded,
              emoji: '✅',
              onTap: widget.onValidate,
              filled: true,
            )),
          ])
        else
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _DS.surfaceAlt,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _DS.border),
            ),
            child: Row(children: [
              const Text('🔒', style: TextStyle(fontSize: 14)),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'Recommandation ${widget.rec?.statutLabel.toLowerCase() ?? ""} — modification verrouillée',
                style: const TextStyle(color: _DS.textMute, fontSize: 11,
                    fontWeight: FontWeight.w500),
              )),
            ]),
          ),
      ]),
    );
  }

  Widget _buildDropdownField({
    required String label,
    String? value,
    required Map<String, String> items,
    ValueChanged<String?>? onChanged,
  }) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: _DS.textSec, fontSize: 12,
          fontWeight: FontWeight.w600)),
      const SizedBox(height: 5),
      Container(
        decoration: BoxDecoration(
          color: _DS.surfaceAlt,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _DS.border),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: DropdownButton<String>(
          value: value,
          hint: const Text('Sélectionnez…',
              style: TextStyle(color: _DS.textMute, fontSize: 12)),
          isExpanded: true,
          underline: const SizedBox(),
          style: const TextStyle(color: _DS.textPri, fontSize: 13),
          dropdownColor: _DS.surface,
          icon: const Icon(Icons.keyboard_arrow_down_rounded,
              color: _DS.textSec, size: 22),
          items: items.entries.map((e) => DropdownMenuItem(
            value: e.key,
            child: Text(e.value),
          )).toList(),
          onChanged: onChanged,
        ),
      ),
    ]);
  }
}

class _KButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final String emoji;
  final VoidCallback onTap;
  final bool filled;
  const _KButton({
    required this.label, required this.icon, required this.emoji,
    required this.onTap, this.filled = false,
  });

  @override
  State<_KButton> createState() => _KButtonState();
}

class _KButtonState extends State<_KButton> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 100));
    _scale = Tween<double>(begin: 1, end: 0.93)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 14),
          decoration: BoxDecoration(
            gradient: widget.filled
                ? const LinearGradient(
                    colors: [Color(0xFFFFD060), Color(0xFFE6A817)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  )
                : null,
            color: widget.filled ? null : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: widget.filled ? _DS.gold : _DS.border,
              width: widget.filled ? 0 : 1.5,
            ),
            boxShadow: widget.filled ? _DS.shadowGold : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(widget.emoji, style: const TextStyle(fontSize: 14)),
              const SizedBox(width: 6),
              Flexible(child: Text(widget.label,
                  style: TextStyle(
                    color: widget.filled
                        ? const Color(0xFF1A1200)
                        : _DS.textSec,
                    fontSize: 12, fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1, overflow: TextOverflow.ellipsis)),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
class _DetailItem {
  final String label;
  final String value;
  const _DetailItem(this.label, this.value);
}